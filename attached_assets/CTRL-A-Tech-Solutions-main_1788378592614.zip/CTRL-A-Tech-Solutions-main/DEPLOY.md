# Deploying ctrla-web to CentOS

This is a pnpm monorepo. In production **one Node process** (`artifacts/api-server`)
serves both the REST API and the prebuilt, prerendered frontend
(`artifacts/ctrla-website/dist/public`) — see `app.ts`. nginx sits in front for
TLS + compression and reverse-proxies everything to that process. There is no
separate static-file webroot to keep in sync.

This box already hosts other client projects (ctrlawms-fe, oms360, SyncCommAI,
b1pluscloud, aartigreentech, ...), each with its own PM2 app and its own
dedicated GitHub Actions runner install. Follow the same per-project pattern
here rather than sharing another project's runner or PM2 process.

## 0. One-time decisions

- **Port**: pick a `PORT` for `ctrla-api` that nothing else on the box is
  using. Check first:
  ```bash
  pm2 list
  ss -tlnp | grep LISTEN
  ```
  Put whatever you pick in `/etc/ctrla-web/api-server.env` (below) as `PORT=`.
- **Domain**: not decided yet. Everything below works fine on the bare IP —
  nginx `server_name` is `_` (catches all) and `PUBLIC_URL` can stay unset
  (sitemap/canonical URLs fall back to a placeholder default). Come back and
  do §6 (TLS) once DNS is pointed at this box.

## 1. Prerequisites on the box

```bash
node --version   # need >=20; install via nvm or dnf module if missing
corepack enable && corepack prepare pnpm@9 --activate   # or: npm i -g pnpm
pm2 --version    # npm i -g pm2 if missing
nginx -v         # dnf install nginx if missing
```

## 2. Clone the repo

```bash
sudo mkdir -p /opt/ctrla-web
sudo chown $USER:$USER /opt/ctrla-web
git clone git@github.com:CtrlA-Tech-Solutions-Private-Limited/ctrla-web.git /opt/ctrla-web
cd /opt/ctrla-web
```

## 3. Create the persistent secrets file

This lives **outside** the git checkout on purpose: `actions/checkout` runs
`git clean -ffdx` on every deploy by default, which would silently delete an
in-repo `.env` file.

```bash
sudo mkdir -p /etc/ctrla-web
sudo touch /etc/ctrla-web/api-server.env
sudo chmod 600 /etc/ctrla-web/api-server.env
```

Fill it in based on `artifacts/api-server/.env.example`. Required values for
this deploy:

```
NODE_ENV=production
PORT=<the port you picked in §0>
DATABASE_URL=<the Neon connection string — get this from the user/1Password/wherever it's kept, do NOT commit it anywhere>
JWT_SECRET=<generate fresh — see below>
SETTINGS_ENCRYPTION_KEY=<MUST match the value the Replit deployment used — see warning below>
UPLOAD_DIR=/var/lib/ctrla-web/uploads
```

**⚠️ SETTINGS_ENCRYPTION_KEY warning**: this Neon database already has real
data in it, including `site_settings` rows (site name, contact email/phone,
WhatsApp number, etc.) encrypted with whatever `SETTINGS_ENCRYPTION_KEY` the
Replit deployment was using. If you set a *different* key here, the app won't
crash, but every one of those fields will silently fail to decrypt and show
raw ciphertext instead of real content until someone re-types them in the
admin panel. Get the exact value from the Replit project's **Tools → Secrets**
panel and reuse it here. If you'd rather not hunt for it, that's fine too —
just re-enter the ~15 settings fields by hand in `/admin` after first boot.

Generate `JWT_SECRET` fresh (changing it just forces re-login, no data loss):
```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

## 4. Create the uploads directory

Replaces Replit's object storage (Replit-only, doesn't work off-Replit) with
plain files on disk — see `artifacts/api-server/src/lib/objectStorage.ts`.

```bash
sudo mkdir -p /var/lib/ctrla-web/uploads
sudo chown $USER:$USER /var/lib/ctrla-web/uploads
```

Back this directory up (rsync/cron, or your existing backup tooling) — it's
the only copy of every uploaded blog image, portfolio image, and job
applicant CV.

## 5. First manual build + start

Validates everything before wiring up CI.

```bash
cd /opt/ctrla-web
pnpm install --frozen-lockfile
set -a; . /etc/ctrla-web/api-server.env; set +a
pnpm --filter @workspace/ctrla-website run build
pnpm --filter @workspace/api-server run build

mkdir -p /var/log/ctrla-web
cd artifacts/api-server
pm2 start ecosystem.config.js
pm2 save
pm2 logs ctrla-api --lines 50
```

Check it's alive: `curl -i http://127.0.0.1:$PORT/api/healthz` should return
`{"status":"ok"}`.

## 6. nginx

```bash
sudo cp /opt/ctrla-web/deploy/nginx/ctrla-web.conf /etc/nginx/conf.d/ctrla-web.conf
```

Edit the `upstream ctrla_api { server 127.0.0.1:PORT; }` line to match the
port you picked in §0, then:

```bash
sudo nginx -t && sudo systemctl reload nginx
```

Once DNS points a real domain at this box, run:
```bash
sudo certbot --nginx -d your-domain.example -d www.your-domain.example
```
This rewrites the config in place to add TLS + HTTP→HTTPS redirect. Then set
`PUBLIC_URL=https://your-domain.example` in `/etc/ctrla-web/api-server.env`
and `pm2 restart ctrla-api`.

## 7. Self-hosted GitHub Actions runner (for CI/CD)

One dedicated runner per project, same pattern as this box's other projects
(`actions-runner-aartigreentech`, etc.) — do not point another project's
runner at this repo.

```bash
mkdir ~/actions-runner-ctrla-web && cd ~/actions-runner-ctrla-web
# Get the exact download command from:
# GitHub repo -> Settings -> Actions -> Runners -> New self-hosted runner (Linux x64)
./config.sh --url https://github.com/CtrlA-Tech-Solutions-Private-Limited/ctrla-web \
  --token <TOKEN_FROM_THAT_PAGE> --labels ctrla-web-prod --name ctrla-web-prod
sudo ./svc.sh install
sudo ./svc.sh start
```

No GitHub Actions secrets need configuring — `.github/workflows/main.yml`
reads everything it needs from `/etc/ctrla-web/api-server.env` on the runner
machine itself, so nothing sensitive touches GitHub's UI.

The runner user needs passwordless `pm2`/`node`/`pnpm` on its `PATH`, and read
access to `/etc/ctrla-web/api-server.env`. If the runner runs as a different
Linux user than the one who set up PM2 in §5, run `pm2 startup` /
re-`pm2 save` as that runner user, or run the runner as the same user.

From here on, every push to `main` runs `.github/workflows/main.yml`:
install → typecheck → build frontend (with prerender) → build api-server →
`pm2 startOrReload`.

## 8. Ongoing schema changes

The app auto-applies its own additive migrations on boot (see
`runMigrations()` in `artifacts/api-server/src/index.ts`) — nothing to do for
those. If you change `lib/db/src/schema`, run the schema push by hand
(deliberately not automated in CI — `drizzle-kit push` can prompt
interactively on ambiguous diffs like renames, which would hang a CI job):

```bash
cd /opt/ctrla-web
set -a; . /etc/ctrla-web/api-server.env; set +a
pnpm --filter @workspace/db run push
```
