# CtrlA Tech Solutions — CMS-Driven Website

## Overview

Full-stack CMS-driven website for CtrlA Tech Solutions (Indian tech company). pnpm monorepo with Express API, PostgreSQL, and React+Vite frontend.

## Architecture

```
artifacts/
  api-server/      — Express 5 REST API (port 8080, proxied at /api)
  ctrla-website/   — React + Vite public website + admin panel (port 20866, proxied at /)
  mockup-sandbox/  — Component preview server (port 8081)
lib/
  db/              — Drizzle ORM schema + PostgreSQL client
  api-spec/        — OpenAPI spec + Orval codegen config
  api-zod/         — Generated Zod schemas (output of codegen)
  api-client-react/ — Generated React hooks + TanStack Query (output of codegen)
```

## Stack

- **Monorepo**: pnpm workspaces
- **Node.js**: 24, **TypeScript**: 5.9
- **API**: Express 5 + Drizzle ORM + PostgreSQL
- **Auth**: JWT (jsonwebtoken + bcryptjs), token stored in localStorage
- **Validation**: Zod v4, drizzle-zod
- **API codegen**: Orval (from OpenAPI spec) → generates Zod schemas + React hooks
- **Frontend**: React + Vite + Wouter (routing) + TanStack Query + shadcn/ui + Tailwind CSS + framer-motion
- **Email**: Nodemailer (SMTP, configurable in admin settings)
- **Logging**: Pino + pino-http

## Color Theme

- Deep navy: `#0A0F2C` (background)
- Electric teal: `#00C9B1` (accent / primary)
- Font: Inter

## Key URLs

- Public site: `/`
- Admin panel: `/admin` (login: `/admin/login`)
- API: `/api/*`

## Default Admin Credentials

- Username: `admin`
- Password: `admin123`

> **Production security**: Set `ADMIN_PASSWORD` as a Replit Secret before first deployment. The server throws an error in `NODE_ENV=production` if this secret is missing when no admin user exists. In development, falls back to `admin123` with a warning.

> The admin user, site settings, menu items, CMS pages (home/about/services), blog post, and 3 portfolio case studies are all seeded automatically on first API server startup.

## Database Schema (8 tables)

| Table | Description |
|---|---|
| `admin_users` | Admin panel users (username, passwordHash, email) |
| `pages` | CMS pages (title, slug, content, SEO, published flag) |
| `menu_items` | Navigation menu (label, url, pageId, sortOrder, openInNewTab) |
| `blog_categories` | Blog post categories |
| `blog_posts` | Blog posts (title, slug, content, featuredImage, isPublished) |
| `media` | Media library (filename, url, mimeType, size) |
| `contact_inquiries` | Contact form submissions (name, email, phone, message, isRead) |
| `site_settings` | All site settings (colors, SMTP, WhatsApp, GA, chatbot config) |

## API Routes

All routes match the OpenAPI spec exactly (HTTP methods and paths).

| Method | Path | Description |
|---|---|---|
| POST | /api/auth/login | Admin login (returns JWT) |
| GET | /api/auth/me | Get current admin user |
| GET | /api/admin/dashboard/stats | Dashboard statistics |
| GET/POST | /api/admin/pages | List / create pages |
| GET/PATCH/DELETE | /api/admin/pages/:id | Get / update / delete page |
| GET/POST | /api/admin/menu | List / create menu items |
| PUT | /api/admin/menu/reorder | Reorder menu items (body: {ids: number[]}) |
| PATCH/DELETE | /api/admin/menu/:id | Update / delete menu item |
| GET/POST | /api/admin/blog/posts | List / create blog posts |
| GET/PATCH/DELETE | /api/admin/blog/posts/:id | Get / update / delete blog post |
| GET/POST | /api/admin/blog/categories | List / create categories |
| GET/POST | /api/admin/media | List / upload media |
| DELETE | /api/admin/media/:id | Delete media |
| GET | /api/admin/contacts | List contacts |
| PATCH | /api/admin/contacts/:id/read | Mark contact as read |
| DELETE | /api/admin/contacts/:id | Delete contact |
| GET | /api/admin/settings | Get site settings (sensitive fields masked) |
| PUT | /api/admin/settings | Update site settings |
| GET | /api/site/config | Public site config (menu, colors, GA, WhatsApp, chatbot) |
| GET | /api/pages/:slug | Get published page by slug |
| GET | /api/blog/posts | List published blog posts (paginated: {posts, total, limit, offset}) |
| GET | /api/blog/posts/:slug | Get published blog post by slug |
| POST | /api/contact | Submit contact form (public) |
| GET | /api/sitemap.xml | Dynamic XML sitemap |
| GET | /api/robots.txt | Dynamic robots.txt |
| POST | /api/chat | AI chatbot (OpenAI/Gemini if configured, FAQ fallback) |
| GET | /api/portfolio | List published portfolio items |
| GET | /api/portfolio/:slug | Get portfolio item by slug |

## Admin Panel Features

- **Dashboard**: Stats cards (total/published pages, blog posts, contacts, media)
- **Pages**: Create, edit, delete CMS pages with slug, content, SEO meta, published toggle
- **Menu**: Create, edit, delete, reorder navigation menu items
- **Blog**: Create, edit, delete blog posts with categories, featured image, publish toggle
- **Media**: Upload and manage media files via object storage
- **Contacts**: View, mark read, delete contact form submissions
- **Settings**: Configure general info, colors/fonts, SMTP, WhatsApp, Google Analytics ID, AI chatbot

## Public Website Pages

- `/` — Homepage (hero, services, stats, testimonials, CTA)
- `/about` — About page (team, values)
- `/services` — Services listing
- `/blog` — Blog list (paginated)
- `/blog/:slug` — Individual blog post
- `/contact` — Contact form (submits to API)
- `/:slug` — Dynamic CMS pages

## Public Website Features

- WhatsApp floating button (configurable number from settings)
- AI chatbot widget (enabled/disabled from settings)
- Google Analytics integration (GA ID from settings)
- SEO meta tags on all pages
- Framer Motion animations

## Key Commands

```bash
# Run API server (dev)
pnpm --filter @workspace/api-server run dev

# Run frontend (dev)
pnpm --filter @workspace/ctrla-website run dev

# Typecheck all packages
pnpm run typecheck

# Regenerate API hooks and Zod schemas from OpenAPI spec
pnpm --filter @workspace/api-spec run codegen

# Push DB schema changes (dev only)
pnpm --filter @workspace/db run push
```

## Security

- **JWT_SECRET**: Required as an environment variable (`JWT_SECRET`). Throws on startup if missing. Set via Replit Secrets or env vars.
- **Sensitive settings**: `smtpPassword` and `smsApiKey` are masked as `"••••••••"` in admin GET `/settings` response. When saving settings, if masked value is sent back unchanged, it's ignored (existing value preserved).
- **Admin credentials hint**: The login page does NOT display default credentials.
- **robots.txt**: Served from `public/robots.txt`, blocks `/admin/`. Points to `/api/sitemap.xml`.

## Frontend Architecture

- **SiteConfigProvider** (`src/contexts/SiteConfigContext.tsx`): Fetches `/api/site/config` once per session and provides it to all public layout components via React context.
- **Navbar**: Reads `menuItems` from `SiteConfigContext` — fully CMS-driven.
- **WhatsApp button**: Only rendered if `whatsappNumber` is set in site config.
- **Chatbot widget**: Only rendered if `chatbotEnabled = true`. Keyword-based FAQ bot.
- **Google Analytics**: Injected into `<head>` dynamically when `gaId` is set in site config.
- **CSS Theme**: All shadcn/ui tokens use proper HSL values (`--primary: 174 100% 39%` teal, `--sidebar: 234 64% 11%` navy). Light and dark mode both defined.

## Important Notes

- **API base URL**: The generated API client paths already include `/api` prefix (e.g., `/api/auth/login`). `apiClient.ts` sets `setBaseUrl(base || null)` — do NOT add `/api` again.
- **Auto-seed**: The API server seeds the DB on startup if no admin users exist (admin/admin123, default settings, 5 menu items).
- **Routing**: Wouter's `/:rest*` doesn't match the base path exactly. Each admin route is registered explicitly in `App.tsx`.
- **Orval codegen**: Uses `mode: "single"` with `workspace: apiZodSrc`, no `schemas` option. Run codegen after editing the OpenAPI spec in `lib/api-spec/src/openapi.yaml`.
- **Blog pagination**: Public blog endpoint returns `{ posts, total, limit, offset }` (not a plain array).
- **OpenAPI spec is the source of truth**: Always update `lib/api-spec/openapi.yaml` and run codegen before changing API contracts.
