import { pgTable, text, serial, timestamp, boolean, integer } from "drizzle-orm/pg-core";

export const industriesTable = pgTable("industries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull(),
  shortDesc: text("short_desc").notNull().default(""),
  description: text("description").default(""),
  imageUrl: text("image_url"),
  iconName: text("icon_name").notNull().default("Building2"),
  accentColor: text("accent_color").notNull().default("#3D4FA0"),
  sortOrder: integer("sort_order").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export type Industry = typeof industriesTable.$inferSelect;
