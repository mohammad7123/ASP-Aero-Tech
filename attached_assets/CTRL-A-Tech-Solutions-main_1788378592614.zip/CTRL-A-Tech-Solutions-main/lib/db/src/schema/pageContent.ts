import { pgTable, text, serial, timestamp, uniqueIndex } from "drizzle-orm/pg-core";

export const pageContentTable = pgTable("page_content_blocks", {
  id: serial("id").primaryKey(),
  pageSlug: text("page_slug").notNull(),
  blockKey: text("block_key").notNull(),
  value: text("value").notNull().default(""),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
}, (t) => [
  uniqueIndex("page_content_slug_key_idx").on(t.pageSlug, t.blockKey),
]);

export type PageContentBlock = typeof pageContentTable.$inferSelect;
