import { pgTable, text, serial, timestamp, integer, jsonb } from "drizzle-orm/pg-core";

export const campaignsTable = pgTable("campaigns", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  subject: text("subject").default(""),
  body: text("body").notNull().default(""),
  status: text("status").notNull().default("draft"),
  audienceFilter: jsonb("audience_filter").$type<{ source?: string; ids?: number[] }>().default({}),
  stats: jsonb("stats").$type<{ total?: number; sent?: number; failed?: number }>().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  sentAt: timestamp("sent_at", { withTimezone: true }),
});

export const campaignRecipientsTable = pgTable("campaign_recipients", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").notNull().references(() => campaignsTable.id, { onDelete: "cascade" }),
  name: text("name").default(""),
  email: text("email").default(""),
  phone: text("phone").default(""),
  status: text("status").notNull().default("pending"),
  sentAt: timestamp("sent_at", { withTimezone: true }),
  errorMsg: text("error_msg"),
  link: text("link"),
});

export type Campaign = typeof campaignsTable.$inferSelect;
export type CampaignRecipient = typeof campaignRecipientsTable.$inferSelect;
