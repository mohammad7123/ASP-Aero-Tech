import { pgTable, text, serial, timestamp, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const siteSettingsTable = pgTable("site_settings", {
  id: serial("id").primaryKey(),
  smtpHost: text("smtp_host"),
  smtpPort: integer("smtp_port"),
  smtpUser: text("smtp_user"),
  smtpPassword: text("smtp_password"),
  smtpFrom: text("smtp_from"),
  whatsappNumber: text("whatsapp_number"),
  whatsappGreeting: text("whatsapp_greeting"),
  // WhatsApp Business API integration (Twilio or Meta Cloud API)
  whatsappProvider: text("whatsapp_provider"),
  whatsappAccountSid: text("whatsapp_account_sid"),
  whatsappAuthToken: text("whatsapp_auth_token"),
  whatsappFromNumber: text("whatsapp_from_number"),
  whatsappPhoneNumberId: text("whatsapp_phone_number_id"),
  whatsappAccessToken: text("whatsapp_access_token"),
  smsProvider: text("sms_provider"),
  smsApiKey: text("sms_api_key"),
  smsSenderId: text("sms_sender_id"),
  // SMS provider extra fields (Twilio account SID, etc.)
  smsAccountSid: text("sms_account_sid"),
  gaId: text("ga_id"),
  chatbotName: text("chatbot_name"),
  chatbotGreeting: text("chatbot_greeting"),
  chatbotEnabled: boolean("chatbot_enabled").notNull().default(false),
  chatbotApiKey: text("chatbot_api_key"),
  chatbotModel: text("chatbot_model"),
  // AI provider configuration (own keys)
  defaultAiProvider: text("default_ai_provider"),
  openaiApiKey: text("openai_api_key"),
  openaiBaseUrl: text("openai_base_url"),
  openaiModel: text("openai_model"),
  anthropicApiKey: text("anthropic_api_key"),
  anthropicBaseUrl: text("anthropic_base_url"),
  anthropicModel: text("anthropic_model"),
  geminiApiKey: text("gemini_api_key"),
  geminiBaseUrl: text("gemini_base_url"),
  geminiModel: text("gemini_model"),
  openrouterApiKey: text("openrouter_api_key"),
  openrouterBaseUrl: text("openrouter_base_url"),
  openrouterModel: text("openrouter_model"),
  primaryColor: text("primary_color").notNull().default("#00C9B1"),
  accentColor: text("accent_color").notNull().default("#0A0F2C"),
  backgroundColor: text("background_color").notNull().default("#ffffff"),
  fontFamily: text("font_family").notNull().default("Inter"),
  siteName: text("site_name").notNull().default("CtrlA Tech Solutions"),
  tagline: text("tagline"),
  logoUrl: text("logo_url"),
  faviconUrl: text("favicon_url"),
  contactEmail: text("contact_email"),
  contactPhone: text("contact_phone"),
  contactPhone2: text("contact_phone2"),
  address: text("address"),
  // Social media links
  linkedinUrl: text("linkedin_url"),
  twitterUrl: text("twitter_url"),
  facebookUrl: text("facebook_url"),
  instagramUrl: text("instagram_url"),
  youtubeUrl: text("youtube_url"),
  // Support portal
  supportLoginUrl: text("support_login_url"),
  // Hero banner display settings
  bannerHeight: integer("banner_height").notNull().default(640),
  bannerSpeed: integer("banner_speed").notNull().default(5000),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertSiteSettingsSchema = createInsertSchema(siteSettingsTable).omit({ id: true, updatedAt: true });
export type InsertSiteSettings = z.infer<typeof insertSiteSettingsSchema>;
export type SiteSettings = typeof siteSettingsTable.$inferSelect;
