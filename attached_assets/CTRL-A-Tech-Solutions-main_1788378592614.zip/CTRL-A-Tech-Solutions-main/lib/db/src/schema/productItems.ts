import { pgTable, text, serial, timestamp, boolean, integer } from "drizzle-orm/pg-core";

export const productItemsTable = pgTable("product_items", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(),
  name: text("name").notNull(),
  slug: text("slug").notNull(),
  shortDesc: text("short_desc").notNull().default(""),
  description: text("description").default(""),
  imageUrl: text("image_url"),
  iconName: text("icon_name").notNull().default("Package"),
  accentColor: text("accent_color").notNull().default("#D4920C"),
  sortOrder: integer("sort_order").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export type ProductItem = typeof productItemsTable.$inferSelect;
