import { pgTable, text, serial, timestamp, integer, jsonb } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const usageEventsTable = pgTable("usage_events", {
  id: serial("id").primaryKey(),
  channel: text("channel").notNull(),
  provider: text("provider").notNull().default(""),
  action: text("action").notNull().default(""),
  status: text("status").notNull().default("success"),
  units: integer("units").notNull().default(1),
  meta: jsonb("meta").default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const usageEventInsertSchema = z.object({
  channel: z.enum(["ai", "email", "sms", "whatsapp"]),
  provider: z.string().default(""),
  action: z.string().default(""),
  status: z.enum(["success", "failed"]).default("success"),
  units: z.number().int().default(1),
  meta: z.record(z.string(), z.unknown()).optional(),
});
export type UsageEvent = typeof usageEventsTable.$inferSelect;
