---
name: site translation approach
description: How the CtrlA public website translates content (Google Translate, not i18next keys)
---

The CtrlA public site uses **Google Website Translate** for full-site translation (every page, menu, button, and CMS/blog content), NOT i18next keys.

**Why:** ~24 public pages (~15k lines) had hardcoded English JSX; wrapping every string in `t()` across 12+ languages was not viable. The user explicitly chose an automatic translator over hand-crafted per-page translation.

**How it works:**
- Flag language switcher (`Navbar.tsx` `LanguageSwitcher`) calls `setLang()` in `src/lib/translate.ts`, which sets the `googtrans` cookie (`/en/<googleCode>`) and does `window.location.reload()`. On reload the hidden Google widget (`GoogleTranslate.tsx`, mounted in `PublicLayout`) reads the cookie and translates the whole document.
- i18next is pinned to `lng:"en"` in `i18n/index.ts` so English is the single source language Google translates from. The old locale JSON files (pt/fr/de/…) are now dead weight — do NOT rely on them for translation.
- Current language = read from `googtrans` cookie (source of truth), not localStorage.

**Critical gotchas — do not regress:**
- The `Node.prototype.removeChild`/`insertBefore` guards in `main.tsx` are REQUIRED. Google Translate wraps text in `<font>` tags; without the guards, wouter client-side navigation (PublicLayout unmounts per page) crashes React with NotFoundError. Never remove them.
- Keep `notranslate` on the language switcher so Google doesn't mangle native language labels.
- Google banner/gadget is hidden via CSS in `index.css` (`.goog-te-banner-frame`, `body { top:0 }`, etc.).
- `domain=.replit.dev`/`.replit.app` cookie variants are rejected (Public Suffix List) — harmless; host-only variant works.
