---
name: Home page architecture
description: Section order and data sources for the redesigned Home page
---

Home.tsx sections (top to bottom):
1. HeroSlideshow — uses useHeroSlides() fetching /api/public/hero-slides; fallback to /home-banner.jpg
2. Trust/Stats bar — dark navy gradient, 4 stats from t() keys
3. Core Services grid — 8 services, 4-col desktop, dark gradient cards, SERVICE_LINKS map
4. Industries We Serve — dark bg, 8 industry tiles with Lucide icons
5. WMS 360 Feature — gray-50 bg, image left + content right
6. Why Choose CtrlA — white bg, 4 differentiator cards
7. Testimonials — dark navy bg, 3 hardcoded quotes (no DB table for testimonials)
8. Blog preview — uses useBlogPosts() fetching /api/public/blog-posts?limit=3; graceful empty state
9. CMS body — optional from cmsPage?.content via useGetPublicPage("home")
10. CTA strip — dark navy, two CTAs

Blog posts DB columns: id, title, slug, excerpt, featured_image, is_published, published_at, created_at. No "status" column.

**Why:** Blog API returns 503 if slugged (use limit param only). Testimonials has no DB table — hardcoded for now.
