---
name: api-server runs a built dist
description: Why new api-server routes/schema can hang until the workflow is restarted
---

The `@workspace/api-server` dev script builds first, then runs the compiled
output (`node dist/index.mjs`) — it does NOT run TypeScript source with a watcher.

**Why:** A running server process holds a stale bundle. When source adds a new
route or a new DB table/schema, the live process keeps serving the old build.
Symptom observed: a newly-added DB-backed route responded (not 404) but the
request hung indefinitely (until the next restart killed it), while existing
routes and raw psql worked fine. Restarting the workflow rebuilt the bundle and
the route returned instantly.

**How to apply:** After adding/changing api-server routes or `@workspace/db`
schema, restart the `artifacts/api-server: API Server` workflow to rebuild
before testing. If a brand-new route hangs while others work, suspect a stale
build first — restart before deep-debugging the query.
