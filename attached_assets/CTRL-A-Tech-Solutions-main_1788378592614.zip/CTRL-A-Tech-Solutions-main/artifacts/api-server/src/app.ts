import express, { type Express, type Request, type Response } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import path from "path";
import http from "http";
import { fileURLToPath } from "url";
import router from "./routes";
import robotsRouter from "./routes/robots";
import sitemapRouter from "./routes/sitemap";
import { logger } from "./lib/logger";
import { db } from "@workspace/db";
import { pagesTable, blogPostsTable, portfolioTable } from "@workspace/db/schema";
import { and, eq } from "drizzle-orm";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve robots.txt and sitemap.xml at root paths so search engine crawlers
// can find them without the /api prefix.
app.use(robotsRouter);
app.use(sitemapRouter);

app.use("/api", router);

// Exact hard-coded public routes that always return 200.
const KNOWN_STATIC_PATHS = new Set([
  "/",
  "/about",
  "/services",
  "/services/erp-solutions",
  "/services/web-development",
  "/services/mobile-apps",
  "/services/custom-software",
  "/services/cloud-solutions",
  "/services/cybersecurity",
  "/services/it-consulting",
  "/services/digital-marketing",
  "/products",
  "/products/erp",
  "/products/business-apps",
  "/products/ai-solutions",
  "/products/cloud-platforms",
  "/products/integration-suite",
  "/portfolio",
  "/blog",
  "/contact",
  "/careers",
  "/clients",
  "/industries",
  "/wms360",
  "/myhrone",
  "/sap-business-one",
  "/sap-business-one-hana",
  "/support-service",
  "/sap-b1-on-cloud",
  "/rise-with-sap",
  "/s4-hana",
  "/b1plus-cloud",
  "/become-a-partner",
  "/technologies",
  "/technologies/microsoft",
  "/technologies/open-source",
  "/technologies/mobile",
  "/technologies/frontend",
  "/technologies/big-data",
  "/technologies/java",
  "/technologies/ai-ml-data-science",
  "/technologies/async-messaging",
  "/technologies/erp-solutions",
]);

// Admin routes are client-side but should not be indexed — still return 200
// so the SPA can render its own auth gate.
const ADMIN_PATTERN = /^\/admin(\/|$)/;

// In production, serve the React frontend as static files and handle SPA routing
if (process.env.NODE_ENV === "production") {
  const frontendDist = path.resolve(__dirname, "../../ctrla-website/dist/public");
  app.use(express.static(frontendDist));
  app.get("/{*splat}", async (req: Request, res: Response) => {
    const indexFile = path.join(frontendDist, "index.html");
    const pathname = req.path;

    // Exact hard-coded routes and admin paths always get 200.
    if (KNOWN_STATIC_PATHS.has(pathname) || ADMIN_PATTERN.test(pathname)) {
      res.status(200).sendFile(indexFile);
      return;
    }

    // Dynamic blog post: verify the slug is a published post.
    const blogMatch = pathname.match(/^\/blog\/([\w-]+)$/);
    if (blogMatch) {
      try {
        const rows = await db
          .select({ id: blogPostsTable.id })
          .from(blogPostsTable)
          .where(and(eq(blogPostsTable.slug, blogMatch[1]), eq(blogPostsTable.isPublished, true)))
          .limit(1);
        res.status(rows.length > 0 ? 200 : 404).sendFile(indexFile);
      } catch {
        res.status(200).sendFile(indexFile);
      }
      return;
    }

    // Dynamic portfolio item: verify the slug is a published item.
    const portfolioMatch = pathname.match(/^\/portfolio\/([\w-]+)$/);
    if (portfolioMatch) {
      try {
        const rows = await db
          .select({ id: portfolioTable.id })
          .from(portfolioTable)
          .where(and(eq(portfolioTable.slug, portfolioMatch[1]), eq(portfolioTable.isPublished, true)))
          .limit(1);
        res.status(rows.length > 0 ? 200 : 404).sendFile(indexFile);
      } catch {
        res.status(200).sendFile(indexFile);
      }
      return;
    }

    // Single-segment paths may be CMS dynamic pages (App.tsx /:slug route).
    // Check DB before deciding 200 vs 404.
    if (/^\/[\w-]+$/.test(pathname)) {
      const slug = pathname.slice(1);
      try {
        const rows = await db
          .select({ id: pagesTable.id })
          .from(pagesTable)
          .where(and(eq(pagesTable.slug, slug), eq(pagesTable.isPublished, true)))
          .limit(1);
        res.status(rows.length > 0 ? 200 : 404).sendFile(indexFile);
      } catch {
        res.status(200).sendFile(indexFile);
      }
      return;
    }

    // Truly unknown URL: return 404 so crawlers do not treat it as a real page.
    res.status(404).sendFile(indexFile);
  });
} else {
  // In development, proxy all non-API requests to the Vite dev server
  const VITE_PORT = 5173;
  app.use("/{*path}", (req: Request, res: Response) => {
    const options = {
      hostname: "localhost",
      port: VITE_PORT,
      path: req.originalUrl,
      method: req.method,
      headers: { ...req.headers, host: `localhost:${VITE_PORT}` },
    };
    const proxy = http.request(options, (proxyRes) => {
      res.writeHead(proxyRes.statusCode ?? 200, proxyRes.headers);
      proxyRes.pipe(res, { end: true });
    });
    proxy.on("error", () => {
      res.status(503).send("Frontend dev server not ready — start the ctrla-website workflow.");
    });
    req.pipe(proxy, { end: true });
  });
}

export default app;
