import app from "./app";
import { logger } from "./lib/logger";
import { db, pool } from "@workspace/db";
import { adminUsersTable, siteSettingsTable, menuItemsTable, pagesTable, blogPostsTable, blogCategoriesTable, servicesTable } from "@workspace/db/schema";
import { portfolioTable } from "@workspace/db/schema";
import bcrypt from "bcryptjs";
import { encryptSetting, decryptSetting, isEncrypted } from "./lib/settingsEncryption";

async function runMigrations() {
  const client = await pool.connect();
  try {
    // site_settings extensions (idempotent)
    await client.query(`
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS chatbot_model TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS whatsapp_provider TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS whatsapp_account_sid TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS whatsapp_auth_token TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS whatsapp_from_number TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS whatsapp_phone_number_id TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS whatsapp_access_token TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS sms_account_sid TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS default_ai_provider TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS openai_api_key TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS openai_base_url TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS openai_model TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS anthropic_api_key TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS anthropic_base_url TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS anthropic_model TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS gemini_api_key TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS gemini_base_url TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS gemini_model TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS openrouter_api_key TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS openrouter_base_url TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS openrouter_model TEXT;
    `);

    // Usage events table (per-channel hit tracking for AI/SMS/WhatsApp/Email)
    await client.query(`
      CREATE TABLE IF NOT EXISTS usage_events (
        id SERIAL PRIMARY KEY,
        channel TEXT NOT NULL,
        provider TEXT NOT NULL DEFAULT '',
        action TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT 'success',
        units INTEGER NOT NULL DEFAULT 1,
        meta JSONB DEFAULT '{}'::jsonb,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
      CREATE INDEX IF NOT EXISTS idx_usage_events_created_at ON usage_events(created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_usage_events_channel ON usage_events(channel);
    `);

    // Services table
    await client.query(`
      CREATE TABLE IF NOT EXISTS services (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        slug TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'general',
        short_desc TEXT NOT NULL DEFAULT '',
        description TEXT DEFAULT '',
        image_url TEXT,
        icon_name TEXT NOT NULL DEFAULT 'Briefcase',
        accent_color TEXT NOT NULL DEFAULT '#D4920C',
        sort_order INTEGER NOT NULL DEFAULT 0,
        is_active BOOLEAN NOT NULL DEFAULT true,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `);

    // Industries table
    await client.query(`
      CREATE TABLE IF NOT EXISTS industries (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        slug TEXT NOT NULL,
        short_desc TEXT NOT NULL DEFAULT '',
        description TEXT DEFAULT '',
        image_url TEXT,
        icon_name TEXT NOT NULL DEFAULT 'Building2',
        accent_color TEXT NOT NULL DEFAULT '#3D4FA0',
        sort_order INTEGER NOT NULL DEFAULT 0,
        is_active BOOLEAN NOT NULL DEFAULT true,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `);

    // Campaigns
    await client.query(`
      CREATE TABLE IF NOT EXISTS campaigns (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        subject TEXT DEFAULT '',
        body TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT 'draft',
        audience_filter JSONB DEFAULT '{}'::jsonb,
        stats JSONB DEFAULT '{}'::jsonb,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        sent_at TIMESTAMPTZ
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS campaign_recipients (
        id SERIAL PRIMARY KEY,
        campaign_id INTEGER NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
        name TEXT DEFAULT '',
        email TEXT DEFAULT '',
        phone TEXT DEFAULT '',
        status TEXT NOT NULL DEFAULT 'pending',
        sent_at TIMESTAMPTZ,
        error_msg TEXT,
        link TEXT
      );
    `);

    // Jobs + Applications tables
    await client.query(`
      CREATE TABLE IF NOT EXISTS jobs (
        id SERIAL PRIMARY KEY,
        title TEXT NOT NULL,
        department TEXT NOT NULL DEFAULT '',
        location TEXT NOT NULL DEFAULT '',
        type TEXT NOT NULL DEFAULT 'full-time',
        description TEXT NOT NULL DEFAULT '',
        requirements TEXT NOT NULL DEFAULT '',
        salary_range TEXT,
        is_active BOOLEAN NOT NULL DEFAULT true,
        sort_order INTEGER NOT NULL DEFAULT 0,
        closed_at TIMESTAMPTZ,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
      CREATE TABLE IF NOT EXISTS job_applications (
        id SERIAL PRIMARY KEY,
        job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT,
        cover_letter TEXT,
        cv_object_path TEXT,
        cv_filename TEXT,
        status TEXT NOT NULL DEFAULT 'new',
        notes TEXT,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
      CREATE INDEX IF NOT EXISTS idx_jobs_is_active ON jobs(is_active);
      CREATE INDEX IF NOT EXISTS idx_job_applications_job_id ON job_applications(job_id);
    `);

    // Social media columns in site_settings (idempotent)
    await client.query(`
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS linkedin_url TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS twitter_url TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS facebook_url TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS instagram_url TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS youtube_url TEXT;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS support_login_url TEXT;
    `);

    // Hero banner display settings (idempotent)
    await client.query(`
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS banner_height INTEGER NOT NULL DEFAULT 640;
      ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS banner_speed INTEGER NOT NULL DEFAULT 5000;
    `);

    // Hero slides extended fields — eyebrow pill, stats, badge (idempotent)
    await client.query(`
      ALTER TABLE hero_slides ADD COLUMN IF NOT EXISTS eyebrow TEXT;
      ALTER TABLE hero_slides ADD COLUMN IF NOT EXISTS stat1 TEXT;
      ALTER TABLE hero_slides ADD COLUMN IF NOT EXISTS stat2 TEXT;
      ALTER TABLE hero_slides ADD COLUMN IF NOT EXISTS stat3 TEXT;
      ALTER TABLE hero_slides ADD COLUMN IF NOT EXISTS badge TEXT;
    `);

    // Clients table
    await client.query(`
      CREATE TABLE IF NOT EXISTS clients (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        logo_url TEXT,
        website_url TEXT,
        industry TEXT,
        testimonial TEXT,
        testimonial_person TEXT,
        testimonial_role TEXT,
        sort_order INTEGER NOT NULL DEFAULT 0,
        is_active BOOLEAN NOT NULL DEFAULT true,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `);

    // Backfill: ensure at least one admin exists. If the very first seeded
    // account was created before role-defaulting was correct, promote the
    // earliest user (lowest id) to "admin" so the admin panel works.
    await client.query(`
      UPDATE admin_users SET role = 'admin'
      WHERE id = (SELECT id FROM admin_users ORDER BY id ASC LIMIT 1)
        AND NOT EXISTS (SELECT 1 FROM admin_users WHERE role = 'admin');
    `);

    logger.info("Migrations: schema up to date");
  } catch (e) {
    logger.warn({ err: e }, "Migration warning (non-fatal)");
  } finally {
    client.release();
  }
}

async function seed() {
  try {
    // ── Admin user ──────────────────────────────────────────────────────────
    const existing = await db.select().from(adminUsersTable).limit(1);
    if (existing.length === 0) {
      const envPassword = process.env["ADMIN_PASSWORD"];
      if (!envPassword && process.env["NODE_ENV"] === "production") {
        throw new Error("ADMIN_PASSWORD environment variable must be set in production before first startup. Set it as a Replit Secret.");
      }
      // Never use a guessable default. Generate a random password if not explicitly set.
      const { randomBytes } = await import("crypto");
      const password = envPassword ?? randomBytes(16).toString("hex");
      const hash = await bcrypt.hash(password, 10);
      await db.insert(adminUsersTable).values({ username: "admin", passwordHash: hash, email: "admin@ctrlatechsolutions.com", role: "admin" });
      if (envPassword) {
        logger.info("Seeded: admin user created (username: admin, password from ADMIN_PASSWORD env)");
      } else {
        logger.warn(
          `FIRST-RUN: Admin account created — username: admin, password: ${password}\n` +
          "This password will NOT be shown again. Set ADMIN_PASSWORD as a Replit Secret to control credentials on future fresh databases.",
        );
      }
    }

    // ── Site settings ────────────────────────────────────────────────────────
    const settings = await db.select().from(siteSettingsTable).limit(1);
    if (settings.length === 0) {
      const e = encryptSetting;
      await db.insert(siteSettingsTable).values({
        siteName: e("CtrlA Tech Solutions"),
        tagline: e("Innovating the Future of Technology"),
        primaryColor: e("#D4920C"),
        accentColor: e("#1A1F36"),
        logoUrl: e("/logo.png"),
        backgroundColor: e("#ffffff"),
        fontFamily: e("Inter"),
        contactEmail: e("Info@ctrlatechsolutions.com"),
        contactPhone: e("+91-9310775007"),
        address: e("India & United Kingdom"),
        whatsappNumber: e("919876543210"),
        whatsappGreeting: e("Hello! How can we help you today?"),
        chatbotEnabled: false,
        chatbotName: e("CtrlA Bot"),
        chatbotGreeting: e("Hi! I'm CtrlA Bot. How can I assist you today?"),
      });
      logger.info("Seeded: site settings created (encrypted)");
    } else {
      // ── Backfill plaintext settings rows ──────────────────────────────────
      const row = settings[0];
      const stringFields = [
        "siteName", "tagline", "primaryColor", "accentColor", "backgroundColor",
        "fontFamily", "contactEmail", "contactPhone", "address",
        "whatsappNumber", "whatsappGreeting", "smsProvider", "smsSenderId",
        "gaId", "chatbotName", "chatbotGreeting", "smtpHost", "smtpUser",
        "smtpFrom", "smtpPassword", "smsApiKey", "chatbotApiKey",
        "logoUrl", "faviconUrl",
      ] as const;
      const patch: Partial<Record<string, string>> = {};
      for (const field of stringFields) {
        const val = (row as Record<string, unknown>)[field];
        if (typeof val === "string" && val && !isEncrypted(val)) {
          patch[field] = encryptSetting(val);
        }
      }
      if (Object.keys(patch).length > 0) {
        const { eq } = await import("drizzle-orm");
        await db.update(siteSettingsTable).set(patch).where(eq(siteSettingsTable.id, row.id));
        logger.info(`Backfilled: encrypted ${Object.keys(patch).length} plaintext settings field(s)`);
      }
    }

    // ── Services (mirror the public Navbar mega-menu so admin sees the same list) ──
    // Per-slug additive insert — preserves any admin-created entries while ensuring
    // every Navbar item exists in the DB.
    {
      const existingSlugs = new Set((await db.select({ slug: servicesTable.slug }).from(servicesTable)).map(r => r.slug));
      const seedRows = [
        { name: "Web Development", slug: "web-development", category: "build", shortDesc: "Modern websites & web apps", iconName: "Globe", accentColor: "#3D4FA0", sortOrder: 10 },
        { name: "Mobile Apps", slug: "mobile-apps", category: "build", shortDesc: "iOS, Android & cross-platform", iconName: "Smartphone", accentColor: "#3D4FA0", sortOrder: 20 },
        { name: "Custom Software", slug: "custom-software", category: "build", shortDesc: "Tailored business solutions", iconName: "Code2", accentColor: "#3D4FA0", sortOrder: 30 },
        { name: "Cloud Solutions", slug: "cloud-solutions", category: "run", shortDesc: "AWS, Azure, GCP architecture", iconName: "Cloud", accentColor: "#16a34a", sortOrder: 40 },
        { name: "Cybersecurity", slug: "cybersecurity", category: "run", shortDesc: "Audits, hardening, monitoring", iconName: "Shield", accentColor: "#16a34a", sortOrder: 50 },
        { name: "IT Consulting", slug: "it-consulting", category: "grow", shortDesc: "Digital transformation strategy", iconName: "Lightbulb", accentColor: "#D4920C", sortOrder: 60 },
        { name: "Digital Marketing", slug: "digital-marketing", category: "grow", shortDesc: "SEO, PPC, social & AI marketing", iconName: "TrendingUp", accentColor: "#D4920C", sortOrder: 65 },
        { name: "SAP Business One", slug: "sap-business-one", category: "sap", shortDesc: "ERP for small & midsize businesses", iconName: "Briefcase", accentColor: "#E84821", sortOrder: 70 },
        { name: "SAP Business One on HANA", slug: "sap-business-one-hana", category: "sap", shortDesc: "In-memory analytics for SAP B1", iconName: "Briefcase", accentColor: "#E84821", sortOrder: 80 },
        { name: "Rise with SAP", slug: "rise-with-sap", category: "sap", shortDesc: "Cloud transformation suite", iconName: "Briefcase", accentColor: "#E84821", sortOrder: 90 },
        { name: "S/4 HANA", slug: "s4-hana", category: "sap", shortDesc: "Next-gen intelligent ERP", iconName: "Briefcase", accentColor: "#E84821", sortOrder: 100 },
        { name: "SAP B1 on Cloud", slug: "sap-b1-on-cloud", category: "sap", shortDesc: "Hosted SAP B1 deployment", iconName: "Cloud", accentColor: "#E84821", sortOrder: 110 },
        { name: "Support Service", slug: "support-service", category: "support", shortDesc: "24x7 functional & technical support", iconName: "MessageSquare", accentColor: "#16a34a", sortOrder: 120 },
      ];
      const toInsert = seedRows.filter(r => !existingSlugs.has(r.slug));
      if (toInsert.length > 0) {
        await db.insert(servicesTable).values(toInsert);
        logger.info(`Seeded: ${toInsert.length} default service(s) from Navbar mega-menu`);
      }
    }

    // ── Industries (seed default SAP-relevant industries) ─────────────────────
    {
      const { industriesTable } = await import("@workspace/db/schema");
      const existingIndustries = await db.select({ slug: industriesTable.slug }).from(industriesTable);
      if (existingIndustries.length === 0) {
        await db.insert(industriesTable).values([
          { name: "Manufacturing", slug: "manufacturing", shortDesc: "End-to-end ERP for production, inventory & supply chain", iconName: "Factory", accentColor: "#E84821", sortOrder: 10, isActive: true },
          { name: "Retail & Distribution", slug: "retail-distribution", shortDesc: "Omnichannel retail, POS integration & demand planning", iconName: "ShoppingBag", accentColor: "#D4920C", sortOrder: 20, isActive: true },
          { name: "Construction & Real Estate", slug: "construction", shortDesc: "Project costing, contracts & asset management", iconName: "HardHat", accentColor: "#3D4FA0", sortOrder: 30, isActive: true },
          { name: "Food & Beverage", slug: "food-beverage", shortDesc: "Recipe management, traceability & compliance", iconName: "Utensils", accentColor: "#16a34a", sortOrder: 40, isActive: true },
          { name: "Professional Services", slug: "professional-services", shortDesc: "Project management, billing & resource planning", iconName: "Briefcase", accentColor: "#D4920C", sortOrder: 50, isActive: true },
          { name: "Healthcare & Pharma", slug: "healthcare-pharma", shortDesc: "Clinical ERP, regulatory compliance & supply chain", iconName: "Pill", accentColor: "#16a34a", sortOrder: 60, isActive: true },
          { name: "Logistics & Transportation", slug: "logistics", shortDesc: "Fleet management, freight & warehouse operations", iconName: "Truck", accentColor: "#E84821", sortOrder: 70, isActive: true },
          { name: "Education", slug: "education", shortDesc: "Student management, fee collection & HR integration", iconName: "GraduationCap", accentColor: "#3D4FA0", sortOrder: 80, isActive: true },
          { name: "Banking & Finance", slug: "banking-finance", shortDesc: "Regulatory reporting, treasury & risk management", iconName: "Banknote", accentColor: "#D4920C", sortOrder: 90, isActive: true },
          { name: "Chemicals & Process", slug: "chemicals", shortDesc: "Batch processing, compliance & quality management", iconName: "FlaskConical", accentColor: "#7c3aed", sortOrder: 100, isActive: true },
        ]);
        logger.info("Seeded: 10 default industries");
      }
    }

    // ── Menu ─────────────────────────────────────────────────────────────────
    const menu = await db.select().from(menuItemsTable).limit(1);
    if (menu.length === 0) {
      await db.insert(menuItemsTable).values([
        { label: "Home", url: "/", sortOrder: 0 },
        { label: "About", url: "/about", sortOrder: 1 },
        { label: "Services", url: "/services", sortOrder: 2 },
        { label: "Blog", url: "/blog", sortOrder: 3 },
        { label: "Portfolio", url: "/portfolio", sortOrder: 4 },
        { label: "Contact", url: "/contact", sortOrder: 5 },
      ]);
      logger.info("Seeded: default menu items created");
    }

    // ── CMS Pages ─────────────────────────────────────────────────────────────
    const pages = await db.select().from(pagesTable).limit(1);
    if (pages.length === 0) {
      await db.insert(pagesTable).values([
        {
          title: "Home",
          slug: "home",
          isPublished: true,
          metaTitle: "CtrlA Tech Solutions — India's Premier Tech Partner",
          metaDescription: "CtrlA Tech Solutions delivers cutting-edge IT services — web development, mobile apps, cloud solutions, and digital transformation for businesses across India.",
          content: `<section style="padding:48px 0">
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:32px;text-align:center;margin-bottom:64px">
  <div><div style="font-size:2.5rem;font-weight:900;color:#00C9B1">500+</div><div style="color:#6b7280;font-size:0.9rem">Projects Delivered</div></div>
  <div><div style="font-size:2.5rem;font-weight:900;color:#00C9B1">200+</div><div style="color:#6b7280;font-size:0.9rem">Happy Clients</div></div>
  <div><div style="font-size:2.5rem;font-weight:900;color:#00C9B1">10+</div><div style="color:#6b7280;font-size:0.9rem">Years Experience</div></div>
  <div><div style="font-size:2.5rem;font-weight:900;color:#00C9B1">50+</div><div style="color:#6b7280;font-size:0.9rem">Tech Experts</div></div>
</div>
<h2 style="font-size:2rem;font-weight:800;color:#0A0F2C;margin-bottom:16px">Our Core Services</h2>
<p style="color:#6b7280;margin-bottom:40px">Comprehensive technology solutions tailored to accelerate your business growth across India and beyond.</p>
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:24px">
  <div style="border:1px solid #e5e7eb;border-radius:16px;padding:32px">
    <h3 style="color:#0A0F2C;font-weight:700;margin-bottom:8px">Web Development</h3>
    <p style="color:#6b7280;font-size:0.9rem">Custom web applications using React, Node.js, and modern frameworks. From landing pages to complex enterprise portals.</p>
  </div>
  <div style="border:1px solid #e5e7eb;border-radius:16px;padding:32px">
    <h3 style="color:#0A0F2C;font-weight:700;margin-bottom:8px">Mobile App Development</h3>
    <p style="color:#6b7280;font-size:0.9rem">Native iOS and Android apps, cross-platform solutions with React Native and Flutter. Intuitive experiences your users will love.</p>
  </div>
  <div style="border:1px solid #e5e7eb;border-radius:16px;padding:32px">
    <h3 style="color:#0A0F2C;font-weight:700;margin-bottom:8px">Cloud Solutions</h3>
    <p style="color:#6b7280;font-size:0.9rem">Complete cloud migration and infrastructure on AWS, Azure, and GCP. Scale effortlessly while reducing costs by up to 40%.</p>
  </div>
  <div style="border:1px solid #e5e7eb;border-radius:16px;padding:32px">
    <h3 style="color:#0A0F2C;font-weight:700;margin-bottom:8px">Cybersecurity</h3>
    <p style="color:#6b7280;font-size:0.9rem">Comprehensive security audits, penetration testing, compliance (ISO 27001), and security training to protect your digital assets.</p>
  </div>
  <div style="border:1px solid #e5e7eb;border-radius:16px;padding:32px">
    <h3 style="color:#0A0F2C;font-weight:700;margin-bottom:8px">IT Consulting</h3>
    <p style="color:#6b7280;font-size:0.9rem">Strategic technology consulting, digital roadmaps, vendor selection, and ROI analysis to drive your business forward.</p>
  </div>
  <div style="border:1px solid #e5e7eb;border-radius:16px;padding:32px">
    <h3 style="color:#0A0F2C;font-weight:700;margin-bottom:8px">Digital Transformation</h3>
    <p style="color:#6b7280;font-size:0.9rem">End-to-end modernisation: process automation, legacy migration, AI/ML integration, and data analytics for enterprises.</p>
  </div>
</div>
</section>`,
        },
        {
          title: "About Us",
          slug: "about",
          isPublished: true,
          metaTitle: "About CtrlA Tech Solutions — India's Premier Technology Partner",
          metaDescription: "Founded in 2014 in Mumbai, CtrlA Tech Solutions has grown to a 50+ expert team delivering technology solutions to 200+ clients across India and globally.",
          content: `<h2>Our Story</h2>
<p>Founded in 2014, CtrlA Tech Solutions started with a mission to democratise technology for Indian businesses. From a small startup in Mumbai, we have grown into a full-service technology company serving 200+ clients across India and beyond.</p>
<p>Our team of 50+ experts specialises in web development, mobile applications, cloud infrastructure, and digital transformation — helping businesses of all sizes navigate the digital landscape with confidence.</p>
<p>We believe technology should be accessible, scalable, and built to last. That is why every solution we deliver is crafted with precision, care, and a deep understanding of the Indian business ecosystem.</p>
<h2>Our Values</h2>
<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:24px;margin:24px 0">
  <div style="background:#f9fafb;border-radius:12px;padding:24px">
    <h3 style="color:#0A0F2C;margin-bottom:8px">Excellence</h3>
    <p style="color:#6b7280;font-size:0.9rem">We deliver world-class solutions with unmatched quality, on time and within budget.</p>
  </div>
  <div style="background:#f9fafb;border-radius:12px;padding:24px">
    <h3 style="color:#0A0F2C;margin-bottom:8px">Innovation</h3>
    <p style="color:#6b7280;font-size:0.9rem">We continuously push technological boundaries to deliver forward-thinking solutions.</p>
  </div>
  <div style="background:#f9fafb;border-radius:12px;padding:24px">
    <h3 style="color:#0A0F2C;margin-bottom:8px">Speed</h3>
    <p style="color:#6b7280;font-size:0.9rem">Rapid deployment cycles without compromising on quality or security.</p>
  </div>
  <div style="background:#f9fafb;border-radius:12px;padding:24px">
    <h3 style="color:#0A0F2C;margin-bottom:8px">Reliability</h3>
    <p style="color:#6b7280;font-size:0.9rem">Trusted by 200+ clients across India — our track record speaks for itself.</p>
  </div>
</div>
<h2>Our Leadership Team</h2>
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:24px;text-align:center;margin:24px 0">
  <div>
    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Rajesh" style="width:80px;height:80px;border-radius:50%;margin:0 auto 12px" alt="Rajesh Kumar" />
    <strong style="display:block;color:#0A0F2C">Rajesh Kumar</strong>
    <span style="color:#00C9B1;font-size:0.85rem">CEO &amp; Founder</span>
  </div>
  <div>
    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Priya" style="width:80px;height:80px;border-radius:50%;margin:0 auto 12px" alt="Priya Sharma" />
    <strong style="display:block;color:#0A0F2C">Priya Sharma</strong>
    <span style="color:#00C9B1;font-size:0.85rem">Chief Technology Officer</span>
  </div>
  <div>
    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Amit" style="width:80px;height:80px;border-radius:50%;margin:0 auto 12px" alt="Amit Patel" />
    <strong style="display:block;color:#0A0F2C">Amit Patel</strong>
    <span style="color:#00C9B1;font-size:0.85rem">Lead Developer</span>
  </div>
  <div>
    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Neha" style="width:80px;height:80px;border-radius:50%;margin:0 auto 12px" alt="Neha Singh" />
    <strong style="display:block;color:#0A0F2C">Neha Singh</strong>
    <span style="color:#00C9B1;font-size:0.85rem">Design Head</span>
  </div>
</div>`,
        },
        {
          title: "Services",
          slug: "services",
          isPublished: true,
          metaTitle: "Our Services — CtrlA Tech Solutions",
          metaDescription: "Web development, mobile apps, cloud solutions, cybersecurity, IT consulting, and digital transformation services by CtrlA Tech Solutions.",
          content: `<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:32px">
  <div style="border:1px solid #e5e7eb;border-radius:16px;padding:32px">
    <h3 style="color:#0A0F2C;font-weight:700;font-size:1.2rem;margin-bottom:12px">Web Development</h3>
    <p style="color:#6b7280;font-size:0.9rem;margin-bottom:16px">We build fast, responsive, and scalable web applications using modern frameworks like React, Next.js, and Node.js. From landing pages to complex enterprise portals.</p>
    <ul style="color:#6b7280;font-size:0.85rem;padding-left:20px">
      <li>Custom Web Applications</li>
      <li>E-Commerce Solutions</li>
      <li>CMS Development</li>
      <li>API Integration &amp; Development</li>
    </ul>
  </div>
  <div style="border:1px solid #e5e7eb;border-radius:16px;padding:32px">
    <h3 style="color:#0A0F2C;font-weight:700;font-size:1.2rem;margin-bottom:12px">Mobile App Development</h3>
    <p style="color:#6b7280;font-size:0.9rem;margin-bottom:16px">Native iOS and Android apps, or cross-platform solutions using React Native and Flutter. We create intuitive mobile experiences your users will love.</p>
    <ul style="color:#6b7280;font-size:0.85rem;padding-left:20px">
      <li>iOS &amp; Android Development</li>
      <li>Cross-Platform Apps</li>
      <li>App Store Optimisation</li>
      <li>Push Notifications &amp; Analytics</li>
    </ul>
  </div>
  <div style="border:1px solid #e5e7eb;border-radius:16px;padding:32px">
    <h3 style="color:#0A0F2C;font-weight:700;font-size:1.2rem;margin-bottom:12px">Cloud Solutions</h3>
    <p style="color:#6b7280;font-size:0.9rem;margin-bottom:16px">Complete cloud migration, infrastructure setup, and ongoing management on AWS, Azure, and GCP. Reduce costs and scale effortlessly.</p>
    <ul style="color:#6b7280;font-size:0.85rem;padding-left:20px">
      <li>Cloud Migration Strategy</li>
      <li>DevOps &amp; CI/CD Pipelines</li>
      <li>Serverless Architecture</li>
      <li>Cost Optimisation</li>
    </ul>
  </div>
  <div style="border:1px solid #e5e7eb;border-radius:16px;padding:32px">
    <h3 style="color:#0A0F2C;font-weight:700;font-size:1.2rem;margin-bottom:12px">Cybersecurity</h3>
    <p style="color:#6b7280;font-size:0.9rem;margin-bottom:16px">Protect your business from cyber threats with comprehensive security solutions. Vulnerability assessments, penetration testing, and security training.</p>
    <ul style="color:#6b7280;font-size:0.85rem;padding-left:20px">
      <li>Security Audits &amp; Assessments</li>
      <li>Penetration Testing</li>
      <li>ISO 27001 Compliance</li>
      <li>Security Awareness Training</li>
    </ul>
  </div>
  <div style="border:1px solid #e5e7eb;border-radius:16px;padding:32px">
    <h3 style="color:#0A0F2C;font-weight:700;font-size:1.2rem;margin-bottom:12px">IT Consulting</h3>
    <p style="color:#6b7280;font-size:0.9rem;margin-bottom:16px">Strategic technology consulting to help you make the right decisions. We analyse your needs and recommend the best solutions for your goals.</p>
    <ul style="color:#6b7280;font-size:0.85rem;padding-left:20px">
      <li>Technology Strategy</li>
      <li>Digital Roadmap Planning</li>
      <li>Vendor Selection &amp; Management</li>
      <li>ROI Analysis</li>
    </ul>
  </div>
  <div style="border:1px solid #e5e7eb;border-radius:16px;padding:32px">
    <h3 style="color:#0A0F2C;font-weight:700;font-size:1.2rem;margin-bottom:12px">Digital Transformation</h3>
    <p style="color:#6b7280;font-size:0.9rem;margin-bottom:16px">End-to-end digital transformation to modernise your business processes, improve efficiency, and drive competitive advantage.</p>
    <ul style="color:#6b7280;font-size:0.85rem;padding-left:20px">
      <li>Business Process Automation</li>
      <li>Legacy System Modernisation</li>
      <li>AI/ML Integration</li>
      <li>Data Analytics &amp; BI</li>
    </ul>
  </div>
</div>`,
        },
      ]);
      logger.info("Seeded: home, about, services CMS pages created");
    }

    // ── Blog categories + posts ──────────────────────────────────────────────
    const categories = await db.select().from(blogCategoriesTable).limit(1);
    let categoryId: number | null = null;
    if (categories.length === 0) {
      const [cat] = await db.insert(blogCategoriesTable).values({ name: "Technology", slug: "technology" }).returning();
      categoryId = cat.id;
      logger.info("Seeded: blog category created");
    } else {
      categoryId = categories[0].id;
    }

    const posts = await db.select().from(blogPostsTable).limit(1);
    if (posts.length === 0 && categoryId) {
      await db.insert(blogPostsTable).values({
        title: "Why Indian Businesses Need a Cloud-First Technology Strategy in 2024",
        slug: "indian-businesses-cloud-first-strategy-2024",
        excerpt: "Cloud computing is no longer optional for Indian businesses. Here is why a cloud-first approach is essential for growth, resilience, and competitive advantage.",
        content: `<h2>The Cloud Revolution in India</h2>
<p>India's digital economy is growing at an unprecedented pace. With over 900 million internet users and a rapidly expanding startup ecosystem, businesses that embrace cloud-first strategies gain a significant competitive edge.</p>
<h2>Key Benefits of Cloud Adoption</h2>
<ul>
  <li><strong>Cost Efficiency</strong> — Reduce infrastructure costs by up to 40% with pay-as-you-go cloud services.</li>
  <li><strong>Scalability</strong> — Scale your applications instantly to handle traffic spikes during festivals and sales events.</li>
  <li><strong>Security</strong> — Enterprise-grade security with compliance for Indian data localisation requirements.</li>
  <li><strong>Business Continuity</strong> — Disaster recovery and high availability built in by default.</li>
</ul>
<h2>Getting Started with Cloud</h2>
<p>At CtrlA Tech Solutions, we help businesses migrate to cloud platforms like AWS, Azure, and GCP with minimal disruption. Our cloud architects assess your current infrastructure, design a migration roadmap, and execute the transition with zero downtime.</p>
<p>Contact us today for a free cloud readiness assessment.</p>`,
        categoryId,
        isPublished: true,
        publishedAt: new Date("2024-03-15"),
        metaTitle: "Cloud-First Strategy for Indian Businesses 2024",
        metaDescription: "Why Indian businesses need a cloud-first technology strategy in 2024 — benefits, challenges, and how to get started.",
      });
      logger.info("Seeded: sample blog post created");
    }

    // ── Portfolio ─────────────────────────────────────────────────────────────
    const portfolio = await db.select().from(portfolioTable).limit(1);
    if (portfolio.length === 0) {
      await db.insert(portfolioTable).values([
        {
          title: "E-Commerce Platform for RetailKart",
          slug: "retailkart-ecommerce-platform",
          description: "Built a scalable multi-vendor e-commerce platform handling 50k+ daily transactions across 12 Indian states.",
          content: `<h2>Project Overview</h2>
<p>RetailKart needed a robust e-commerce platform to support their expansion across 12 Indian states. We delivered a cloud-native solution on AWS that handles 50,000+ daily transactions with 99.9% uptime.</p>
<h2>Technologies Used</h2>
<p>React, Node.js, PostgreSQL, AWS (ECS, RDS, CloudFront, S3), Redis, Stripe, Razorpay</p>
<h2>Results</h2>
<ul>
  <li>40% reduction in infrastructure costs vs previous on-premise setup</li>
  <li>3x faster page load times with CloudFront CDN</li>
  <li>99.9% uptime SLA achieved</li>
  <li>Supports 50,000+ daily active users</li>
</ul>`,
          clientName: "RetailKart India Pvt Ltd",
          technologies: "React, Node.js, PostgreSQL, AWS, Redis, Razorpay",
          isPublished: true,
          sortOrder: 1,
          completedAt: new Date("2023-09-30"),
        },
        {
          title: "FinTech Payment Gateway Integration",
          slug: "fintech-payment-gateway-integration",
          description: "Integrated UPI, NEFT, and IMPS payment rails for a leading NBFC, achieving PCI-DSS compliance.",
          content: `<h2>Project Overview</h2>
<p>We built a PCI-DSS compliant payment gateway supporting UPI, NEFT, IMPS, and card payments for a major NBFC serving 500,000+ customers across India.</p>
<h2>Technologies Used</h2>
<p>Node.js, Express, PostgreSQL, Redis, AWS Lambda, RDS, RazorpayX, NPCI UPI APIs</p>
<h2>Results</h2>
<ul>
  <li>PCI-DSS Level 1 compliance achieved</li>
  <li>Transaction success rate improved from 87% to 98.5%</li>
  <li>Average transaction processing time reduced to under 2 seconds</li>
  <li>Fraud detection rate improved by 65% with ML models</li>
</ul>`,
          clientName: "SecurePay NBFC",
          technologies: "Node.js, PostgreSQL, AWS Lambda, Redis, UPI APIs",
          isPublished: true,
          sortOrder: 2,
          completedAt: new Date("2024-01-15"),
        },
        {
          title: "AI-Powered HR Management System",
          slug: "ai-hr-management-system",
          description: "Developed an AI-driven HRMS for a pan-India manufacturing company with 5,000+ employees.",
          content: `<h2>Project Overview</h2>
<p>CtrlA designed and built a comprehensive HRMS with AI-based resume screening, biometric attendance automation, payroll processing, and performance management for a manufacturing company with 5,000+ employees across 8 facilities.</p>
<h2>Technologies Used</h2>
<p>React, Python, FastAPI, PostgreSQL, TensorFlow, Azure ML, Azure AD, Power BI</p>
<h2>Results</h2>
<ul>
  <li>70% reduction in time-to-hire through AI screening</li>
  <li>Payroll processing time cut from 5 days to 4 hours</li>
  <li>98% attendance tracking accuracy with biometric integration</li>
  <li>₹2.4 Cr annual savings in HR operational costs</li>
</ul>`,
          clientName: "ManufactureIndia Corp",
          technologies: "React, Python, FastAPI, PostgreSQL, TensorFlow, Azure",
          isPublished: true,
          sortOrder: 3,
          completedAt: new Date("2024-03-01"),
        },
      ]);
      logger.info("Seeded: 3 portfolio case studies created");
    }

    // ── One-time fixup: replace old placeholder contact info with real values ──
    {
      const { eq } = await import("drizzle-orm");
      const [current] = await db.select().from(siteSettingsTable).limit(1);
      if (current) {
        const fixes: Partial<Record<string, string>> = {};
        const tryFix = (enc: string | null | undefined, oldVal: string, newVal: string, key: string) => {
          try { if (enc && decryptSetting(enc) === oldVal) fixes[key] = encryptSetting(newVal); } catch {}
        };
        tryFix(current.contactPhone,  "+91 98765 43210",       "+91-9310775007",        "contactPhone");
        tryFix(current.address,        "Mumbai, Maharashtra, India", "India & United Kingdom", "address");
        tryFix(current.contactEmail,   "info@ctrlatechsolutions.com", "Info@ctrlatechsolutions.com", "contactEmail");
        if (Object.keys(fixes).length > 0) {
          await db.update(siteSettingsTable).set(fixes).where(eq(siteSettingsTable.id, current.id));
          logger.info(`Upgraded: corrected ${Object.keys(fixes).length} placeholder contact field(s)`);
        }
      }
    }

    // ── One-time fixup: clear old home-page seed content (user cleared it in CMS) ──
    {
      const { eq } = await import("drizzle-orm");
      const [homePage] = await db.select().from(pagesTable).where(eq(pagesTable.slug, "home")).limit(1);
      if (homePage && homePage.content && homePage.content.includes("Projects Delivered") && homePage.content.includes("500+")) {
        await db.update(pagesTable).set({ content: "" }).where(eq(pagesTable.slug, "home"));
        logger.info("Upgraded: cleared old home page seed content");
      }
    }

  } catch (e) {
    logger.error({ err: e }, "Seed error (non-fatal)");
  }
}

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error("PORT environment variable is required but was not provided.");
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
  runMigrations().then(() => seed());
});
