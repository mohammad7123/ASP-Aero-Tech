import { db } from "@workspace/db";
import {
  adminUsersTable, siteSettingsTable, pagesTable, menuItemsTable,
  blogPostsTable, portfolioTable, heroSlidesTable
} from "@workspace/db/schema";
import bcrypt from "bcryptjs";
import crypto from "crypto";
import { encryptSetting } from "./lib/settingsEncryption";

async function seed() {
  console.log("Seeding database...");

  const existing = await db.select().from(adminUsersTable).limit(1);
  if (existing.length === 0) {
    const password = process.env.ADMIN_PASSWORD ?? crypto.randomBytes(16).toString("hex");
    const hash = await bcrypt.hash(password, 10);
    await db.insert(adminUsersTable).values({ username: "admin", passwordHash: hash, email: "admin@ctrlatechsolutions.com", role: "admin" });
    if (!process.env.ADMIN_PASSWORD) {
      console.log(`[seed] Admin created — username: admin  password: ${password}  (set ADMIN_PASSWORD env var to use a fixed password)`);
    } else {
      console.log("[seed] Admin user created with ADMIN_PASSWORD from environment.");
    }
  } else {
    console.log("[seed] Admin user already exists, skipping.");
  }

  const settings = await db.select().from(siteSettingsTable).limit(1);
  if (settings.length === 0) {
    const e = encryptSetting;
    await db.insert(siteSettingsTable).values({
      siteName: e("CtrlA Tech Solutions"),
      tagline: e("Innovating the Future of Technology"),
      primaryColor: e("#D4920C"),
      accentColor: e("#1A1F36"),
      backgroundColor: e("#ffffff"),
      fontFamily: e("Inter"),
      contactEmail: e("Info@ctrlatechsolutions.com"),
      contactPhone: e("+91-9310775007"),
      contactPhone2: e("+44-7557035271"),
      address: e("India & United Kingdom"),
      whatsappNumber: e("919310775007"),
      whatsappGreeting: e("Hello! How can we help you?"),
      chatbotEnabled: false,
      chatbotName: e("CtrlA Bot"),
      chatbotGreeting: e("Hi! I'm CtrlA Bot. How can I assist you today?"),
    });
    console.log("[seed] Created site settings (encrypted)");
  }

  const pages = await db.select().from(pagesTable).limit(1);
  if (pages.length === 0) {
    await db.insert(pagesTable).values([
      {
        title: "Home", slug: "home", isPublished: true, sortOrder: 0,
        content: "<h2>Welcome to CtrlA Tech Solutions</h2><p>Your trusted technology partner in India. We build innovative web and mobile applications, cloud solutions, and IT consulting services for businesses of all sizes.</p>",
        metaTitle: "CtrlA Tech Solutions — India's Premier Tech Partner",
        metaDescription: "CtrlA Tech Solutions delivers cutting-edge IT services that empower businesses to scale, innovate, and lead in the digital era.",
      },
      {
        title: "About Us", slug: "about", isPublished: true, sortOrder: 1,
        content: "<h2>About CtrlA Tech Solutions</h2><p>We are a premier technology solutions company based in India & UK, dedicated to providing cutting-edge IT services and solutions since 2014.</p><p>Our team of 50+ experts specialises in SAP ERP, web development, mobile applications, cloud infrastructure, and digital transformation, helping businesses navigate the digital landscape with confidence.</p>",
        metaTitle: "About Us — CtrlA Tech Solutions",
        metaDescription: "Learn about CtrlA Tech Solutions — India's premier technology partner with 10+ years of experience delivering innovative IT solutions.",
      },
      {
        title: "Services", slug: "services", isPublished: true, sortOrder: 2,
        content: "<h2>Our Services</h2><p>We offer comprehensive technology solutions including web development, mobile apps, cloud computing, cybersecurity, and IT consulting — all tailored to accelerate your business growth.</p>",
        metaTitle: "Our Services — CtrlA Tech Solutions",
        metaDescription: "Comprehensive technology solutions: web development, mobile apps, cloud computing, cybersecurity and IT consulting from CtrlA Tech Solutions.",
      },
      {
        title: "Contact", slug: "contact", isPublished: true, sortOrder: 3,
        content: "<h2>Contact Us</h2><p>Get in touch with our team for all your technology needs. We're ready to help you build the future.</p>",
        metaTitle: "Contact Us — CtrlA Tech Solutions",
        metaDescription: "Contact CtrlA Tech Solutions for SAP ERP, web development, mobile apps, cloud solutions, and IT consulting in India.",
      },
    ]);
    console.log("Created default pages");
  }

  const menu = await db.select().from(menuItemsTable).limit(1);
  if (menu.length === 0) {
    await db.insert(menuItemsTable).values([
      { label: "Home", url: "/", sortOrder: 0, isVisible: true },
      { label: "About", url: "/about", sortOrder: 1, isVisible: true },
      { label: "Services", url: "/services", sortOrder: 2, isVisible: true },
      { label: "Products", url: "/products", sortOrder: 3, isVisible: true },
      { label: "Portfolio", url: "/portfolio", sortOrder: 4, isVisible: true },
      { label: "Blog", url: "/blog", sortOrder: 5, isVisible: true },
      { label: "Contact", url: "/contact", sortOrder: 6, isVisible: true },
    ]);
    console.log("Created default menu items");
  }

  const slides = await db.select().from(heroSlidesTable).limit(1);
  if (slides.length === 0) {
    await db.insert(heroSlidesTable).values([
      {
        title: "Innovating the Future of Technology",
        subtitle: "End-to-end SAP ERP, cloud, AI, and digital transformation solutions for businesses across India and the UK.",
        imageUrl: "/home-banner.jpg",
        ctaText: "Get Started",
        ctaUrl: "/contact",
        sortOrder: 0,
        isActive: true,
      },
      {
        title: "SAP Business One & ERP Solutions",
        subtitle: "Streamline operations with SAP Business One, S/4 HANA, and 19+ specialized SAP add-ons tailored for your industry.",
        imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1920&q=80",
        ctaText: "Explore ERP",
        ctaUrl: "/products/erp",
        sortOrder: 1,
        isActive: true,
      },
      {
        title: "AI-Powered Business Intelligence",
        subtitle: "Transform your business with cutting-edge AI solutions — from demand forecasting to intelligent document processing.",
        imageUrl: "https://images.unsplash.com/photo-1677442135703-1787eea5ce01?auto=format&fit=crop&w=1920&q=80",
        ctaText: "Discover AI Solutions",
        ctaUrl: "/products/ai-solutions",
        sortOrder: 2,
        isActive: true,
      },
      {
        title: "Cloud & Integration Platform",
        subtitle: "Move to the cloud with confidence. Managed AWS & Azure hosting, backup, high availability, and 360° integration suite.",
        imageUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1920&q=80",
        ctaText: "View Cloud Solutions",
        ctaUrl: "/products/cloud-platforms",
        sortOrder: 3,
        isActive: true,
      },
    ]);
    console.log("[seed] Created default hero slides");
  }

  const posts = await db.select().from(blogPostsTable).limit(1);
  if (posts.length === 0) {
    await db.insert(blogPostsTable).values([
      {
        title: "Why Indian Businesses Need Cloud-First Technology Strategy",
        slug: "indian-businesses-cloud-first-strategy",
        excerpt: "Cloud computing is no longer optional for Indian businesses. Here's why a cloud-first approach is essential for growth in 2024.",
        content: `<h2>The Cloud Revolution in India</h2>
<p>India's digital economy is growing at an unprecedented pace. With over 900 million internet users and a rapidly expanding startup ecosystem, businesses that embrace cloud-first strategies gain a significant competitive edge.</p>
<h2>Key Benefits of Cloud Adoption</h2>
<ul>
<li><strong>Cost Efficiency</strong> — Reduce infrastructure costs by up to 40% with pay-as-you-go cloud services.</li>
<li><strong>Scalability</strong> — Scale your applications instantly to handle traffic spikes during festive seasons or product launches.</li>
<li><strong>Security</strong> — Enterprise-grade security with compliance for Indian data localisation requirements.</li>
<li><strong>Remote Work</strong> — Enable distributed teams across India with secure, collaborative cloud environments.</li>
</ul>
<h2>Getting Started</h2>
<p>At CtrlA Tech Solutions, we help businesses migrate to cloud platforms like AWS, Azure, and GCP with minimal disruption. Our cloud architects design solutions optimised for Indian internet conditions and regulatory requirements.</p>
<p>Ready to move to the cloud? <a href="/contact">Contact our team</a> for a free cloud readiness assessment.</p>`,
        isPublished: true,
        publishedAt: new Date("2024-03-15"),
        metaTitle: "Cloud-First Strategy for Indian Businesses — CtrlA Tech Solutions",
        metaDescription: "Why Indian businesses need a cloud-first technology strategy in 2024. Cost savings, scalability, and competitive advantage.",
      },
    ]);
    console.log("Created sample blog post");
  }

  const portfolio = await db.select().from(portfolioTable).limit(1);
  if (portfolio.length === 0) {
    await db.insert(portfolioTable).values([
      {
        title: "E-Commerce Platform for Fashion Brand",
        slug: "fashion-ecommerce-platform",
        description: "A scalable e-commerce platform handling 50,000+ daily orders with real-time inventory management.",
        content: `<h2>Project Overview</h2>
<p>We built a high-performance e-commerce platform for a leading Indian fashion brand, replacing their legacy system with a modern, scalable architecture.</p>
<h2>Results</h2>
<ul>
<li>99.99% uptime during peak events</li>
<li>3x improvement in page load speed</li>
<li>40% increase in mobile conversions</li>
</ul>`,
        clientName: "FashionHub India",
        technologies: "React, Node.js, AWS, PostgreSQL, Redis",
        isPublished: true,
        sortOrder: 0,
        completedAt: new Date("2023-11-01"),
      },
    ]);
    console.log("Created sample portfolio items");
  }

  console.log("Seeding complete!");
  process.exit(0);
}

seed().catch(e => { console.error(e); process.exit(1); });
