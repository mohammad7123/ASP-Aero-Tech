import { Router, type IRouter, type Request, type Response } from "express";
import jwt from "jsonwebtoken";

const router: IRouter = Router();

function getCaptchaSecret(): string {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error("JWT_SECRET not set");
  return secret;
}

export function verifyCaptchaToken(
  token: string | undefined,
  answer: string | number | undefined
): boolean {
  if (!token || answer === undefined || answer === null || String(answer).trim() === "") return false;
  try {
    const payload = jwt.verify(token, getCaptchaSecret()) as { ca: number; type: string };
    if (payload.type !== "captcha") return false;
    return payload.ca === Number(answer);
  } catch {
    return false;
  }
}

router.get("/public/captcha", (_req: Request, res: Response) => {
  const a = Math.floor(Math.random() * 9) + 1;
  const b = Math.floor(Math.random() * 9) + 1;
  const useAdd = Math.random() > 0.5;
  const [x, y] = useAdd ? [a, b] : [Math.max(a, b), Math.min(a, b)];
  const answer = useAdd ? x + y : x - y;
  const question = `What is ${x} ${useAdd ? "+" : "-"} ${y}?`;
  const token = jwt.sign({ ca: answer, type: "captcha" }, getCaptchaSecret(), { expiresIn: "10m" });
  res.json({ question, token });
});

export default router;
