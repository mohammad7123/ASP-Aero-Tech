import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { pagesTable, blogPostsTable, portfolioTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";

const router: IRouter = Router();
const PUBLIC_SITE_URL = "https://www.ctrlatechsolutions.com";

const STATIC_ROUTES: Array<{ path: string; priority: string }> = [
  { path: "/",                             priority: "1.0" },
  { path: "/about",                        priority: "0.8" },
  { path: "/services",                     priority: "0.8" },
  { path: "/services/erp-solutions",       priority: "0.7" },
  { path: "/services/web-development",     priority: "0.7" },
  { path: "/services/mobile-apps",         priority: "0.7" },
  { path: "/services/custom-software",     priority: "0.7" },
  { path: "/services/cloud-solutions",     priority: "0.7" },
  { path: "/services/cybersecurity",       priority: "0.7" },
  { path: "/services/it-consulting",       priority: "0.7" },
  { path: "/services/digital-marketing",  priority: "0.7" },
  { path: "/products",                     priority: "0.8" },
  { path: "/products/erp",                 priority: "0.7" },
  { path: "/products/business-apps",       priority: "0.7" },
  { path: "/products/ai-solutions",        priority: "0.7" },
  { path: "/products/cloud-platforms",     priority: "0.7" },
  { path: "/products/integration-suite",   priority: "0.7" },
  { path: "/portfolio",                    priority: "0.8" },
  { path: "/blog",                         priority: "0.7" },
  { path: "/industries",                   priority: "0.7" },
  { path: "/wms360",                       priority: "0.7" },
  { path: "/myhrone",                      priority: "0.7" },
  { path: "/sap-business-one",             priority: "0.7" },
  { path: "/sap-business-one-hana",        priority: "0.7" },
  { path: "/sap-b1-on-cloud",             priority: "0.7" },
  { path: "/rise-with-sap",               priority: "0.7" },
  { path: "/s4-hana",                     priority: "0.7" },
  { path: "/support-service",             priority: "0.7" },
  { path: "/b1plus-cloud",               priority: "0.7" },
  { path: "/careers",                     priority: "0.6" },
  { path: "/clients",                     priority: "0.6" },
  { path: "/become-a-partner",           priority: "0.6" },
  { path: "/contact",                     priority: "0.7" },
  { path: "/technologies",                priority: "0.7" },
  { path: "/technologies/microsoft",      priority: "0.7" },
  { path: "/technologies/open-source",    priority: "0.7" },
  { path: "/technologies/mobile",         priority: "0.7" },
  { path: "/technologies/frontend",       priority: "0.7" },
  { path: "/technologies/big-data",       priority: "0.7" },
  { path: "/technologies/java",           priority: "0.7" },
  { path: "/technologies/ai-ml-data-science", priority: "0.7" },
  { path: "/technologies/async-messaging", priority: "0.7" },
  { path: "/technologies/erp-solutions",  priority: "0.7" },
];

router.get("/sitemap.xml", async (req: Request, res: Response) => {
  // Always emit an absolute, public URL. A proxy or local preview can expose
  // an internal host such as localhost, which would make the sitemap useless
  // to search engines if it leaked into production.
  const configuredUrl = process.env.PUBLIC_URL?.trim().replace(/\/+$/, "");
  const baseUrl = configuredUrl || PUBLIC_SITE_URL;

  const [pages, posts, portfolio] = await Promise.all([
    db.select({ slug: pagesTable.slug, updatedAt: pagesTable.updatedAt })
      .from(pagesTable)
      .where(eq(pagesTable.isPublished, true)),
    db.select({ slug: blogPostsTable.slug, updatedAt: blogPostsTable.updatedAt })
      .from(blogPostsTable)
      .where(eq(blogPostsTable.isPublished, true)),
    db.select({ slug: portfolioTable.slug, updatedAt: portfolioTable.updatedAt })
      .from(portfolioTable)
      .where(eq(portfolioTable.isPublished, true)),
  ]);

  const staticUrls = STATIC_ROUTES.map(r => ({
    loc: `${baseUrl}${r.path}`,
    priority: r.priority,
  }));

  const pageUrls = pages.map(p => ({
    loc: `${baseUrl}/${p.slug}`,
    lastmod: p.updatedAt.toISOString().split("T")[0],
    priority: "0.6",
  }));

  const postUrls = posts.map(p => ({
    loc: `${baseUrl}/blog/${p.slug}`,
    lastmod: p.updatedAt.toISOString().split("T")[0],
    priority: "0.6",
  }));

  const portfolioUrls = portfolio.map(p => ({
    loc: `${baseUrl}/portfolio/${p.slug}`,
    lastmod: p.updatedAt.toISOString().split("T")[0],
    priority: "0.7",
  }));

  const allUrls = [...staticUrls, ...pageUrls, ...postUrls, ...portfolioUrls];

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${allUrls.map(u => `  <url>
    <loc>${u.loc}</loc>${"lastmod" in u ? `\n    <lastmod>${u.lastmod}</lastmod>` : ""}
    <priority>${u.priority}</priority>
  </url>`).join("\n")}
</urlset>`;

  res.setHeader("Content-Type", "application/xml");
  res.send(xml);
});

export default router;
