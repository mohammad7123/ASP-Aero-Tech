import { Router, type IRouter, type Request, type Response } from "express";
import bcrypt from "bcryptjs";
import { db } from "@workspace/db";
import { adminUsersTable } from "@workspace/db/schema";
import { eq, asc, ne } from "drizzle-orm";
import { requireAdmin, type AuthRequest } from "../middlewares/auth";

const router: IRouter = Router();

const mapUser = (u: typeof adminUsersTable.$inferSelect) => ({
  id: u.id,
  username: u.username,
  email: u.email ?? null,
  role: u.role,
  createdAt: u.createdAt.toISOString(),
  updatedAt: u.updatedAt.toISOString(),
});

router.get("/admin/users", requireAdmin, async (_req: Request, res: Response) => {
  const users = await db.select().from(adminUsersTable).orderBy(asc(adminUsersTable.createdAt));
  res.json(users.map(mapUser));
});

router.post("/admin/users", requireAdmin, async (req: Request, res: Response) => {
  const { username, password, email, role } = req.body ?? {};
  if (!username || !password) {
    res.status(400).json({ error: "username and password required" });
    return;
  }
  const validRole = role === "admin" ? "admin" : "user";
  const passwordHash = await bcrypt.hash(password, 10);
  try {
    const [user] = await db.insert(adminUsersTable).values({
      username,
      passwordHash,
      email: email || null,
      role: validRole,
    }).returning();
    res.status(201).json(mapUser(user));
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes("unique")) {
      res.status(409).json({ error: "Username already exists" });
    } else {
      res.status(500).json({ error: "Failed to create user" });
    }
  }
});

router.patch("/admin/users/:id", requireAdmin, async (req: AuthRequest, res: Response) => {
  const id = Number(req.params.id);
  const { email, role, password, username } = req.body ?? {};
  const upd: Record<string, unknown> = {};
  if (username !== undefined) upd.username = username;
  if (email !== undefined) upd.email = email || null;
  if (role !== undefined) upd.role = role === "admin" ? "admin" : "user";
  if (password) upd.passwordHash = await bcrypt.hash(password, 10);
  if (Object.keys(upd).length === 0) {
    res.status(400).json({ error: "Nothing to update" });
    return;
  }
  const [user] = await db.update(adminUsersTable).set(upd).where(eq(adminUsersTable.id, id)).returning();
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  res.json(mapUser(user));
});

router.delete("/admin/users/:id", requireAdmin, async (req: AuthRequest, res: Response) => {
  const id = Number(req.params.id);
  if (id === req.adminId) {
    res.status(400).json({ error: "Cannot delete your own account" });
    return;
  }
  await db.delete(adminUsersTable).where(eq(adminUsersTable.id, id));
  res.status(204).send();
});

export default router;
