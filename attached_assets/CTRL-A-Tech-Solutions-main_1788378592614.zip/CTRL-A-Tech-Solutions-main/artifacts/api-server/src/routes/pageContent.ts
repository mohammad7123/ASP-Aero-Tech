import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { pageContentTable } from "@workspace/db/schema";
import { eq, and } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

type BlocksMap = Record<string, string>;

async function loadBlocks(slug: string): Promise<BlocksMap> {
  const rows = await db.select().from(pageContentTable).where(eq(pageContentTable.pageSlug, slug));
  const map: BlocksMap = {};
  for (const row of rows) map[row.blockKey] = row.value;
  return map;
}

// Public: fetch content overrides for a page slug.
router.get("/pages/:slug/content", async (req: Request, res: Response) => {
  const slug = String(req.params.slug);
  try {
    const blocks = await loadBlocks(slug);
    res.json({ slug, blocks });
  } catch (err) {
    console.error("[pageContent] failed to load blocks for", slug, err);
    res.status(500).json({ error: "failed to load page content" });
  }
});

// Admin: fetch content overrides for a page slug.
router.get("/admin/pages/:slug/content", requireAuth, async (req: Request, res: Response) => {
  const slug = String(req.params.slug);
  const blocks = await loadBlocks(slug);
  res.json({ slug, blocks });
});

// Admin: bulk upsert content overrides. Empty/blank values delete the override
// so the page falls back to its built-in default.
router.put("/admin/pages/:slug/content", requireAuth, async (req: Request, res: Response) => {
  const slug = String(req.params.slug);
  const body = req.body as { blocks?: Record<string, unknown> };
  if (!body || typeof body.blocks !== "object" || body.blocks === null) {
    res.status(400).json({ error: "blocks object required" });
    return;
  }

  for (const [key, rawValue] of Object.entries(body.blocks)) {
    const value = typeof rawValue === "string" ? rawValue : rawValue == null ? "" : String(rawValue);
    if (value.trim() === "") {
      await db.delete(pageContentTable)
        .where(and(eq(pageContentTable.pageSlug, slug), eq(pageContentTable.blockKey, key)));
    } else {
      await db.insert(pageContentTable)
        .values({ pageSlug: slug, blockKey: key, value })
        .onConflictDoUpdate({
          target: [pageContentTable.pageSlug, pageContentTable.blockKey],
          set: { value, updatedAt: new Date() },
        });
    }
  }

  const blocks = await loadBlocks(slug);
  res.json({ slug, blocks });
});

export default router;
