import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { contactInquiriesTable, siteSettingsTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import { SubmitContactBody, ListContactsResponse, MarkContactReadResponse } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/auth";
import nodemailer from "nodemailer";
import { decryptSetting, isEncrypted } from "../lib/settingsEncryption";
import { verifyCaptchaToken } from "./captcha";
const router: IRouter = Router();

function decryptIfNeeded(value: string | null | undefined): string | null {
  if (!value) return null;
  try {
    return isEncrypted(value) ? decryptSetting(value) : value;
  } catch {
    return value;
  }
}

const mapContact = (c: typeof contactInquiriesTable.$inferSelect) => ({
  id: c.id,
  name: c.name,
  email: c.email,
  phone: c.phone,
  subject: c.subject,
  message: c.message,
  isRead: c.isRead,
  createdAt: c.createdAt.toISOString(),
});

async function handleContactSubmit(req: Request, res: Response) {
  if (!verifyCaptchaToken(req.body?.captchaToken, req.body?.captchaAnswer)) {
    res.status(400).json({ error: "Security check failed. Please answer the math question correctly." });
    return;
  }
  const parsed = SubmitContactBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid body", details: parsed.error.flatten() }); return; }
  const [contact] = await db.insert(contactInquiriesTable).values(parsed.data).returning();

  try {
    const [settings] = await db.select().from(siteSettingsTable).limit(1);
    if (settings?.smtpHost && settings.smtpUser && settings.smtpPassword && settings.contactEmail) {
      const plainHost = decryptIfNeeded(settings.smtpHost);
      const plainUser = decryptIfNeeded(settings.smtpUser);
      const plainPassword = decryptIfNeeded(settings.smtpPassword);
      const plainFrom = decryptIfNeeded(settings.smtpFrom);
      const plainContactEmail = decryptIfNeeded(settings.contactEmail);
      if (plainHost && plainUser && plainPassword && plainContactEmail) {
        const transporter = nodemailer.createTransport({
          host: plainHost,
          port: settings.smtpPort ?? 587,
          auth: { user: plainUser, pass: plainPassword },
        });
        await transporter.sendMail({
          from: plainFrom ?? plainUser,
          to: plainContactEmail,
          subject: `New Contact: ${contact.subject ?? contact.name}`,
          text: `Name: ${contact.name}\nEmail: ${contact.email}\nPhone: ${contact.phone ?? '-'}\n\n${contact.message}`,
        });
      }
    }
  } catch (err) {
    req.log.warn({ err }, "Failed to send contact email notification");
  }

  res.status(201).json(mapContact(contact));
}

router.post("/public/contacts", handleContactSubmit);

router.post("/contact", handleContactSubmit);

router.get("/admin/contacts", requireAuth, async (_req: Request, res: Response) => {
  const rows = await db.select().from(contactInquiriesTable).orderBy(contactInquiriesTable.createdAt);
  res.json(ListContactsResponse.parse(rows.map(mapContact)));
});

router.patch("/admin/contacts/:id/read", requireAuth, async (req: Request, res: Response) => {
  const [contact] = await db.update(contactInquiriesTable).set({ isRead: true }).where(eq(contactInquiriesTable.id, Number(req.params.id))).returning();
  if (!contact) { res.status(404).json({ error: "Not found" }); return; }
  res.json(MarkContactReadResponse.parse(mapContact(contact)));
});

router.delete("/admin/contacts/:id", requireAuth, async (req: Request, res: Response) => {
  await db.delete(contactInquiriesTable).where(eq(contactInquiriesTable.id, Number(req.params.id)));
  res.status(204).send();
});

export default router;
