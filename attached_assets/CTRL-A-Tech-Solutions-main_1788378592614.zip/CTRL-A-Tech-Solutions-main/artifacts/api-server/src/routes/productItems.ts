import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { productItemsTable } from "@workspace/db/schema";
import { eq, asc, and, gt, lt, desc } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

type UpsertBody = {
  category?: string;
  name?: string;
  slug?: string;
  shortDesc?: string;
  description?: string;
  imageUrl?: string | null;
  iconName?: string;
  accentColor?: string;
  sortOrder?: number;
  isActive?: boolean;
};

const mapItem = (item: typeof productItemsTable.$inferSelect) => ({
  id: item.id,
  category: item.category,
  name: item.name,
  slug: item.slug,
  shortDesc: item.shortDesc,
  description: item.description,
  imageUrl: item.imageUrl,
  iconName: item.iconName,
  accentColor: item.accentColor,
  sortOrder: item.sortOrder,
  isActive: item.isActive,
  createdAt: item.createdAt.toISOString(),
  updatedAt: item.updatedAt.toISOString(),
});

router.get("/public/product-items", async (req: Request, res: Response) => {
  const { category } = req.query;
  const rows = category
    ? await db.select().from(productItemsTable)
        .where(and(eq(productItemsTable.category, String(category)), eq(productItemsTable.isActive, true)))
        .orderBy(asc(productItemsTable.sortOrder))
    : await db.select().from(productItemsTable)
        .where(eq(productItemsTable.isActive, true))
        .orderBy(asc(productItemsTable.category), asc(productItemsTable.sortOrder));
  res.json(rows.map(mapItem));
});

router.get("/admin/product-items", requireAuth, async (req: Request, res: Response) => {
  const { category } = req.query;
  const rows = category
    ? await db.select().from(productItemsTable)
        .where(eq(productItemsTable.category, String(category)))
        .orderBy(asc(productItemsTable.sortOrder))
    : await db.select().from(productItemsTable)
        .orderBy(asc(productItemsTable.category), asc(productItemsTable.sortOrder));
  res.json(rows.map(mapItem));
});

router.post("/admin/product-items", requireAuth, async (req: Request, res: Response) => {
  const body = req.body as UpsertBody;
  if (!body.category || !body.name) { res.status(400).json({ error: "category and name required" }); return; }
  const slug = body.slug || body.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  const [item] = await db.insert(productItemsTable).values({
    category: body.category,
    name: body.name,
    slug,
    shortDesc: body.shortDesc ?? "",
    description: body.description ?? "",
    imageUrl: body.imageUrl ?? null,
    iconName: body.iconName ?? "Package",
    accentColor: body.accentColor ?? "#D4920C",
    sortOrder: body.sortOrder ?? 0,
    isActive: body.isActive ?? true,
  }).returning();
  res.status(201).json(mapItem(item));
});

router.patch("/admin/product-items/:id", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const body = req.body as UpsertBody;
  const upd: Record<string, unknown> = {};
  if (body.name !== undefined) upd.name = body.name;
  if (body.slug !== undefined) upd.slug = body.slug;
  if (body.category !== undefined) upd.category = body.category;
  if (body.shortDesc !== undefined) upd.shortDesc = body.shortDesc;
  if (body.description !== undefined) upd.description = body.description;
  if ("imageUrl" in body) upd.imageUrl = body.imageUrl ?? null;
  if (body.iconName !== undefined) upd.iconName = body.iconName;
  if (body.accentColor !== undefined) upd.accentColor = body.accentColor;
  if (body.sortOrder !== undefined) upd.sortOrder = body.sortOrder;
  if (body.isActive !== undefined) upd.isActive = body.isActive;
  const [item] = await db.update(productItemsTable).set(upd).where(eq(productItemsTable.id, id)).returning();
  if (!item) { res.status(404).json({ error: "Not found" }); return; }
  res.json(mapItem(item));
});

router.delete("/admin/product-items/:id", requireAuth, async (req: Request, res: Response) => {
  await db.delete(productItemsTable).where(eq(productItemsTable.id, Number(req.params.id)));
  res.status(204).send();
});

router.post("/admin/product-items/:id/move", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const direction = req.body?.direction === "up" ? "up" : "down";
  const [me] = await db.select().from(productItemsTable).where(eq(productItemsTable.id, id));
  if (!me) { res.status(404).json({ error: "Not found" }); return; }
  // Move within the same category
  const sameCategoryFilter = eq(productItemsTable.category, me.category);
  const neighbors = direction === "up"
    ? await db.select().from(productItemsTable)
        .where(and(sameCategoryFilter, lt(productItemsTable.sortOrder, me.sortOrder)))
        .orderBy(desc(productItemsTable.sortOrder)).limit(1)
    : await db.select().from(productItemsTable)
        .where(and(sameCategoryFilter, gt(productItemsTable.sortOrder, me.sortOrder)))
        .orderBy(asc(productItemsTable.sortOrder)).limit(1);
  let neighbor = neighbors[0];
  if (!neighbor) {
    const ties = await db.select().from(productItemsTable).where(and(sameCategoryFilter, eq(productItemsTable.sortOrder, me.sortOrder), direction === "up" ? lt(productItemsTable.id, me.id) : gt(productItemsTable.id, me.id)));
    neighbor = direction === "up" ? ties[ties.length - 1] : ties[0];
  }
  if (!neighbor) { res.json({ ok: true, moved: false }); return; }
  await db.update(productItemsTable).set({ sortOrder: neighbor.sortOrder }).where(eq(productItemsTable.id, me.id));
  await db.update(productItemsTable).set({ sortOrder: me.sortOrder }).where(eq(productItemsTable.id, neighbor.id));
  res.json({ ok: true, moved: true });
});

export default router;
