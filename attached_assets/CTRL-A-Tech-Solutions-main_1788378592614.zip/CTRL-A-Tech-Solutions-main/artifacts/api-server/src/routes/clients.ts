import { Router, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { clientsTable } from "@workspace/db/schema";
import { eq, asc } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router = Router();

const mapClient = (c: typeof clientsTable.$inferSelect) => ({
  id: c.id,
  name: c.name,
  logoUrl: c.logoUrl,
  websiteUrl: c.websiteUrl,
  industry: c.industry,
  testimonial: c.testimonial,
  testimonialPerson: c.testimonialPerson,
  testimonialRole: c.testimonialRole,
  sortOrder: c.sortOrder,
  isActive: c.isActive,
  createdAt: c.createdAt,
  updatedAt: c.updatedAt,
});

router.get("/public/clients", async (_req: Request, res: Response) => {
  const rows = await db.select().from(clientsTable)
    .where(eq(clientsTable.isActive, true))
    .orderBy(asc(clientsTable.sortOrder), asc(clientsTable.id));
  res.json(rows.map(mapClient));
});

router.get("/admin/clients", requireAuth, async (_req: Request, res: Response) => {
  const rows = await db.select().from(clientsTable)
    .orderBy(asc(clientsTable.sortOrder), asc(clientsTable.id));
  res.json(rows.map(mapClient));
});

router.post("/admin/clients", requireAuth, async (req: Request, res: Response) => {
  const { name, logoUrl, websiteUrl, industry, testimonial, testimonialPerson, testimonialRole, sortOrder, isActive } = req.body;
  if (!name) { res.status(400).json({ error: "name is required" }); return; }
  const [row] = await db.insert(clientsTable).values({
    name,
    logoUrl: logoUrl || null,
    websiteUrl: websiteUrl || null,
    industry: industry || null,
    testimonial: testimonial || null,
    testimonialPerson: testimonialPerson || null,
    testimonialRole: testimonialRole || null,
    sortOrder: sortOrder ?? 0,
    isActive: isActive ?? true,
  }).returning();
  res.json(mapClient(row));
});

router.patch("/admin/clients/:id", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const upd: Record<string, unknown> = {};
  const fields = ["name", "logoUrl", "websiteUrl", "industry", "testimonial", "testimonialPerson", "testimonialRole", "sortOrder", "isActive"];
  for (const f of fields) {
    if (req.body[f] !== undefined) upd[f] = req.body[f] === "" ? null : req.body[f];
  }
  const [row] = await db.update(clientsTable).set(upd).where(eq(clientsTable.id, id)).returning();
  if (!row) { res.status(404).json({ error: "Not found" }); return; }
  res.json(mapClient(row));
});

router.delete("/admin/clients/:id", requireAuth, async (req: Request, res: Response) => {
  await db.delete(clientsTable).where(eq(clientsTable.id, Number(req.params.id)));
  res.status(204).end();
});

export default router;
