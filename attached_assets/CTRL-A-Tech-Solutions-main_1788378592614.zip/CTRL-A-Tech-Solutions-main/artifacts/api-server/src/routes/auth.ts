import { Router, type IRouter, type Request, type Response } from "express";
import bcrypt from "bcryptjs";
import { db } from "@workspace/db";
import { adminUsersTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import { requireAuth, signToken, type AuthRequest } from "../middlewares/auth";
import { verifyCaptchaToken } from "./captcha";

const router: IRouter = Router();

router.post("/auth/login", async (req: Request, res: Response) => {
  const { username, password, captchaToken, captchaAnswer } = req.body ?? {};
  if (!username || !password) {
    res.status(400).json({ error: "Username and password required" });
    return;
  }
  if (!verifyCaptchaToken(captchaToken, captchaAnswer)) {
    res.status(400).json({ error: "Security check failed. Please answer the math question correctly." });
    return;
  }
  const [user] = await db.select().from(adminUsersTable).where(eq(adminUsersTable.username, username)).limit(1);
  if (!user) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }
  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }
  const token = signToken({ id: user.id, username: user.username, role: user.role });
  res.json({
    token,
    user: {
      id: user.id,
      username: user.username,
      email: user.email ?? null,
      role: user.role,
      createdAt: user.createdAt.toISOString(),
    },
  });
});

router.post("/auth/logout", (_req: Request, res: Response) => {
  res.json({ message: "Logged out successfully" });
});

router.get("/auth/me", requireAuth, async (req: AuthRequest, res: Response) => {
  const [user] = await db.select().from(adminUsersTable).where(eq(adminUsersTable.id, req.adminId!)).limit(1);
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  res.json({
    id: user.id,
    username: user.username,
    email: user.email ?? null,
    role: user.role,
    createdAt: user.createdAt.toISOString(),
  });
});

export default router;
