import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { heroSlidesTable } from "@workspace/db/schema";
import { eq, asc } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

type CreateSlideBody = {
  title: string;
  eyebrow?: string | null;
  subtitle?: string | null;
  imageUrl: string;
  ctaText?: string | null;
  ctaUrl?: string | null;
  stat1?: string | null;
  stat2?: string | null;
  stat3?: string | null;
  badge?: string | null;
  sortOrder?: number;
  isActive?: boolean;
};
type UpdateSlideBody = Partial<CreateSlideBody>;
type ReorderBody = { ids: number[] };

const mapSlide = (s: typeof heroSlidesTable.$inferSelect) => ({
  id: s.id,
  eyebrow: s.eyebrow,
  title: s.title,
  subtitle: s.subtitle,
  imageUrl: s.imageUrl,
  ctaText: s.ctaText,
  ctaUrl: s.ctaUrl,
  stat1: s.stat1,
  stat2: s.stat2,
  stat3: s.stat3,
  badge: s.badge,
  sortOrder: s.sortOrder,
  isActive: s.isActive,
  createdAt: s.createdAt.toISOString(),
  updatedAt: s.updatedAt.toISOString(),
});

router.get("/admin/slides", requireAuth, async (_req: Request, res: Response) => {
  const rows = await db.select().from(heroSlidesTable).orderBy(asc(heroSlidesTable.sortOrder));
  res.json(rows.map(mapSlide));
});

router.get("/public/hero-slides", async (_req: Request, res: Response) => {
  const rows = await db.select().from(heroSlidesTable)
    .where(eq(heroSlidesTable.isActive, true))
    .orderBy(asc(heroSlidesTable.sortOrder));
  res.json(rows.map(mapSlide));
});

router.post("/admin/slides", requireAuth, async (req: Request, res: Response) => {
  const body = req.body as CreateSlideBody;
  if (!body.title || !body.imageUrl) { res.status(400).json({ error: "title and imageUrl required" }); return; }
  const [slide] = await db.insert(heroSlidesTable).values({
    eyebrow: body.eyebrow ?? null,
    title: body.title,
    subtitle: body.subtitle ?? null,
    imageUrl: body.imageUrl,
    ctaText: body.ctaText ?? null,
    ctaUrl: body.ctaUrl ?? null,
    stat1: body.stat1 ?? null,
    stat2: body.stat2 ?? null,
    stat3: body.stat3 ?? null,
    badge: body.badge ?? null,
    sortOrder: body.sortOrder ?? 0,
    isActive: body.isActive ?? true,
  }).returning();
  res.status(201).json(mapSlide(slide));
});

router.put("/admin/slides/reorder", requireAuth, async (req: Request, res: Response) => {
  const body = req.body as ReorderBody;
  if (!Array.isArray(body.ids)) { res.status(400).json({ error: "ids must be array" }); return; }
  const updated = await Promise.all(
    body.ids.map((id, index) =>
      db.update(heroSlidesTable).set({ sortOrder: index }).where(eq(heroSlidesTable.id, id)).returning().then(r => r[0])
    )
  );
  res.json(updated.filter(Boolean).map(mapSlide));
});

router.patch("/admin/slides/:id", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const body = req.body as UpdateSlideBody;
  const [slide] = await db.update(heroSlidesTable).set(body).where(eq(heroSlidesTable.id, id)).returning();
  if (!slide) { res.status(404).json({ error: "Slide not found" }); return; }
  res.json(mapSlide(slide));
});

router.delete("/admin/slides/:id", requireAuth, async (req: Request, res: Response) => {
  await db.delete(heroSlidesTable).where(eq(heroSlidesTable.id, Number(req.params.id)));
  res.status(204).send();
});

export default router;
