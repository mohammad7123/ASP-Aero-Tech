import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { mediaTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import { CreateMediaBody, ListMediaResponse } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

const mapMedia = (m: typeof mediaTable.$inferSelect) => ({
  id: m.id,
  filename: m.filename,
  objectPath: m.objectPath,
  mimeType: m.mimeType,
  size: m.size,
  altText: m.altText,
  createdAt: m.createdAt.toISOString(),
});

router.get("/admin/media", requireAuth, async (_req: Request, res: Response) => {
  const rows = await db.select().from(mediaTable).orderBy(mediaTable.createdAt);
  res.json(ListMediaResponse.parse(rows.map(mapMedia)));
});

router.post("/admin/media", requireAuth, async (req: Request, res: Response) => {
  const parsed = CreateMediaBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid body" }); return; }
  const [media] = await db.insert(mediaTable).values(parsed.data).returning();
  res.status(201).json(mapMedia(media));
});

router.delete("/admin/media/:id", requireAuth, async (req: Request, res: Response) => {
  await db.delete(mediaTable).where(eq(mediaTable.id, Number(req.params.id)));
  res.status(204).send();
});

export default router;
