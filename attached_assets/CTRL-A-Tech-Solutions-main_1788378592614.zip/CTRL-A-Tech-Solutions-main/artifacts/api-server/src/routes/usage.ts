import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { usageEventsTable } from "@workspace/db/schema";
import { sql, gte, and, eq } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

router.get("/admin/usage/summary", requireAuth, async (req: Request, res: Response) => {
  const days = Math.max(1, Math.min(365, Number(req.query.days ?? 30)));
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

  const rows = await db
    .select({
      channel: usageEventsTable.channel,
      provider: usageEventsTable.provider,
      status: usageEventsTable.status,
      total: sql<number>`count(*)::int`,
    })
    .from(usageEventsTable)
    .where(gte(usageEventsTable.createdAt, since))
    .groupBy(usageEventsTable.channel, usageEventsTable.provider, usageEventsTable.status);

  type Bucket = { channel: string; total: number; success: number; failed: number; providers: Record<string, { success: number; failed: number }> };
  const channels: Record<string, Bucket> = {};
  for (const c of ["ai", "email", "sms", "whatsapp"]) {
    channels[c] = { channel: c, total: 0, success: 0, failed: 0, providers: {} };
  }
  for (const r of rows) {
    const b = channels[r.channel] ?? (channels[r.channel] = { channel: r.channel, total: 0, success: 0, failed: 0, providers: {} });
    b.total += r.total;
    if (r.status === "success") b.success += r.total;
    else b.failed += r.total;
    const provKey = r.provider || "default";
    const p = b.providers[provKey] ?? (b.providers[provKey] = { success: 0, failed: 0 });
    if (r.status === "success") p.success += r.total;
    else p.failed += r.total;
  }
  res.json({ days, since: since.toISOString(), channels: Object.values(channels) });
});

router.get("/admin/usage/recent", requireAuth, async (req: Request, res: Response) => {
  const channel = String(req.query.channel ?? "");
  const limit = Math.max(1, Math.min(200, Number(req.query.limit ?? 50)));
  const conds = [];
  if (channel) conds.push(eq(usageEventsTable.channel, channel));
  const rows = await db
    .select()
    .from(usageEventsTable)
    .where(conds.length ? and(...conds) : undefined)
    .orderBy(sql`${usageEventsTable.createdAt} DESC`)
    .limit(limit);
  res.json(rows.map(r => ({
    id: r.id,
    channel: r.channel,
    provider: r.provider,
    action: r.action,
    status: r.status,
    units: r.units,
    meta: r.meta,
    createdAt: r.createdAt.toISOString(),
  })));
});

export default router;
