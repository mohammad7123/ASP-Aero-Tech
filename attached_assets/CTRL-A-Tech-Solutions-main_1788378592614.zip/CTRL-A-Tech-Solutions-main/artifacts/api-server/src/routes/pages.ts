import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { pagesTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import {
  CreatePageBody,
  UpdatePageBody,
  ListPagesResponse,
  GetPageResponse,
  UpdatePageResponse,
} from "@workspace/api-zod";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

const mapPage = (p: typeof pagesTable.$inferSelect) => ({
  id: p.id,
  title: p.title,
  slug: p.slug,
  content: p.content,
  metaTitle: p.metaTitle,
  metaDescription: p.metaDescription,
  heroImage: p.heroImage,
  isPublished: p.isPublished,
  sortOrder: p.sortOrder,
  createdAt: p.createdAt.toISOString(),
  updatedAt: p.updatedAt.toISOString(),
});

router.get("/admin/pages", requireAuth, async (_req: Request, res: Response) => {
  const rows = await db.select().from(pagesTable).orderBy(pagesTable.sortOrder);
  res.json(ListPagesResponse.parse(rows.map(mapPage)));
});

router.post("/admin/pages", requireAuth, async (req: Request, res: Response) => {
  const parsed = CreatePageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid body", details: parsed.error.flatten() });
    return;
  }
  const [page] = await db.insert(pagesTable).values(parsed.data).returning();
  res.status(201).json(mapPage(page));
});

router.get("/admin/pages/:id", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const [page] = await db.select().from(pagesTable).where(eq(pagesTable.id, id)).limit(1);
  if (!page) { res.status(404).json({ error: "Page not found" }); return; }
  res.json(GetPageResponse.parse(mapPage(page)));
});

router.patch("/admin/pages/:id", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const parsed = UpdatePageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid body", details: parsed.error.flatten() });
    return;
  }
  const [page] = await db.update(pagesTable).set(parsed.data).where(eq(pagesTable.id, id)).returning();
  if (!page) { res.status(404).json({ error: "Page not found" }); return; }
  res.json(UpdatePageResponse.parse(mapPage(page)));
});

router.delete("/admin/pages/:id", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  await db.delete(pagesTable).where(eq(pagesTable.id, id));
  res.status(204).send();
});

export default router;
