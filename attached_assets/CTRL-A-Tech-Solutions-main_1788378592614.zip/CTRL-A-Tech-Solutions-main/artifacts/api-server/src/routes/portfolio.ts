import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { portfolioTable } from "@workspace/db/schema";
import { eq, asc } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";
import { CreatePortfolioItemBody, UpdatePortfolioItemBody } from "@workspace/api-zod";

const router: IRouter = Router();

function mapItem(p: typeof portfolioTable.$inferSelect) {
  return {
    id: p.id,
    title: p.title,
    slug: p.slug,
    description: p.description,
    content: p.content,
    featuredImage: p.featuredImage,
    clientName: p.clientName,
    projectUrl: p.projectUrl,
    technologies: p.technologies,
    isPublished: p.isPublished,
    sortOrder: p.sortOrder,
    completedAt: p.completedAt?.toISOString() ?? null,
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
  };
}

router.get("/admin/portfolio", requireAuth, async (_req: Request, res: Response) => {
  const items = await db.select().from(portfolioTable).orderBy(asc(portfolioTable.sortOrder));
  res.json(items.map(mapItem));
});

router.post("/admin/portfolio", requireAuth, async (req: Request, res: Response) => {
  const parsed = CreatePortfolioItemBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid body", details: parsed.error.flatten() }); return; }
  const d = parsed.data;
  const insertData: typeof portfolioTable.$inferInsert = {
    title: d.title,
    slug: d.slug,
    description: d.description ?? null,
    content: d.content ?? "",
    featuredImage: d.featuredImage ?? null,
    clientName: d.clientName ?? null,
    projectUrl: d.projectUrl ?? null,
    technologies: d.technologies ?? null,
    isPublished: d.isPublished ?? false,
    sortOrder: d.sortOrder ?? 0,
    completedAt: d.completedAt ? new Date(d.completedAt) : null,
  };
  const [item] = await db.insert(portfolioTable).values(insertData).returning();
  res.status(201).json(mapItem(item));
});

router.get("/admin/portfolio/:id", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const [item] = await db.select().from(portfolioTable).where(eq(portfolioTable.id, id)).limit(1);
  if (!item) { res.status(404).json({ error: "Not found" }); return; }
  res.json(mapItem(item));
});

router.patch("/admin/portfolio/:id", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const parsed = UpdatePortfolioItemBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid body", details: parsed.error.flatten() }); return; }
  const d = parsed.data;
  const updateData: Partial<typeof portfolioTable.$inferInsert> = {};
  if (d.title !== undefined) updateData.title = d.title;
  if (d.slug !== undefined) updateData.slug = d.slug;
  if (d.description !== undefined) updateData.description = d.description ?? null;
  if (d.content !== undefined) updateData.content = d.content;
  if (d.featuredImage !== undefined) updateData.featuredImage = d.featuredImage ?? null;
  if (d.clientName !== undefined) updateData.clientName = d.clientName ?? null;
  if (d.projectUrl !== undefined) updateData.projectUrl = d.projectUrl ?? null;
  if (d.technologies !== undefined) updateData.technologies = d.technologies ?? null;
  if (d.isPublished !== undefined) updateData.isPublished = d.isPublished;
  if (d.sortOrder !== undefined) updateData.sortOrder = d.sortOrder;
  if (d.completedAt !== undefined) updateData.completedAt = d.completedAt ? new Date(d.completedAt) : null;
  const [item] = await db.update(portfolioTable).set(updateData).where(eq(portfolioTable.id, id)).returning();
  if (!item) { res.status(404).json({ error: "Not found" }); return; }
  res.json(mapItem(item));
});

router.delete("/admin/portfolio/:id", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  await db.delete(portfolioTable).where(eq(portfolioTable.id, id));
  res.status(204).send();
});

router.get("/portfolio", async (_req: Request, res: Response) => {
  const items = await db.select().from(portfolioTable)
    .where(eq(portfolioTable.isPublished, true))
    .orderBy(asc(portfolioTable.sortOrder));
  res.json(items.map(mapItem));
});

router.get("/portfolio/:slug", async (req: Request, res: Response) => {
  const [item] = await db.select().from(portfolioTable)
    .where(eq(portfolioTable.slug, String(req.params.slug)))
    .limit(1);
  if (!item || !item.isPublished) { res.status(404).json({ error: "Not found" }); return; }
  res.json(mapItem(item));
});

export default router;
