import { Router, type IRouter, type Request, type Response } from "express";

const router: IRouter = Router();

const PUBLIC_SITE_URL = "https://www.ctrlatechsolutions.com";

router.get("/robots.txt", (_req: Request, res: Response) => {
  const lines = [
    "User-agent: *",
    "Disallow: /admin",
    "Disallow: /api/admin",
    "",
    `Sitemap: ${PUBLIC_SITE_URL}/sitemap.xml`,
  ];

  res.type("text/plain").send(lines.join("\n"));
});

export default router;
