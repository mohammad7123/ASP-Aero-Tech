import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { pagesTable } from "@workspace/db/schema";
import { eq, and } from "drizzle-orm";
import { GetPublicPageResponse } from "@workspace/api-zod";

const router: IRouter = Router();

const mapPage = (p: typeof pagesTable.$inferSelect) => ({
  id: p.id,
  title: p.title,
  slug: p.slug,
  content: p.content,
  metaTitle: p.metaTitle,
  metaDescription: p.metaDescription,
  heroImage: p.heroImage,
  isPublished: p.isPublished,
  sortOrder: p.sortOrder,
  createdAt: p.createdAt.toISOString(),
  updatedAt: p.updatedAt.toISOString(),
});

router.get("/pages/:slug", async (req: Request, res: Response) => {
  const [page] = await db.select().from(pagesTable)
    .where(and(eq(pagesTable.slug, String(req.params.slug)), eq(pagesTable.isPublished, true)))
    .limit(1);
  if (!page) { res.status(404).json({ error: "Page not found" }); return; }
  res.json(GetPublicPageResponse.parse(mapPage(page)));
});

export default router;
