import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { siteSettingsTable, menuItemsTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import { UpdateSettingsBody, GetSettingsResponse, UpdateSettingsResponse, GetSiteConfigResponse } from "@workspace/api-zod";
import { requireAuth, requireAdmin } from "../middlewares/auth";
import { encryptSetting, decryptSetting, isEncrypted } from "../lib/settingsEncryption";

function enc(value: string | null | undefined): string | null {
  if (value == null || value === "") return value ?? null;
  return encryptSetting(value);
}

function dec(value: string | null | undefined): string | null {
  if (!value) return value ?? null;
  try { return isEncrypted(value) ? decryptSetting(value) : value; } catch { return value; }
}

const router: IRouter = Router();

async function getOrCreateSettings() {
  const [existing] = await db.select().from(siteSettingsTable).limit(1);
  if (existing) return existing;
  const [created] = await db.insert(siteSettingsTable).values({}).returning();
  return created;
}

const mask = (v: string | null) => (v ? "••••••••" : null);
const mapSettings = (s: typeof siteSettingsTable.$inferSelect) => ({
  smtpHost: dec(s.smtpHost),
  smtpPort: s.smtpPort,
  smtpUser: dec(s.smtpUser),
  smtpPassword: mask(dec(s.smtpPassword)),
  smtpFrom: dec(s.smtpFrom),
  whatsappNumber: dec(s.whatsappNumber),
  whatsappGreeting: dec(s.whatsappGreeting),
  whatsappProvider: dec(s.whatsappProvider),
  whatsappAccountSid: dec(s.whatsappAccountSid),
  whatsappAuthToken: mask(dec(s.whatsappAuthToken)),
  whatsappFromNumber: dec(s.whatsappFromNumber),
  whatsappPhoneNumberId: dec(s.whatsappPhoneNumberId),
  whatsappAccessToken: mask(dec(s.whatsappAccessToken)),
  smsProvider: dec(s.smsProvider),
  smsApiKey: mask(dec(s.smsApiKey)),
  smsSenderId: dec(s.smsSenderId),
  smsAccountSid: dec(s.smsAccountSid),
  gaId: dec(s.gaId),
  chatbotName: dec(s.chatbotName),
  chatbotGreeting: dec(s.chatbotGreeting),
  chatbotEnabled: s.chatbotEnabled,
  chatbotApiKey: mask(dec(s.chatbotApiKey)),
  chatbotModel: dec(s.chatbotModel),
  defaultAiProvider: dec(s.defaultAiProvider),
  openaiApiKey: mask(dec(s.openaiApiKey)),
  openaiBaseUrl: dec(s.openaiBaseUrl),
  openaiModel: dec(s.openaiModel),
  anthropicApiKey: mask(dec(s.anthropicApiKey)),
  anthropicBaseUrl: dec(s.anthropicBaseUrl),
  anthropicModel: dec(s.anthropicModel),
  geminiApiKey: mask(dec(s.geminiApiKey)),
  geminiBaseUrl: dec(s.geminiBaseUrl),
  geminiModel: dec(s.geminiModel),
  openrouterApiKey: mask(dec(s.openrouterApiKey)),
  openrouterBaseUrl: dec(s.openrouterBaseUrl),
  openrouterModel: dec(s.openrouterModel),
  primaryColor: dec(s.primaryColor),
  accentColor: dec(s.accentColor),
  backgroundColor: dec(s.backgroundColor),
  fontFamily: dec(s.fontFamily),
  siteName: dec(s.siteName),
  tagline: dec(s.tagline),
  logoUrl: dec(s.logoUrl),
  faviconUrl: dec(s.faviconUrl),
  contactEmail: dec(s.contactEmail),
  contactPhone: dec(s.contactPhone),
  contactPhone2: dec(s.contactPhone2),
  address: dec(s.address),
  linkedinUrl: dec(s.linkedinUrl),
  twitterUrl: dec(s.twitterUrl),
  facebookUrl: dec(s.facebookUrl),
  instagramUrl: dec(s.instagramUrl),
  youtubeUrl: dec(s.youtubeUrl),
  supportLoginUrl: dec(s.supportLoginUrl),
  bannerHeight: s.bannerHeight ?? 640,
  bannerSpeed: s.bannerSpeed ?? 5000,
  updatedAt: s.updatedAt.toISOString(),
});

router.get("/admin/settings", requireAuth, async (_req: Request, res: Response) => {
  const settings = await getOrCreateSettings();
  res.json(mapSettings(settings));
});

router.put("/admin/settings", requireAdmin, async (req: Request, res: Response) => {
  // Soft-validate the schema fields, but accept extended fields (WhatsApp/AI providers)
  // straight from req.body since they were added after the api-zod schema froze.
  const parsed = UpdateSettingsBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid body", details: parsed.error.flatten() }); return; }

  const existing = await getOrCreateSettings();
  const raw = (req.body ?? {}) as Record<string, unknown>;
  const updateData: Record<string, unknown> = {};

  const sensitiveKeys = [
    "smtpPassword", "smsApiKey", "chatbotApiKey",
    "whatsappAuthToken", "whatsappAccessToken",
    "openaiApiKey", "anthropicApiKey", "geminiApiKey", "openrouterApiKey",
  ] as const;
  for (const key of sensitiveKeys) {
    const v = raw[key];
    if (v === "••••••••") continue; // keep existing encrypted value
    if (typeof v === "string" && v) updateData[key] = enc(v);
    else if (v === null || v === "") updateData[key] = null;
  }

  const plainStringKeys = [
    "smtpHost", "smtpUser", "smtpFrom",
    "whatsappNumber", "whatsappGreeting", "whatsappProvider",
    "whatsappAccountSid", "whatsappFromNumber", "whatsappPhoneNumberId",
    "smsProvider", "smsSenderId", "smsAccountSid",
    "gaId", "chatbotName", "chatbotGreeting", "chatbotModel",
    "defaultAiProvider",
    "openaiBaseUrl", "openaiModel", "anthropicBaseUrl", "anthropicModel",
    "geminiBaseUrl", "geminiModel", "openrouterBaseUrl", "openrouterModel",
    "primaryColor", "accentColor", "backgroundColor", "fontFamily",
    "siteName", "tagline", "logoUrl", "faviconUrl",
    "contactEmail", "contactPhone", "contactPhone2", "address",
    "linkedinUrl", "twitterUrl", "facebookUrl", "instagramUrl", "youtubeUrl",
    "supportLoginUrl",
  ] as const;

  for (const key of plainStringKeys) {
    if (key in raw) {
      const v = raw[key];
      updateData[key] = typeof v === "string" && v ? enc(v) : null;
    }
  }

  if ("smtpPort" in raw) updateData.smtpPort = raw.smtpPort === null || raw.smtpPort === "" ? null : Number(raw.smtpPort);
  if ("chatbotEnabled" in raw) updateData.chatbotEnabled = !!raw.chatbotEnabled;
  if ("bannerHeight" in raw) updateData.bannerHeight = Math.min(1200, Math.max(300, Number(raw.bannerHeight) || 640));
  if ("bannerSpeed" in raw) updateData.bannerSpeed = Math.min(30000, Math.max(1000, Number(raw.bannerSpeed) || 5000));

  const [updated] = await db.update(siteSettingsTable).set(updateData).where(eq(siteSettingsTable.id, existing.id)).returning();
  res.json(mapSettings(updated));
});

async function handleSiteConfig(_req: Request, res: Response) {
  const [settings] = await db.select().from(siteSettingsTable).limit(1);
  const menuRows = await db.select().from(menuItemsTable)
    .where(eq(menuItemsTable.isVisible, true))
    .orderBy(menuItemsTable.sortOrder);

  const menuItems = menuRows.map(m => ({
    id: m.id,
    label: m.label,
    url: m.url,
    pageId: m.pageId,
    sortOrder: m.sortOrder,
    openInNewTab: m.openInNewTab,
    isVisible: m.isVisible,
    createdAt: m.createdAt.toISOString(),
  }));

  const base = GetSiteConfigResponse.parse({
    siteName: dec(settings?.siteName) ?? "CtrlA Tech Solutions",
    tagline: dec(settings?.tagline) ?? null,
    logoUrl: dec(settings?.logoUrl) ?? null,
    faviconUrl: dec(settings?.faviconUrl) ?? null,
    primaryColor: dec(settings?.primaryColor) ?? "#00C9B1",
    accentColor: dec(settings?.accentColor) ?? "#0A0F2C",
    backgroundColor: dec(settings?.backgroundColor) ?? "#ffffff",
    fontFamily: dec(settings?.fontFamily) ?? "Inter",
    whatsappNumber: dec(settings?.whatsappNumber) ?? null,
    whatsappGreeting: dec(settings?.whatsappGreeting) ?? null,
    gaId: dec(settings?.gaId) ?? null,
    chatbotEnabled: settings?.chatbotEnabled ?? false,
    chatbotName: dec(settings?.chatbotName) ?? null,
    chatbotGreeting: dec(settings?.chatbotGreeting) ?? null,
    contactEmail: dec(settings?.contactEmail) ?? null,
    contactPhone: dec(settings?.contactPhone) ?? null,
    address: dec(settings?.address) ?? null,
    menuItems,
  });
  // Extend with social media + contactPhone2 + banner display settings (not in frozen api-zod schema)
  res.json({
    ...base,
    contactPhone2: dec(settings?.contactPhone2) ?? null,
    linkedinUrl: dec(settings?.linkedinUrl) ?? null,
    twitterUrl: dec(settings?.twitterUrl) ?? null,
    facebookUrl: dec(settings?.facebookUrl) ?? null,
    instagramUrl: dec(settings?.instagramUrl) ?? null,
    youtubeUrl: dec(settings?.youtubeUrl) ?? null,
    supportLoginUrl: dec(settings?.supportLoginUrl) ?? null,
    bannerHeight: settings?.bannerHeight ?? 640,
    bannerSpeed: settings?.bannerSpeed ?? 5000,
  });
}

router.get("/site/config", handleSiteConfig);
router.get("/site-config", handleSiteConfig);
router.get("/public/site-config", handleSiteConfig);

export default router;
