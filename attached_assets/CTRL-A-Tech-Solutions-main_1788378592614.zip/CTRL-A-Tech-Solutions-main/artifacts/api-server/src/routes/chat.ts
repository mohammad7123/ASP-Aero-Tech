import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { siteSettingsTable } from "@workspace/db/schema";
import { decryptSetting, isEncrypted } from "../lib/settingsEncryption";

const router: IRouter = Router();

const FAQ: { patterns: RegExp[]; answer: string }[] = [
  { patterns: [/service|offer|what.*do/i], answer: "We offer web development, mobile apps, cloud solutions, cybersecurity, IT consulting, and digital transformation services." },
  { patterns: [/price|cost|charge|fee|rate/i], answer: "Pricing depends on project scope. Please contact us for a free consultation and custom quote." },
  { patterns: [/contact|reach|email|phone|call/i], answer: "You can reach us via the Contact page or WhatsApp. We typically respond within 24 hours." },
  { patterns: [/location|where|office|based|india/i], answer: "We are based in India and serve clients globally." },
  { patterns: [/time|long|deadline|deliver|duration/i], answer: "Project timelines vary from a few weeks to several months. We provide clear timelines in our initial consultation." },
];

function faqReply(input: string): string {
  for (const faq of FAQ) {
    if (faq.patterns.some(p => p.test(input))) return faq.answer;
  }
  return "Thanks for your question! For a detailed answer, please visit our Contact page or chat with us on WhatsApp.";
}

function decryptIfNeeded(value: string | null | undefined): string | null {
  if (!value) return null;
  try { return isEncrypted(value) ? decryptSetting(value) : value; } catch { return value; }
}

router.post("/chat", async (req: Request, res: Response) => {
  const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
  const history: { role: string; content: string }[] = Array.isArray(req.body?.history) ? req.body.history : [];

  if (!message) { res.status(400).json({ error: "message is required" }); return; }

  try {
    const [settings] = await db.select().from(siteSettingsTable).limit(1);

    if (settings?.chatbotEnabled && settings.chatbotApiKey) {
      const apiKey = decryptIfNeeded(settings.chatbotApiKey);
      if (apiKey) {
        const botName = decryptIfNeeded(settings.chatbotName) ?? "CtrlA Bot";
        const siteName = decryptIfNeeded(settings.siteName) ?? "CtrlA Tech Solutions";
        const greeting = decryptIfNeeded(settings.chatbotGreeting);
        const systemPrompt = `You are ${botName}, a helpful assistant for ${siteName}, an Indian technology company. Be concise, professional, and helpful.${greeting ? ` Greeting: ${greeting}` : ""}`;

        const messages = [
          { role: "system", content: systemPrompt },
          ...history.slice(-8).map((m: { role: string; content: string }) => ({
            role: m.role === "bot" ? "assistant" : "user",
            content: m.content,
          })),
          { role: "user", content: message },
        ];

        // Detect provider by key prefix: Google keys start with "AIza"
        const isGemini = apiKey.startsWith("AIza");

        if (isGemini) {
          const geminiModel = decryptIfNeeded(settings.chatbotModel) || "gemini-1.5-flash-latest";
          const geminiRes = await fetch(
            `https://generativelanguage.googleapis.com/v1beta/models/${geminiModel}:generateContent?key=${apiKey}`,
            {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                systemInstruction: { parts: [{ text: systemPrompt }] },
                contents: messages
                  .filter(m => m.role !== "system")
                  .map(m => ({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content }] })),
              }),
            },
          );
          if (geminiRes.ok) {
            const data = await geminiRes.json() as { candidates?: { content?: { parts?: { text?: string }[] } }[] };
            const reply = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? faqReply(message);
            res.json({ reply }); return;
          }
        } else {
          // OpenAI-compatible (OpenAI, Azure, Groq, Anthropic OpenAI compat, etc.)
          const model = decryptIfNeeded(settings.chatbotModel) || "gpt-4o-mini";
          const openaiRes = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
            body: JSON.stringify({ model, messages, max_tokens: 300, temperature: 0.7 }),
          });
          if (openaiRes.ok) {
            const data = await openaiRes.json() as { choices?: { message?: { content?: string } }[] };
            const reply = data?.choices?.[0]?.message?.content ?? faqReply(message);
            res.json({ reply }); return;
          }
        }
      }
    }
  } catch (err) {
    req.log?.warn?.({ err }, "AI chat API call failed — falling back to FAQ");
  }

  // Fallback: FAQ-based response
  res.json({ reply: faqReply(message) });
});

export default router;
