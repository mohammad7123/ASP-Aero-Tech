import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { servicesTable } from "@workspace/db/schema";
import { eq, asc, and, gt, lt, desc } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

const mapItem = (item: typeof servicesTable.$inferSelect) => ({
  id: item.id,
  name: item.name,
  slug: item.slug,
  category: item.category,
  shortDesc: item.shortDesc,
  description: item.description,
  imageUrl: item.imageUrl,
  iconName: item.iconName,
  accentColor: item.accentColor,
  sortOrder: item.sortOrder,
  isActive: item.isActive,
  createdAt: item.createdAt.toISOString(),
  updatedAt: item.updatedAt.toISOString(),
});

router.get("/public/services", async (_req: Request, res: Response) => {
  const rows = await db.select().from(servicesTable)
    .where(eq(servicesTable.isActive, true))
    .orderBy(asc(servicesTable.sortOrder), asc(servicesTable.id));
  res.json(rows.map(mapItem));
});

router.get("/admin/services", requireAuth, async (_req: Request, res: Response) => {
  const rows = await db.select().from(servicesTable)
    .orderBy(asc(servicesTable.sortOrder), asc(servicesTable.id));
  res.json(rows.map(mapItem));
});

router.post("/admin/services", requireAuth, async (req: Request, res: Response) => {
  const b = req.body ?? {};
  if (!b.name) { res.status(400).json({ error: "name required" }); return; }
  const slug = b.slug || String(b.name).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  const [item] = await db.insert(servicesTable).values({
    name: b.name,
    slug,
    category: b.category ?? "general",
    shortDesc: b.shortDesc ?? "",
    description: b.description ?? "",
    imageUrl: b.imageUrl ?? null,
    iconName: b.iconName ?? "Briefcase",
    accentColor: b.accentColor ?? "#D4920C",
    sortOrder: b.sortOrder ?? 0,
    isActive: b.isActive ?? true,
  }).returning();
  res.status(201).json(mapItem(item));
});

router.patch("/admin/services/:id", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const b = req.body ?? {};
  const upd: Record<string, unknown> = {};
  for (const k of ["name","slug","category","shortDesc","description","iconName","accentColor","sortOrder","isActive"] as const) {
    if (b[k] !== undefined) upd[k] = b[k];
  }
  if ("imageUrl" in b) upd.imageUrl = b.imageUrl ?? null;
  const [item] = await db.update(servicesTable).set(upd).where(eq(servicesTable.id, id)).returning();
  if (!item) { res.status(404).json({ error: "Not found" }); return; }
  res.json(mapItem(item));
});

router.delete("/admin/services/:id", requireAuth, async (req: Request, res: Response) => {
  await db.delete(servicesTable).where(eq(servicesTable.id, Number(req.params.id)));
  res.status(204).send();
});

router.post("/admin/services/:id/move", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const direction = req.body?.direction === "up" ? "up" : "down";
  const [me] = await db.select().from(servicesTable).where(eq(servicesTable.id, id));
  if (!me) { res.status(404).json({ error: "Not found" }); return; }
  const neighbors = direction === "up"
    ? await db.select().from(servicesTable).where(lt(servicesTable.sortOrder, me.sortOrder)).orderBy(desc(servicesTable.sortOrder)).limit(1)
    : await db.select().from(servicesTable).where(gt(servicesTable.sortOrder, me.sortOrder)).orderBy(asc(servicesTable.sortOrder)).limit(1);
  let neighbor = neighbors[0];
  if (!neighbor) {
    // No tied neighbor; try one with same sort_order but different id
    const ties = await db.select().from(servicesTable).where(and(eq(servicesTable.sortOrder, me.sortOrder), direction === "up" ? lt(servicesTable.id, me.id) : gt(servicesTable.id, me.id)));
    neighbor = direction === "up" ? ties[ties.length - 1] : ties[0];
  }
  if (!neighbor) { res.json({ ok: true, moved: false }); return; }
  await db.update(servicesTable).set({ sortOrder: neighbor.sortOrder }).where(eq(servicesTable.id, me.id));
  await db.update(servicesTable).set({ sortOrder: me.sortOrder }).where(eq(servicesTable.id, neighbor.id));
  res.json({ ok: true, moved: true });
});

export default router;
