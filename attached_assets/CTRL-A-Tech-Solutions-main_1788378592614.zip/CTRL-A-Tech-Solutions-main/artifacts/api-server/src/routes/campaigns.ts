import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { campaignsTable, campaignRecipientsTable, contactInquiriesTable, siteSettingsTable, usageEventsTable } from "@workspace/db/schema";
import { eq, desc, inArray } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";
import { decryptSetting, isEncrypted } from "../lib/settingsEncryption";

const router: IRouter = Router();

function dec(v: string | null | undefined): string | null {
  if (!v) return null;
  try { return isEncrypted(v) ? decryptSetting(v) : v; } catch { return v; }
}

async function loadSettings() {
  const [s] = await db.select().from(siteSettingsTable).limit(1);
  return s ?? null;
}

async function recordUsage(channel: "email" | "sms" | "whatsapp", provider: string, action: string, status: "success" | "failed", meta: Record<string, unknown> = {}) {
  try {
    await db.insert(usageEventsTable).values({ channel, provider, action, status, units: 1, meta });
  } catch (err) {
    console.warn("[usage] record fail:", err instanceof Error ? err.message : err);
  }
}

const mapCampaign = (c: typeof campaignsTable.$inferSelect) => ({
  id: c.id,
  name: c.name,
  type: c.type,
  subject: c.subject,
  body: c.body,
  status: c.status,
  audienceFilter: c.audienceFilter,
  stats: c.stats,
  createdAt: c.createdAt.toISOString(),
  updatedAt: c.updatedAt.toISOString(),
  sentAt: c.sentAt ? c.sentAt.toISOString() : null,
});

function applyMerge(template: string, ctx: Record<string, string>): string {
  return template.replace(/\{(\w+)\}/g, (_, k) => ctx[k] ?? `{${k}}`);
}

router.get("/admin/campaigns", requireAuth, async (_req: Request, res: Response) => {
  const rows = await db.select().from(campaignsTable).orderBy(desc(campaignsTable.createdAt));
  res.json(rows.map(mapCampaign));
});

router.get("/admin/campaigns/:id", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const [c] = await db.select().from(campaignsTable).where(eq(campaignsTable.id, id));
  if (!c) { res.status(404).json({ error: "Not found" }); return; }
  const recipients = await db.select().from(campaignRecipientsTable).where(eq(campaignRecipientsTable.campaignId, id));
  res.json({ ...mapCampaign(c), recipients });
});

router.post("/admin/campaigns", requireAuth, async (req: Request, res: Response) => {
  const b = req.body ?? {};
  if (!b.name || !b.type) { res.status(400).json({ error: "name and type required" }); return; }
  if (!["email", "sms", "whatsapp"].includes(b.type)) { res.status(400).json({ error: "type must be email|sms|whatsapp" }); return; }
  const [c] = await db.insert(campaignsTable).values({
    name: b.name,
    type: b.type,
    subject: b.subject ?? "",
    body: b.body ?? "",
    status: "draft",
    audienceFilter: b.audienceFilter ?? {},
    stats: {},
  }).returning();
  res.status(201).json(mapCampaign(c));
});

router.patch("/admin/campaigns/:id", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const b = req.body ?? {};
  const upd: Record<string, unknown> = {};
  for (const k of ["name","type","subject","body","status","audienceFilter"] as const) {
    if (b[k] !== undefined) upd[k] = b[k];
  }
  const [c] = await db.update(campaignsTable).set(upd).where(eq(campaignsTable.id, id)).returning();
  if (!c) { res.status(404).json({ error: "Not found" }); return; }
  res.json(mapCampaign(c));
});

router.delete("/admin/campaigns/:id", requireAuth, async (req: Request, res: Response) => {
  await db.delete(campaignsTable).where(eq(campaignsTable.id, Number(req.params.id)));
  res.status(204).send();
});

async function resolveAudience(filter: { source?: string; ids?: number[] } | null | undefined) {
  const f = filter ?? {};
  const source = f.source ?? "all-leads";
  if (source === "selected" && Array.isArray(f.ids) && f.ids.length > 0) {
    const rows = await db.select().from(contactInquiriesTable).where(inArray(contactInquiriesTable.id, f.ids));
    return rows.map(r => ({ name: r.name, email: r.email, phone: r.phone ?? "" }));
  }
  const rows = await db.select().from(contactInquiriesTable);
  return rows.map(r => ({ name: r.name, email: r.email, phone: r.phone ?? "" }));
}

router.post("/admin/campaigns/:id/preview", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const [c] = await db.select().from(campaignsTable).where(eq(campaignsTable.id, id));
  if (!c) { res.status(404).json({ error: "Not found" }); return; }
  const audience = await resolveAudience(c.audienceFilter as { source?: string; ids?: number[] } | null);
  const samples = audience.slice(0, 3).map(p => {
    const ctx = { name: p.name || "Friend", email: p.email, phone: p.phone };
    return {
      to: c.type === "email" ? p.email : p.phone,
      name: p.name,
      subject: c.type === "email" ? applyMerge(c.subject ?? "", ctx) : undefined,
      body: applyMerge(c.body, ctx),
    };
  });
  res.json({ totalRecipients: audience.length, samples });
});

router.post("/admin/campaigns/:id/send", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const [c] = await db.select().from(campaignsTable).where(eq(campaignsTable.id, id));
  if (!c) { res.status(404).json({ error: "Not found" }); return; }
  if (c.status === "sending") { res.status(400).json({ error: "Already sending" }); return; }

  const audience = await resolveAudience(c.audienceFilter as { source?: string; ids?: number[] } | null);
  if (audience.length === 0) { res.status(400).json({ error: "No recipients" }); return; }

  const settings = await loadSettings();

  // Pre-flight: ensure required channel is configured
  if (c.type === "email") {
    if (!settings || !dec(settings.smtpHost) || !dec(settings.smtpUser) || !dec(settings.smtpPassword)) {
      res.status(400).json({ error: "Email channel not configured. Set SMTP host/user/password in Settings → SMTP." });
      return;
    }
  } else if (c.type === "sms") {
    if (!settings || !dec(settings.smsProvider) || !dec(settings.smsApiKey)) {
      res.status(400).json({ error: "SMS channel not configured. Set provider and API key in Settings → SMS." });
      return;
    }
  } else if (c.type === "whatsapp") {
    // wa.me link mode is always available; API mode requires provider
    // We still proceed even without an API integration.
  }

  await db.update(campaignsTable).set({ status: "sending" }).where(eq(campaignsTable.id, id));
  await db.delete(campaignRecipientsTable).where(eq(campaignRecipientsTable.campaignId, id));

  let sent = 0;
  let failed = 0;
  const results: Array<{ name: string; status: string; link?: string; error?: string }> = [];

  for (const p of audience) {
    const ctx = { name: p.name || "Friend", email: p.email, phone: p.phone };
    const renderedBody = applyMerge(c.body, ctx);
    const renderedSubject = applyMerge(c.subject ?? "", ctx);
    let status: "sent" | "failed" | "ready" = "ready";
    let errorMsg: string | null = null;
    let link: string | null = null;
    let providerUsed = "";

    try {
      if (c.type === "email") {
        if (!p.email) {
          status = "failed"; errorMsg = "missing email";
        } else {
          const r = await sendEmail(settings, { to: p.email, subject: renderedSubject, body: renderedBody });
          status = r.ok ? "sent" : "failed";
          errorMsg = r.error;
          providerUsed = "smtp";
        }
      } else if (c.type === "sms") {
        if (!p.phone) {
          status = "failed"; errorMsg = "missing phone";
        } else {
          const r = await sendSms(settings, { to: p.phone, body: renderedBody });
          status = r.ok ? "sent" : "failed";
          errorMsg = r.error;
          providerUsed = r.provider;
        }
      } else if (c.type === "whatsapp") {
        if (!p.phone) {
          status = "failed"; errorMsg = "missing phone";
        } else {
          const r = await sendWhatsapp(settings, { to: p.phone, body: renderedBody });
          status = r.status;
          errorMsg = r.error;
          link = r.link;
          providerUsed = r.provider;
        }
      }
    } catch (err) {
      status = "failed";
      errorMsg = err instanceof Error ? err.message : "unknown error";
    }

    if (status === "sent" || status === "ready") sent++;
    else failed++;

    await db.insert(campaignRecipientsTable).values({
      campaignId: id,
      name: p.name,
      email: p.email,
      phone: p.phone,
      status,
      sentAt: status === "sent" ? new Date() : null,
      errorMsg,
      link,
    });

    await recordUsage(c.type as "email"|"sms"|"whatsapp", providerUsed, `campaign:${id}`, status === "failed" ? "failed" : "success", { campaignId: id });

    results.push({ name: p.name, status, link: link ?? undefined, error: errorMsg ?? undefined });
  }

  const finalStatus = c.type === "whatsapp" && sent > 0 && failed === 0 ? "ready" : (failed === audience.length ? "failed" : "sent");
  await db.update(campaignsTable).set({
    status: finalStatus,
    stats: { total: audience.length, sent, failed },
    sentAt: new Date(),
  }).where(eq(campaignsTable.id, id));

  res.json({ ok: true, total: audience.length, sent, failed, results });
});

// ── Senders ────────────────────────────────────────────────────────────────────
type Settings = typeof siteSettingsTable.$inferSelect | null;

async function sendEmail(s: Settings, { to, subject, body }: { to: string; subject: string; body: string }): Promise<{ ok: boolean; error: string | null }> {
  const host = dec(s?.smtpHost);
  const user = dec(s?.smtpUser);
  const pass = dec(s?.smtpPassword);
  const from = dec(s?.smtpFrom) || user;
  const port = s?.smtpPort ?? 587;
  if (!host || !user || !pass) return { ok: false, error: "SMTP not configured" };
  try {
    const nodemailer = (await import("nodemailer")).default;
    const transporter = nodemailer.createTransport({
      host, port, secure: port === 465, auth: { user, pass },
    });
    await transporter.sendMail({ from: from ?? user, to, subject, html: body });
    return { ok: true, error: null };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : "send failed" };
  }
}

async function sendSms(s: Settings, { to, body }: { to: string; body: string }): Promise<{ ok: boolean; error: string | null; provider: string }> {
  const provider = (dec(s?.smsProvider) ?? "").toLowerCase();
  const apiKey = dec(s?.smsApiKey) ?? "";
  const senderId = dec(s?.smsSenderId) ?? "";
  if (!provider || !apiKey) return { ok: false, error: "SMS not configured", provider };
  const recipient = to.startsWith("+") ? to : `+${to.replace(/[^\d]/g, "")}`;

  try {
    if (provider === "twilio") {
      const sid = dec(s?.smsAccountSid) ?? "";
      if (!sid) return { ok: false, error: "Twilio Account SID missing (Settings → SMS)", provider };
      const auth = Buffer.from(`${sid}:${apiKey}`).toString("base64");
      const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
        method: "POST",
        headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ To: recipient, From: senderId, Body: body }).toString(),
      });
      if (!r.ok) {
        const t = await r.text(); return { ok: false, error: `Twilio ${r.status}: ${t.slice(0, 200)}`, provider };
      }
      return { ok: true, error: null, provider };
    }
    if (provider === "msg91") {
      const r = await fetch("https://control.msg91.com/api/v5/flow/", {
        method: "POST",
        headers: { "Content-Type": "application/json", "authkey": apiKey },
        body: JSON.stringify({ template_id: senderId, sender: senderId, mobiles: recipient.replace("+", ""), VAR1: body.slice(0, 160) }),
      });
      if (!r.ok) { const t = await r.text(); return { ok: false, error: `MSG91 ${r.status}: ${t.slice(0, 200)}`, provider }; }
      return { ok: true, error: null, provider };
    }
    if (provider === "fast2sms") {
      const r = await fetch("https://www.fast2sms.com/dev/bulkV2", {
        method: "POST",
        headers: { "Content-Type": "application/json", "authorization": apiKey },
        body: JSON.stringify({ route: "q", message: body, language: "english", numbers: recipient.replace("+91", "").replace("+", "") }),
      });
      if (!r.ok) { const t = await r.text(); return { ok: false, error: `Fast2SMS ${r.status}: ${t.slice(0, 200)}`, provider }; }
      return { ok: true, error: null, provider };
    }
    if (provider === "textlocal") {
      const params = new URLSearchParams({ apikey: apiKey, numbers: recipient.replace("+", ""), message: body, sender: senderId || "TXTLCL" });
      const r = await fetch(`https://api.textlocal.in/send/?${params.toString()}`);
      if (!r.ok) { const t = await r.text(); return { ok: false, error: `Textlocal ${r.status}: ${t.slice(0, 200)}`, provider }; }
      return { ok: true, error: null, provider };
    }
    return { ok: false, error: `SMS provider '${provider}' not supported`, provider };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : "send failed", provider };
  }
}

async function sendWhatsapp(s: Settings, { to, body }: { to: string; body: string }): Promise<{ status: "sent" | "ready" | "failed"; error: string | null; link: string | null; provider: string }> {
  const provider = (dec(s?.whatsappProvider) ?? "link").toLowerCase();
  const cleanPhone = to.replace(/[^\d]/g, "");

  if (provider === "twilio") {
    const sid = dec(s?.whatsappAccountSid) ?? "";
    const token = dec(s?.whatsappAuthToken) ?? "";
    const from = dec(s?.whatsappFromNumber) ?? "";
    if (!sid || !token || !from) return { status: "failed", error: "Twilio WhatsApp creds missing (Settings → WhatsApp)", link: null, provider };
    try {
      const auth = Buffer.from(`${sid}:${token}`).toString("base64");
      const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
        method: "POST",
        headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ To: `whatsapp:+${cleanPhone}`, From: from.startsWith("whatsapp:") ? from : `whatsapp:${from}`, Body: body }).toString(),
      });
      if (!r.ok) { const t = await r.text(); return { status: "failed", error: `Twilio ${r.status}: ${t.slice(0, 200)}`, link: null, provider }; }
      return { status: "sent", error: null, link: null, provider };
    } catch (err) {
      return { status: "failed", error: err instanceof Error ? err.message : "send failed", link: null, provider };
    }
  }

  if (provider === "meta") {
    const phoneId = dec(s?.whatsappPhoneNumberId) ?? "";
    const token = dec(s?.whatsappAccessToken) ?? "";
    if (!phoneId || !token) return { status: "failed", error: "Meta WhatsApp creds missing (Settings → WhatsApp)", link: null, provider };
    try {
      const r = await fetch(`https://graph.facebook.com/v20.0/${phoneId}/messages`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ messaging_product: "whatsapp", to: cleanPhone, type: "text", text: { body } }),
      });
      if (!r.ok) { const t = await r.text(); return { status: "failed", error: `Meta ${r.status}: ${t.slice(0, 200)}`, link: null, provider }; }
      return { status: "sent", error: null, link: null, provider };
    } catch (err) {
      return { status: "failed", error: err instanceof Error ? err.message : "send failed", link: null, provider };
    }
  }

  // Default: wa.me click-through link
  const link = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(body)}`;
  return { status: "ready", error: null, link, provider: "link" };
}

export default router;
