import { Router, type IRouter, type Request, type Response } from "express";
import { Readable } from "stream";
import {
  RequestUploadUrlBody,
  RequestUploadUrlResponse,
} from "@workspace/api-zod";
import { ObjectStorageService, ObjectNotFoundError, verifyUploadToken, MAX_UPLOAD_BYTES } from "../lib/objectStorage";
import { canAccessObject, ObjectPermission, setObjectAclPolicy } from "../lib/objectAcl";
import { requireAuth, type AuthRequest } from "../middlewares/auth";

const router: IRouter = Router();
const objectStorageService = new ObjectStorageService();

/**
 * PUT /storage/objects/uploads/:id
 *
 * Receives the raw file bytes for an upload URL previously issued by
 * POST /storage/uploads/request-url. Authenticated by a signed, short-lived
 * `token`/`exp` query pair rather than a session — mirrors how a real
 * presigned cloud-storage URL works, and lets unauthenticated flows (e.g.
 * public job-application CV uploads) keep working without exposing writes
 * to arbitrary paths.
 */
router.put("/storage/objects/uploads/:id", async (req: Request, res: Response) => {
  const objectName = `uploads/${req.params.id}`;
  const token = String(req.query.token ?? "");
  const exp = Number(req.query.exp ?? "0");

  if (!token || !verifyUploadToken(objectName, exp, token)) {
    res.status(403).json({ error: "Upload URL is invalid or has expired" });
    return;
  }

  const contentLength = Number(req.headers["content-length"] ?? "0");
  if (contentLength > MAX_UPLOAD_BYTES) {
    res.status(413).json({ error: "File too large" });
    return;
  }

  try {
    const contentType = req.headers["content-type"] || "application/octet-stream";
    await objectStorageService.writeObjectEntity(objectName, req, contentType);
    res.status(200).json({ ok: true });
  } catch (error) {
    req.log.error({ err: error }, "Error writing uploaded object");
    res.status(500).json({ error: "Failed to store uploaded file" });
  }
});

/**
 * POST /storage/uploads/request-url
 *
 * Request a presigned URL for file upload.
 * Requires admin authentication — prevents anonymous storage abuse.
 */
router.post("/storage/uploads/request-url", requireAuth, async (req: AuthRequest, res: Response) => {
  const parsed = RequestUploadUrlBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Missing or invalid required fields" });
    return;
  }

  try {
    const { name, size, contentType } = parsed.data;

    const uploadURL = await objectStorageService.getObjectEntityUploadURL();
    const objectPath = objectStorageService.normalizeObjectEntityPath(uploadURL);

    res.json(
      RequestUploadUrlResponse.parse({
        uploadURL,
        objectPath,
        metadata: { name, size, contentType },
      }),
    );
  } catch (error) {
    req.log.error({ err: error }, "Error generating upload URL");
    res.status(500).json({ error: "Failed to generate upload URL" });
  }
});

/**
 * GET /storage/public-objects/*
 *
 * Serve public assets from PUBLIC_OBJECT_SEARCH_PATHS.
 * These are unconditionally public — no authentication or ACL checks.
 * IMPORTANT: Always provide this endpoint when object storage is set up.
 */
router.get("/storage/public-objects/*filePath", async (req: Request, res: Response) => {
  try {
    const raw = req.params.filePath;
    const filePath = Array.isArray(raw) ? raw.join("/") : raw;
    const file = await objectStorageService.searchPublicObject(filePath);
    if (!file) {
      res.status(404).json({ error: "File not found" });
      return;
    }

    const response = await objectStorageService.downloadObject(file);

    res.status(response.status);
    response.headers.forEach((value, key) => res.setHeader(key, value));

    if (response.body) {
      const nodeStream = Readable.fromWeb(response.body as ReadableStream<Uint8Array>);
      nodeStream.pipe(res);
    } else {
      res.end();
    }
  } catch (error) {
    req.log.error({ err: error }, "Error serving public object");
    res.status(500).json({ error: "Failed to serve public object" });
  }
});

/**
 * GET /storage/objects/*
 *
 * Serve object entities from PRIVATE_OBJECT_DIR with ACL enforcement.
 * Files with explicit ACL policy are checked; files without ACL policy
 * default to public read (CMS media uploaded by admin are public assets).
 * Private objects require a valid admin Bearer token.
 *
 * Auth is optional — parsed from Bearer header when present so that
 * ACL rules can check admin identity for private objects.
 */
router.get("/storage/objects/*path", async (req: AuthRequest, res: Response) => {
  // Optionally parse JWT from Authorization header (fail-safe: missing/invalid = unauthenticated)
  const authHeader = req.headers.authorization;
  if (authHeader?.startsWith("Bearer ")) {
    try {
      const jwt = await import("jsonwebtoken");
      const { JWT_SECRET } = await import("../middlewares/auth");
      const payload = jwt.default.verify(authHeader.slice(7), JWT_SECRET) as { id: number };
      req.adminId = payload.id;
    } catch {
      // Invalid token — treat as unauthenticated (not an error for public objects)
    }
  }

  try {
    const raw = req.params.path;
    const wildcardPath = Array.isArray(raw) ? raw.join("/") : raw;
    const objectPath = `/objects/${wildcardPath}`;
    const objectFile = await objectStorageService.getObjectEntityFile(objectPath);

    // Fail-closed: any ACL evaluation error → deny access
    const allowed = await canAccessObject({
      userId: req.adminId?.toString(),
      objectFile,
      requestedPermission: ObjectPermission.READ,
    }).catch(() => false);

    if (!allowed) {
      if (!authHeader?.startsWith("Bearer ")) {
        res.status(401).json({ error: "Unauthorized" });
        return;
      }
      res.status(403).json({ error: "Forbidden" });
      return;
    }

    const response = await objectStorageService.downloadObject(objectFile);

    res.status(response.status);
    response.headers.forEach((value, key) => res.setHeader(key, value));

    if (response.body) {
      const nodeStream = Readable.fromWeb(response.body as ReadableStream<Uint8Array>);
      nodeStream.pipe(res);
    } else {
      res.end();
    }
  } catch (error) {
    if (error instanceof ObjectNotFoundError) {
      req.log.warn({ err: error }, "Object not found");
      res.status(404).json({ error: "Object not found" });
      return;
    }
    req.log.error({ err: error }, "Error serving object");
    res.status(500).json({ error: "Failed to serve object" });
  }
});

export { setObjectAclPolicy };
export default router;
