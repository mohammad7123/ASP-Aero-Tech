import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { pagesTable, blogPostsTable, contactInquiriesTable, mediaTable, portfolioTable } from "@workspace/db/schema";
import { eq, count } from "drizzle-orm";
import { GetDashboardStatsResponse } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

router.get("/admin/dashboard/stats", requireAuth, async (_req: Request, res: Response) => {
  const [[pages], [publishedPages], [posts], [publishedPosts], [contacts], [unread], [media], [portfolio]] = await Promise.all([
    db.select({ count: count() }).from(pagesTable),
    db.select({ count: count() }).from(pagesTable).where(eq(pagesTable.isPublished, true)),
    db.select({ count: count() }).from(blogPostsTable),
    db.select({ count: count() }).from(blogPostsTable).where(eq(blogPostsTable.isPublished, true)),
    db.select({ count: count() }).from(contactInquiriesTable),
    db.select({ count: count() }).from(contactInquiriesTable).where(eq(contactInquiriesTable.isRead, false)),
    db.select({ count: count() }).from(mediaTable),
    db.select({ count: count() }).from(portfolioTable),
  ]);
  res.json(GetDashboardStatsResponse.parse({
    totalPages: pages.count,
    publishedPages: publishedPages.count,
    totalBlogPosts: posts.count,
    publishedBlogPosts: publishedPosts.count,
    totalContacts: contacts.count,
    unreadContacts: unread.count,
    totalMedia: media.count,
    totalPortfolio: portfolio.count,
  }));
});

export default router;
