import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { jobsTable, jobApplicationsTable } from "@workspace/db/schema";
import { eq, desc, and } from "drizzle-orm";
import { requireAuth, requireAdmin } from "../middlewares/auth";
import { ObjectStorageService } from "../lib/objectStorage";

const router: IRouter = Router();

const mapJob = (j: typeof jobsTable.$inferSelect) => ({
  id: j.id,
  title: j.title,
  department: j.department,
  location: j.location,
  type: j.type,
  description: j.description,
  requirements: j.requirements,
  salaryRange: j.salaryRange,
  isActive: j.isActive,
  sortOrder: j.sortOrder,
  closedAt: j.closedAt ? j.closedAt.toISOString() : null,
  createdAt: j.createdAt.toISOString(),
  updatedAt: j.updatedAt.toISOString(),
});

const mapApplication = (a: typeof jobApplicationsTable.$inferSelect) => ({
  id: a.id,
  jobId: a.jobId,
  name: a.name,
  email: a.email,
  phone: a.phone,
  coverLetter: a.coverLetter,
  cvObjectPath: a.cvObjectPath,
  cvFilename: a.cvFilename,
  status: a.status,
  notes: a.notes,
  createdAt: a.createdAt.toISOString(),
  updatedAt: a.updatedAt.toISOString(),
});

const objectStorageService = new ObjectStorageService();

// ── Public routes ──────────────────────────────────────────────────────────

// Public CV upload URL — no admin auth required so applicants can attach CVs
router.post("/public/jobs/upload-cv-url", async (req: Request, res: Response) => {
  const { name, size, contentType } = req.body ?? {};
  if (!name || !contentType) {
    res.status(400).json({ error: "name and contentType are required" });
    return;
  }
  try {
    const uploadURL = await objectStorageService.getObjectEntityUploadURL();
    const objectPath = objectStorageService.normalizeObjectEntityPath(uploadURL);
    res.json({ uploadURL, objectPath, metadata: { name, size, contentType } });
  } catch (err) {
    res.status(500).json({ error: "Failed to generate upload URL" });
  }
});

router.get("/public/jobs", async (_req: Request, res: Response) => {
  const jobs = await db.select().from(jobsTable)
    .where(eq(jobsTable.isActive, true))
    .orderBy(jobsTable.sortOrder, desc(jobsTable.createdAt));
  res.json(jobs.map(mapJob));
});

router.get("/public/jobs/:id", async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const [job] = await db.select().from(jobsTable)
    .where(and(eq(jobsTable.id, id), eq(jobsTable.isActive, true)));
  if (!job) { res.status(404).json({ error: "Job not found" }); return; }
  res.json(mapJob(job));
});

router.post("/public/jobs/:id/apply", async (req: Request, res: Response) => {
  const { verifyCaptchaToken } = await import("./captcha");
  if (!verifyCaptchaToken(req.body?.captchaToken, req.body?.captchaAnswer)) {
    res.status(400).json({ error: "Security check failed. Please answer the math question correctly." });
    return;
  }
  const jobId = Number(req.params.id);
  const [job] = await db.select().from(jobsTable)
    .where(and(eq(jobsTable.id, jobId), eq(jobsTable.isActive, true)));
  if (!job) { res.status(404).json({ error: "Job not found or no longer active" }); return; }

  const { name, email, phone, coverLetter, cvObjectPath, cvFilename } = req.body ?? {};
  if (!name || !email) { res.status(400).json({ error: "name and email are required" }); return; }

  const [application] = await db.insert(jobApplicationsTable).values({
    jobId,
    name,
    email,
    phone: phone ?? null,
    coverLetter: coverLetter ?? null,
    cvObjectPath: cvObjectPath ?? null,
    cvFilename: cvFilename ?? null,
    status: "new",
  }).returning();

  res.status(201).json(mapApplication(application));
});

// ── Admin routes ───────────────────────────────────────────────────────────

router.get("/admin/jobs", requireAuth, async (_req: Request, res: Response) => {
  const jobs = await db.select().from(jobsTable).orderBy(jobsTable.sortOrder, desc(jobsTable.createdAt));
  res.json(jobs.map(mapJob));
});

router.post("/admin/jobs", requireAdmin, async (req: Request, res: Response) => {
  const b = req.body ?? {};
  if (!b.title) { res.status(400).json({ error: "title is required" }); return; }
  const [job] = await db.insert(jobsTable).values({
    title: b.title,
    department: b.department ?? "",
    location: b.location ?? "",
    type: b.type ?? "full-time",
    description: b.description ?? "",
    requirements: b.requirements ?? "",
    salaryRange: b.salaryRange ?? null,
    isActive: b.isActive !== false,
    sortOrder: b.sortOrder ?? 0,
  }).returning();
  res.status(201).json(mapJob(job));
});

router.patch("/admin/jobs/:id", requireAdmin, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const b = req.body ?? {};
  const upd: Record<string, unknown> = {};
  for (const k of ["title", "department", "location", "type", "description", "requirements", "salaryRange", "sortOrder"] as const) {
    if (b[k] !== undefined) upd[k] = b[k];
  }
  if (b.isActive !== undefined) upd.isActive = !!b.isActive;
  const [job] = await db.update(jobsTable).set(upd).where(eq(jobsTable.id, id)).returning();
  if (!job) { res.status(404).json({ error: "Not found" }); return; }
  res.json(mapJob(job));
});

router.delete("/admin/jobs/:id", requireAdmin, async (req: Request, res: Response) => {
  await db.delete(jobsTable).where(eq(jobsTable.id, Number(req.params.id)));
  res.status(204).send();
});

router.get("/admin/jobs/:id/applications", requireAuth, async (req: Request, res: Response) => {
  const jobId = Number(req.params.id);
  const applications = await db.select().from(jobApplicationsTable)
    .where(eq(jobApplicationsTable.jobId, jobId))
    .orderBy(desc(jobApplicationsTable.createdAt));
  res.json(applications.map(mapApplication));
});

router.get("/admin/applications", requireAuth, async (_req: Request, res: Response) => {
  const applications = await db.select().from(jobApplicationsTable)
    .orderBy(desc(jobApplicationsTable.createdAt));
  res.json(applications.map(mapApplication));
});

router.patch("/admin/applications/:id", requireAdmin, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const { status, notes } = req.body ?? {};
  const upd: Record<string, unknown> = {};
  if (status !== undefined) upd.status = status;
  if (notes !== undefined) upd.notes = notes;
  const [app] = await db.update(jobApplicationsTable).set(upd).where(eq(jobApplicationsTable.id, id)).returning();
  if (!app) { res.status(404).json({ error: "Not found" }); return; }
  res.json(mapApplication(app));
});

export default router;
