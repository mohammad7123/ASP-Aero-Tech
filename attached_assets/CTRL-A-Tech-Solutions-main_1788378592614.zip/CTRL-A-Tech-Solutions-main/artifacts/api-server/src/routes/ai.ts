import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { siteSettingsTable, usageEventsTable } from "@workspace/db/schema";
import { requireAuth } from "../middlewares/auth.js";
import { decryptSetting, isEncrypted } from "../lib/settingsEncryption";

const router: IRouter = Router();

const PRESETS: Record<string, string> = {
  "marketing-email": "You are a senior B2B marketing copywriter for CtrlA Tech Solutions, an Indian SAP partner specializing in SAP Business One, SAP HANA, and ERP solutions. Write a persuasive, professional marketing email. Keep tone warm, confident, and consultative. Output only the email body (no subject line, no preamble). Use {Name} as the recipient placeholder. End with a clear single CTA.",
  "email-subject": "You are a B2B email subject-line expert. Write 5 short (under 60 chars), high-open-rate subject lines for the campaign described. Output as a numbered list, nothing else.",
  "blog-post": "You are an expert SAP and ERP technical content writer. Write a well-structured, SEO-optimized blog post in clean HTML (use <h2>, <h3>, <p>, <ul>, <li> tags only — no <html> or <body>). Include a compelling intro, 3-5 sections with subheadings, and a conclusion with CTA. 600-900 words.",
  "blog-outline": "You are an SEO content strategist. Create a detailed blog post outline with SEO-optimized H2/H3 structure, target keywords, meta description, and 3 suggested titles. Output in clean markdown.",
  "seo-meta": "You are an SEO specialist. Generate: 1) An optimized meta title (max 60 chars), 2) Meta description (max 155 chars), 3) Five focus keywords. Output as a clean numbered list.",
  "social-post": "You are a B2B social media manager. Write a punchy LinkedIn post (under 1300 chars) with engaging hook, 2-3 short paragraphs, relevant emojis (sparingly), and 5-7 hashtags at the end. Plain text only.",
  "ad-copy": "You are a Google Ads / Meta Ads copywriter for B2B SaaS. Generate 3 ad headline variants (max 30 chars each) and 3 description variants (max 90 chars each). Format as: HEADLINES: ... DESCRIPTIONS: ...",
  "product-description": "You are a B2B product marketer. Write a compelling product description with: 1) Punchy opening line, 2) Three key benefits as bullet points, 3) Who it's for, 4) Short closing CTA. Output in clean HTML using <p>, <ul>, <li> tags only.",
  "lead-reply": "You are a friendly B2B sales rep at CtrlA Tech Solutions. Write a personalized reply to the lead's enquiry. Acknowledge their need, briefly suggest the right product/solution, and propose next step (call/demo). Keep under 150 words. Output only the email body.",
  "sms-copy": "You are an SMS copywriter. Write 3 short SMS message variants (under 160 chars each) for the campaign described. Use {Name} as the recipient placeholder. Output as a numbered list.",
  "whatsapp-copy": "You are a WhatsApp business messaging specialist. Write a friendly, professional WhatsApp message (under 600 chars). Use {Name} as the recipient placeholder. Include 1-2 light emojis. End with clear next step.",
  "freeform": "You are a senior B2B marketing assistant for CtrlA Tech Solutions (an Indian SAP partner — SAP Business One, HANA, S/4 HANA, cloud, AI ERP). Help the user with their marketing/content task. Be specific, professional, and actionable.",
};

type Provider = "openai" | "anthropic" | "gemini" | "openrouter";

const PROVIDER_DEFAULTS: Record<Provider, { defaultModel: string; longModel: string; defaultBaseUrl: string; label: string }> = {
  openai: {
    defaultModel: "gpt-4o-mini",
    longModel: "gpt-4o",
    defaultBaseUrl: "https://api.openai.com/v1",
    label: "OpenAI (GPT-4o)",
  },
  anthropic: {
    defaultModel: "claude-3-5-haiku-latest",
    longModel: "claude-3-5-sonnet-latest",
    defaultBaseUrl: "https://api.anthropic.com/v1",
    label: "Anthropic (Claude)",
  },
  gemini: {
    defaultModel: "gemini-1.5-flash",
    longModel: "gemini-1.5-pro",
    defaultBaseUrl: "https://generativelanguage.googleapis.com/v1beta",
    label: "Google Gemini",
  },
  openrouter: {
    defaultModel: "openai/gpt-4o-mini",
    longModel: "openai/gpt-4o",
    defaultBaseUrl: "https://openrouter.ai/api/v1",
    label: "OpenRouter (multi-model)",
  },
};

function dec(v: string | null | undefined): string | null {
  if (!v) return null;
  try { return isEncrypted(v) ? decryptSetting(v) : v; } catch { return v; }
}

async function loadProviderConfig(provider: Provider): Promise<{ apiKey: string | null; baseUrl: string; model: string; longModel: string; label: string }> {
  const [s] = await db.select().from(siteSettingsTable).limit(1);
  const def = PROVIDER_DEFAULTS[provider];
  let apiKey: string | null = null;
  let baseUrl = def.defaultBaseUrl;
  let model = def.defaultModel;
  if (s) {
    if (provider === "openai") {
      apiKey = dec(s.openaiApiKey) ?? null;
      baseUrl = dec(s.openaiBaseUrl) ?? baseUrl;
      model = dec(s.openaiModel) ?? model;
    } else if (provider === "anthropic") {
      apiKey = dec(s.anthropicApiKey) ?? null;
      baseUrl = dec(s.anthropicBaseUrl) ?? baseUrl;
      model = dec(s.anthropicModel) ?? model;
    } else if (provider === "gemini") {
      apiKey = dec(s.geminiApiKey) ?? null;
      baseUrl = dec(s.geminiBaseUrl) ?? baseUrl;
      model = dec(s.geminiModel) ?? model;
    } else {
      apiKey = dec(s.openrouterApiKey) ?? null;
      baseUrl = dec(s.openrouterBaseUrl) ?? baseUrl;
      model = dec(s.openrouterModel) ?? model;
    }
  }
  return { apiKey, baseUrl, model, longModel: def.longModel, label: def.label };
}

async function recordUsage(channel: "ai" | "email" | "sms" | "whatsapp", provider: string, action: string, status: "success" | "failed", meta: Record<string, unknown> = {}) {
  try {
    await db.insert(usageEventsTable).values({ channel, provider, action, status, units: 1, meta });
  } catch (err) {
    console.warn("[usage] failed to record:", err instanceof Error ? err.message : err);
  }
}

router.get("/admin/ai/providers", requireAuth, async (_req, res) => {
  const [s] = await db.select().from(siteSettingsTable).limit(1);
  const list = (Object.keys(PROVIDER_DEFAULTS) as Provider[]).map(key => {
    const cfg = PROVIDER_DEFAULTS[key];
    let configured = false;
    if (s) {
      if (key === "openai") configured = !!dec(s.openaiApiKey);
      else if (key === "anthropic") configured = !!dec(s.anthropicApiKey);
      else if (key === "gemini") configured = !!dec(s.geminiApiKey);
      else if (key === "openrouter") configured = !!dec(s.openrouterApiKey);
    }
    return {
      key,
      label: cfg.label,
      configured,
      defaultModel: cfg.defaultModel,
      longModel: cfg.longModel,
    };
  });
  const defaultProvider = (s ? dec(s.defaultAiProvider) : null) ?? "openai";
  res.json({ providers: list, defaultProvider });
});

router.get("/admin/ai/presets", requireAuth, (_req, res) => {
  res.json({
    presets: Object.keys(PRESETS).map(key => ({
      key,
      label: key.replace(/-/g, " ").replace(/\b\w/g, c => c.toUpperCase()),
    })),
  });
});

router.post("/admin/ai/generate", requireAuth, async (req, res): Promise<void> => {
  const { preset = "freeform", prompt, context, provider: requestedProvider, model: requestedModel } = req.body ?? {};
  if (!prompt || typeof prompt !== "string" || prompt.trim().length === 0) {
    res.status(400).json({ error: "prompt is required" });
    return;
  }

  let provider: Provider;
  if (requestedProvider && PROVIDER_DEFAULTS[requestedProvider as Provider]) {
    provider = requestedProvider as Provider;
  } else {
    // Use admin-configured default provider when caller didn't specify one
    const [s] = await db.select().from(siteSettingsTable).limit(1);
    const def = (s ? dec(s.defaultAiProvider) : null) ?? "openai";
    provider = (PROVIDER_DEFAULTS[def as Provider] ? def : "openai") as Provider;
  }
  const cfg = await loadProviderConfig(provider);

  if (!cfg.apiKey) {
    await recordUsage("ai", provider, preset, "failed", { reason: "no-key" });
    res.status(400).json({ error: `${cfg.label} not configured. Add an API key in Settings → AI Providers.` });
    return;
  }

  const system = PRESETS[preset] ?? PRESETS["freeform"];
  const userMsg = context ? `${prompt.trim()}\n\nContext:\n${context}` : prompt.trim();
  const isLong = preset === "blog-post";
  const model = requestedModel || (isLong ? cfg.longModel : cfg.model);
  const maxTokens = isLong ? 3000 : 1000;
  const baseUrl = cfg.baseUrl.replace(/\/$/, "");

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 60000);
  const t0 = Date.now();

  try {
    let content = "";
    if (provider === "anthropic") {
      const response = await fetch(`${baseUrl}/messages`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": cfg.apiKey,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model,
          max_tokens: maxTokens,
          system,
          messages: [{ role: "user", content: userMsg }],
        }),
        signal: controller.signal,
      });
      if (!response.ok) {
        const errText = await response.text().catch(() => "");
        await recordUsage("ai", provider, preset, "failed", { status: response.status, model });
        res.status(502).json({ error: `Anthropic ${response.status}: ${errText.slice(0, 200)}` });
        return;
      }
      const data = await response.json() as { content?: Array<{ text?: string }> };
      content = data.content?.[0]?.text ?? "";
    } else if (provider === "gemini") {
      const url = `${baseUrl}/models/${model}:generateContent?key=${encodeURIComponent(cfg.apiKey)}`;
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: system }] },
          contents: [{ role: "user", parts: [{ text: userMsg }] }],
          generationConfig: { maxOutputTokens: maxTokens },
        }),
        signal: controller.signal,
      });
      if (!response.ok) {
        const errText = await response.text().catch(() => "");
        await recordUsage("ai", provider, preset, "failed", { status: response.status, model });
        res.status(502).json({ error: `Gemini ${response.status}: ${errText.slice(0, 200)}` });
        return;
      }
      const data = await response.json() as { candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }> };
      content = data.candidates?.[0]?.content?.parts?.map(p => p.text ?? "").join("") ?? "";
    } else {
      // openai + openrouter (both OpenAI-compatible)
      const response = await fetch(`${baseUrl}/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${cfg.apiKey}`,
        },
        body: JSON.stringify({
          model,
          max_tokens: maxTokens,
          messages: [
            { role: "system", content: system },
            { role: "user", content: userMsg },
          ],
        }),
        signal: controller.signal,
      });
      if (!response.ok) {
        const errText = await response.text().catch(() => "");
        await recordUsage("ai", provider, preset, "failed", { status: response.status, model });
        res.status(502).json({ error: `${cfg.label} ${response.status}: ${errText.slice(0, 200)}` });
        return;
      }
      const data = await response.json() as { choices?: Array<{ message?: { content?: string } }> };
      content = data.choices?.[0]?.message?.content ?? "";
    }

    await recordUsage("ai", provider, preset, "success", { model, ms: Date.now() - t0, chars: content.length });
    console.log(`[AI] ${provider}/${model} preset=${preset} took ${Date.now() - t0}ms, ${content.length} chars`);
    res.json({ content, preset, provider, model });
  } catch (err: unknown) {
    const isAbort = err instanceof Error && err.name === "AbortError";
    const message = isAbort ? "AI request timed out (60s)" : (err instanceof Error ? err.message : "AI generation failed");
    await recordUsage("ai", provider, preset, "failed", { error: message });
    console.error(`[AI] Error:`, message);
    res.status(isAbort ? 504 : 500).json({ error: message });
  } finally {
    clearTimeout(timeoutId);
  }
});

export default router;
