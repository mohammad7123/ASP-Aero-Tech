import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { blogPostsTable, blogCategoriesTable } from "@workspace/db/schema";
import { eq, desc, and, count } from "drizzle-orm";
import {
  CreateBlogPostBody,
  UpdateBlogPostBody,
  CreateBlogCategoryBody,
  GetAdminBlogPostResponse,
  GetPublicBlogPostResponse,
  UpdateBlogPostResponse,
  ListBlogCategoriesResponse,
  ListBlogPostsResponse,
  ListPublicBlogPostsResponse,
  ListPublicBlogPostsQueryParams,
} from "@workspace/api-zod";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

const mapPost = (p: typeof blogPostsTable.$inferSelect) => ({
  id: p.id,
  title: p.title,
  slug: p.slug,
  excerpt: p.excerpt,
  content: p.content,
  featuredImage: p.featuredImage,
  categoryId: p.categoryId,
  isPublished: p.isPublished,
  metaTitle: p.metaTitle,
  metaDescription: p.metaDescription,
  publishedAt: p.publishedAt?.toISOString() ?? null,
  createdAt: p.createdAt.toISOString(),
  updatedAt: p.updatedAt.toISOString(),
});

const mapCat = (c: typeof blogCategoriesTable.$inferSelect) => ({
  id: c.id,
  name: c.name,
  slug: c.slug,
  createdAt: c.createdAt.toISOString(),
});

router.get("/admin/blog/posts", requireAuth, async (_req: Request, res: Response) => {
  const rows = await db.select().from(blogPostsTable).orderBy(desc(blogPostsTable.createdAt));
  res.json(ListBlogPostsResponse.parse(rows.map(mapPost)));
});

router.post("/admin/blog/posts", requireAuth, async (req: Request, res: Response) => {
  const parsed = CreateBlogPostBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid body", details: parsed.error.flatten() }); return; }
  const data = { ...parsed.data, publishedAt: parsed.data.isPublished ? new Date() : null };
  const [post] = await db.insert(blogPostsTable).values(data).returning();
  res.status(201).json(mapPost(post));
});

router.get("/admin/blog/posts/:id", requireAuth, async (req: Request, res: Response) => {
  const [post] = await db.select().from(blogPostsTable).where(eq(blogPostsTable.id, Number(req.params.id))).limit(1);
  if (!post) { res.status(404).json({ error: "Not found" }); return; }
  res.json(GetAdminBlogPostResponse.parse(mapPost(post)));
});

router.patch("/admin/blog/posts/:id", requireAuth, async (req: Request, res: Response) => {
  const parsed = UpdateBlogPostBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid body" }); return; }
  const updateData: Record<string, unknown> = { ...parsed.data };
  if (parsed.data.isPublished !== undefined) {
    updateData.publishedAt = parsed.data.isPublished ? new Date() : null;
  }
  const [post] = await db.update(blogPostsTable).set(updateData).where(eq(blogPostsTable.id, Number(req.params.id))).returning();
  if (!post) { res.status(404).json({ error: "Not found" }); return; }
  res.json(UpdateBlogPostResponse.parse(mapPost(post)));
});

router.delete("/admin/blog/posts/:id", requireAuth, async (req: Request, res: Response) => {
  await db.delete(blogPostsTable).where(eq(blogPostsTable.id, Number(req.params.id)));
  res.status(204).send();
});

router.get("/admin/blog/categories", requireAuth, async (_req: Request, res: Response) => {
  const rows = await db.select().from(blogCategoriesTable);
  res.json(ListBlogCategoriesResponse.parse(rows.map(mapCat)));
});

router.post("/admin/blog/categories", requireAuth, async (req: Request, res: Response) => {
  const parsed = CreateBlogCategoryBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid body" }); return; }
  const [cat] = await db.insert(blogCategoriesTable).values(parsed.data).returning();
  res.status(201).json(mapCat(cat));
});

router.delete("/admin/blog/categories/:id", requireAuth, async (req: Request, res: Response) => {
  await db.delete(blogCategoriesTable).where(eq(blogCategoriesTable.id, Number(req.params.id)));
  res.status(204).send();
});

router.get("/blog/posts", async (req: Request, res: Response) => {
  const parsed = ListPublicBlogPostsQueryParams.safeParse(req.query);
  const limit = parsed.success ? (parsed.data.limit ?? 10) : 10;
  const offset = parsed.success ? (parsed.data.offset ?? 0) : 0;

  const [{ total }] = await db
    .select({ total: count() })
    .from(blogPostsTable)
    .where(eq(blogPostsTable.isPublished, true));

  const rows = await db.select().from(blogPostsTable)
    .where(eq(blogPostsTable.isPublished, true))
    .orderBy(desc(blogPostsTable.publishedAt))
    .limit(limit)
    .offset(offset);

  res.json(ListPublicBlogPostsResponse.parse({ posts: rows.map(mapPost), total, limit, offset }));
});

router.get("/blog/posts/:slug", async (req: Request, res: Response) => {
  const [post] = await db.select().from(blogPostsTable)
    .where(and(eq(blogPostsTable.slug, String(req.params.slug)), eq(blogPostsTable.isPublished, true)))
    .limit(1);
  if (!post) { res.status(404).json({ error: "Not found" }); return; }
  res.json(GetPublicBlogPostResponse.parse(mapPost(post)));
});

export default router;
