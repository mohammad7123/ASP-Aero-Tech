import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { menuItemsTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import {
  CreateMenuItemBody,
  UpdateMenuItemBody,
  ReorderMenuItemsBody,
} from "@workspace/api-zod";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

const mapItem = (m: typeof menuItemsTable.$inferSelect) => ({
  id: m.id,
  label: m.label,
  url: m.url,
  pageId: m.pageId,
  sortOrder: m.sortOrder,
  openInNewTab: m.openInNewTab,
  isVisible: m.isVisible,
  createdAt: m.createdAt.toISOString(),
  updatedAt: m.updatedAt.toISOString(),
});

router.get("/admin/menu", requireAuth, async (_req: Request, res: Response) => {
  const rows = await db.select().from(menuItemsTable).orderBy(menuItemsTable.sortOrder);
  res.json(rows.map(mapItem));
});

router.post("/admin/menu", requireAuth, async (req: Request, res: Response) => {
  const parsed = CreateMenuItemBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid body" }); return; }
  const [item] = await db.insert(menuItemsTable).values(parsed.data).returning();
  res.status(201).json(mapItem(item));
});

router.put("/admin/menu/reorder", requireAuth, async (req: Request, res: Response) => {
  const parsed = ReorderMenuItemsBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid body" }); return; }
  const updated = await Promise.all(
    parsed.data.ids.map((id, index) =>
      db.update(menuItemsTable).set({ sortOrder: index }).where(eq(menuItemsTable.id, id)).returning().then(r => r[0])
    )
  );
  res.json(updated.filter(Boolean).map(mapItem));
});

router.patch("/admin/menu/:id/visibility", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const { isVisible } = req.body as { isVisible: boolean };
  if (typeof isVisible !== "boolean") { res.status(400).json({ error: "isVisible must be boolean" }); return; }
  const [item] = await db.update(menuItemsTable).set({ isVisible }).where(eq(menuItemsTable.id, id)).returning();
  if (!item) { res.status(404).json({ error: "Menu item not found" }); return; }
  res.json(mapItem(item));
});

router.patch("/admin/menu/:id", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const parsed = UpdateMenuItemBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid body" }); return; }
  const [item] = await db.update(menuItemsTable).set(parsed.data).where(eq(menuItemsTable.id, id)).returning();
  if (!item) { res.status(404).json({ error: "Menu item not found" }); return; }
  res.json(mapItem(item));
});

router.delete("/admin/menu/:id", requireAuth, async (req: Request, res: Response) => {
  await db.delete(menuItemsTable).where(eq(menuItemsTable.id, Number(req.params.id)));
  res.status(204).send();
});

export default router;
