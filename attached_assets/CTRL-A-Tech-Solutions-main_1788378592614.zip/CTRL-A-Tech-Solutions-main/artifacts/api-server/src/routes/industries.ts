import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { industriesTable } from "@workspace/db/schema";
import { eq, asc, and, gt, lt, desc } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

const mapItem = (item: typeof industriesTable.$inferSelect) => ({
  id: item.id,
  name: item.name,
  slug: item.slug,
  shortDesc: item.shortDesc,
  description: item.description,
  imageUrl: item.imageUrl,
  iconName: item.iconName,
  accentColor: item.accentColor,
  sortOrder: item.sortOrder,
  isActive: item.isActive,
  createdAt: item.createdAt.toISOString(),
  updatedAt: item.updatedAt.toISOString(),
});

router.get("/public/industries", async (_req: Request, res: Response) => {
  const rows = await db.select().from(industriesTable)
    .where(eq(industriesTable.isActive, true))
    .orderBy(asc(industriesTable.sortOrder), asc(industriesTable.id));
  res.json(rows.map(mapItem));
});

router.get("/admin/industries", requireAuth, async (_req: Request, res: Response) => {
  const rows = await db.select().from(industriesTable)
    .orderBy(asc(industriesTable.sortOrder), asc(industriesTable.id));
  res.json(rows.map(mapItem));
});

router.post("/admin/industries", requireAuth, async (req: Request, res: Response) => {
  const b = req.body ?? {};
  if (!b.name) { res.status(400).json({ error: "name required" }); return; }
  const slug = b.slug || String(b.name).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  const [item] = await db.insert(industriesTable).values({
    name: b.name,
    slug,
    shortDesc: b.shortDesc ?? "",
    description: b.description ?? "",
    imageUrl: b.imageUrl ?? null,
    iconName: b.iconName ?? "Building2",
    accentColor: b.accentColor ?? "#3D4FA0",
    sortOrder: b.sortOrder ?? 0,
    isActive: b.isActive ?? true,
  }).returning();
  res.status(201).json(mapItem(item));
});

router.patch("/admin/industries/:id", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const b = req.body ?? {};
  const upd: Record<string, unknown> = {};
  for (const k of ["name","slug","shortDesc","description","iconName","accentColor","sortOrder","isActive"] as const) {
    if (b[k] !== undefined) upd[k] = b[k];
  }
  if ("imageUrl" in b) upd.imageUrl = b.imageUrl ?? null;
  const [item] = await db.update(industriesTable).set(upd).where(eq(industriesTable.id, id)).returning();
  if (!item) { res.status(404).json({ error: "Not found" }); return; }
  res.json(mapItem(item));
});

router.delete("/admin/industries/:id", requireAuth, async (req: Request, res: Response) => {
  await db.delete(industriesTable).where(eq(industriesTable.id, Number(req.params.id)));
  res.status(204).send();
});

router.post("/admin/industries/:id/move", requireAuth, async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const direction = req.body?.direction === "up" ? "up" : "down";
  const [me] = await db.select().from(industriesTable).where(eq(industriesTable.id, id));
  if (!me) { res.status(404).json({ error: "Not found" }); return; }
  const neighbors = direction === "up"
    ? await db.select().from(industriesTable).where(lt(industriesTable.sortOrder, me.sortOrder)).orderBy(desc(industriesTable.sortOrder)).limit(1)
    : await db.select().from(industriesTable).where(gt(industriesTable.sortOrder, me.sortOrder)).orderBy(asc(industriesTable.sortOrder)).limit(1);
  let neighbor = neighbors[0];
  if (!neighbor) {
    const ties = await db.select().from(industriesTable).where(and(eq(industriesTable.sortOrder, me.sortOrder), direction === "up" ? lt(industriesTable.id, me.id) : gt(industriesTable.id, me.id)));
    neighbor = direction === "up" ? ties[ties.length - 1] : ties[0];
  }
  if (!neighbor) { res.json({ ok: true, moved: false }); return; }
  await db.update(industriesTable).set({ sortOrder: neighbor.sortOrder }).where(eq(industriesTable.id, me.id));
  await db.update(industriesTable).set({ sortOrder: me.sortOrder }).where(eq(industriesTable.id, neighbor.id));
  res.json({ ok: true, moved: true });
});

export default router;
