import crypto from "crypto";
import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";

// Known-leaked / committed secrets. Refuse to boot if any of these appear in
// process.env.JWT_SECRET — forces operator to rotate.
const BLOCKED_JWT_SECRETS = new Set<string>([
  "4087bd417b14f9aa3a4d7665d44e30413741db19bf797816e4fc67b14e414fdd5b0ac143e57cda2507abab5347337db9",
  "059f71e9fa3069e6fce3e0845f985be30b3dc35255eab818f86fa2e4c1d728ce3e90dc87183b942a099dd5a2e1e47c0f",
]);

let JWT_SECRET: string;
if (process.env.JWT_SECRET) {
  if (BLOCKED_JWT_SECRETS.has(process.env.JWT_SECRET)) {
    throw new Error(
      "JWT_SECRET matches a known-leaked value. Rotate it in your Secrets store before starting the server.",
    );
  }
  if (process.env.JWT_SECRET.length < 32) {
    throw new Error("JWT_SECRET is too short. Use at least 32 chars (64+ recommended).");
  }
  JWT_SECRET = process.env.JWT_SECRET;
} else if (process.env.NODE_ENV === "production") {
  throw new Error("JWT_SECRET environment variable is required in production");
} else {
  JWT_SECRET = crypto.randomBytes(32).toString("hex");
  console.warn(
    "[auth] WARNING: JWT_SECRET not set. Using ephemeral random secret. " +
    "All sessions will be invalidated on server restart. " +
    "Set JWT_SECRET as a Replit Secret for persistent sessions.",
  );
}

export interface AuthRequest extends Request {
  adminId?: number;
  adminUsername?: string;
  adminRole?: string;
}

export { JWT_SECRET };

export function requireAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const token = authHeader.slice(7);
  try {
    const payload = jwt.verify(token, JWT_SECRET) as { id: number; username: string; role: string };
    req.adminId = payload.id;
    req.adminUsername = payload.username;
    req.adminRole = payload.role ?? "admin";
    next();
  } catch {
    res.status(401).json({ error: "Invalid or expired token" });
  }
}

export function requireAdmin(req: AuthRequest, res: Response, next: NextFunction) {
  requireAuth(req, res, () => {
    if (req.adminRole !== "admin") {
      res.status(403).json({ error: "Admin access required" });
      return;
    }
    next();
  });
}

export function signToken(payload: { id: number; username: string; role: string }): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: "7d" });
}
