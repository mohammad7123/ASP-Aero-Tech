import crypto from "crypto";

const ALGO = "aes-256-gcm";
const IV_LEN = 12;
const TAG_LEN = 16;
const ENC_PREFIX = "enc:v1:";

let _key: Buffer | null = null;

function getKey(): Buffer {
  if (_key) return _key;

  const raw = process.env.SETTINGS_ENCRYPTION_KEY;
  if (raw) {
    _key = crypto.scryptSync(raw, "ctrla-cms-settings-v1", 32);
    return _key;
  }

  console.warn(
    "[settings] WARNING: SETTINGS_ENCRYPTION_KEY not set. " +
    "Using deterministic fallback key. " +
    "Set SETTINGS_ENCRYPTION_KEY as a Replit Secret for production security.",
  );
  _key = crypto.scryptSync("dev-only-ctrla-cms-key-not-for-prod", "ctrla-cms-settings-v1", 32);
  return _key;
}

export function encryptSetting(plaintext: string): string {
  const key = getKey();
  const iv = crypto.randomBytes(IV_LEN);
  const cipher = crypto.createCipheriv(ALGO, key, iv);
  const ciphertext = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${ENC_PREFIX}${iv.toString("hex")}:${tag.toString("hex")}:${ciphertext.toString("hex")}`;
}

export function decryptSetting(value: string): string {
  if (!value.startsWith(ENC_PREFIX)) {
    return value;
  }
  const key = getKey();
  const parts = value.slice(ENC_PREFIX.length).split(":");
  if (parts.length !== 3) throw new Error("Malformed encrypted setting");
  const [ivHex, tagHex, ctHex] = parts;
  const iv = Buffer.from(ivHex, "hex");
  const tag = Buffer.from(tagHex, "hex");
  const ciphertext = Buffer.from(ctHex, "hex");
  const decipher = crypto.createDecipheriv(ALGO, key, iv);
  decipher.setAuthTag(tag);
  return decipher.update(ciphertext).toString("utf8") + decipher.final("utf8");
}

export function isEncrypted(value: string): boolean {
  return value.startsWith(ENC_PREFIX);
}
