import fs, { promises as fsp } from "fs";
import path from "path";
import crypto, { randomUUID } from "crypto";
import { Readable } from "stream";
import {
  ObjectAclPolicy,
  ObjectPermission,
  canAccessObject,
  getObjectAclPolicy,
  setObjectAclPolicy,
} from "./objectAcl";

// ── Local disk object storage ────────────────────────────────────────────────
//
// Replaces Replit's built-in object storage sidecar (only reachable inside
// Replit) with plain files on the server's disk. Uploads use the same
// two-step "presigned URL" contract the frontend already speaks:
//   1. POST /api/storage/uploads/request-url -> { uploadURL, objectPath }
//   2. PUT <uploadURL> with the raw file bytes
// Here `uploadURL` is a same-origin path signed with an HMAC token instead
// of a real cloud-signed URL, so no separate credential exchange is needed.

const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || path.join(process.cwd(), "uploads"));
const UPLOAD_TOKEN_TTL_SEC = 15 * 60;
export const MAX_UPLOAD_BYTES = 25 * 1024 * 1024; // 25 MB

function getSigningSecret(): string {
  const secret = process.env.JWT_SECRET;
  if (secret) return secret;
  if (process.env.NODE_ENV === "production") {
    throw new Error("JWT_SECRET must be set in production (also used to sign upload URLs).");
  }
  return "dev-only-upload-signing-secret";
}

function signUploadToken(objectName: string, expiresAt: number): string {
  return crypto
    .createHmac("sha256", getSigningSecret())
    .update(`${objectName}:${expiresAt}`)
    .digest("hex");
}

export function verifyUploadToken(objectName: string, expiresAt: number, token: string): boolean {
  if (Number.isNaN(expiresAt) || Date.now() > expiresAt) return false;
  const expected = signUploadToken(objectName, expiresAt);
  const a = Buffer.from(expected, "hex");
  const b = Buffer.from(token, "hex");
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export class ObjectNotFoundError extends Error {
  constructor() {
    super("Object not found");
    this.name = "ObjectNotFoundError";
    Object.setPrototypeOf(this, ObjectNotFoundError.prototype);
  }
}

interface LocalMeta {
  contentType: string;
  size: number;
  acl?: ObjectAclPolicy;
}

function metaPath(diskPath: string): string {
  return `${diskPath}.meta.json`;
}

async function readMeta(diskPath: string): Promise<LocalMeta | null> {
  try {
    const raw = await fsp.readFile(metaPath(diskPath), "utf8");
    return JSON.parse(raw) as LocalMeta;
  } catch {
    return null;
  }
}

async function writeMeta(diskPath: string, meta: LocalMeta): Promise<void> {
  await fsp.writeFile(metaPath(diskPath), JSON.stringify(meta), "utf8");
}

/** A minimal stand-in for the subset of the GCS `File` API this app uses. */
export class LocalObjectFile {
  constructor(public readonly objectName: string, public readonly diskPath: string) {}

  async exists(): Promise<[boolean]> {
    return [fs.existsSync(this.diskPath)];
  }

  async getMetadata(): Promise<[{ contentType?: string; size?: number; aclPolicy?: ObjectAclPolicy }]> {
    const meta = await readMeta(this.diskPath);
    const stat = await fsp.stat(this.diskPath).catch(() => null);
    return [
      {
        contentType: meta?.contentType || "application/octet-stream",
        size: stat?.size,
        aclPolicy: meta?.acl,
      },
    ];
  }

  async setMetadata(update: { metadata: Record<string, string> }): Promise<void> {
    const meta = (await readMeta(this.diskPath)) ?? { contentType: "application/octet-stream", size: 0 };
    const rawAcl = update.metadata["custom:aclPolicy"];
    if (rawAcl) meta.acl = JSON.parse(rawAcl) as ObjectAclPolicy;
    await writeMeta(this.diskPath, meta);
  }

  createReadStream(): fs.ReadStream {
    return fs.createReadStream(this.diskPath);
  }
}

export class ObjectStorageService {
  private ensureDirSync(dir: string) {
    fs.mkdirSync(dir, { recursive: true });
  }

  private objectNameToDiskPath(objectName: string): string {
    const resolved = path.resolve(UPLOAD_DIR, objectName);
    if (resolved !== UPLOAD_DIR && !resolved.startsWith(UPLOAD_DIR + path.sep)) {
      throw new Error("Invalid object path");
    }
    return resolved;
  }

  /** Returns a same-origin, HMAC-signed URL the client can PUT the file to. */
  async getObjectEntityUploadURL(): Promise<string> {
    const objectId = randomUUID();
    const objectName = `uploads/${objectId}`;
    this.ensureDirSync(path.dirname(this.objectNameToDiskPath(objectName)));

    const expiresAt = Date.now() + UPLOAD_TOKEN_TTL_SEC * 1000;
    const token = signUploadToken(objectName, expiresAt);
    return `/api/storage/objects/${objectName}?token=${token}&exp=${expiresAt}`;
  }

  /** Converts an upload URL or a canonical `/objects/...` path into the canonical form. */
  normalizeObjectEntityPath(rawPath: string): string {
    const match = rawPath.match(/\/api\/storage\/objects\/(uploads\/[^?]+)/);
    if (match) return `/objects/${match[1]}`;
    return rawPath;
  }

  async writeObjectEntity(objectName: string, body: Readable, contentType: string): Promise<number> {
    const diskPath = this.objectNameToDiskPath(objectName);
    this.ensureDirSync(path.dirname(diskPath));

    let size = 0;
    await new Promise<void>((resolve, reject) => {
      const out = fs.createWriteStream(diskPath);
      body.on("data", (chunk: Buffer) => {
        size += chunk.length;
        if (size > MAX_UPLOAD_BYTES) {
          out.destroy();
          body.destroy();
          reject(new Error("File too large"));
        }
      });
      body.pipe(out);
      out.on("finish", resolve);
      out.on("error", reject);
      body.on("error", reject);
    });

    await writeMeta(diskPath, { contentType, size });
    return size;
  }

  async getObjectEntityFile(objectPath: string): Promise<LocalObjectFile> {
    if (!objectPath.startsWith("/objects/")) {
      throw new ObjectNotFoundError();
    }
    const objectName = objectPath.slice("/objects/".length);
    const diskPath = this.objectNameToDiskPath(objectName);
    if (!fs.existsSync(diskPath)) {
      throw new ObjectNotFoundError();
    }
    return new LocalObjectFile(objectName, diskPath);
  }

  async searchPublicObject(filePath: string): Promise<LocalObjectFile | null> {
    const objectName = `uploads/${filePath}`;
    const diskPath = this.objectNameToDiskPath(objectName);
    if (fs.existsSync(diskPath)) {
      return new LocalObjectFile(objectName, diskPath);
    }
    return null;
  }

  async downloadObject(file: LocalObjectFile, cacheTtlSec: number = 3600): Promise<Response> {
    const [metadata] = await file.getMetadata();
    const aclPolicy = await getObjectAclPolicy(file);
    const isPublic = aclPolicy?.visibility !== "private";

    const nodeStream = file.createReadStream();
    const webStream = Readable.toWeb(nodeStream) as ReadableStream;

    const headers: Record<string, string> = {
      "Content-Type": metadata.contentType || "application/octet-stream",
      "Cache-Control": `${isPublic ? "public" : "private"}, max-age=${cacheTtlSec}`,
    };
    if (metadata.size !== undefined) {
      headers["Content-Length"] = String(metadata.size);
    }

    return new Response(webStream, { headers });
  }

  async trySetObjectEntityAclPolicy(rawPath: string, aclPolicy: ObjectAclPolicy): Promise<string> {
    const normalizedPath = this.normalizeObjectEntityPath(rawPath);
    if (!normalizedPath.startsWith("/")) {
      return normalizedPath;
    }
    const objectFile = await this.getObjectEntityFile(normalizedPath);
    await setObjectAclPolicy(objectFile, aclPolicy);
    return normalizedPath;
  }

  async canAccessObjectEntity({
    userId,
    objectFile,
    requestedPermission,
  }: {
    userId?: string;
    objectFile: LocalObjectFile;
    requestedPermission?: ObjectPermission;
  }): Promise<boolean> {
    return canAccessObject({
      userId,
      objectFile,
      requestedPermission: requestedPermission ?? ObjectPermission.READ,
    });
  }
}
