// PM2 process definition for the api-server. In production it also serves
// the prebuilt frontend (artifacts/ctrla-website/dist/public) — see app.ts.
//
// Usage on the server:
//   cd artifacts/api-server
//   pm2 start ecosystem.config.js
//   pm2 save
//
// Secrets live at /etc/ctrla-web/api-server.env, OUTSIDE the git checkout —
// not at a repo-relative .env path, because `actions/checkout` runs
// `git clean -ffdx` on every deploy by default, which would silently delete
// an in-repo .env file. See DEPLOY.md for how to create that file.
module.exports = {
  apps: [
    {
      name: "ctrla-api",
      cwd: __dirname,
      script: "./dist/index.mjs",
      node_args: "--enable-source-maps -r dotenv/config",
      env: {
        DOTENV_CONFIG_PATH: "/etc/ctrla-web/api-server.env",
      },
      instances: 1,
      exec_mode: "fork",
      autorestart: true,
      max_restarts: 10,
      restart_delay: 3000,
      max_memory_restart: "500M",
      out_file: "/var/log/ctrla-web/api-out.log",
      error_file: "/var/log/ctrla-web/api-error.log",
      time: true,
    },
  ],
};
