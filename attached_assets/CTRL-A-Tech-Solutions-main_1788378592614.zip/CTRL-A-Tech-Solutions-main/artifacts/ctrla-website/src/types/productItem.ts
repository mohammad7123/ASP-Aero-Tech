export type ProductItem = {
  id: number;
  category: string;
  name: string;
  slug: string;
  shortDesc: string;
  description: string | null;
  imageUrl: string | null;
  iconName: string;
  accentColor: string;
  sortOrder: number;
  isActive: boolean;
};
