import { useState, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import PublicLayout from "@/components/public/PublicLayout";
import { MapPin, Clock, DollarSign, Briefcase, Upload, X, CheckCircle, ChevronDown, ChevronUp, ArrowRight } from "lucide-react";
import { useSiteConfig } from "@/contexts/SiteConfigContext";
import { SEO } from "@/components/SEO";
import CaptchaWidget from "@/components/public/CaptchaWidget";
import SuccessModal from "@/components/public/SuccessModal";

function isValidPhone(phone: string): boolean {
  if (!phone.trim()) return true;
  const digits = phone.replace(/[^0-9]/g, "");
  return /^[+]?[0-9\s\-().]{7,20}$/.test(phone.trim()) && digits.length >= 7;
}

const _C_BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";
type CareersCarmsPage = { metaTitle?: string | null; metaDescription?: string | null };
async function _fetchCareersCmsPage(slug: string): Promise<CareersCarmsPage> {
  const res = await fetch(`${_C_BASE}/api/pages/${slug}`);
  if (!res.ok) return {};
  return res.json();
}

type Job = {
  id: number; title: string; department: string; location: string; type: string;
  description: string; requirements: string; salaryRange: string | null; createdAt: string;
};

const TYPE_COLORS: Record<string, string> = {
  "full-time": "bg-green-100 text-green-700",
  "part-time": "bg-blue-100 text-blue-700",
  "contract": "bg-purple-100 text-purple-700",
  "internship": "bg-orange-100 text-orange-700",
  "remote": "bg-teal-100 text-teal-700",
};

async function fetchJobs(): Promise<Job[]> {
  const base = import.meta.env.BASE_URL.replace(/\/$/, "");
  const res = await fetch(`${base}/api/public/jobs`);
  if (!res.ok) throw new Error("Failed to fetch jobs");
  return res.json();
}

export default function CareersPage() {
  const config = useSiteConfig();
  const [applyJob, setApplyJob] = useState<Job | null>(null);
  const [expanded, setExpanded] = useState<number | null>(null);

  const { data: jobs = [], isLoading } = useQuery<Job[]>({
    queryKey: ["public-jobs"],
    queryFn: fetchJobs,
  });
  const { data: cmsPage } = useQuery<CareersCarmsPage>({ queryKey: ["pages", "careers"], queryFn: () => _fetchCareersCmsPage("careers"), staleTime: 60_000 });

  return (
    <PublicLayout>
      <SEO
        title={cmsPage?.metaTitle ?? "Careers — CtrlA Tech Solutions"}
        description={cmsPage?.metaDescription ?? "Join the CtrlA Tech Solutions team. Explore job openings in technology, SAP, cloud, and digital marketing across India and the UK."}
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "WebPage",
          name: cmsPage?.metaTitle ?? "Careers — CtrlA Tech Solutions",
          description: cmsPage?.metaDescription ?? "Join the CtrlA Tech Solutions team. Explore job openings in technology, SAP, cloud, and digital marketing across India and the UK.",
          url: window.location.href,
          about: {
            "@type": "Organization",
            name: "CtrlA Tech Solutions",
            url: window.location.origin,
          },
        }}
      />
      <div className="bg-gradient-to-br from-[#1A1F36] to-[#3D4FA0] pt-28 pb-16 text-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold mb-5 bg-white/15 backdrop-blur-sm">
            <Briefcase size={12} /> Careers at {config.siteName}
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
            Join Our <span style={{ color: config.primaryColor }}>Growing Team</span>
          </h1>
          <p className="text-white/80 text-lg max-w-2xl">
            Build the future of enterprise technology with us. We're looking for passionate people to help our clients succeed with SAP and cutting-edge tech.
          </p>
        </div>
      </div>

      <section className="py-16 bg-gray-50 min-h-[50vh]">
        <div className="max-w-5xl mx-auto px-4 sm:px-6">
          {isLoading ? (
            <div className="space-y-4">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="h-28 bg-white rounded-xl border border-gray-200 animate-pulse" />
              ))}
            </div>
          ) : jobs.length === 0 ? (
            <div className="text-center py-20">
              <Briefcase size={48} className="mx-auto mb-4 text-gray-300" />
              <h2 className="text-xl font-bold text-gray-700 mb-2">No openings at the moment</h2>
              <p className="text-gray-500">We're not actively hiring right now, but check back soon or send us your CV!</p>
              <a href="/contact" className="mt-6 inline-flex items-center gap-2 px-5 py-2.5 rounded-lg text-white text-sm font-bold"
                style={{ backgroundColor: config.primaryColor }}>
                Contact Us <ArrowRight size={14} />
              </a>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-gray-500 text-sm font-medium mb-2">{jobs.length} open position{jobs.length !== 1 ? "s" : ""}</p>
              {jobs.map(job => (
                <div key={job.id} className="bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow overflow-hidden">
                  <div className="p-5">
                    <div className="flex flex-col sm:flex-row sm:items-start gap-3">
                      <div className="flex-1">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <h3 className="text-lg font-bold text-gray-900">{job.title}</h3>
                          <span className={`text-xs font-semibold px-2 py-0.5 rounded-full capitalize ${TYPE_COLORS[job.type] ?? "bg-gray-100 text-gray-600"}`}>
                            {job.type}
                          </span>
                        </div>
                        <div className="flex flex-wrap gap-3 text-sm text-gray-500">
                          {job.department && <span className="flex items-center gap-1"><Briefcase size={13} /> {job.department}</span>}
                          {job.location && <span className="flex items-center gap-1"><MapPin size={13} /> {job.location}</span>}
                          {job.salaryRange && <span className="flex items-center gap-1"><DollarSign size={13} /> {job.salaryRange}</span>}
                        </div>
                      </div>
                      <div className="flex gap-2 flex-shrink-0">
                        <button onClick={() => setExpanded(expanded === job.id ? null : job.id)}
                          className="flex items-center gap-1.5 px-4 py-2 rounded-lg border border-gray-200 text-sm font-semibold text-gray-600 hover:bg-gray-50">
                          Details {expanded === job.id ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                        </button>
                        <button onClick={() => setApplyJob(job)}
                          className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-bold text-white"
                          style={{ backgroundColor: config.primaryColor }}>
                          Apply <ArrowRight size={13} />
                        </button>
                      </div>
                    </div>

                    {expanded === job.id && (
                      <div className="mt-4 pt-4 border-t border-gray-100 space-y-3">
                        {job.description && (
                          <div>
                            <h4 className="text-sm font-bold text-gray-800 mb-1">About the Role</h4>
                            <p className="text-sm text-gray-600 whitespace-pre-line leading-relaxed">{job.description}</p>
                          </div>
                        )}
                        {job.requirements && (
                          <div>
                            <h4 className="text-sm font-bold text-gray-800 mb-1">Requirements</h4>
                            <p className="text-sm text-gray-600 whitespace-pre-line leading-relaxed">{job.requirements}</p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {applyJob && <ApplyModal job={applyJob} onClose={() => setApplyJob(null)} />}
    </PublicLayout>
  );
}

function ApplyModal({ job, onClose }: { job: Job; onClose: () => void }) {
  const config = useSiteConfig();
  const [form, setForm] = useState({ name: "", email: "", phone: "", coverLetter: "" });
  const [file, setFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [captchaToken, setCaptchaToken] = useState("");
  const [captchaAnswer, setCaptchaAnswer] = useState("");
  const [captchaKey, setCaptchaKey] = useState(0);
  const [phoneError, setPhoneError] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      const base = import.meta.env.BASE_URL.replace(/\/$/, "");
      let cvObjectPath: string | null = null;
      let cvFilename: string | null = null;

      if (file) {
        const urlRes = await fetch(`${base}/api/public/jobs/upload-cv-url`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name: file.name, size: file.size, contentType: file.type }),
        });
        if (!urlRes.ok) throw new Error("Failed to get upload URL");
        const { uploadURL, objectPath } = await urlRes.json();
        const uploadRes = await fetch(uploadURL, { method: "PUT", body: file, headers: { "Content-Type": file.type } });
        if (!uploadRes.ok) throw new Error("CV upload failed");
        cvObjectPath = objectPath;
        cvFilename = file.name;
      }

      if (form.phone && !isValidPhone(form.phone)) {
        setPhoneError("Please enter a valid phone number (digits, +, -, spaces; min 7 digits).");
        setSubmitting(false);
        return;
      }
      const res = await fetch(`${base}/api/public/jobs/${job.id}/apply`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, cvObjectPath, cvFilename, captchaToken, captchaAnswer }),
      });
      if (!res.ok) {
        const d = await res.json().catch(() => ({}));
        throw new Error(d.error ?? "Submission failed");
      }
      setForm({ name: "", email: "", phone: "", coverLetter: "" });
      setFile(null);
      setPhoneError("");
      setCaptchaToken("");
      setCaptchaAnswer("");
      setCaptchaKey(k => k + 1);
      setShowSuccess(true);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Submission failed";
      setError(msg);
      if (msg.toLowerCase().includes("security check") || msg.toLowerCase().includes("captcha")) {
        setCaptchaToken("");
        setCaptchaAnswer("");
        setCaptchaKey(k => k + 1);
      }
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[95vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-100 sticky top-0 bg-white z-10">
          <div>
            <h2 className="text-lg font-bold text-gray-900">Apply for Position</h2>
            <p className="text-sm text-gray-500">{job.title}</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100"><X size={18} /></button>
        </div>

        <SuccessModal
          open={showSuccess}
          onClose={() => { setShowSuccess(false); onClose(); }}
          title="Application Submitted!"
          message="Thank you for applying! We have received your application and our team will review it and get back to you as soon as possible."
        />
        {(
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Full Name *</label>
              <input required value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-[#E84821]"
                placeholder="Your full name" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Email *</label>
              <input required type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-[#E84821]"
                placeholder="your@email.com" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Phone</label>
              <input type="tel" value={form.phone} onChange={e => {
                const val = e.target.value;
                setForm(p => ({ ...p, phone: val }));
                setPhoneError(val && !isValidPhone(val) ? "Enter a valid phone number (7–15 digits, may include +, -, spaces)." : "");
              }}
                className={`w-full border rounded-lg px-3 py-2.5 text-sm outline-none focus:border-[#E84821] ${phoneError ? "border-red-400" : "border-gray-200"}`}
                placeholder="+91 98765 43210" />
              {phoneError && <p className="text-xs text-red-500 mt-1">{phoneError}</p>}
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Cover Letter (optional)</label>
              <textarea value={form.coverLetter} onChange={e => setForm(p => ({ ...p, coverLetter: e.target.value }))}
                rows={4} className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-[#E84821] resize-y"
                placeholder="Tell us why you'd be a great fit…" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Upload CV / Resume</label>
              <div
                onClick={() => fileRef.current?.click()}
                className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-colors ${file ? "border-green-400 bg-green-50" : "border-gray-200 hover:border-gray-400"}`}
              >
                {file ? (
                  <div className="flex items-center justify-center gap-2 text-green-700">
                    <CheckCircle size={16} />
                    <span className="text-sm font-medium">{file.name}</span>
                    <button type="button" onClick={e => { e.stopPropagation(); setFile(null); }}
                      className="ml-1 text-gray-400 hover:text-red-500"><X size={14} /></button>
                  </div>
                ) : (
                  <div className="text-gray-400">
                    <Upload size={24} className="mx-auto mb-2" />
                    <p className="text-sm">Click to upload CV (PDF, DOC, DOCX)</p>
                    <p className="text-xs mt-0.5">Max 10 MB</p>
                  </div>
                )}
                <input ref={fileRef} type="file" className="hidden"
                  accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                  onChange={e => setFile(e.target.files?.[0] ?? null)} />
              </div>
            </div>
            {error && <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{error}</p>}
            <CaptchaWidget
              key={captchaKey}
              onVerify={(tok, ans) => { setCaptchaToken(tok); setCaptchaAnswer(ans); }}
              onExpire={() => { setCaptchaToken(""); setCaptchaAnswer(""); }}
            />
            <div className="flex justify-end gap-3 pt-2 border-t border-gray-100">
              <button type="button" onClick={onClose} className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900">Cancel</button>
              <button type="submit" disabled={submitting || !captchaAnswer}
                className="px-5 py-2.5 text-white rounded-lg text-sm font-bold disabled:opacity-50 transition-opacity"
                style={{ backgroundColor: config.primaryColor }}>
                {submitting ? "Submitting…" : "Submit Application"}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
