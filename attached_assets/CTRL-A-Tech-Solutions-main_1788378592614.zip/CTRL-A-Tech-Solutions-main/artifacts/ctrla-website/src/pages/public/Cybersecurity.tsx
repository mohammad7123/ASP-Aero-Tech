import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  ArrowRight, Shield, CheckCircle2, Lock, Eye, Wifi,
  Users, HardDrive, AlertTriangle, ChevronRight, ArrowUpRight,
  Building2, ShoppingCart, Truck, BarChart3, GraduationCap,
  Briefcase, HeartPulse, Globe2,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

const CYBER_SERVICES = [
  {
    icon: AlertTriangle,
    title: "Security Assessment & Risk Analysis",
    color: "#E84821",
    bg: "#FFF4F1",
    desc: "Identify vulnerabilities, evaluate risks, and receive actionable recommendations to strengthen your security posture.",
    features: ["Vulnerability Scanning", "Risk Evaluation", "Gap Analysis", "Remediation Roadmap", "Compliance Review", "Security Benchmarking"],
  },
  {
    icon: Wifi,
    title: "Network Security",
    color: "#3D4FA0",
    bg: "#F0F3FF",
    desc: "Protect your infrastructure with advanced firewalls, intrusion prevention systems, VPNs, network segmentation, and continuous monitoring.",
    features: ["Advanced Firewalls", "Intrusion Prevention (IPS)", "VPN Setup", "Network Segmentation", "Continuous Monitoring", "Traffic Analysis"],
  },
  {
    icon: Globe2,
    title: "Cloud Security",
    color: "#059669",
    bg: "#ECFDF5",
    desc: "Secure your AWS, Microsoft Azure, Google Cloud, and hybrid cloud environments through industry best practices and continuous monitoring.",
    features: ["Cloud Config Review", "IAM Hardening", "Data Encryption", "Threat Detection", "Compliance Monitoring", "Cloud Security Posture"],
  },
  {
    icon: Shield,
    title: "Endpoint Protection",
    color: "#7C3AED",
    bg: "#F5F3FF",
    desc: "Safeguard desktops, laptops, servers, and mobile devices against ransomware, malware, phishing, and advanced cyber threats.",
    features: ["EDR Deployment", "Anti-Ransomware", "Anti-Malware", "Phishing Protection", "Device Management", "Mobile Security"],
  },
  {
    icon: Users,
    title: "Identity & Access Management",
    color: "#D4920C",
    bg: "#FFFBEB",
    desc: "Ensure only authorized users have access to business-critical systems using role-based access control, MFA, and Single Sign-On (SSO).",
    features: ["Role-Based Access Control", "Multi-Factor Authentication", "Single Sign-On (SSO)", "Privileged Access Mgmt", "User Lifecycle Mgmt", "Access Reviews"],
  },
  {
    icon: HardDrive,
    title: "Data Protection & Backup",
    color: "#0F766E",
    bg: "#F0FDFA",
    desc: "Protect sensitive business information with encryption, secure backup solutions, disaster recovery planning, and business continuity strategies.",
    features: ["Data Encryption", "Secure Backup", "DLP Solutions", "Disaster Recovery", "Business Continuity", "Data Classification"],
  },
  {
    icon: Eye,
    title: "Security Monitoring & Incident Response",
    color: "#DC2626",
    bg: "#FFF1F1",
    desc: "Detect threats in real time, respond rapidly to security incidents, and minimize operational disruption through continuous monitoring.",
    features: ["SIEM Implementation", "24×7 Threat Monitoring", "Incident Response", "Forensic Analysis", "Threat Intelligence", "Post-Incident Review"],
  },
];

const SECURITY_SOLUTIONS = [
  "Firewall Implementation & Management",
  "Endpoint Detection & Response (EDR)",
  "Multi-Factor Authentication (MFA)",
  "Email Security",
  "Web Application Security",
  "Vulnerability Assessment",
  "Penetration Testing Coordination",
  "Secure VPN Solutions",
  "Data Encryption",
  "Backup & Disaster Recovery",
  "Security Policy Implementation",
  "Cloud Security Monitoring",
  "Security Awareness Training",
];

const INDUSTRIES = [
  { icon: Building2, label: "Manufacturing", color: "#3D4FA0" },
  { icon: ShoppingCart, label: "Retail & Distribution", color: "#E84821" },
  { icon: HeartPulse, label: "Healthcare", color: "#DC2626" },
  { icon: Truck, label: "Logistics", color: "#D4920C" },
  { icon: BarChart3, label: "Financial Services", color: "#059669" },
  { icon: Globe2, label: "E-Commerce", color: "#7C3AED" },
  { icon: GraduationCap, label: "Education", color: "#0F766E" },
  { icon: Briefcase, label: "Professional Services", color: "#B45309" },
];

const WHY_TRUST = [
  "Security-First Infrastructure Design",
  "Cloud & Network Security Expertise",
  "Enterprise Data Protection",
  "Business Continuity Planning",
  "Secure Remote Access Solutions",
  "Continuous Threat Monitoring",
  "Rapid Incident Response",
  "Affordable Managed Security Services",
  "Ongoing Security Reviews & Best Practices",
];

export default function CybersecurityPage() {
  const { primaryColor, accentColor } = useSiteConfig();

  return (
    <PublicLayout>
      <SEO
        title="Cybersecurity Services — Protect Your Business | CtrlA Tech Solutions"
        description="Comprehensive cybersecurity solutions: security assessments, network security, endpoint protection, cloud security, identity management, and 24×7 threat monitoring for Indian businesses."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: "Cybersecurity Services",
          description: "Comprehensive cybersecurity solutions: security assessments, network security, endpoint protection, cloud security, identity management, and 24×7 threat monitoring for Indian businesses.",
          provider: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
          areaServed: ["IN", "GB"],
          serviceType: ["Security Assessment", "Network Security", "Endpoint Protection", "Cloud Security", "Threat Monitoring"],
          url: window.location.href,
        }}
      />

      {/* ── HERO ─────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden" style={{ background: "linear-gradient(140deg, #0d1225 0%, #1A1F36 55%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 1200 520" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="970" cy="260" r="340" stroke="#7C3AED" strokeWidth="0.8" strokeDasharray="12 8"/>
          <circle cx="970" cy="260" r="200" stroke={primaryColor} strokeWidth="0.5" strokeDasharray="6 10"/>
          <rect x="810" y="60" width="160" height="160" rx="22" stroke="#DC2626" strokeWidth="0.6" strokeDasharray="8 6"/>
          <path d="M0 380 Q300 330 600 360 Q900 390 1200 350" stroke="white" strokeWidth="0.5" fill="none" strokeDasharray="7 7"/>
          {[[60,55],[190,290],[320,85],[220,195],[510,330],[640,110],[770,265]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-7 L2-2.5 L7-2.5 L3.5 2 L5 7 L0 4 L-5 7 L-3.5 2 L-7-2.5 L-2-2.5Z" fill="white" opacity="0.45"/>
            </g>
          ))}
        </svg>

        <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-22">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <Link href="/services" className="inline-flex items-center gap-1.5 text-white/40 text-xs mb-5 hover:text-white/70 transition-colors">← IT Services</Link>
              <div className="inline-flex items-center gap-2 mb-4 px-3 py-1.5 rounded-full border border-[#7C3AED]/40 bg-[#7C3AED]/12">
                <Shield size={13} className="text-[#7C3AED]"/>
                <span className="text-xs font-black uppercase tracking-widest text-[#7C3AED]">Cybersecurity</span>
              </div>
              <h1 className="text-4xl sm:text-5xl font-black leading-[1.06] text-white mb-3">
                Protect Your Business<br/>
                <span style={{ color: primaryColor }}>with Enterprise-Grade</span><br/>
                <span className="text-white/80 text-3xl sm:text-4xl font-bold">Cybersecurity Solutions</span>
              </h1>
              <div className="flex gap-2 my-5">
                <span className="h-1 w-12 rounded-full bg-[#E84821]"/>
                <span className="h-1 w-7 rounded-full" style={{ backgroundColor: primaryColor }}/>
                <span className="h-1 w-4 rounded-full bg-[#3D4FA0]"/>
              </div>
              <p className="text-gray-300 text-sm leading-relaxed mb-3 max-w-lg">
                As businesses become increasingly digital, cyber threats continue to evolve. CtrlA Tech Solutions helps organizations protect their critical systems, applications, cloud infrastructure, and business data.
              </p>
              <p className="text-gray-400 text-sm leading-relaxed mb-8 max-w-lg">
                Our <strong className="text-white">security-first approach</strong> enables businesses to operate confidently while maintaining compliance, business continuity, and customer trust.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 shadow-lg transition-all text-sm">
                  Schedule a Security Assessment <ArrowRight size={15}/>
                </Link>
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
                  Talk to Our Security Experts <ChevronRight size={14}/>
                </Link>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.12 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10">
                <img
                  src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80"
                  alt="Cybersecurity operations"
                  className="w-full h-64 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/80 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-red-400 animate-pulse flex-shrink-0"/>
                    <span className="text-white text-xs font-semibold">24×7 threat monitoring · rapid incident response</span>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3 mt-4">
                {[{ n: "24×7", label: "Monitoring" }, { n: "13+", label: "Solutions" }, { n: "8", label: "Industries" }].map(s => (
                  <div key={s.label} className="bg-white/5 border border-white/10 rounded-xl p-3 text-center">
                    <div className="text-xl font-black text-white">{s.n}</div>
                    <div className="text-white/50 text-xs mt-0.5">{s.label}</div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
        <div className="h-1 flex">
          <div className="flex-[3] bg-[#E84821]"/><div className="flex-[2]" style={{ backgroundColor: primaryColor }}/><div className="flex-1 bg-[#3D4FA0]"/>
        </div>
      </section>

      {/* ── CYBERSECURITY SERVICES ───────────────────────────────────── */}
      <section className="py-16 md:py-20 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #F5F3FF 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 700" preserveAspectRatio="xMidYMid slice">
          {Array.from({length:20}).map((_,r)=>Array.from({length:26}).map((_,c)=>(
            <circle key={`${r}-${c}`} cx={c*35+17} cy={r*35+17} r="1.6" fill="#7C3AED"/>
          )))}
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Our Cybersecurity Services</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Comprehensive protection for your entire digital estate</h2>
            <p className="text-gray-500 text-sm mt-2 max-w-xl mx-auto">From vulnerability assessment to 24×7 incident response — we prevent, detect, and respond to modern cyber threats.</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {CYBER_SERVICES.map((s, i) => {
              const Icon = s.icon;
              return (
                <motion.div key={s.title} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.07 }}
                  className="bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                  <div className="h-1.5 w-full" style={{ backgroundColor: s.color }}/>
                  <div className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: s.bg }}>
                        <Icon size={20} style={{ color: s.color }}/>
                      </div>
                      <h3 className="font-bold text-gray-900 text-sm leading-tight">{s.title}</h3>
                    </div>
                    <p className="text-gray-500 text-xs leading-relaxed mb-4">{s.desc}</p>
                    <div className="grid grid-cols-2 gap-1.5">
                      {s.features.map(f => (
                        <div key={f} className="flex items-center gap-1.5 text-xs text-gray-600">
                          <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: s.color }}/>
                          {f}
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── SECURITY SOLUTIONS + INDUSTRIES ─────────────────────────── */}
      <section className="py-16 bg-white border-t border-gray-100 relative overflow-hidden">
        <svg className="absolute -right-16 inset-y-0 h-full opacity-[0.04]" viewBox="0 0 300 600" fill="none">
          <circle cx="250" cy="300" r="220" stroke="#7C3AED" strokeWidth="1.5" strokeDasharray="8 6"/>
          <circle cx="250" cy="300" r="140" stroke="#E84821" strokeWidth="1" strokeDasharray="5 8"/>
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-14">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-6 h-0.5 rounded bg-[#7C3AED]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#7C3AED]">Security Solutions We Offer</span>
              </div>
              <h2 className="text-2xl font-bold mb-5" style={{ color: accentColor }}>13 security solutions for complete protection</h2>
              <div className="grid sm:grid-cols-2 gap-2">
                {SECURITY_SOLUTIONS.map((s, i) => (
                  <motion.div key={s} initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}
                    className="flex items-center gap-2 p-2.5 rounded-xl bg-gray-50 border border-gray-100 text-xs font-semibold text-gray-700 hover:border-[#7C3AED]/30 hover:bg-[#7C3AED]/3 transition-all">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#7C3AED] flex-shrink-0"/>
                    {s}
                  </motion.div>
                ))}
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Industries We Protect</span>
              </div>
              <h2 className="text-2xl font-bold mb-5" style={{ color: accentColor }}>Security for every sector</h2>
              <div className="grid grid-cols-2 gap-3">
                {INDUSTRIES.map((ind, i) => {
                  const Icon = ind.icon;
                  return (
                    <motion.div key={ind.label} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.06 }}
                      className="flex items-center gap-3 p-3 rounded-xl bg-gray-50 border border-gray-100 hover:shadow-md hover:-translate-y-0.5 transition-all">
                      <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${ind.color}15` }}>
                        <Icon size={16} style={{ color: ind.color }}/>
                      </div>
                      <span className="text-sm font-semibold text-gray-700">{ind.label}</span>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── WHY TRUST ────────────────────────────────────────────────── */}
      <section className="py-16 border-t border-gray-100 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #EFF2FF 100%)" }}>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-14 items-center">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why CtrlA Tech Solutions?</span>
              </div>
              <h2 className="text-3xl font-bold mb-4" style={{ color: accentColor }}>
                Cybersecurity is about protecting<br/>
                <span style={{ color: "#E84821" }}>your business, not just your systems</span>
              </h2>
              <p className="text-gray-500 text-sm leading-relaxed mb-6">
                Our experienced security professionals work proactively to secure your infrastructure, applications, cloud platforms, and business data while ensuring your systems remain compliant, available, and resilient.
              </p>
              <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white shadow-lg hover:-translate-y-0.5 transition-all text-sm" style={{ backgroundColor: primaryColor }}>
                Request a Security Consultation <ArrowRight size={15}/>
              </Link>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="space-y-2.5">
                {WHY_TRUST.map((w, i) => (
                  <motion.div key={w} initial={{ opacity: 0, x: 12 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.07 }}
                    className="flex items-center gap-3 p-3 rounded-xl bg-white border border-gray-100 hover:border-[#7C3AED]/30 hover:bg-[#7C3AED]/3 transition-all">
                    <div className="w-9 h-9 rounded-lg flex items-center justify-center bg-[#7C3AED]/10 flex-shrink-0">
                      <CheckCircle2 size={15} className="text-[#7C3AED]"/>
                    </div>
                    <span className="text-sm font-semibold text-gray-700">{w}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 900 280" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="820" cy="140" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          {[[80,50],[200,210],[370,60],[520,190]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-5 L2-2 L5-2 L3 2 L4 5 L0 3 L-4 5 L-3 2 L-5-2 L-2-2Z" fill="white" opacity="0.5"/>
            </g>
          ))}
        </svg>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <h2 className="text-3xl font-bold text-white mb-3">Secure Today. Grow Tomorrow.</h2>
          <p className="text-gray-400 text-sm mb-8 max-w-2xl mx-auto leading-relaxed">
            Protect your business with comprehensive cybersecurity solutions that safeguard your digital assets, strengthen customer trust, and ensure uninterrupted business operations. With CtrlA Tech Solutions as your security partner, you can focus on innovation while we help protect what matters most.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 transition-all text-sm shadow-xl">
              Request a Security Consultation <ArrowRight size={15}/>
            </Link>
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
              Protect Your Business Today <ChevronRight size={14}/>
            </Link>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1 flex">
          <div className="flex-[3] bg-[#E84821]"/>
          <div className="flex-[2]" style={{ backgroundColor: primaryColor }}/>
          <div className="flex-1 bg-[#3D4FA0]"/>
        </div>
      </section>
    </PublicLayout>
  );
}
