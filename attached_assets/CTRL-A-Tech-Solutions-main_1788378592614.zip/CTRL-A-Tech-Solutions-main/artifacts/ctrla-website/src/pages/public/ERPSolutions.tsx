import { motion } from "framer-motion";
import { Link } from "wouter";
import { ArrowRight, CheckCircle2, Clock, Cloud, Headphones, Server, Zap, Building2, BarChart3, ArrowUpRight } from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import PageHero from "@/components/public/PageHero";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

const OFFERINGS = [
  {
    title: "SAP Business One",
    badge: "For Growing SMEs",
    tagline: "Complete ERP for growing businesses",
    desc: "Manage accounting, inventory, sales, purchasing, CRM, and operations on a single platform built for small and medium enterprises.",
    accent: "#E84821",
    bg: "#FFF4F1",
    icon: Building2,
    href: "/sap-business-one",
  },
  {
    title: "SAP Business One HANA",
    badge: "High Performance",
    tagline: "In-memory ERP at lightning speed",
    desc: "Leverage the power of SAP HANA for real-time analytics, faster reporting, and improved business decision-making.",
    accent: "#3D4FA0",
    bg: "#F0F3FF",
    icon: Zap,
    href: "/sap-business-one-hana",
  },
  {
    title: "RISE with SAP",
    badge: "Cloud Transformation",
    tagline: "Business transformation as a service",
    desc: "Modernize your enterprise with cloud ERP, process intelligence, and scalable digital transformation capabilities.",
    accent: "#0F766E",
    bg: "#F0FDFA",
    icon: Cloud,
    href: "/rise-with-sap",
  },
  {
    title: "SAP S/4HANA",
    badge: "Enterprise ERP",
    tagline: "Intelligent enterprise ERP suite",
    desc: "Run complex enterprise operations with advanced finance, manufacturing, supply chain, and analytics capabilities.",
    accent: "#7C3AED",
    bg: "#F5F3FF",
    icon: BarChart3,
    href: "/s4-hana",
  },
  {
    title: "SAP B1 on Cloud",
    badge: "Managed Cloud",
    tagline: "Managed cloud ERP, no servers required",
    desc: "Access your ERP securely from anywhere with fully managed cloud infrastructure and backup services.",
    accent: "#D4920C",
    bg: "#FFFBEB",
    icon: Server,
    href: "/sap-b1-on-cloud",
  },
  {
    title: "ERP Support Services",
    badge: "24×7 Support",
    tagline: "SLA-backed AMC & helpdesk",
    desc: "Ensure business continuity with proactive monitoring, technical support, upgrades, and maintenance services.",
    accent: "#059669",
    bg: "#F0FDF6",
    icon: Headphones,
    href: "/support-service",
  },
];

const IMPLEMENTATION_STEPS = [
  { step: "01", label: "Business Study" },
  { step: "02", label: "Solution Design" },
  { step: "03", label: "Configuration" },
  { step: "04", label: "Customization" },
  { step: "05", label: "Migration" },
  { step: "06", label: "Integration" },
  { step: "07", label: "Training" },
  { step: "08", label: "Go-Live & Support" },
];

const WHY_CHOOSE = [
  { title: "22+ years of combined ERP consulting experience", desc: "Deep functional and technical expertise across industries." },
  { title: "Industry-specific ERP solutions", desc: "Tailored workflows, reports, and automation." },
  { title: "Custom development & integrations", desc: "Connect ERP with WMS, eCommerce, CRM, and third-party systems." },
  { title: "Cloud, on-premise & hybrid deployment options", desc: "Choose the infrastructure that fits your business." },
  { title: "Dedicated implementation & support team", desc: "Reliable delivery and responsive assistance." },
  { title: "90% customer retention", desc: "Long-term partnerships built on trust and results." },
];

export default function ERPSolutionsPage() {
  const config = useSiteConfig();

  return (
    <PublicLayout>
      <SEO
        title="ERP Solutions — SAP Business One, S/4HANA & End-to-End ERP"
        description="CtrlA Tech Solutions delivers complete SAP ERP implementations — SAP Business One, RISE with SAP, S/4HANA, cloud hosting, and 24×7 support for businesses across India and the UK."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: "ERP Solutions",
          description: "CtrlA Tech Solutions delivers complete SAP ERP implementations — SAP Business One, RISE with SAP, S/4HANA, cloud hosting, and 24×7 support for businesses across India and the UK.",
          provider: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
          areaServed: ["IN", "GB"],
          serviceType: ["SAP Business One Implementation", "SAP S/4HANA", "RISE with SAP", "ERP Cloud Hosting", "ERP Support"],
          url: window.location.href,
        }}
      />

      <PageHero
        eyebrow="ERP Solutions"
        title={<>SAP Business One, S/4HANA &amp; <span style={{ color: "#E84821" }}>End-to-End ERP</span></>}
        subtitle="At CtrlA Tech Solutions, we help organizations streamline operations, improve visibility, and accelerate growth through powerful ERP solutions tailored to their business needs."
        heroImage="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80"
        heroImageAlt="Enterprise ERP implementation team"
      />

      {/* ── Intro ────────────────────────────────────────────────────────── */}
      <section className="py-12 bg-white relative overflow-hidden">
        {/* Circuit doodle bg */}
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 400" fill="none" preserveAspectRatio="xMidYMid slice">
          <path d="M0 200h180l40-60h120l40 60h200l30-30h120l30 30h140" stroke="#3D4FA0" strokeWidth="2"/>
          <circle cx="180" cy="200" r="8" fill="#3D4FA0"/>
          <circle cx="540" cy="200" r="8" fill="#3D4FA0"/>
          <path d="M700 0v120l50 50v120" stroke="#E84821" strokeWidth="2"/>
          <rect x="820" y="100" width="16" height="16" stroke="#D4920C" strokeWidth="2"/>
          <rect x="820" y="280" width="12" height="12" stroke="#059669" strokeWidth="2"/>
        </svg>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 mb-4">
              <span className="w-6 h-0.5 rounded bg-[#E84821]" />
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Our Expertise</span>
            </div>
            <p className="text-gray-700 text-lg leading-relaxed mb-4">
              From small and mid-sized businesses to large enterprises, our ERP services are designed to integrate <strong>finance, sales, purchasing, inventory, production, warehousing, and customer management</strong> into a single intelligent platform.
            </p>
            <p className="text-gray-600 leading-relaxed">
              We specialize in <strong>SAP Business One, SAP Business One HANA, RISE with SAP, and SAP S/4HANA</strong>, delivering complete implementation, customization, integration, migration, cloud hosting, training, and support services.
            </p>
          </div>
        </div>
      </section>

      {/* ── ERP Offerings ─────────────────────────────────────────────────── */}
      <section className="py-12 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        {/* Star doodles */}
        <svg className="absolute top-0 left-0 w-full h-full opacity-10" viewBox="0 0 900 500" fill="none" preserveAspectRatio="xMidYMid slice">
          {[[80,60],[250,100],[500,40],[750,80],[860,30],[120,300],[350,380],[600,320],[800,420],[60,420],[450,200],[680,160]].map(([cx, cy], i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-7 L2-2 L7-2 L3 2 L5 7 L0 4 L-5 7 L-3 2 L-7-2 L-2-2Z" fill="white" opacity="0.6"/>
            </g>
          ))}
          <circle cx="450" cy="250" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="6 6" opacity="0.12"/>
        </svg>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#D4920C]" />
              <span className="text-xs font-bold uppercase tracking-widest text-[#D4920C]">Our ERP Offerings</span>
              <span className="w-6 h-0.5 rounded bg-[#D4920C]" />
            </div>
            <h2 className="text-3xl font-bold text-white">Complete SAP & ERP Portfolio</h2>
            <p className="mt-2 text-gray-300 max-w-xl mx-auto text-sm">Choose the solution that fits your business size, industry, and growth ambitions.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {OFFERINGS.map((item, i) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.07 }}
                >
                  <Link
                    href={item.href}
                    className="group block h-full rounded-2xl p-6 border border-white/10 hover:border-white/30 transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl"
                    style={{ backgroundColor: "rgba(255,255,255,0.06)", backdropFilter: "blur(6px)" }}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: item.bg }}>
                        <Icon size={22} style={{ color: item.accent }} />
                      </div>
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-full" style={{ backgroundColor: item.accent + "25", color: item.accent }}>
                        {item.badge}
                      </span>
                    </div>
                    <h3 className="text-white font-bold text-base mb-1">{item.title}</h3>
                    <p className="text-xs font-semibold mb-2" style={{ color: item.accent }}>{item.tagline}</p>
                    <p className="text-gray-400 text-xs leading-relaxed mb-3">{item.desc}</p>
                    <div className="flex items-center gap-1 text-xs font-semibold opacity-60 group-hover:opacity-100 transition-opacity" style={{ color: item.accent }}>
                      Learn More <ArrowUpRight size={12} />
                    </div>
                    {/* wavy doodle underline */}
                    <svg className="mt-3" width="40" height="5" viewBox="0 0 40 5">
                      <path d="M0 2.5 Q10 0 20 2.5 Q30 5 40 2.5" stroke={item.accent} strokeWidth="1.5" fill="none"/>
                    </svg>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── Implementation Methodology ───────────────────────────────────── */}
      <section className="py-12 bg-white relative overflow-hidden">
        {/* Dotted grid doodle */}
        <svg className="absolute inset-0 w-full h-full opacity-[0.04]" viewBox="0 0 900 400" preserveAspectRatio="xMidYMid slice">
          {Array.from({ length: 14 }).map((_, row) =>
            Array.from({ length: 30 }).map((_, col) => (
              <circle key={`${row}-${col}`} cx={col * 30 + 15} cy={row * 30 + 15} r="2" fill="#3D4FA0"/>
            ))
          )}
        </svg>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]" />
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Our Process</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900">End-to-End ERP Implementation</h2>
            <p className="mt-2 text-gray-500 max-w-xl mx-auto text-sm">Our proven methodology covers every stage of the ERP transformation journey.</p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
            {IMPLEMENTATION_STEPS.map((s, i) => (
              <motion.div
                key={s.step}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.06 }}
                className="flex flex-col items-center text-center group"
              >
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center text-white font-black text-sm mb-2 shadow-md group-hover:scale-110 transition-transform duration-300"
                  style={{ background: `linear-gradient(135deg, #E84821, #D4920C)` }}
                >
                  {s.step}
                </div>
                {/* connector line (not last) */}
                <p className="text-xs font-semibold text-gray-700 leading-snug">{s.label}</p>
              </motion.div>
            ))}
          </div>

          {/* connector dots row */}
          <div className="hidden lg:flex items-center justify-between max-w-5xl mx-auto mt-1 px-6">
            {Array.from({ length: 7 }).map((_, i) => (
              <div key={i} className="flex-1 h-0.5 mx-1" style={{ background: "linear-gradient(90deg, #E84821, #D4920C)" }} />
            ))}
          </div>
        </div>
      </section>

      {/* ── Why Choose CtrlA ─────────────────────────────────────────────── */}
      <section className="py-12 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 100%)" }}>
        {/* Hand-drawn shape doodle */}
        <svg className="absolute -bottom-6 -left-6 opacity-[0.06] w-72 h-72" viewBox="0 0 200 200" fill="none">
          <path d="M20 180 Q60 140 100 160 Q140 180 160 140 Q180 100 160 60" stroke="#3D4FA0" strokeWidth="3" strokeLinecap="round"/>
          <path d="M155 55 L165 70 M155 55 L170 58" stroke="#3D4FA0" strokeWidth="2.5" strokeLinecap="round"/>
          <circle cx="50" cy="60" r="12" stroke="#E84821" strokeWidth="2" strokeDasharray="4 3"/>
        </svg>
        <svg className="absolute -top-6 -right-6 opacity-[0.06] w-60 h-60" viewBox="0 0 200 200" fill="none">
          <path d="M40 40 L80 20 L160 60 L180 140 L120 180 L40 160 L20 80 Z" stroke="#059669" strokeWidth="2.5" strokeDasharray="6 4"/>
        </svg>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]" />
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Our Advantage</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900">Why Businesses Choose CtrlA Tech Solutions</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {WHY_CHOOSE.map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="bg-white rounded-2xl p-6 border border-gray-100 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300"
              >
                <div className="flex items-start gap-3">
                  <CheckCircle2 size={18} className="flex-shrink-0 mt-0.5" style={{ color: "#E84821" }} />
                  <div>
                    <h4 className="font-bold text-gray-900 text-sm mb-1">{item.title}</h4>
                    <p className="text-gray-500 text-xs leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 900 300" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="450" cy="150" r="120" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          <circle cx="450" cy="150" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="4 8" opacity="0.6"/>
          {[[100,50],[200,200],[700,60],[800,220],[300,130],[600,180]].map(([cx, cy], i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-6 L2-2 L6-2 L3 2 L4 6 L0 3 L-4 6 L-3 2 L-6-2 L-2-2Z" fill="white" opacity="0.5"/>
            </g>
          ))}
        </svg>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <Clock size={32} className="mx-auto mb-4 text-[#D4920C]" />
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Ready to Transform Your Business with ERP?</h2>
          <p className="text-gray-300 max-w-2xl mx-auto mb-8 leading-relaxed">
            Whether you are implementing ERP for the first time or upgrading your existing system, CtrlA Tech Solutions can help you build a <strong className="text-white">scalable, efficient, and future-ready</strong> enterprise platform.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/contact"
              className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl text-sm font-bold text-white shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all bg-[#E84821]"
            >
              Get a Free Consultation <ArrowRight size={16} />
            </Link>
            <Link
              href="/sap-business-one"
              className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl text-sm font-bold border border-white/30 text-white hover:bg-white/10 transition-all"
            >
              Explore SAP Business One
            </Link>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
