import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  ArrowRight, CheckCircle2, Code2, Building2, GitBranch,
  Package, Brain, Plug, Cloud, Shield, Zap, Globe2,
  Settings, Users, ChevronRight, BarChart3, Layers,
  Cpu, Database,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

const SOLUTIONS = [
  {
    icon: Building2,
    title: "Enterprise Applications",
    color: "#E84821",
    bg: "#FFF4F1",
    desc: "Scalable software for finance, HR, inventory, procurement, manufacturing, logistics, and operations.",
    tags: ["Finance Management","HR Systems","Inventory Control","Procurement","Manufacturing","Logistics","Operations"],
  },
  {
    icon: Database,
    title: "ERP & CRM Development",
    color: "#3D4FA0",
    bg: "#F0F3FF",
    desc: "Custom ERP modules, CRM platforms, and business management applications tailored to your processes.",
    tags: ["Custom ERP Modules","CRM Platforms","Sales Pipeline","Customer Management","Business Analytics","Reporting"],
  },
  {
    icon: GitBranch,
    title: "Workflow Automation",
    color: "#D4920C",
    bg: "#FFFBEB",
    desc: "Digitize approvals, document management, business processes, and operational workflows.",
    tags: ["Approval Workflows","Document Management","Process Automation","Task Routing","Audit Trails","Notifications"],
  },
  {
    icon: Package,
    title: "Order & Inventory Management",
    color: "#059669",
    bg: "#ECFDF5",
    desc: "Custom OMS, WMS, inventory tracking, procurement, and fulfillment systems.",
    tags: ["Order Management","Warehouse Management","Inventory Tracking","Procurement","Fulfillment","Stock Alerts"],
  },
  {
    icon: Brain,
    title: "AI & Business Automation",
    color: "#7C3AED",
    bg: "#F5F3FF",
    desc: "AI-powered business assistants, OCR solutions, chatbot development, intelligent reporting, and predictive analytics.",
    tags: ["AI Assistants","OCR Solutions","Chatbot Development","Predictive Analytics","Intelligent Reporting","Automation"],
  },
  {
    icon: Plug,
    title: "Integration Solutions",
    color: "#0F766E",
    bg: "#F0FDFA",
    desc: "Connect ERP, CRM, accounting software, payment gateways, logistics providers, and third-party platforms through secure APIs.",
    tags: ["ERP Integration","Payment Gateway","Logistics APIs","Third-Party Connectors","Middleware","Data Sync"],
  },
];

const TECHNOLOGIES = [
  { name: "Microsoft .NET", cat: "Backend" },
  { name: "Java", cat: "Backend" },
  { name: "Node.js", cat: "Backend" },
  { name: "Python", cat: "Backend" },
  { name: "React", cat: "Frontend" },
  { name: "Next.js", cat: "Frontend" },
  { name: "Angular", cat: "Frontend" },
  { name: "Flutter", cat: "Mobile" },
  { name: "SQL Server", cat: "Database" },
  { name: "PostgreSQL", cat: "Database" },
  { name: "SAP HANA", cat: "Database" },
  { name: "MongoDB", cat: "Database" },
  { name: "Docker", cat: "DevOps" },
  { name: "Kubernetes", cat: "DevOps" },
  { name: "AWS", cat: "Cloud" },
  { name: "Azure", cat: "Cloud" },
];

const CAT_COLORS: Record<string, string> = {
  Backend: "#3D4FA0",
  Frontend: "#E84821",
  Mobile: "#D4920C",
  Database: "#059669",
  DevOps: "#7C3AED",
  Cloud: "#0F766E",
};

const WHY_CUSTOM = [
  { icon: Settings, label: "Designed Around Your Business" },
  { icon: Zap, label: "Eliminate Manual Processes" },
  { icon: Users, label: "Improve Productivity" },
  { icon: BarChart3, label: "Reduce Operational Costs" },
  { icon: Plug, label: "Integrate Existing Systems" },
  { icon: Layers, label: "Scale as Your Business Grows" },
  { icon: Shield, label: "High Security & Reliability" },
  { icon: Globe2, label: "Long-Term Competitive Advantage" },
];

const WHY_CTRLA = [
  { icon: Brain, label: "Business Process Consulting" },
  { icon: Cpu, label: "Experienced Solution Architects" },
  { icon: GitBranch, label: "Agile Development Methodology" },
  { icon: Building2, label: "Enterprise-Grade Applications" },
  { icon: Plug, label: "API-First Development" },
  { icon: Cloud, label: "Cloud-Ready Solutions" },
  { icon: Zap, label: "AI & Automation Expertise" },
  { icon: CheckCircle2, label: "Comprehensive Testing" },
  { icon: Settings, label: "Ongoing Maintenance & Support" },
  { icon: Users, label: "Long-Term Technology Partnership" },
];

export default function CustomSoftwarePage() {
  const { primaryColor, accentColor } = useSiteConfig();

  return (
    <PublicLayout>
      <SEO
        title="Custom Software Development — Tailor-Made Business Solutions | CtrlA Tech Solutions"
        description="CtrlA builds custom enterprise applications, ERP/CRM platforms, workflow automation, AI solutions, and integration systems designed specifically around your business processes."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: "Custom Software Development",
          description: "CtrlA builds custom enterprise applications, ERP/CRM platforms, workflow automation, AI solutions, and integration systems designed specifically around your business processes.",
          provider: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
          areaServed: ["IN", "GB"],
          serviceType: ["Enterprise Application Development", "ERP Development", "CRM Development", "Workflow Automation", "AI Integration"],
          url: window.location.href,
        }}
      />

      {/* ── HERO ─────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden" style={{ background: "linear-gradient(140deg, #0a0d1a 0%, #141827 50%, #1A2035 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 1200 520" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="960" cy="260" r="330" stroke="#7C3AED" strokeWidth="0.7" strokeDasharray="10 7"/>
          <circle cx="960" cy="260" r="200" stroke={primaryColor} strokeWidth="0.5" strokeDasharray="5 9"/>
          <path d="M0 360 Q280 310 560 350 Q840 390 1200 340" stroke="white" strokeWidth="0.5" fill="none" strokeDasharray="6 6"/>
          {/* grid dots */}
          {[[80,60],[200,290],[380,80],[260,200],[520,330],[660,80]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-6 L2-2 L6-2 L3 2 L4 6 L0 3 L-4 6 L-3 2 L-6-2 L-2-2Z" fill="white" opacity="0.5"/></g>
          ))}
          {[[140,140],[300,270],[460,100],[600,200]].map(([cx,cy],i) => (
            <rect key={`sq${i}`} x={cx-14} y={cy-14} width="28" height="28" stroke="white" strokeWidth="0.3" opacity="0.2" rx="4"/>
          ))}
        </svg>

        <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <Link href="/services" className="inline-flex items-center gap-1.5 text-white/40 text-xs mb-5 hover:text-white/70 transition-colors">← IT Services</Link>
              <div className="inline-flex items-center gap-2 mb-4 px-3 py-1.5 rounded-full border border-[#7C3AED]/40 bg-[#7C3AED]/12">
                <Code2 size={13} className="text-[#A78BFA]"/>
                <span className="text-xs font-black uppercase tracking-widest text-[#A78BFA]">Custom Software Development</span>
              </div>
              <h1 className="text-4xl sm:text-5xl font-black leading-[1.06] text-white mb-3">
                Tailor-Made Software<br/>
                <span style={{ color: primaryColor }}>Built Around</span><br/>
                <span className="text-white/80 text-3xl sm:text-4xl font-bold">Your Business</span>
              </h1>
              <div className="flex gap-2 my-5">
                <span className="h-1 w-12 rounded-full bg-[#7C3AED]"/>
                <span className="h-1 w-7 rounded-full" style={{ backgroundColor: primaryColor }}/>
                <span className="h-1 w-4 rounded-full bg-[#E84821]"/>
              </div>
              <p className="text-gray-300 text-sm leading-relaxed mb-3 max-w-lg">
                Every business operates differently, and off-the-shelf software doesn't always meet unique operational requirements.
              </p>
              <p className="text-gray-400 text-sm leading-relaxed mb-8 max-w-lg">
                We develop <strong className="text-white">custom software solutions</strong> that automate processes, improve efficiency, and support long-term business growth — software that fits your business, not the other way around.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#7C3AED] hover:opacity-90 hover:-translate-y-0.5 shadow-lg transition-all text-sm">
                  Discuss Your Requirements <ArrowRight size={15}/>
                </Link>
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
                  Get a Free Consultation <ChevronRight size={14}/>
                </Link>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.12 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10">
                <img src="https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=800&q=80"
                  alt="Custom software development" className="w-full h-64 object-cover"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a0d1a]/70 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse flex-shrink-0"/>
                  <span className="text-white text-xs font-semibold">6 solution categories · 16 technologies</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
        <div className="h-1 flex"><div className="flex-[3] bg-[#7C3AED]"/><div className="flex-[2]" style={{ backgroundColor: primaryColor }}/><div className="flex-1 bg-[#E84821]"/></div>
      </section>

      {/* ── SOLUTION CARDS ───────────────────────────────────────────── */}
      <section className="py-16 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #F5F3FF 60%, #FFF4F1 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.025]" viewBox="0 0 900 700" preserveAspectRatio="xMidYMid slice">
          {Array.from({length:20}).map((_,r)=>Array.from({length:26}).map((_,c)=>(
            <circle key={`${r}-${c}`} cx={c*35+17} cy={r*35+17} r="1.5" fill="#7C3AED"/>
          )))}
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#7C3AED]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#7C3AED]">Our Custom Software Solutions</span>
              <span className="w-6 h-0.5 rounded bg-[#7C3AED]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Software engineered for your exact business needs</h2>
            <p className="mt-2 text-gray-500 text-sm max-w-xl mx-auto">From enterprise applications to AI-powered automation — every solution is built around your workflows.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {SOLUTIONS.map((sol, i) => {
              const Icon = sol.icon;
              return (
                <motion.div key={sol.title} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }}
                  className="bg-white rounded-2xl border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 overflow-hidden">
                  <div className="h-1.5 w-full" style={{ backgroundColor: sol.color }}/>
                  <div className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-11 h-11 rounded-xl flex items-center justify-center" style={{ backgroundColor: sol.bg }}>
                        <Icon size={20} style={{ color: sol.color }}/>
                      </div>
                      <h3 className="font-bold text-gray-900 text-sm leading-tight">{sol.title}</h3>
                    </div>
                    <p className="text-gray-500 text-xs leading-relaxed mb-4">{sol.desc}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {sol.tags.map(tag => (
                        <span key={tag} className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
                          style={{ backgroundColor: sol.color + "12", color: sol.color }}>
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── TECHNOLOGIES + WHY CUSTOM ────────────────────────────────── */}
      <section className="py-16 bg-white border-t border-gray-100 relative overflow-hidden">
        <svg className="absolute -right-20 inset-y-0 h-full opacity-[0.04]" viewBox="0 0 300 600" fill="none">
          <circle cx="250" cy="300" r="220" stroke="#7C3AED" strokeWidth="1.5" strokeDasharray="8 6"/>
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-14">
            {/* technologies */}
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-6 h-0.5 rounded bg-[#7C3AED]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#7C3AED]">Technologies & Platforms</span>
              </div>
              <h2 className="text-2xl font-bold mb-5" style={{ color: accentColor }}>Enterprise-grade stack for every layer</h2>
              <div className="flex flex-wrap gap-2">
                {TECHNOLOGIES.map((t, i) => (
                  <motion.span key={t.name} initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold bg-white hover:shadow-md hover:-translate-y-0.5 transition-all"
                    style={{ borderColor: CAT_COLORS[t.cat] + "40", color: CAT_COLORS[t.cat] }}>
                    <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: CAT_COLORS[t.cat] }}/>
                    {t.name}
                  </motion.span>
                ))}
              </div>
              <div className="flex flex-wrap gap-3 mt-4">
                {Object.entries(CAT_COLORS).map(([cat, col]) => (
                  <div key={cat} className="flex items-center gap-1.5 text-[10px] text-gray-500">
                    <span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: col }}/>
                    {cat}
                  </div>
                ))}
              </div>
            </motion.div>

            {/* why custom software */}
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why Build Custom Software?</span>
              </div>
              <h2 className="text-2xl font-bold mb-5" style={{ color: accentColor }}>Off-the-shelf can't do what custom can</h2>
              <div className="grid grid-cols-2 gap-2">
                {WHY_CUSTOM.map((w, i) => {
                  const Icon = w.icon;
                  return (
                    <motion.div key={w.label} initial={{ opacity: 0, x: 8 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                      className="flex items-center gap-2 p-2.5 rounded-xl bg-gray-50 border border-gray-100 hover:border-[#E84821]/30 hover:bg-[#E84821]/3 transition-all">
                      <div className="w-7 h-7 rounded-lg flex items-center justify-center bg-[#E84821]/10 flex-shrink-0">
                        <Icon size={12} className="text-[#E84821]"/>
                      </div>
                      <span className="text-[11px] font-semibold text-gray-700 leading-tight">{w.label}</span>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── WHY CTRLA — dark section ─────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 900 350" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="820" cy="175" r="220" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          {[[80,50],[200,270],[350,70],[500,210]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-5 L2-2 L5-2 L3 2 L4 5 L0 3 L-4 5 L-3 2 L-5-2 L-2-2Z" fill="white" opacity="0.5"/></g>
          ))}
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#D4920C]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#D4920C]">Why CtrlA Tech Solutions?</span>
              <span className="w-6 h-0.5 rounded bg-[#D4920C]"/>
            </div>
            <h2 className="text-3xl font-bold text-white">Your long-term technology partner</h2>
            <p className="text-gray-400 text-sm mt-2 max-w-xl mx-auto">From discovery to deployment and beyond — we work alongside your team at every step.</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {WHY_CTRLA.map((w, i) => {
              const Icon = w.icon;
              return (
                <motion.div key={w.label} initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.06 }}
                  className="flex flex-col items-center text-center gap-2.5 bg-white/6 border border-white/10 rounded-2xl p-4 hover:bg-white/10 transition-colors">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-[#D4920C]/15">
                    <Icon size={17} className="text-[#D4920C]"/>
                  </div>
                  <span className="text-xs font-semibold text-gray-300 leading-tight">{w.label}</span>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────── */}
      <section className="py-14 bg-white border-t border-gray-100 text-center relative overflow-hidden">
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 200" fill="none" preserveAspectRatio="xMidYMid slice">
          <path d="M0 80 Q225 40 450 80 Q675 120 900 80" stroke="#7C3AED" strokeWidth="1.5" fill="none" strokeDasharray="8 6"/>
          <path d="M0 120 Q225 80 450 120 Q675 160 900 120" stroke="#E84821" strokeWidth="1" fill="none" strokeDasharray="5 8"/>
        </svg>
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="inline-flex items-center gap-2 mb-4">
            <span className="w-5 h-0.5 rounded bg-[#7C3AED]"/>
            <Code2 size={14} className="text-[#7C3AED]"/>
            <span className="w-5 h-0.5 rounded bg-[#7C3AED]"/>
          </div>
          <h2 className="text-3xl font-bold mb-3" style={{ color: accentColor }}>
            Build digital solutions that grow with your business
          </h2>
          <p className="text-gray-500 text-sm mb-8 max-w-xl mx-auto leading-relaxed">
            Whether developing a modern website, launching a mobile application, or building custom enterprise software — CtrlA delivers secure, scalable, and future-ready digital solutions.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl font-bold text-white bg-[#7C3AED] hover:opacity-90 hover:-translate-y-1 transition-all text-sm shadow-xl">
              Discuss Your Requirements <ArrowRight size={15}/>
            </Link>
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl font-bold border-2 border-gray-200 text-gray-700 hover:border-[#7C3AED] hover:text-[#7C3AED] transition-all text-sm">
              Get a Free Consultation
            </Link>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1 flex">
          <div className="flex-[3] bg-[#7C3AED]"/>
          <div className="flex-[2]" style={{ backgroundColor: primaryColor }}/>
          <div className="flex-1 bg-[#E84821]"/>
        </div>
      </section>
    </PublicLayout>
  );
}
