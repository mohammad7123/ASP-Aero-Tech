import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowRight, Briefcase, CheckCircle2, Globe2, Smartphone, Code2,
  Package, ShoppingCart, Users, MapPin, CreditCard, Star,
  Truck, BarChart3, ChevronRight, ArrowUpRight,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";
import ProductItemModal from "@/components/public/ProductItemModal";
import { getIcon } from "@/lib/iconMap";
import type { ProductItem } from "@/types/productItem";

const BENEFITS = [
  "India-first design for local business needs",
  "Deep SAP B1 integration available",
  "Cloud-native, mobile-first architecture",
  "Rapid deployment — go live in weeks",
  "API-first for easy third-party integration",
  "Dedicated implementation & support team",
];

/* Products that have their own dedicated page — keyed by name fragment */
const PRODUCT_PAGE_MAP: Record<string, string> = {
  "WMS 360":        "/wms360",
  "WMS360":         "/wms360",
  "wms360":         "/wms360",
  "wms-360":        "/wms360",
  "HRMS":           "/myhrone",
  "hrms":           "/myhrone",
  "MyHROne":        "/myhrone",
  "myhrone":        "/myhrone",
  "Human Resource": "/myhrone",
};

/* Related IT services */
const RELATED_SERVICES = [
  {
    icon: Globe2,
    title: "Web Development",
    href: "/services/web-development",
    color: "#E84821",
    bg: "#FFF4F1",
    desc: "Corporate websites, eCommerce stores, business portals, and custom web applications.",
  },
  {
    icon: Smartphone,
    title: "Mobile Apps",
    href: "/services/mobile-apps",
    color: "#3D4FA0",
    bg: "#F0F3FF",
    desc: "Native Android & iOS apps, cross-platform solutions, and enterprise mobile applications.",
  },
  {
    icon: Code2,
    title: "Custom Software",
    href: "/services/custom-software",
    color: "#D4920C",
    bg: "#FFFBEB",
    desc: "Bespoke business software built to your exact workflows, integrations, and scale requirements.",
  },
];

function getProductPageUrl(product: ProductItem): string | null {
  for (const [key, url] of Object.entries(PRODUCT_PAGE_MAP)) {
    if (
      product.name?.toLowerCase().includes(key.toLowerCase()) ||
      (product as any).slug?.toLowerCase().includes(key.toLowerCase())
    ) {
      return url;
    }
  }
  return null;
}

export default function ProductsBusinessAppsPage() {
  const config = useSiteConfig();
  const primary = config.primaryColor;
  const accent = config.accentColor;
  const [selected, setSelected] = useState<ProductItem | null>(null);

  const base = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";
  const { data: items = [], isLoading } = useQuery<ProductItem[]>({
    queryKey: ["product-items", "business-apps"],
    queryFn: () => fetch(`${base}/api/public/product-items?category=business-apps`).then(r => r.json()),
  });

  return (
    <PublicLayout>
      <SEO
        title="Business Applications — Ecommerce, WMS, OMS, HRMS | CtrlA Tech Solutions"
        description="14 purpose-built business applications including Ecommerce, WMS 360, OMS, HRMS, POS, Fleet Management, and Loyalty Platform from CtrlA Tech Solutions."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "Business Applications — CtrlA Tech Solutions",
          description: "14 purpose-built business applications including Ecommerce, WMS 360, OMS, HRMS, POS, Fleet Management, and Loyalty Platform from CtrlA Tech Solutions.",
          url: window.location.href,
          publisher: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
        }}
      />

      {/* ── HERO ──────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden" style={{ background: "linear-gradient(140deg, #0d1225 0%, #1A1F36 55%, #2D3561 100%)" }}>
        {/* SVG doodles */}
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 1200 520" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="980" cy="260" r="340" stroke="#D4920C" strokeWidth="0.8" strokeDasharray="12 8"/>
          <circle cx="980" cy="260" r="210" stroke={primary} strokeWidth="0.5" strokeDasharray="6 10"/>
          <rect x="800" y="60" width="180" height="180" rx="24" stroke="#E84821" strokeWidth="0.6" strokeDasharray="8 6"/>
          <path d="M0 380 Q300 330 600 360 Q900 390 1200 350" stroke="white" strokeWidth="0.5" fill="none" strokeDasharray="7 7"/>
          {[[60,50],[190,300],[330,90],[220,200],[500,340],[620,110],[750,280]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-7 L2-2.5 L7-2.5 L3.5 2 L5 7 L0 4 L-5 7 L-3.5 2 L-7-2.5 L-2-2.5Z" fill="white" opacity="0.45"/>
            </g>
          ))}
          <path d="M-10 150 L80 120 L160 170 L260 130 L350 165" stroke={primary} strokeWidth="0.5" strokeDasharray="5 8" fill="none"/>
        </svg>

        <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-22">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <Link href="/products" className="inline-flex items-center gap-1.5 text-white/40 text-xs mb-5 hover:text-white/70 transition-colors">← Products</Link>
              <div className="inline-flex items-center gap-2 mb-4 px-3 py-1.5 rounded-full border border-[#D4920C]/40 bg-[#D4920C]/12">
                <Briefcase size={13} className="text-[#D4920C]"/>
                <span className="text-xs font-black uppercase tracking-widest text-[#D4920C]">Business Applications</span>
              </div>
              <h1 className="text-4xl sm:text-5xl font-black leading-[1.06] text-white mb-3">
                Purpose-Built Apps<br/>
                <span style={{ color: primary }}>for Indian Business</span><br/>
                <span className="text-white/80 text-3xl sm:text-4xl font-bold">Across Every Industry</span>
              </h1>
              <div className="flex gap-2 my-5">
                <span className="h-1 w-12 rounded-full bg-[#E84821]"/>
                <span className="h-1 w-7 rounded-full" style={{ backgroundColor: primary }}/>
                <span className="h-1 w-4 rounded-full bg-[#3D4FA0]"/>
              </div>
              <p className="text-gray-300 text-sm leading-relaxed mb-2 max-w-lg">
                From warehouse floors to customer loyalty — our 14 business applications solve real operational challenges across ecommerce, distribution, HR, logistics, and more.
              </p>
              <p className="text-gray-400 text-sm leading-relaxed mb-8 max-w-lg">
                <strong className="text-white">Deep SAP B1 integration, cloud-native architecture,</strong> and rapid deployment means you go live in weeks, not months.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 shadow-lg transition-all text-sm">
                  Request a Demo <ArrowRight size={15}/>
                </Link>
                <Link href="/wms360" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
                  Explore WMS 360 <ChevronRight size={14}/>
                </Link>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.12 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10">
                <img
                  src="https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=800&q=80"
                  alt="Business Applications dashboard"
                  className="w-full h-64 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/80 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse flex-shrink-0"/>
                    <span className="text-white text-xs font-semibold">14 business applications · 500+ implementations</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { icon: Package, label: "WMS 360" },
                      { icon: ShoppingCart, label: "eCommerce" },
                      { icon: Users, label: "HRMS" },
                    ].map(({ icon: Icon, label }) => (
                      <div key={label} className="flex items-center gap-1.5 bg-white/10 backdrop-blur-sm rounded-lg px-2 py-1.5">
                        <Icon size={12} className="text-white/80 flex-shrink-0"/>
                        <span className="text-white/80 text-[10px] font-medium">{label}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* key stats */}
              <div className="grid grid-cols-3 gap-3 mt-4">
                {[
                  { n: "14", label: "Products" },
                  { n: "500+", label: "Go-Lives" },
                  { n: "8+", label: "Industries" },
                ].map(s => (
                  <div key={s.label} className="bg-white/5 border border-white/10 rounded-xl p-3 text-center">
                    <div className="text-2xl font-black text-white">{s.n}</div>
                    <div className="text-white/50 text-xs mt-0.5">{s.label}</div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* checklist row */}
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }}
            className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {BENEFITS.map(b => (
              <div key={b} className="flex items-center gap-2 text-sm text-white/65">
                <CheckCircle2 size={14} style={{ color: primary }} className="flex-shrink-0"/>
                {b}
              </div>
            ))}
          </motion.div>
        </div>
        <div className="h-1 flex">
          <div className="flex-[3] bg-[#E84821]"/><div className="flex-[2]" style={{ backgroundColor: primary }}/><div className="flex-1 bg-[#3D4FA0]"/>
        </div>
      </section>

      {/* ── FEATURED: WMS 360 ──────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 400" preserveAspectRatio="xMidYMid slice">
          {Array.from({length:12}).map((_,r)=>Array.from({length:28}).map((_,c)=>(
            <circle key={`${r}-${c}`} cx={c*33+16} cy={r*33+16} r="1.5" fill="#3D4FA0"/>
          )))}
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-10 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-3">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Featured Product</span>
              </div>
              <div className="inline-flex items-center gap-2 mb-4 px-3 py-1 rounded-full bg-[#3D4FA0]/10">
                <Package size={14} className="text-[#3D4FA0]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">WMS 360</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-bold leading-tight mb-3" style={{ color: accent }}>
                India's Most Advanced<br/><span style={{ color: "#E84821" }}>Warehouse Management System</span>
              </h2>
              <p className="text-gray-500 text-sm leading-relaxed mb-6 max-w-lg">
                WMS 360 brings end-to-end warehouse intelligence — inbound, putaway, picking, packing, dispatch, and returns — all in one platform with native mobile apps and SAP B1 integration.
              </p>
              <div className="grid sm:grid-cols-2 gap-2 mb-7">
                {["Complete Warehouse Management","Order Management System (OMS)","Native Android & iOS Apps","AI-Powered Inventory Intelligence","Barcode & QR Code Operations","Real-Time Analytics & Reports"].map(f => (
                  <div key={f} className="flex items-center gap-2 text-sm text-gray-700">
                    <CheckCircle2 size={13} className="text-[#E84821] flex-shrink-0"/>
                    {f}
                  </div>
                ))}
              </div>
              <Link href="/wms360" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 shadow-lg transition-all text-sm">
                Explore WMS 360 <ArrowUpRight size={15}/>
              </Link>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-gray-100">
                <img
                  src="https://images.unsplash.com/photo-1601598851547-4302969d0614?auto=format&fit=crop&w=800&q=80"
                  alt="WMS 360 warehouse management"
                  className="w-full h-60 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/60 to-transparent"/>
                <div className="absolute bottom-4 left-4 flex items-center gap-2 bg-white/10 backdrop-blur-sm px-3 py-2 rounded-xl border border-white/20">
                  <Truck size={14} className="text-white"/>
                  <span className="text-white text-xs font-semibold">500+ warehouse go-lives across India</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── FEATURED: MyHROne ──────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden bg-white border-t border-gray-100">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-10 items-center">
            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-gray-100">
                <img
                  src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=800&q=80"
                  alt="MyHROne HR team management"
                  className="w-full h-60 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/60 to-transparent"/>
                <div className="absolute bottom-4 left-4 flex items-center gap-2 bg-white/10 backdrop-blur-sm px-3 py-2 rounded-xl border border-white/20">
                  <Users size={14} className="text-white"/>
                  <span className="text-white text-xs font-semibold">AI-Powered HRMS · Payroll · Attendance · Field Workforce</span>
                </div>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-3">
                <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Featured Product</span>
              </div>
              <div className="inline-flex items-center gap-2 mb-4 px-3 py-1 rounded-full bg-[#E84821]/10">
                <Users size={14} className="text-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">MyHROne — HRMS</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-bold leading-tight mb-3 text-[#1A1F36]">
                Empower Your Workforce with<br/><span style={{ color: "#E84821" }}>AI-Powered HR Management</span>
              </h2>
              <p className="text-gray-500 text-sm leading-relaxed mb-6 max-w-lg">
                MyHROne brings HR, Payroll, AI Face Recognition Attendance, GPS Field Workforce, Performance Management, and Employee Engagement onto one intelligent platform.
              </p>
              <div className="grid sm:grid-cols-2 gap-2 mb-7">
                {["Complete Employee Lifecycle","Automated Payroll & Compliance","AI Face Recognition Attendance","GPS Field Workforce Tracking","Performance Management & KPIs","AI Business Insights Dashboard"].map(f => (
                  <div key={f} className="flex items-center gap-2 text-sm text-gray-700">
                    <CheckCircle2 size={13} className="text-[#E84821] flex-shrink-0"/>
                    {f}
                  </div>
                ))}
              </div>
              <Link href="/myhrone" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 shadow-lg transition-all text-sm">
                Explore MyHROne <ArrowUpRight size={15}/>
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── ALL 14 PRODUCTS ────────────────────────────────────────────── */}
      <section className="py-16 md:py-20 bg-white border-t border-gray-100">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-10 text-center">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Full Product Range</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold" style={{ color: accent }}>All 14 Business Applications</h2>
            <p className="text-gray-400 text-sm mt-2">Click any product to learn more · Products with dedicated pages link directly</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {isLoading
              ? Array.from({ length: 6 }).map((_, i) => <div key={i} className="rounded-2xl border border-gray-100 bg-gray-50 animate-pulse h-36" />)
              : items.map((p, i) => {
                  const Icon = getIcon(p.iconName);
                  const pageUrl = getProductPageUrl(p);
                  return (
                    <motion.div key={p.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-40px" }} transition={{ duration: 0.4, delay: i * 0.04 }}>
                      {pageUrl ? (
                        <Link
                          href={pageUrl}
                          className="group flex flex-col h-full text-left rounded-2xl border border-gray-100 overflow-hidden hover:border-transparent hover:shadow-xl transition-all hover:-translate-y-0.5 bg-white"
                        >
                          <div className="h-1.5 w-full" style={{ backgroundColor: p.accentColor || primary }}/>
                          <div className="p-6 flex flex-col flex-1">
                            <div className="flex items-center gap-3 mb-3">
                              <div className="p-2 rounded-lg flex-shrink-0" style={{ backgroundColor: `${p.accentColor || primary}15` }}>
                                <Icon size={18} style={{ color: p.accentColor || primary }} />
                              </div>
                              <h3 className="font-bold text-gray-900 text-sm group-hover:text-[#E84821] transition-colors leading-tight">{p.name}</h3>
                              <span className="ml-auto text-[10px] font-bold uppercase tracking-wide text-[#E84821] bg-[#E84821]/8 px-2 py-0.5 rounded-full flex-shrink-0">Page →</span>
                            </div>
                            <p className="text-gray-500 text-xs leading-relaxed flex-1">{p.shortDesc}</p>
                            <div className="mt-3 flex items-center gap-1 text-xs font-semibold text-[#E84821]">
                              View full details <ArrowUpRight size={12} className="group-hover:translate-x-0.5 transition-transform" />
                            </div>
                          </div>
                        </Link>
                      ) : (
                        <button
                          onClick={() => setSelected(p)}
                          className="group flex flex-col h-full w-full text-left rounded-2xl border border-gray-100 overflow-hidden hover:border-transparent hover:shadow-xl transition-all hover:-translate-y-0.5 bg-white cursor-pointer"
                        >
                          <div className="h-1.5 w-full" style={{ backgroundColor: p.accentColor || primary }}/>
                          <div className="p-6 flex flex-col flex-1">
                            <div className="flex items-center gap-3 mb-3">
                              <div className="p-2 rounded-lg flex-shrink-0" style={{ backgroundColor: `${p.accentColor || primary}15` }}>
                                <Icon size={18} style={{ color: p.accentColor || primary }} />
                              </div>
                              <h3 className="font-bold text-gray-900 text-sm group-hover:text-[#D4920C] transition-colors leading-tight">{p.name}</h3>
                            </div>
                            <p className="text-gray-500 text-xs leading-relaxed flex-1">{p.shortDesc}</p>
                            <div className="mt-3 flex items-center gap-1 text-xs font-semibold" style={{ color: p.accentColor || primary }}>
                              Learn more <ArrowRight size={12} className="group-hover:translate-x-0.5 transition-transform" />
                            </div>
                          </div>
                        </button>
                      )}
                    </motion.div>
                  );
                })
            }
          </div>
        </div>
      </section>

      {/* ── RELATED IT SERVICES ────────────────────────────────────────── */}
      <section className="py-16 relative overflow-hidden border-t border-gray-100" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 400" preserveAspectRatio="xMidYMid slice">
          {Array.from({length:12}).map((_,r)=>Array.from({length:28}).map((_,c)=>(
            <circle key={`${r}-${c}`} cx={c*33+16} cy={r*33+16} r="1.5" fill="#E84821"/>
          )))}
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Related IT Services</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
            </div>
            <h2 className="text-3xl font-bold mb-2" style={{ color: accent }}>Need a Custom Solution?</h2>
            <p className="text-gray-500 text-sm max-w-xl mx-auto">Our IT services team can develop web, mobile, and custom software tailored to your exact business requirements.</p>
          </div>
          <div className="grid sm:grid-cols-3 gap-5">
            {RELATED_SERVICES.map((s, i) => {
              const Icon = s.icon;
              return (
                <motion.div key={s.title} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
                  <Link href={s.href}
                    className="group flex flex-col h-full bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                    <div className="h-1.5 w-full" style={{ backgroundColor: s.color }}/>
                    <div className="p-6 flex flex-col flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: s.bg }}>
                          <Icon size={20} style={{ color: s.color }}/>
                        </div>
                        <h3 className="font-bold text-gray-900 text-sm group-hover:text-[#D4920C] transition-colors leading-tight">{s.title}</h3>
                      </div>
                      <p className="text-gray-500 text-xs leading-relaxed flex-1">{s.desc}</p>
                      <div className="mt-4 flex items-center gap-1 text-xs font-semibold transition-colors" style={{ color: s.color }}>
                        Learn more <ArrowRight size={12} className="group-hover:translate-x-0.5 transition-transform"/>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 900 280" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="820" cy="140" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          {[[80,50],[200,210],[370,60],[520,190]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-5 L2-2 L5-2 L3 2 L4 5 L0 3 L-4 5 L-3 2 L-5-2 L-2-2Z" fill="white" opacity="0.5"/>
            </g>
          ))}
        </svg>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <h2 className="text-3xl font-bold text-white mb-3">Ready to Transform Your Operations?</h2>
          <p className="text-gray-400 text-sm mb-8 max-w-xl mx-auto leading-relaxed">
            Get a tailored demo of the applications that match your industry, workflows, and scale — and go live in weeks.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 transition-all text-sm shadow-xl">
              Book a Free Demo <ArrowRight size={15}/>
            </Link>
            <Link href="/wms360" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
              Explore WMS 360 <ChevronRight size={14}/>
            </Link>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1 flex">
          <div className="flex-[3] bg-[#E84821]"/>
          <div className="flex-[2]" style={{ backgroundColor: primary }}/>
          <div className="flex-1 bg-[#3D4FA0]"/>
        </div>
      </section>

      {selected && <ProductItemModal open product={selected} onClose={() => setSelected(null)} />}
    </PublicLayout>
  );
}
