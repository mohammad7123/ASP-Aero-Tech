import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "wouter";
import {
  ArrowRight, Globe, Smartphone, Cloud, Shield, Code2, Lightbulb,
  Boxes, Sparkles, CheckCircle2, ChevronLeft, ChevronRight, Database,
  Brain, Quote, Factory, ShoppingBag, Truck, HeartPulse, Package,
  FlaskConical, Car, Building2, Award, LifeBuoy, MapPin, Clock, BookOpen,
} from "lucide-react";
import { useTranslation } from "react-i18next";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";
import { useGetPublicPage } from "@/lib/apiClient";
import { usePageContent } from "@/lib/usePageContent";

const SERVICE_ICONS = [Database, Globe, Smartphone, Cloud, Shield, Code2, Lightbulb, Brain];
const SERVICE_KEYS = ["erp", "webDev", "mobileApps", "cloud", "cyber", "software", "consulting", "aiSolutions"] as const;
const SERVICE_LINKS: Record<string, string> = {
  erp:        "/services/erp-solutions",
  webDev:     "/services/web-development",
  mobileApps: "/services/mobile-apps",
  software:   "/services/custom-software",
  cloud:      "/services/cloud-solutions",
  cyber:      "/services/cybersecurity",
  consulting: "/services/it-consulting",
};

const SERVICE_COLORS = [
  "#0d1225", "#1A4FA0", "#1A1F36", "#0d4a6e",
  "#1a2744", "#0f3d2a", "#2d1a4a", "#1a3044",
];

const TESTIMONIALS = [
  {
    quote: "CtrlA's WMS 360 transformed our warehouse operations completely. Real-time inventory visibility and seamless SAP integration saved our team hours every single day.",
    name: "Rajesh Mehta",
    title: "Operations Director",
    company: "ShipFast Logistics India",
    initials: "RM",
    color: "#E84821",
  },
  {
    quote: "The SAP Business One implementation was seamless. Their team understood our needs perfectly and delivered a solution that's made our month-end closing 60% faster.",
    name: "Priya Sharma",
    title: "Chief Financial Officer",
    company: "MedTech Solutions Pvt Ltd",
    initials: "PS",
    color: "#3561A7",
  },
  {
    quote: "Cloud migration handled flawlessly. Our infrastructure is now 40% more cost-efficient with zero downtime. The CtrlA team's expertise and communication were outstanding.",
    name: "Anil Gupta",
    title: "Chief Technology Officer",
    company: "RetailEdge India",
    initials: "AG",
    color: "#0d1225",
  },
];

const INDUSTRIES = [
  { labelKey: "industryManufacturing", Icon: Factory },
  { labelKey: "industryRetail", Icon: ShoppingBag },
  { labelKey: "industryLogistics", Icon: Truck },
  { labelKey: "industryHealthcare", Icon: HeartPulse },
  { labelKey: "industryFMCG", Icon: Package },
  { labelKey: "industryPharma", Icon: FlaskConical },
  { labelKey: "industryAutomatic", Icon: Car },
  { labelKey: "industryReal", Icon: Building2 },
];

const WHY_ITEMS = [
  { titleKey: "why1Title", descKey: "why1Desc", Icon: Award, color: "#E84821" },
  { titleKey: "why2Title", descKey: "why2Desc", Icon: LifeBuoy, color: "#3561A7" },
  { titleKey: "why3Title", descKey: "why3Desc", Icon: MapPin, color: "#0d1225" },
  { titleKey: "why4Title", descKey: "why4Desc", Icon: Clock, color: "#1A4FA0" },
];

interface HeroSlide {
  id: number;
  eyebrow?: string | null;
  title: string;
  subtitle: string | null;
  imageUrl: string;
  ctaText: string | null;
  ctaUrl: string | null;
  stat1?: string | null;
  stat2?: string | null;
  stat3?: string | null;
  badge?: string | null;
  sortOrder: number;
  isActive: boolean;
}

interface BlogPost {
  id: number;
  title: string;
  slug: string;
  excerpt: string | null;
  featuredImage: string | null;
  published_at: string | null;
}

function useHeroSlides() {
  const [slides, setSlides] = useState<HeroSlide[]>([]);
  const base = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";
  useEffect(() => {
    fetch(`${base}/api/public/hero-slides`)
      .then(r => r.ok ? r.json() : [])
      .then(setSlides)
      .catch(() => setSlides([]));
  }, [base]);
  return slides;
}

function useBlogPosts(limit = 3) {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);
  const base = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";
  useEffect(() => {
    fetch(`${base}/api/blog/posts?limit=${limit}`)
      .then(r => r.ok ? r.json() : { posts: [] })
      .then((data) => {
        setPosts(Array.isArray(data) ? data : (data.posts ?? []));
        setLoading(false);
      })
      .catch(() => { setPosts([]); setLoading(false); });
  }, [base, limit]);
  return { posts, loading };
}

function HeroSlideshow({ primary, accent, config, cmsPage }: {
  primary: string;
  accent: string;
  config: { siteName: string; tagline: string | null; bannerHeight: number; bannerSpeed: number };
  cmsPage?: { metaTitle?: string | null; metaDescription?: string | null; heroImage?: string | null } | null;
}) {
  const { t } = useTranslation();
  const remoteSlides = useHeroSlides();
  const bannerHeight = config.bannerHeight ?? 640;
  const bannerSpeed = config.bannerSpeed ?? 5000;

  const fallbackSlides: HeroSlide[] = [
    {
      id: 0,
      eyebrow: "SAP + Artificial Intelligence",
      title: "Grow Your Business with Intelligent Business Management",
      subtitle: null,
      imageUrl: "/hero-banner.png",
      ctaText: t("home.heroCta"),
      ctaUrl: "/contact",
      sortOrder: -1,
      isActive: true,
    },
    {
      id: 1,
      title: config.tagline ?? t("home.heroFallback"),
      subtitle: `${config.siteName} delivers cutting-edge IT services that empower businesses to scale, innovate, and lead in the digital era.`,
      imageUrl: cmsPage?.heroImage ?? "/home-banner.jpg",
      ctaText: t("home.heroCta"),
      ctaUrl: "/contact",
      sortOrder: 0,
      isActive: true,
    },
  ];

  const slides = remoteSlides.length > 0 ? remoteSlides : fallbackSlides;
  const [current, setCurrent] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const goTo = useCallback((idx: number) => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrent(idx);
    setTimeout(() => setIsAnimating(false), 600);
  }, [isAnimating]);

  const next = useCallback(() => goTo((current + 1) % slides.length), [current, slides.length, goTo]);
  const prev = useCallback(() => goTo((current - 1 + slides.length) % slides.length), [current, slides.length, goTo]);

  useEffect(() => {
    if (slides.length <= 1) return;
    const timer = setInterval(next, bannerSpeed);
    return () => clearInterval(timer);
  }, [slides.length, next, bannerSpeed]);

  const slide = slides[current];

  return (
    <section className="relative overflow-hidden flex flex-col" style={{ height: bannerHeight }}>
      <AnimatePresence mode="wait">
        <motion.div
          key={current}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6 }}
          className="absolute inset-0"
        >
          <img
            src={slide.imageUrl}
            alt={slide.title}
            className="absolute inset-0 w-full h-full object-cover object-right"
            loading="eager"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0d1225]/92 via-[#0d1225]/68 to-[#0d1225]/20" />
        </motion.div>
      </AnimatePresence>

      <div className="pointer-events-none absolute -top-24 -left-24 w-[380px] h-[380px] rounded-full opacity-20 blur-3xl" style={{ backgroundColor: primary }} />

      <div className="relative flex-1 flex items-center max-w-[1440px] mx-auto w-full px-4 sm:px-6 lg:px-8 py-20 md:py-24 lg:py-28">
        <AnimatePresence mode="wait">
          <motion.div
            key={current}
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.55 }}
            className="max-w-2xl"
          >
            <div className="inline-flex items-center gap-2 mb-6 px-3.5 py-1.5 rounded-full bg-white/10 border border-white/20 backdrop-blur-sm">
              <span className="flex gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#E84821]" />
                <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: primary }} />
                <span className="w-1.5 h-1.5 rounded-full bg-[#3D4FA0]" />
              </span>
              <span className="text-xs font-semibold text-white/90 tracking-wide">{slide.eyebrow ?? t("home.heroPill")}</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-[52px] font-bold leading-[1.12] tracking-tight text-white drop-shadow-lg">
              {slide.title}
            </h1>

            <div className="mt-5 flex items-center gap-1.5">
              <div className="h-1 w-12 rounded-full bg-[#E84821]" />
              <div className="h-1 w-6 rounded-full" style={{ backgroundColor: primary }} />
              <div className="h-1 w-3 rounded-full bg-[#3D4FA0]" />
            </div>

            {slide.subtitle && (
              <p className="text-base sm:text-lg text-white/75 mt-6 mb-8 max-w-xl leading-relaxed">
                {slide.subtitle}
              </p>
            )}

            <div className="flex flex-wrap gap-3">
              <Link
                href={slide.ctaUrl ?? "/contact"}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-lg font-bold text-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5"
                style={{ backgroundColor: primary }}
              >
                {slide.ctaText ?? t("home.heroCta")} <ArrowRight size={16} />
              </Link>
              <Link
                href="/services"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-lg font-semibold border-2 border-white/30 hover:border-[#D4920C] text-white hover:text-[#D4920C] transition-all backdrop-blur-sm"
              >
                {t("home.heroServices")}
              </Link>
            </div>

            {(slide.stat1 || slide.stat2 || slide.stat3 || t("home.stat1")) && (
              <div className="mt-10 flex flex-wrap items-center gap-x-8 gap-y-3 text-xs text-white/60">
                {(slide.stat1 || t("home.stat1")) && (
                  <div className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400" /> {slide.stat1 || t("home.stat1")}</div>
                )}
                {(slide.stat2 || t("home.stat2")) && (
                  <div className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: primary }} /> {slide.stat2 || t("home.stat2")}</div>
                )}
                {(slide.stat3 || t("home.stat3")) && (
                  <div className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-[#3D4FA0]" /> {slide.stat3 || t("home.stat3")}</div>
                )}
              </div>
            )}

            {(slide.badge || t("home.heroBadge")) && (
              <div className="mt-8 inline-flex items-center gap-2 text-white/70 text-xs">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                {slide.badge || t("home.heroBadge")}
              </div>
            )}
          </motion.div>
        </AnimatePresence>

        {slides.length > 1 && (
          <div className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 flex flex-col gap-3">
            <button onClick={prev} className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/25 border border-white/20 flex items-center justify-center text-white transition-all hover:scale-110 backdrop-blur-sm">
              <ChevronLeft size={18} />
            </button>
            <button onClick={next} className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/25 border border-white/20 flex items-center justify-center text-white transition-all hover:scale-110 backdrop-blur-sm">
              <ChevronRight size={18} />
            </button>
          </div>
        )}
      </div>

      <div className="relative flex-shrink-0">
        {slides.length > 1 && (
          <div className="flex justify-center gap-2 pb-4">
            {slides.map((_, i) => (
              <button
                key={i}
                onClick={() => goTo(i)}
                className={`transition-all duration-300 rounded-full ${i === current ? "w-8 h-2 bg-white" : "w-2 h-2 bg-white/40 hover:bg-white/70"}`}
              />
            ))}
          </div>
        )}
        <div className="h-1 flex">
          <div className="flex-[3] bg-[#E84821]" />
          <div className="flex-[2]" style={{ backgroundColor: primary }} />
          <div className="flex-1 bg-[#3D4FA0]" />
        </div>
      </div>
    </section>
  );
}

function SectionLabel({ label, primary }: { label: string; primary: string }) {
  return (
    <div className="mb-10">
      <div className="text-xs font-bold uppercase tracking-widest mb-3" style={{ color: primary }}>{label}</div>
      <div className="mt-2 flex items-center gap-1.5">
        <div className="h-1 w-12 rounded-full bg-[#E84821]" />
        <div className="h-1 w-6 rounded-full" style={{ backgroundColor: primary }} />
        <div className="h-1 w-3 rounded-full bg-[#3D4FA0]" />
      </div>
    </div>
  );
}

export default function HomePage() {
  const { t } = useTranslation();
  const config = useSiteConfig();
  const { data: cmsPage, isLoading } = useGetPublicPage("home");
  const { field } = usePageContent("home");
  const { posts: blogPosts, loading: blogLoading } = useBlogPosts(3);

  const primary = config.primaryColor;
  const accent = config.accentColor;

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: config.siteName,
    url: typeof window !== "undefined" ? window.location.origin : "",
    description: config.tagline ?? "India's premier technology partner",
    ...(config.contactEmail ? { email: config.contactEmail } : {}),
    ...(config.contactPhone ? { telephone: config.contactPhone } : {}),
    ...(config.address ? { address: config.address } : {}),
  };

  const wmsFeatures = [
    t("home.wmsBullet1"),
    t("home.wmsBullet2"),
    t("home.wmsBullet3"),
    t("home.wmsBullet4"),
  ];

  return (
    <PublicLayout>
      <SEO
        title={cmsPage?.metaTitle ?? undefined}
        description={cmsPage?.metaDescription ?? config.tagline ?? "CtrlA Tech Solutions delivers cutting-edge IT services that empower businesses to scale, innovate, and lead in the digital era."}
        jsonLd={jsonLd}
      />

      {/* Hero Slideshow */}
      <HeroSlideshow primary={primary} accent={accent} config={{ siteName: config.siteName, tagline: config.tagline, bannerHeight: config.bannerHeight, bannerSpeed: config.bannerSpeed }} cmsPage={cmsPage} />

      {/* ── Trust / Stats Bar ── */}
      <section style={{ background: "linear-gradient(135deg, #0d1225 0%, #1A1F36 60%, #2D3561 100%)" }} className="py-10 border-b border-white/10">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
            {[
              { label: t("home.stat1"), value: "100+", color: "#E84821" },
              { label: t("home.stat2"), value: "24/7", color: primary },
              { label: t("home.stat3"), value: "50+", color: "#3D4FA0" },
              { label: t("home.stat4"), value: "✓", color: "#10b981" },
            ].map(({ label, value, color }, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.07 }}
                className="flex items-center gap-4"
              >
                <div className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-black text-lg flex-shrink-0" style={{ backgroundColor: `${color}22`, border: `1.5px solid ${color}40` }}>
                  <span style={{ color }}>{value}</span>
                </div>
                <p className="text-white/75 text-sm font-medium leading-snug">{label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Core Services ── */}
      <section className="pt-8 pb-16 md:pt-10 md:pb-20 bg-white">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-10">
            <div className="text-xs font-bold uppercase tracking-widest mb-3" style={{ color: primary }}>{field("services_label", t("home.sectionLabel"))}</div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight" style={{ color: accent }}>
              {field("services_title", t("home.sectionTitle"))}
            </h2>
            <div className="mt-4 flex items-center gap-1.5">
              <div className="h-1 w-12 rounded-full bg-[#E84821]" />
              <div className="h-1 w-6 rounded-full" style={{ backgroundColor: primary }} />
              <div className="h-1 w-3 rounded-full bg-[#3D4FA0]" />
            </div>
            <p className="text-gray-500 mt-4 max-w-4xl text-base leading-relaxed">
              {field("services_desc", t("home.sectionDesc"))}
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {SERVICE_KEYS.map((key, i) => {
              const Icon = SERVICE_ICONS[i];
              const bg = SERVICE_COLORS[i];
              return (
                <motion.div
                  key={key}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.4, delay: i * 0.06 }}
                >
                  <Link
                    href={SERVICE_LINKS[key] ?? "/services"}
                    className="group flex flex-col h-full rounded-2xl p-6 transition-all duration-300 overflow-hidden hover:-translate-y-1.5 hover:shadow-2xl border border-white/10 relative"
                    style={{ background: `linear-gradient(140deg, ${bg} 0%, ${bg}dd 100%)` }}
                  >
                    <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-2xl" style={{ background: `linear-gradient(140deg, ${primary}ee 0%, ${primary}bb 100%)` }} />
                    <div className="relative w-11 h-11 rounded-xl flex items-center justify-center mb-5 bg-white/15 group-hover:bg-white/25 transition-colors">
                      <Icon size={20} className="text-white" />
                    </div>
                    <h3 className="relative text-sm font-bold text-white mb-2 leading-tight">{t(`home.services.${key}`)}</h3>
                    <p className="relative text-xs text-white/70 leading-relaxed flex-1">{t(`home.services.${key}Desc`)}</p>
                    <div className="relative mt-4 flex items-center gap-1 text-xs font-semibold text-white/50 group-hover:text-white/90 transition-colors">
                      {t("home.learnMore")} <ArrowRight size={12} />
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>

          <div className="mt-8 text-center">
            <Link href="/services" className="inline-flex items-center gap-2 text-sm font-semibold hover:gap-3 transition-all" style={{ color: primary }}>
              View all services <ArrowRight size={15} />
            </Link>
          </div>
        </div>
      </section>

      {/* ── Industries We Serve ── */}
      <section className="py-16 md:py-20" style={{ background: "linear-gradient(140deg, #0d1225 0%, #1A1F36 55%, #2D3561 100%)" }}>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="text-xs font-bold uppercase tracking-widest mb-3 text-[#E84821]">{field("industry_label", t("home.industryLabel"))}</div>
            <h2 className="text-2xl sm:text-3xl font-bold text-white">{field("industry_title", t("home.industryTitle"))}</h2>
            <p className="text-white/55 mt-3 max-w-xl mx-auto text-sm">{field("industry_desc", t("home.industryDesc"))}</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {INDUSTRIES.map(({ labelKey, Icon }, i) => (
              <motion.div
                key={labelKey}
                initial={{ opacity: 0, scale: 0.92 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.35, delay: i * 0.05 }}
                className="group flex flex-col items-center gap-3 rounded-2xl p-5 cursor-default transition-all duration-300 border border-white/10 hover:border-white/30 hover:bg-white/8"
                style={{ backgroundColor: "rgba(255,255,255,0.04)" }}
              >
                <div className="w-12 h-12 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform" style={{ backgroundColor: `${primary}25`, border: `1px solid ${primary}40` }}>
                  <Icon size={22} style={{ color: primary }} />
                </div>
                <span className="text-white/80 text-sm font-semibold text-center leading-tight group-hover:text-white transition-colors">{t(`home.${labelKey}`)}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── WMS 360 Feature ── */}
      <section className="relative bg-gray-50 py-16 md:py-20 border-y border-gray-100 overflow-hidden">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-10 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.5 }}
              className="lg:col-span-6 order-2 lg:order-1"
            >
              <div className="relative">
                <div className="absolute -top-3 -left-3 w-24 h-24 rounded-2xl bg-[#E84821]/10" />
                <div className="absolute -bottom-3 -right-3 w-20 h-20 rounded-2xl" style={{ backgroundColor: `${primary}1a` }} />
                <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-gray-100 aspect-[4/3]">
                  <img
                    src="https://images.unsplash.com/photo-1601598851547-4302969d0614?auto=format&fit=crop&w=1200&q=80"
                    alt="Modern warehouse operations powered by WMS 360"
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/40 to-transparent" />
                  <div className="absolute top-4 left-4 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/95 backdrop-blur text-xs font-bold uppercase tracking-widest" style={{ color: "#E84821" }}>
                    <Sparkles size={11} /> {t("home.flagshipBadge")}
                  </div>
                </div>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="lg:col-span-6 order-1 lg:order-2"
            >
              <div className="inline-flex items-center gap-2 mb-4 px-3 py-1 rounded-full bg-[#E84821]/10 text-[#E84821]">
                <Boxes size={14} />
                <span className="text-xs font-bold uppercase tracking-widest">{field("wms_intro", t("home.wmsIntro"))}</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-bold leading-tight" style={{ color: accent }}>
                {field("wms_headline", t("home.wmsHeadline"))}<span style={{ color: "#E84821" }}>{field("wms_headline_highlight", t("home.wmsHeadlineHighlight"))}</span>
              </h2>
              <p className="text-gray-600 mt-5 mb-6 leading-relaxed">{field("wms_desc", t("home.wmsDesc"))}</p>
              <ul className="space-y-2.5 mb-8">
                {wmsFeatures.map(feat => (
                  <li key={feat} className="flex items-start gap-2.5 text-sm text-gray-700">
                    <CheckCircle2 size={18} style={{ color: primary }} className="flex-shrink-0 mt-0.5" />
                    {feat}
                  </li>
                ))}
              </ul>
              <div className="flex flex-wrap gap-3">
                <Link href="/wms360" className="inline-flex items-center gap-2 px-6 py-3 rounded-lg font-bold text-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5" style={{ backgroundColor: primary }}>
                  {t("home.wmsExplore")} <ArrowRight size={16} />
                </Link>
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-lg font-semibold border-2 border-gray-200 hover:border-[#D4920C] text-gray-800 hover:text-[#D4920C] transition-all">
                  {t("home.wmsDemo")}
                </Link>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── Why Choose CtrlA ── */}
      <section className="py-16 md:py-20 bg-white overflow-hidden">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 xl:gap-16 items-center">

            {/* Left — content */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.5 }}
            >
              <div className="text-xs font-bold uppercase tracking-widest mb-3" style={{ color: primary }}>{field("why_label", t("home.whyLabel"))}</div>
              <h2 className="text-2xl sm:text-3xl font-bold" style={{ color: accent }}>{field("why_title", t("home.whyTitle"))}</h2>
              <div className="mt-4 flex items-center gap-1.5">
                <div className="h-1 w-12 rounded-full bg-[#E84821]" />
                <div className="h-1 w-6 rounded-full" style={{ backgroundColor: primary }} />
                <div className="h-1 w-3 rounded-full bg-[#3D4FA0]" />
              </div>
              <p className="text-gray-500 mt-4 mb-8 text-sm leading-relaxed">{field("why_desc", t("home.whyDesc"))}</p>

              <div className="space-y-5">
                {WHY_ITEMS.map(({ titleKey, descKey, Icon, color }, i) => (
                  <motion.div
                    key={titleKey}
                    initial={{ opacity: 0, x: -12 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: i * 0.08 }}
                    className="flex gap-4 group"
                  >
                    <div
                      className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform"
                      style={{ backgroundColor: `${color}12`, border: `1.5px solid ${color}25` }}
                    >
                      <Icon size={20} style={{ color }} />
                    </div>
                    <div>
                      <h3 className="font-bold text-sm mb-1" style={{ color: accent }}>{t(`home.${titleKey}`)}</h3>
                      <p className="text-gray-500 text-xs leading-relaxed">{t(`home.${descKey}`)}</p>
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="mt-8">
                <Link
                  href="/about"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-lg font-bold text-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5"
                  style={{ backgroundColor: primary }}
                >
                  Meet Our Team <ArrowRight size={16} />
                </Link>
              </div>
            </motion.div>

            {/* Right — image + stat overlays */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="relative"
            >
              {/* Decorative bg blobs */}
              <div className="absolute -top-6 -right-6 w-48 h-48 rounded-full opacity-10 blur-3xl" style={{ backgroundColor: primary }} />
              <div className="absolute -bottom-6 -left-6 w-40 h-40 rounded-full opacity-10 blur-3xl bg-[#E84821]" />

              {/* Main image */}
              <div className="relative rounded-3xl overflow-hidden shadow-2xl aspect-[4/5]">
                <img
                  src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&w=900&q=80"
                  alt="CtrlA Tech Solutions — India & UK technology partner"
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
                {/* Gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d1225]/50 via-transparent to-transparent" />

                {/* Bottom badge */}
                <div className="absolute bottom-5 left-5 right-5 bg-white/95 backdrop-blur rounded-2xl p-4 shadow-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${primary}18` }}>
                      <Globe size={20} style={{ color: primary }} />
                    </div>
                    <div>
                      <p className="font-bold text-sm text-gray-900">Serving India & United Kingdom</p>
                      <p className="text-xs text-gray-500">Offices in Gurugram (India) & London (UK)</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Stat cards row — below the image */}
              <div className="mt-4 grid grid-cols-3 gap-3">
                {[
                  { value: "100+", label: "Projects Delivered", color: "#E84821" },
                  { value: "500+", label: "Businesses Empowered", color: primary },
                  { value: "15+",  label: "Years of Expertise",  color: "#3D4FA0" },
                ].map(({ value, label, color }) => (
                  <div key={label} className="bg-white rounded-2xl shadow-lg border border-gray-100 p-4 text-center">
                    <div className="text-2xl font-black leading-none" style={{ color }}>{value}</div>
                    <div className="text-xs font-semibold text-gray-500 mt-1 leading-snug">{label}</div>
                  </div>
                ))}
              </div>
            </motion.div>

          </div>
        </div>
      </section>

      {/* ── Testimonials ── */}
      <section className="py-16 md:py-20" style={{ background: "linear-gradient(140deg, #0d1225 0%, #1A1F36 55%, #2D3561 100%)" }}>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="text-xs font-bold uppercase tracking-widest mb-3 text-[#E84821]">{field("testimonials_label", t("home.testimonialsLabel"))}</div>
            <h2 className="text-2xl sm:text-3xl font-bold text-white">{field("testimonials_title", t("home.testimonialsTitle"))}</h2>
            <div className="mt-4 flex justify-center items-center gap-1.5">
              <div className="h-1 w-12 rounded-full bg-[#E84821]" />
              <div className="h-1 w-6 rounded-full" style={{ backgroundColor: primary }} />
              <div className="h-1 w-3 rounded-full bg-[#3D4FA0]" />
            </div>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {TESTIMONIALS.map(({ quote, name, title, company, initials, color }, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.45, delay: i * 0.1 }}
                className="relative rounded-2xl p-6 flex flex-col border border-white/10"
                style={{ backgroundColor: "rgba(255,255,255,0.05)" }}
              >
                <Quote size={28} className="mb-4 opacity-30 text-white" />
                <p className="text-white/80 text-sm leading-relaxed flex-1 italic">"{quote}"</p>
                <div className="mt-6 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0" style={{ backgroundColor: color }}>
                    {initials}
                  </div>
                  <div>
                    <p className="text-white text-sm font-semibold">{name}</p>
                    <p className="text-white/50 text-xs">{title}, {company}</p>
                  </div>
                </div>
                <div className="absolute top-0 left-6 right-6 h-px" style={{ background: `linear-gradient(90deg, ${color}60, transparent)` }} />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Blog / Knowledge Centre ── */}
      <section className="py-16 md:py-20 bg-gray-50 border-t border-gray-100">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between mb-10 gap-4">
            <div>
              <div className="text-xs font-bold uppercase tracking-widest mb-3" style={{ color: primary }}>{field("blog_label", t("home.blogLabel"))}</div>
              <h2 className="text-2xl sm:text-3xl font-bold" style={{ color: accent }}>{field("blog_title", t("home.blogTitle"))}</h2>
              <div className="mt-4 flex items-center gap-1.5">
                <div className="h-1 w-12 rounded-full bg-[#E84821]" />
                <div className="h-1 w-6 rounded-full" style={{ backgroundColor: primary }} />
                <div className="h-1 w-3 rounded-full bg-[#3D4FA0]" />
              </div>
            </div>
            <Link href="/blog" className="hidden sm:inline-flex items-center gap-2 text-sm font-semibold flex-shrink-0 hover:gap-3 transition-all" style={{ color: primary }}>
              {t("home.blogCta")} <ArrowRight size={15} />
            </Link>
          </div>

          {blogLoading ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1,2,3].map(i => (
                <div key={i} className="rounded-2xl bg-white overflow-hidden animate-pulse">
                  <div className="h-44 bg-gray-100" />
                  <div className="p-5 space-y-3">
                    <div className="h-4 bg-gray-100 rounded w-3/4" />
                    <div className="h-3 bg-gray-100 rounded w-full" />
                    <div className="h-3 bg-gray-100 rounded w-2/3" />
                  </div>
                </div>
              ))}
            </div>
          ) : blogPosts.length === 0 ? (
            <div className="text-center py-16 rounded-2xl bg-white border border-gray-100">
              <BookOpen size={40} className="mx-auto mb-4 text-gray-300" />
              <p className="text-gray-400 text-sm">{t("home.blogNoPosts")}</p>
            </div>
          ) : (
            <div className={
                blogPosts.length === 1
                  ? "flex justify-center"
                  : blogPosts.length === 2
                    ? "grid sm:grid-cols-2 gap-6 max-w-2xl mx-auto"
                    : "grid sm:grid-cols-2 lg:grid-cols-3 gap-6"
              }>
              {blogPosts.map((post, i) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.4, delay: i * 0.08 }}
                  className={blogPosts.length === 1 ? "w-full max-w-sm" : ""}
                >
                  <Link href={`/blog/${post.slug}`} className="group flex flex-col h-full rounded-2xl bg-white overflow-hidden border border-gray-100 hover:border-gray-200 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                    <div className="h-44 overflow-hidden bg-gray-100 relative flex-shrink-0">
                      {post.featuredImage ? (
                        <img src={post.featuredImage} alt={post.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center" style={{ background: `linear-gradient(140deg, ${primary}22 0%, #3D4FA022 100%)` }}>
                          <BookOpen size={36} className="text-gray-300" />
                        </div>
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <div className="p-5 flex flex-col flex-1">
                      <h3 className="font-bold text-sm leading-tight mb-2 line-clamp-2 transition-colors" style={{ color: accent }}>
                        {post.title}
                      </h3>
                      {post.excerpt && (
                        <p className="text-gray-500 text-xs leading-relaxed line-clamp-3 flex-1">
                          {post.excerpt}
                        </p>
                      )}
                      <div className="mt-4 flex items-center gap-1 text-xs font-semibold transition-colors group-hover:gap-2" style={{ color: primary }}>
                        {t("home.blogReadMore")} <ArrowRight size={12} />
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          )}

          <div className="mt-8 text-center sm:hidden">
            <Link href="/blog" className="inline-flex items-center gap-2 text-sm font-semibold" style={{ color: primary }}>
              {t("home.blogCta")} <ArrowRight size={15} />
            </Link>
          </div>
        </div>
      </section>

      {/* CMS-driven body */}
      {!isLoading && cmsPage?.content ? (
        <section className="py-16 bg-white border-t border-gray-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div
              className="prose prose-lg max-w-none"
              style={{ "--tw-prose-headings": accent, "--tw-prose-links": primary, "--tw-prose-bold": accent } as React.CSSProperties}
              dangerouslySetInnerHTML={{ __html: cmsPage.content }}
            />
          </div>
        </section>
      ) : null}

      {/* ── CTA strip ── */}
      <section className="relative py-20 overflow-hidden border-t border-gray-100" style={{ background: "linear-gradient(140deg, #0d1225 0%, #1A1F36 55%, #2D3561 100%)" }}>
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute -top-32 -right-32 w-96 h-96 rounded-full opacity-10 blur-3xl" style={{ backgroundColor: primary }} />
          <div className="absolute -bottom-32 -left-32 w-96 h-96 rounded-full opacity-10 blur-3xl bg-[#E84821]" />
        </div>
        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 mb-6 px-3 py-1 rounded-full bg-white/10 border border-white/20">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs text-white/70 font-medium">Ready to get started?</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold mb-4 text-white">{t("home.ctaTitle")}</h2>
          <p className="text-white/60 mb-8 max-w-2xl mx-auto">{t("home.ctaDesc", { siteName: config.siteName })}</p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Link href="/contact" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-lg font-bold text-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5" style={{ backgroundColor: primary }}>
              {t("home.ctaButton")} <ArrowRight size={18} />
            </Link>
            <Link href="/services" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-lg font-semibold border-2 border-white/25 text-white/80 hover:border-white/50 hover:text-white transition-all">
              {t("home.heroServices")}
            </Link>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1 flex">
          <div className="flex-[3] bg-[#E84821]" />
          <div className="flex-[2]" style={{ backgroundColor: primary }} />
          <div className="flex-1 bg-[#3D4FA0]" />
        </div>
      </section>
    </PublicLayout>
  );
}
