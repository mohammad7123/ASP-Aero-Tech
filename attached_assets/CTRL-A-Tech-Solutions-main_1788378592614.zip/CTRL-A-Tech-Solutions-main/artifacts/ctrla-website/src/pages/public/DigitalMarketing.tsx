import { Link } from "wouter";
import {
  ArrowRight, TrendingUp, Search, MousePointerClick, Share2,
  FileText, Brain, Mail, BarChart3, Star, ShieldCheck,
  CheckCircle2, ChevronRight, Megaphone, Globe, Zap,
} from "lucide-react";
import { motion } from "framer-motion";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

const SERVICES = [
  {
    icon: Search,
    title: "Search Engine Optimisation (SEO)",
    tagline: "Rank Higher. Get Found Faster.",
    color: "#E84821",
    bg: "#FFF4F1",
    desc: "Improve your visibility on Google with ethical, long-term SEO strategies that drive organic traffic and quality leads.",
    items: ["Technical SEO", "Keyword Research", "On-Page & Off-Page SEO", "Local SEO", "E-commerce SEO", "Link Building"],
  },
  {
    icon: MousePointerClick,
    title: "Search Engine Marketing (PPC)",
    tagline: "Maximise ROI with High-Performance Paid Campaigns",
    color: "#3D4FA0",
    bg: "#F0F3FF",
    desc: "Reach your target audience instantly with optimised Google Ads and display campaigns designed to increase conversions while reducing ad costs.",
    items: ["Google Ads", "Display Campaigns", "Shopping Ads", "Performance Max", "YouTube Advertising", "Remarketing"],
  },
  {
    icon: Share2,
    title: "Social Media Marketing",
    tagline: "Build Stronger Customer Relationships",
    color: "#7C3AED",
    bg: "#F5F3FF",
    desc: "Connect with your audience through engaging content and targeted advertising across leading social platforms.",
    items: ["Facebook & Instagram", "LinkedIn", "YouTube", "X (Twitter)", "Social Media Strategy", "Paid Advertising"],
  },
  {
    icon: FileText,
    title: "Content Marketing",
    tagline: "Content That Educates, Engages & Converts",
    color: "#D4920C",
    bg: "#FFFBEB",
    desc: "Create valuable content that builds authority, attracts customers, and supports your SEO and lead generation efforts.",
    items: ["Blog Writing", "Landing Pages", "Case Studies", "Whitepapers", "Video Scripts", "Email Content"],
  },
  {
    icon: Brain,
    title: "AI-Powered Digital Marketing",
    tagline: "Smarter Marketing with Artificial Intelligence",
    color: "#059669",
    bg: "#ECFDF5",
    desc: "Leverage AI to optimise campaigns, understand customer behaviour, and improve marketing performance at scale.",
    items: ["AI Content Generation", "Campaign Optimisation", "Audience Segmentation", "Predictive Marketing", "AI Chatbots", "Marketing Automation"],
  },
  {
    icon: Mail,
    title: "Email Marketing & Automation",
    tagline: "Nurture Leads Automatically",
    color: "#0891B2",
    bg: "#ECFEFF",
    desc: "Convert prospects into loyal customers with personalised email campaigns and automated customer journeys.",
    items: ["Email Campaigns", "Lead Nurturing", "Marketing Automation", "Newsletter Design", "Customer Segmentation", "Campaign Analytics"],
  },
  {
    icon: TrendingUp,
    title: "Conversion Rate Optimisation (CRO)",
    tagline: "Turn Visitors into Customers",
    color: "#B45309",
    bg: "#FFF8EC",
    desc: "Improve your website's performance through user experience optimisation, A/B testing, and data-driven improvements.",
    items: ["Landing Page Optimisation", "A/B Testing", "User Behaviour Analysis", "Funnel Optimisation", "Heatmap Analysis", "Conversion Tracking"],
  },
  {
    icon: ShieldCheck,
    title: "Online Reputation Management",
    tagline: "Build Trust. Protect Your Brand.",
    color: "#DC2626",
    bg: "#FEF2F2",
    desc: "Monitor and improve your online reputation through proactive review management and brand monitoring.",
    items: ["Review Monitoring", "Reputation Analysis", "Brand Monitoring", "Crisis Management", "Customer Feedback Management"],
  },
  {
    icon: BarChart3,
    title: "Analytics & Performance Reporting",
    tagline: "Every Marketing Decision Backed by Data",
    color: "#1D4ED8",
    bg: "#EFF6FF",
    desc: "Track every click, lead, conversion, and campaign with powerful dashboards and detailed business insights.",
    items: ["Google Analytics", "Search Console", "Lead Analytics", "Campaign Performance", "ROI Reports", "Executive Dashboards"],
  },
];

const WHY_ITEMS = [
  "Increase Website Traffic",
  "Generate Qualified Leads",
  "Improve Brand Visibility",
  "Increase Online Sales",
  "Improve Search Engine Rankings",
  "Build Customer Engagement",
  "Optimise Marketing Spend",
  "Measure ROI with Real-Time Analytics",
  "Automate Marketing Processes",
  "Scale Your Business Faster",
];

const TRUST_ITEMS = [
  "SEO Experts & Google Ads Specialists",
  "Social Media Professionals",
  "AI-Powered Marketing Solutions",
  "Creative Content Team",
  "Data-Driven Campaign Management",
  "Transparent Reporting",
  "ROI-Focused Strategies",
  "Dedicated Account Managers",
  "End-to-End Digital Growth Partner",
];

const INDUSTRIES = [
  "Manufacturing", "Retail & eCommerce", "Healthcare", "Education",
  "Real Estate", "Hospitality", "Financial Services", "Logistics",
  "Food & Beverage", "Professional Services", "Technology Companies", "Startups",
];

export default function DigitalMarketingPage() {
  const { primaryColor, accentColor } = useSiteConfig();

  return (
    <PublicLayout>
      <SEO
        title="Digital Marketing Services — SEO, PPC, Social Media & AI Marketing | CtrlA Tech Solutions"
        description="Grow your business with data-driven digital marketing — SEO, Google Ads, social media, content marketing, AI automation, and analytics. India & UK experts."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: "Digital Marketing Services",
          description: "Grow your business with data-driven digital marketing — SEO, Google Ads, social media, content marketing, AI automation, and analytics. India & UK experts.",
          provider: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
          areaServed: ["IN", "GB"],
          serviceType: ["SEO", "PPC / Google Ads", "Social Media Marketing", "Content Marketing", "AI Marketing Automation", "Web Analytics"],
          url: window.location.href,
        }}
      />

      {/* ── HERO ── */}
      <section className="relative overflow-hidden" style={{ background: "linear-gradient(140deg, #0d1225 0%, #1A1F36 55%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.06]" viewBox="0 0 1200 520" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="980" cy="260" r="340" stroke="#E84821" strokeWidth="0.8" strokeDasharray="12 8"/>
          <circle cx="980" cy="260" r="200" stroke={primaryColor} strokeWidth="0.5" strokeDasharray="6 10"/>
          <path d="M0 380 Q300 330 600 360 Q900 390 1200 350" stroke="white" strokeWidth="0.5" fill="none" strokeDasharray="7 7"/>
        </svg>

        <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <div className="inline-flex items-center gap-2 mb-4 px-3 py-1.5 rounded-full border border-[#0891B2]/40 bg-[#0891B2]/12">
                <TrendingUp size={13} className="text-[#0891B2]" />
                <span className="text-xs font-black uppercase tracking-widest text-[#0891B2]">Digital Marketing</span>
              </div>
              <h1 className="text-4xl sm:text-5xl font-black leading-[1.06] text-white mb-3">
                Grow Your Business<br/>
                <span style={{ color: "#0891B2" }}>with Data-Driven</span><br/>
                <span className="text-white/80 text-3xl sm:text-4xl font-bold">Digital Marketing</span>
              </h1>
              <div className="flex gap-2 my-5">
                <span className="h-1 w-12 rounded-full bg-[#E84821]" />
                <span className="h-1 w-7 rounded-full bg-[#0891B2]" />
                <span className="h-1 w-4 rounded-full bg-[#3D4FA0]" />
              </div>
              <p className="text-gray-300 text-sm leading-relaxed mb-2 max-w-lg">
                In today's digital-first world, having a website is only the beginning. We combine creativity, technology, AI, and data analytics to develop digital marketing strategies that deliver measurable business results.
              </p>
              <p className="text-gray-400 text-sm leading-relaxed mb-8 max-w-lg">
                From SEO and paid advertising to social media, content marketing, and AI-powered automation — we help businesses across <strong className="text-white">India & UK</strong> stay ahead of the competition.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#0891B2] hover:opacity-90 hover:-translate-y-0.5 shadow-lg transition-all text-sm">
                  Get a Free Marketing Audit <ArrowRight size={15} />
                </Link>
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
                  Talk to Our Experts <ChevronRight size={14} />
                </Link>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.12 }} className="hidden lg:block">
              <div className="grid grid-cols-2 gap-4">
                {[
                  { icon: Search,          label: "SEO",             color: "#E84821" },
                  { icon: MousePointerClick, label: "PPC Ads",       color: "#3D4FA0" },
                  { icon: Share2,          label: "Social Media",    color: "#7C3AED" },
                  { icon: Brain,           label: "AI Marketing",    color: "#059669" },
                  { icon: Mail,            label: "Email Automation",color: "#0891B2" },
                  { icon: BarChart3,       label: "Analytics",       color: "#D4920C" },
                ].map(({ icon: Icon, label, color }) => (
                  <div key={label} className="flex items-center gap-3 bg-white/6 border border-white/10 rounded-2xl p-4">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${color}25` }}>
                      <Icon size={18} style={{ color }} />
                    </div>
                    <span className="text-white/80 text-sm font-semibold">{label}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>

        <div className="h-1 flex">
          <div className="flex-[3] bg-[#E84821]" />
          <div className="flex-[2] bg-[#0891B2]" />
          <div className="flex-1 bg-[#3D4FA0]" />
        </div>
      </section>

      {/* ── Why Choose ── */}
      <section className="py-14 bg-white border-b border-gray-100">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#0891B2]" />
              <span className="text-xs font-bold uppercase tracking-widest text-[#0891B2]">Why CtrlA Digital Marketing?</span>
              <span className="w-6 h-0.5 rounded bg-[#0891B2]" />
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold mb-3" style={{ color: accentColor }}>
              Digital marketing is more than running ads —<br className="hidden sm:block" />
              <span style={{ color: "#0891B2" }}>it's a complete growth strategy</span>
            </h2>
            <p className="text-gray-500 text-sm max-w-2xl mx-auto">Our services help you achieve measurable outcomes across every stage of your customer journey.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {WHY_ITEMS.map((item, i) => (
              <motion.div
                key={item}
                initial={{ opacity: 0, y: 14 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="flex items-start gap-2.5 p-3 rounded-xl bg-gray-50 border border-gray-100"
              >
                <CheckCircle2 size={15} className="text-[#0891B2] flex-shrink-0 mt-0.5" />
                <span className="text-xs font-semibold text-gray-700">{item}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Services Grid ── */}
      <section className="py-16 md:py-20" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #F0FDFF 100%)" }}>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]" />
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Our Digital Marketing Services</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]" />
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold" style={{ color: accentColor }}>End-to-End Digital Growth Solutions</h2>
            <p className="text-gray-500 text-sm mt-2 max-w-xl mx-auto">Every service is designed to drive traffic, generate leads, and grow your revenue.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {SERVICES.map((s, i) => {
              const Icon = s.icon;
              return (
                <motion.div
                  key={s.title}
                  initial={{ opacity: 0, y: 18 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.06 }}
                  className="bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col"
                >
                  <div className="h-1.5 w-full" style={{ backgroundColor: s.color }} />
                  <div className="p-6 flex flex-col flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: s.bg }}>
                        <Icon size={20} style={{ color: s.color }} />
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-900 text-sm leading-tight">{s.title}</h3>
                        <p className="text-[10px] font-semibold mt-0.5" style={{ color: s.color }}>{s.tagline}</p>
                      </div>
                    </div>
                    <p className="text-gray-500 text-xs leading-relaxed mb-4 flex-1">{s.desc}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {s.items.map(f => (
                        <span key={f} className="text-[10px] font-semibold px-2 py-0.5 rounded-full border" style={{ color: s.color, borderColor: `${s.color}30`, backgroundColor: `${s.color}08` }}>
                          {f}
                        </span>
                      ))}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── Industries ── */}
      <section className="py-14 bg-white border-t border-gray-100">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]" />
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Industries We Serve</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold" style={{ color: accentColor }}>Digital Marketing for Every Industry</h2>
            <p className="text-gray-500 text-sm mt-2">Our solutions are designed for businesses across diverse sectors.</p>
          </div>
          <div className="flex flex-wrap justify-center gap-3">
            {INDUSTRIES.map((ind, i) => (
              <motion.span
                key={ind}
                initial={{ opacity: 0, scale: 0.92 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.04 }}
                className="px-4 py-2 rounded-full border border-gray-200 text-sm font-semibold text-gray-700 hover:border-[#0891B2] hover:text-[#0891B2] transition-colors cursor-default"
              >
                {ind}
              </motion.span>
            ))}
          </div>
        </div>
      </section>

      {/* ── Why Trust Us ── */}
      <section className="py-14 border-t border-gray-100" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #EFF2FF 100%)" }}>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-14 items-center">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#E84821]" />
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why Businesses Trust CtrlA</span>
              </div>
              <h2 className="text-3xl font-bold mb-3" style={{ color: accentColor }}>
                Your dedicated partner<br/>
                <span style={{ color: "#0891B2" }}>for digital growth</span>
              </h2>
              <p className="text-gray-500 text-sm leading-relaxed mb-6">
                We combine deep marketing expertise with technology, AI, and analytics to deliver campaigns that drive measurable results and long-term success for businesses across India & UK.
              </p>
              <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#0891B2] hover:opacity-90 hover:-translate-y-0.5 transition-all text-sm shadow-lg">
                Request a Free Consultation <ArrowRight size={15} />
              </Link>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="space-y-3">
                {TRUST_ITEMS.map((w, i) => (
                  <motion.div
                    key={w}
                    initial={{ opacity: 0, x: 12 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.06 }}
                    className="flex items-center gap-3 p-3 rounded-xl bg-white border border-gray-100 hover:border-[#0891B2]/30 transition-all"
                  >
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-[#0891B2]/10 flex-shrink-0">
                      <CheckCircle2 size={14} className="text-[#0891B2]" />
                    </div>
                    <span className="text-sm font-semibold text-gray-700">{w}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #0c3547 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.06]" viewBox="0 0 900 280" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="820" cy="140" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
        </svg>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <div className="inline-flex items-center gap-2 mb-4 px-3 py-1 rounded-full bg-white/10 border border-white/20">
            <Zap size={12} className="text-[#0891B2]" />
            <span className="text-xs text-white/70 font-medium">Ready to Accelerate Your Digital Growth?</span>
          </div>
          <h2 className="text-3xl font-bold text-white mb-3">
            Let's Build Your Digital Marketing Strategy
          </h2>
          <p className="text-gray-400 text-sm mb-8 max-w-2xl mx-auto leading-relaxed">
            Whether you're looking to increase website traffic, generate quality leads, improve search rankings, or build a stronger online presence — CtrlA Tech Solutions delivers strategies that grow your business faster and smarter.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold text-white bg-[#0891B2] hover:opacity-90 hover:-translate-y-0.5 transition-all text-sm shadow-xl">
              Get Your Free Marketing Audit <ArrowRight size={15} />
            </Link>
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
              Get SEO & Website Audit <ChevronRight size={14} />
            </Link>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1 flex">
          <div className="flex-[3] bg-[#E84821]" />
          <div className="flex-[2] bg-[#0891B2]" />
          <div className="flex-1 bg-[#3D4FA0]" />
        </div>
      </section>
    </PublicLayout>
  );
}
