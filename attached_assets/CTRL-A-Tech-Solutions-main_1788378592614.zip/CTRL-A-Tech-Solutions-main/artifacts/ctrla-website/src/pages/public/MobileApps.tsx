import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  ArrowRight, CheckCircle2, Smartphone, Monitor, Tablet,
  Building2, ShoppingCart, Globe2, Bell, MapPin, Scan,
  Wifi, Shield, CreditCard, Camera, BarChart3, Cloud,
  ChevronRight, Zap, Lock, RefreshCw, Layers,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

const SERVICES = [
  {
    icon: Smartphone,
    title: "Android App Development",
    color: "#3D4FA0",
    bg: "#F0F3FF",
    desc: "Native Android applications optimized for speed, reliability, and user experience.",
    image: "https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?auto=format&fit=crop&w=700&q=80",
  },
  {
    icon: Monitor,
    title: "iOS App Development",
    color: "#E84821",
    bg: "#FFF4F1",
    desc: "Premium iPhone and iPad applications built using Apple's latest technologies.",
    image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?auto=format&fit=crop&w=700&q=80",
  },
  {
    icon: Tablet,
    title: "Cross-Platform Apps",
    color: "#D4920C",
    bg: "#FFFBEB",
    desc: "Develop once and deploy across Android and iOS using Flutter and React Native.",
    image: "https://images.unsplash.com/photo-1551650975-87deedd944c3?auto=format&fit=crop&w=700&q=80",
  },
  {
    icon: Building2,
    title: "Enterprise Mobile Apps",
    color: "#059669",
    bg: "#ECFDF5",
    desc: "Warehouse Management, Sales Force Automation, Field Service, Inventory, CRM, and ERP-integrated mobile applications.",
    image: "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&w=700&q=80",
  },
  {
    icon: ShoppingCart,
    title: "Customer Apps",
    color: "#7C3AED",
    bg: "#F5F3FF",
    desc: "eCommerce, Booking, Loyalty Programs, Delivery Tracking, Payment Solutions, and Self-Service Applications.",
    image: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=700&q=80",
  },
  {
    icon: Globe2,
    title: "Progressive Web Apps (PWA)",
    color: "#0F766E",
    bg: "#F0FDFA",
    desc: "Fast, installable web applications that work seamlessly across all devices.",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=700&q=80",
  },
];

const FEATURES = [
  { icon: Bell, label: "Real-Time Notifications" },
  { icon: MapPin, label: "GPS & Location Tracking" },
  { icon: Scan, label: "Barcode & QR Code Scanning" },
  { icon: Wifi, label: "Offline Synchronization" },
  { icon: Lock, label: "Secure Authentication" },
  { icon: CreditCard, label: "Payment Gateway Integration" },
  { icon: Camera, label: "Camera & Document Upload" },
  { icon: Zap, label: "API Integration" },
  { icon: Cloud, label: "Cloud Synchronization" },
  { icon: BarChart3, label: "Analytics Dashboard" },
];

const TECHNOLOGIES = [
  { name: "Flutter", cat: "Cross-Platform" },
  { name: "React Native", cat: "Cross-Platform" },
  { name: "Kotlin", cat: "Android" },
  { name: "Swift", cat: "iOS" },
  { name: "Firebase", cat: "Backend" },
  { name: "Node.js", cat: "Backend" },
  { name: "REST APIs", cat: "Integration" },
  { name: "GraphQL", cat: "Integration" },
  { name: "AWS", cat: "Cloud" },
  { name: "Azure", cat: "Cloud" },
];

const CAT_COLORS: Record<string, string> = {
  "Cross-Platform": "#D4920C",
  Android: "#3D4FA0",
  iOS: "#E84821",
  Backend: "#059669",
  Integration: "#7C3AED",
  Cloud: "#0F766E",
};

const WHY = [
  { icon: Zap, label: "Native Performance" },
  { icon: Layers, label: "Modern UI/UX" },
  { icon: Shield, label: "Enterprise-Grade Security" },
  { icon: RefreshCw, label: "Fast Deployment" },
  { icon: Tablet, label: "Cross-Platform Compatibility" },
  { icon: Wifi, label: "Offline Capability" },
  { icon: CheckCircle2, label: "Easy Maintenance" },
  { icon: Globe2, label: "App Store Deployment Support" },
];

export default function MobileAppsPage() {
  const { primaryColor, accentColor } = useSiteConfig();

  return (
    <PublicLayout>
      <SEO
        title="Mobile App Development — iOS, Android & Cross-Platform | CtrlA Tech Solutions"
        description="CtrlA builds feature-rich Android, iOS, and cross-platform mobile apps for enterprises and consumers — including Flutter, React Native, PWA, and ERP-integrated solutions."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: "Mobile App Development",
          description: "CtrlA builds feature-rich Android, iOS, and cross-platform mobile apps for enterprises and consumers — including Flutter, React Native, PWA, and ERP-integrated solutions.",
          provider: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
          areaServed: ["IN", "GB"],
          serviceType: ["Android App Development", "iOS App Development", "Flutter Development", "React Native Development", "PWA Development"],
          url: window.location.href,
        }}
      />

      {/* ── HERO ─────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden" style={{ background: "linear-gradient(140deg, #080C1F 0%, #111627 50%, #1C2340 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.08]" viewBox="0 0 1200 520" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="980" cy="260" r="340" stroke="#3D4FA0" strokeWidth="0.7" strokeDasharray="10 7"/>
          <circle cx="980" cy="260" r="210" stroke={primaryColor} strokeWidth="0.5" strokeDasharray="5 9"/>
          <path d="M0 380 Q300 330 600 365 Q900 400 1200 350" stroke="white" strokeWidth="0.5" fill="none" strokeDasharray="6 6"/>
          {[[60,70],[190,300],[350,90],[220,200],[500,330]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-6 L2-2 L6-2 L3 2 L4 6 L0 3 L-4 6 L-3 2 L-6-2 L-2-2Z" fill="white" opacity="0.5"/></g>
          ))}
        </svg>

        <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <Link href="/services" className="inline-flex items-center gap-1.5 text-white/40 text-xs mb-5 hover:text-white/70 transition-colors">← IT Services</Link>
              <div className="inline-flex items-center gap-2 mb-4 px-3 py-1.5 rounded-full border border-[#3D4FA0]/50 bg-[#3D4FA0]/15">
                <Smartphone size={13} className="text-[#9BAFFF]"/>
                <span className="text-xs font-black uppercase tracking-widest text-[#9BAFFF]">Mobile App Development</span>
              </div>
              <h1 className="text-4xl sm:text-5xl font-black leading-[1.06] text-white mb-3">
                Intelligent Mobile Apps<br/>
                <span style={{ color: primaryColor }}>for Android, iOS</span><br/>
                <span className="text-white/80 text-3xl sm:text-4xl font-bold">&amp; Cross-Platform</span>
              </h1>
              <div className="flex gap-2 my-5">
                <span className="h-1 w-12 rounded-full bg-[#3D4FA0]"/>
                <span className="h-1 w-7 rounded-full" style={{ backgroundColor: primaryColor }}/>
                <span className="h-1 w-4 rounded-full bg-[#E84821]"/>
              </div>
              <p className="text-gray-300 text-sm leading-relaxed mb-3 max-w-lg">
                Transform your business with feature-rich mobile applications that keep your workforce connected and your customers engaged.
              </p>
              <p className="text-gray-400 text-sm leading-relaxed mb-8 max-w-lg">
                We build <strong className="text-white">intuitive, secure, and scalable mobile applications</strong> that deliver seamless experiences across Android, iOS, and cross-platform environments.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#3D4FA0] hover:opacity-90 hover:-translate-y-0.5 shadow-lg transition-all text-sm">
                  Book a Demo <ArrowRight size={15}/>
                </Link>
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
                  Start Your Mobile Project <ChevronRight size={14}/>
                </Link>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.12 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10">
                <img src="https://images.unsplash.com/photo-1526498460520-4c246339dccb?auto=format&fit=crop&w=800&q=80"
                  alt="Mobile app development" className="w-full h-64 object-cover"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#080C1F]/70 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse flex-shrink-0"/>
                  <span className="text-white text-xs font-semibold">Android · iOS · Flutter · React Native</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
        <div className="h-1 flex"><div className="flex-[3] bg-[#3D4FA0]"/><div className="flex-[2]" style={{ backgroundColor: primaryColor }}/><div className="flex-1 bg-[#E84821]"/></div>
      </section>

      {/* ── SERVICES — image cards ────────────────────────────────────── */}
      <section className="py-16 bg-white relative overflow-hidden">
        <svg className="absolute -bottom-10 -left-10 opacity-[0.04] w-72 h-72" viewBox="0 0 200 200" fill="none">
          <circle cx="100" cy="100" r="80" stroke="#3D4FA0" strokeWidth="1.5" strokeDasharray="5 4"/>
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Our Mobile App Services</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Apps built for performance, security, and productivity</h2>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {SERVICES.map((s, i) => {
              const Icon = s.icon;
              return (
                <motion.div key={s.title} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }}
                  className="group rounded-2xl overflow-hidden border border-gray-100 hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 bg-white">
                  <div className="relative h-36 overflow-hidden">
                    <img src={s.image} alt={s.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy"/>
                    <div className="absolute inset-0" style={{ background: `linear-gradient(to bottom, ${s.color}50, #111627CC)` }}/>
                    <div className="absolute top-3 left-3 w-9 h-9 rounded-xl flex items-center justify-center bg-white shadow-md">
                      <Icon size={16} style={{ color: s.color }}/>
                    </div>
                  </div>
                  <div className="p-5">
                    <div className="h-0.5 w-10 rounded-full mb-3" style={{ backgroundColor: s.color }}/>
                    <h3 className="font-bold text-gray-900 text-sm mb-2 group-hover:text-[#3D4FA0] transition-colors">{s.title}</h3>
                    <p className="text-gray-500 text-xs leading-relaxed">{s.desc}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── FEATURES + TECH + WHY ─────────────────────────────────────── */}
      <section className="py-16 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F0F3FF 0%, #F8F9FF 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.025]" viewBox="0 0 900 600" preserveAspectRatio="xMidYMid slice">
          {Array.from({length:18}).map((_,r)=>Array.from({length:24}).map((_,c)=>(
            <circle key={`${r}-${c}`} cx={c*38+19} cy={r*34+17} r="1.6" fill="#3D4FA0"/>
          )))}
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-3 gap-10">
            {/* Mobile Features */}
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-5 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">App Features</span>
              </div>
              <h3 className="text-xl font-bold mb-4" style={{ color: accentColor }}>Built-in capabilities for modern businesses</h3>
              <div className="space-y-2">
                {FEATURES.map((f, i) => {
                  const Icon = f.icon;
                  return (
                    <motion.div key={f.label} initial={{ opacity: 0, x: -8 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                      className="flex items-center gap-2.5 p-2.5 rounded-xl bg-white border border-gray-100 hover:border-[#3D4FA0]/30 hover:shadow-sm transition-all">
                      <div className="w-7 h-7 rounded-lg flex items-center justify-center bg-[#3D4FA0]/10 flex-shrink-0">
                        <Icon size={13} className="text-[#3D4FA0]"/>
                      </div>
                      <span className="text-xs font-semibold text-gray-700">{f.label}</span>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>

            {/* Technologies */}
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.08 }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-5 h-0.5 rounded bg-[#D4920C]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#D4920C]">Technologies</span>
              </div>
              <h3 className="text-xl font-bold mb-4" style={{ color: accentColor }}>Industry-leading mobile tech stack</h3>
              <div className="flex flex-wrap gap-2">
                {TECHNOLOGIES.map((t, i) => (
                  <motion.span key={t.name} initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold bg-white hover:shadow-sm hover:-translate-y-0.5 transition-all"
                    style={{ borderColor: CAT_COLORS[t.cat] + "50", color: CAT_COLORS[t.cat] }}>
                    <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: CAT_COLORS[t.cat] }}/>
                    {t.name}
                  </motion.span>
                ))}
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                {Object.entries(CAT_COLORS).map(([cat, col]) => (
                  <div key={cat} className="flex items-center gap-1.5 text-[10px] text-gray-500">
                    <span className="w-2 h-2 rounded-sm" style={{ backgroundColor: col }}/>
                    {cat}
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Why choose */}
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.16 }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-5 h-0.5 rounded bg-[#059669]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#059669]">Why Choose Our Mobile Apps?</span>
              </div>
              <h3 className="text-xl font-bold mb-4" style={{ color: accentColor }}>Performance-first, enterprise-ready</h3>
              <div className="space-y-2">
                {WHY.map((w, i) => {
                  const Icon = w.icon;
                  return (
                    <motion.div key={w.label} initial={{ opacity: 0, x: 8 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                      className="flex items-center gap-2.5 p-2.5 rounded-xl bg-white border border-gray-100 hover:border-[#059669]/30 hover:shadow-sm transition-all">
                      <div className="w-7 h-7 rounded-lg flex items-center justify-center bg-[#059669]/10 flex-shrink-0">
                        <Icon size={13} className="text-[#059669]"/>
                      </div>
                      <span className="text-xs font-semibold text-gray-700">{w.label}</span>
                      <CheckCircle2 size={12} className="text-[#059669] ml-auto flex-shrink-0"/>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.06]" viewBox="0 0 900 280" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="800" cy="140" r="180" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          {[[80,50],[220,200],[370,60]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-5 L2-2 L5-2 L3 2 L4 5 L0 3 L-4 5 L-3 2 L-5-2 L-2-2Z" fill="white" opacity="0.5"/></g>
          ))}
        </svg>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <h2 className="text-3xl font-bold text-white mb-3">Ready to launch your mobile app?</h2>
          <p className="text-gray-400 text-sm mb-8 max-w-xl mx-auto leading-relaxed">
            From enterprise mobility to customer-facing apps — our team builds mobile solutions that engage users and drive real business outcomes.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold text-white bg-[#3D4FA0] hover:opacity-90 hover:-translate-y-0.5 transition-all text-sm shadow-xl">
              Book a Demo <ArrowRight size={15}/>
            </Link>
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
              Start Your Mobile Project <ChevronRight size={14}/>
            </Link>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1 flex">
          <div className="flex-[3] bg-[#3D4FA0]"/>
          <div className="flex-[2]" style={{ backgroundColor: primaryColor }}/>
          <div className="flex-1 bg-[#E84821]"/>
        </div>
      </section>
    </PublicLayout>
  );
}
