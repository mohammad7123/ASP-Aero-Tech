import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  ArrowRight, CheckCircle2, Database, Cloud, Zap, Brain,
  Smartphone, GitBranch, BarChart3, Scan, Plug, Receipt,
  FileCheck, ShoppingCart, Warehouse, Factory, Users,
  Wrench, Package, HeadphonesIcon, Globe2, Layers, ChevronRight,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

/* ── Linked (dedicated page) products ─────────────────────────────────── */
const FEATURED = [
  {
    icon: Database,
    title: "SAP Business One",
    tagline: "All-in-one ERP for SMEs",
    desc: "A powerful ERP solution designed specifically for small and medium-sized businesses, helping manage finance, sales, purchasing, inventory, production, CRM, and business operations from a single integrated platform.",
    perfectFor: "Growing SMEs seeking an all-in-one ERP solution.",
    href: "/sap-business-one",
    accent: "#E84821",
    image: "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=600&q=80",
  },
  {
    icon: Zap,
    title: "SAP Business One HANA",
    tagline: "Real-time intelligence on in-memory DB",
    desc: "Experience lightning-fast performance with SAP Business One powered by SAP HANA's in-memory database. Gain real-time analytics, interactive dashboards, instant reporting, and superior business performance.",
    perfectFor: "Businesses requiring high-speed reporting and real-time business intelligence.",
    href: "/sap-business-one-hana",
    accent: "#D4920C",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=600&q=80",
  },
  {
    icon: Brain,
    title: "SAP S/4HANA",
    tagline: "Next-gen intelligent enterprise ERP",
    desc: "SAP's next-generation intelligent ERP platform built for enterprises looking to modernize operations through AI, automation, advanced analytics, and intelligent business processes.",
    perfectFor: "Medium and large enterprises planning digital transformation.",
    href: "/s4-hana",
    accent: "#3D4FA0",
    image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=600&q=80",
  },
  {
    icon: Cloud,
    title: "SAP Business One on Cloud",
    tagline: "Secure managed cloud hosting",
    desc: "Run SAP Business One SQL or SAP Business One HANA on secure, enterprise-grade cloud infrastructure with high availability, automated backups, disaster recovery, and managed services.",
    perfectFor: "Organizations wanting cloud ERP without infrastructure overhead.",
    href: "/sap-b1-on-cloud",
    accent: "#059669",
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=600&q=80",
  },
  {
    icon: Globe2,
    title: "RISE with SAP",
    tagline: "Business Transformation as a Service",
    desc: "An end-to-end Business Transformation as a Service solution that combines S/4HANA Cloud, infrastructure, business process intelligence, and managed services into a single subscription.",
    perfectFor: "Enterprises ready for complete cloud ERP transformation.",
    href: "/rise-with-sap",
    accent: "#7C3AED",
    image: "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=600&q=80",
  },
  {
    icon: HeadphonesIcon,
    title: "SAP Support Services",
    tagline: "AMC, helpdesk & managed support",
    desc: "Comprehensive Annual Maintenance Contracts (AMC), remote support, dedicated SAP consultants, proactive monitoring, user training, and continuous system optimization.",
    perfectFor: "Organizations seeking reliable, expert SAP managed support.",
    href: "/support-service",
    accent: "#0F766E",
    image: "https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&w=600&q=80",
  },
];

/* ── Extension / Add-on products (no dedicated page yet → /contact) ─── */
const EXTENSIONS = [
  {
    category: "Business Extensions",
    accent: "#E84821",
    bg: "#FFF4F1",
    items: [
      { icon: Layers, title: "SAP Add-ons", desc: "Enhance your ERP with specialized add-ons that extend SAP functionality for compliance, automation, reporting, approvals, finance, and inventory." },
      { icon: Smartphone, title: "SAP Mobility Solutions", desc: "Empower your workforce with secure mobile apps: Sales Order Entry, Inventory Lookup, Customer Info, Approval Management, Field Service, and Executive Dashboards." },
      { icon: GitBranch, title: "SAP Approval Workflow", desc: "Automate document approvals for Purchase Orders, Sales Orders, Payments, Credit Limits, Expenses, and Master Data Changes using configurable workflows." },
      { icon: BarChart3, title: "SAP Dashboards & Business Analytics", desc: "Transform business data into actionable insights: Executive Dashboards, Financial Analytics, Sales Performance, Inventory Insights, Business KPIs, and Interactive Reports." },
    ],
  },
  {
    category: "Compliance & Finance",
    accent: "#D4920C",
    bg: "#FFFBEB",
    items: [
      { icon: Receipt, title: "SAP E-Invoicing Solution", desc: "Automate GST-compliant electronic invoicing with seamless IRP integration, automatic IRN generation, QR code creation, and invoice validation." },
      { icon: FileCheck, title: "SAP GST Compliance", desc: "Simplify GST compliance through automated tax calculation, reconciliation, return preparation, e-Way Bill integration, and statutory reporting." },
      { icon: Scan, title: "SAP Barcode & Printing Solutions", desc: "Improve warehouse accuracy and operational efficiency with barcode scanning, label printing, QR code generation, and mobile warehouse operations." },
      { icon: Plug, title: "SAP Integration Platform", desc: "Integrate SAP with eCommerce platforms, logistics providers, banking systems, CRM apps, marketplaces, payment gateways, and third-party software via secure APIs." },
    ],
  },
  {
    category: "Industry & Operations",
    accent: "#3D4FA0",
    bg: "#F0F3FF",
    items: [
      { icon: ShoppingCart, title: "SAP Retail Solutions", desc: "Manage modern retail with integrated inventory, billing, loyalty programs, promotions, pricing, omnichannel sales, and business analytics." },
      { icon: Warehouse, title: "SAP Warehouse Management", desc: "Optimize warehouse operations with advanced inventory control, barcode scanning, bin management, goods receipt, picking, packing, and cycle counting." },
      { icon: Factory, title: "SAP Production Planning", desc: "Improve manufacturing efficiency with MRP, Bill of Materials, production scheduling, shop floor control, and production costing." },
      { icon: Users, title: "SAP CRM Solutions", desc: "Build stronger customer relationships through lead management, opportunity tracking, sales automation, service management, and customer engagement tools." },
      { icon: Wrench, title: "SAP Service Management", desc: "Manage service contracts, preventive maintenance, field service, warranties, equipment history, and customer support from a centralized platform." },
      { icon: Package, title: "SAP Asset Management", desc: "Track the complete lifecycle of business assets: acquisition, depreciation, maintenance scheduling, compliance, and asset performance." },
    ],
  },
];

const WHY_CHOOSE = [
  "Complete ERP solutions for businesses of all sizes",
  "Cloud, On-Premise & Hybrid deployment options",
  "Industry-specific business solutions",
  "Seamless integration with third-party applications",
  "AI-ready and future-proof architecture",
  "Mobile-enabled business operations",
  "Secure, scalable, and enterprise-grade platforms",
  "Complete implementation, customization, and support",
  "Trusted by organizations across multiple industries",
];

const OUR_EXPERTISE = [
  "End-to-End ERP Consulting",
  "SAP Business One & SAP S/4HANA Specialists",
  "Cloud Migration & Managed Hosting",
  "Enterprise Integrations & APIs",
  "AI-Powered Business Automation",
  "Custom Development & Extensions",
  "Business Intelligence & Analytics",
  "Industry-Specific Solutions",
  "Annual Maintenance & Support Services",
  "Digital Transformation Consulting",
];

/* ── Component ────────────────────────────────────────────────────────── */
export default function ProductsERPPage() {
  const { primaryColor, accentColor } = useSiteConfig();

  return (
    <PublicLayout>
      <SEO
        title="SAP ERP Products — Complete SAP Solutions | CtrlA Tech Solutions"
        description="Explore CtrlA's complete SAP product portfolio: SAP Business One, SAP S/4HANA, RISE with SAP, cloud hosting, add-ons, mobility, GST, e-invoicing, warehouse management, and more."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "SAP ERP Products — CtrlA Tech Solutions",
          description: "Explore CtrlA's complete SAP product portfolio: SAP Business One, SAP S/4HANA, RISE with SAP, cloud hosting, add-ons, mobility, GST, e-invoicing, warehouse management, and more.",
          url: window.location.href,
          publisher: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
        }}
      />

      {/* ── HERO — dark split banner ──────────────────────────────────────── */}
      <section className="relative overflow-hidden" style={{ background: "linear-gradient(135deg, #0d1225 0%, #1A1F36 60%, #2D3561 100%)" }}>
        {/* decorative circles */}
        <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 900 400" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="750" cy="200" r="250" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          <circle cx="750" cy="200" r="380" stroke="white" strokeWidth="0.5" strokeDasharray="4 8" opacity="0.5"/>
          {[[80,60],[180,320],[320,40],[200,180]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-6 L2-2 L6-2 L3 2 L4 6 L0 3 L-4 6 L-3 2 L-6-2 L-2-2Z" fill="white" opacity="0.6"/></g>
          ))}
        </svg>

        <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* left text */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.55 }}>
              <Link href="/products" className="inline-flex items-center gap-1.5 text-white/40 text-xs mb-5 hover:text-white/70 transition-colors">← Products</Link>
              <div className="inline-flex items-center gap-2 mb-4 px-3 py-1 rounded-full bg-[#E84821]/20 border border-[#E84821]/30">
                <Database size={13} className="text-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">SAP ERP Products</span>
              </div>
              <h1 className="text-4xl sm:text-5xl font-black text-white leading-[1.08] mb-5">
                Complete SAP Solutions for<br/>
                <span style={{ color: primaryColor }}>Every Stage of Your Growth</span>
              </h1>
              <p className="text-gray-300 text-base leading-relaxed mb-6 max-w-lg">
                From intelligent ERP platforms to industry-specific extensions, cloud services, mobility solutions, and business automation — a comprehensive portfolio designed to simplify operations, improve productivity, and accelerate digital transformation.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all bg-[#E84821]">
                  Request a Product Demo <ArrowRight size={15}/>
                </Link>
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border border-white/25 text-white hover:bg-white/10 transition-all">
                  Speak to Our SAP Consultants
                </Link>
              </div>
            </motion.div>

            {/* right — why-choose pill grid */}
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.55, delay: 0.1 }}>
              <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-sm">
                <div className="text-xs font-bold uppercase tracking-widest text-[#D4920C] mb-4">Why Choose Our SAP Products?</div>
                <div className="grid grid-cols-1 gap-2">
                  {WHY_CHOOSE.map((w, i) => (
                    <motion.div key={w} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.15 + i * 0.05 }}
                      className="flex items-center gap-2.5 text-sm text-gray-300">
                      <CheckCircle2 size={13} className="text-[#E84821] flex-shrink-0"/>
                      {w}
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
        <div className="h-1 flex"><div className="flex-[3] bg-[#E84821]"/><div className="flex-[2]" style={{ backgroundColor: primaryColor }}/><div className="flex-1 bg-[#3D4FA0]"/></div>
      </section>

      {/* ── CORE ERP PLATFORMS — 3-col bento grid ────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden">
        <svg className="absolute -bottom-8 -left-8 opacity-[0.04] w-72 h-72" viewBox="0 0 200 200" fill="none">
          <circle cx="100" cy="100" r="80" stroke="#3D4FA0" strokeWidth="1.5" strokeDasharray="5 4"/>
          <circle cx="100" cy="100" r="50" stroke="#E84821" strokeWidth="1" strokeDasharray="3 4"/>
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Core ERP Platforms</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Flagship SAP products with dedicated solutions</h2>
            <p className="mt-2 text-gray-500 text-sm max-w-xl mx-auto">Six SAP platforms and services, each with in-depth information and direct links to explore further.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {FEATURED.map((prod, i) => {
              const Icon = prod.icon;
              return (
                <motion.div key={prod.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.07 }}>
                  <Link href={prod.href} className="group block rounded-2xl overflow-hidden border border-gray-100 hover:border-transparent hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 bg-white h-full">
                    {/* image strip */}
                    <div className="relative h-36 overflow-hidden">
                      <img src={prod.image} alt={prod.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy"/>
                      <div className="absolute inset-0" style={{ background: `linear-gradient(to bottom, ${prod.accent}40, #1A1F3680)` }}/>
                      <div className="absolute top-3 left-3 w-9 h-9 rounded-xl flex items-center justify-center bg-white shadow-md">
                        <Icon size={16} style={{ color: prod.accent }}/>
                      </div>
                      <div className="absolute top-3 right-3 text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full bg-white/90" style={{ color: prod.accent }}>
                        View Page →
                      </div>
                    </div>
                    {/* content */}
                    <div className="p-5">
                      <div className="text-[10px] font-bold uppercase tracking-widest mb-1" style={{ color: prod.accent }}>{prod.tagline}</div>
                      <h3 className="font-bold text-gray-900 text-base mb-2 group-hover:text-[#E84821] transition-colors">{prod.title}</h3>
                      <p className="text-gray-500 text-xs leading-relaxed mb-3">{prod.desc}</p>
                      <div className="border-t border-gray-100 pt-3 flex items-center justify-between">
                        <div>
                          <div className="text-[9px] font-bold uppercase tracking-widest text-gray-400 mb-0.5">Perfect For</div>
                          <div className="text-xs text-gray-600 leading-tight">{prod.perfectFor}</div>
                        </div>
                        <div className="flex-shrink-0 w-7 h-7 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform ml-3" style={{ backgroundColor: prod.accent + "18" }}>
                          <ArrowRight size={13} style={{ color: prod.accent }}/>
                        </div>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── EXTENSIONS — category-grouped compact tiles ───────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.035]" viewBox="0 0 900 900" preserveAspectRatio="xMidYMid slice">
          {Array.from({ length: 20 }).map((_, row) => Array.from({ length: 26 }).map((_, col) => (
            <circle key={`${row}-${col}`} cx={col * 35 + 17} cy={row * 35 + 17} r="1.8" fill="#3D4FA0"/>
          )))}
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Our SAP Product Portfolio</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>14 specialised SAP extensions &amp; solutions</h2>
            <p className="mt-2 text-gray-500 text-sm max-w-xl mx-auto">Explore our complete range of SAP products and business solutions designed to address every aspect of enterprise management.</p>
          </div>

          <div className="space-y-10">
            {EXTENSIONS.map((group, gi) => (
              <motion.div key={group.category} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: gi * 0.1 }}>
                {/* category header */}
                <div className="flex items-center gap-3 mb-5">
                  <span className="w-3 h-3 rounded-sm flex-shrink-0" style={{ backgroundColor: group.accent }}/>
                  <h3 className="text-sm font-black uppercase tracking-widest" style={{ color: group.accent }}>{group.category}</h3>
                  <div className="flex-1 h-px bg-gray-200"/>
                </div>

                {/* tiles */}
                <div className={`grid sm:grid-cols-2 ${group.items.length > 4 ? "lg:grid-cols-3" : "lg:grid-cols-4"} gap-4`}>
                  {group.items.map((item, ii) => {
                    const Icon = item.icon;
                    return (
                      <motion.div key={item.title} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: ii * 0.06 }}>
                        <Link href="/contact"
                          className="group flex flex-col h-full bg-white rounded-2xl p-5 border border-gray-100 hover:border-transparent hover:shadow-xl hover:-translate-y-0.5 transition-all duration-300">
                          <div className="flex items-start gap-3 mb-3">
                            <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: group.accent + "15" }}>
                              <Icon size={16} style={{ color: group.accent }}/>
                            </div>
                            <h4 className="font-bold text-gray-900 text-sm leading-tight group-hover:text-[#E84821] transition-colors">{item.title}</h4>
                          </div>
                          <p className="text-gray-500 text-xs leading-relaxed flex-1">{item.desc}</p>
                          <div className="mt-3 flex items-center gap-1 text-[11px] font-semibold" style={{ color: group.accent }}>
                            Enquire <ChevronRight size={11} className="group-hover:translate-x-0.5 transition-transform"/>
                          </div>
                        </Link>
                      </motion.div>
                    );
                  })}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── WHY CTRLA — horizontal feature strip ─────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 900 300" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="180" cy="150" r="120" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          <circle cx="720" cy="150" r="120" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          {[[450,40],[450,260],[100,270],[800,30]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-5 L2-2 L5-2 L3 2 L4 5 L0 3 L-4 5 L-3 2 L-5-2 L-2-2Z" fill="white" opacity="0.5"/></g>
          ))}
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#D4920C]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#D4920C]">Why CtrlA Tech Solutions?</span>
              </div>
              <h2 className="text-3xl font-bold text-white mb-4">Selecting the right SAP solution is only the beginning</h2>
              <p className="text-gray-400 text-sm leading-relaxed mb-6">
                Success depends on choosing a technology partner that understands your business and delivers solutions aligned with your long-term goals. Our team combines deep ERP expertise with modern technologies to help organizations implement, integrate, customize, and support SAP solutions that drive measurable business outcomes.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 transition-all">
                  Schedule a Free Consultation <ArrowRight size={15}/>
                </Link>
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border border-white/25 text-white hover:bg-white/10 transition-all">
                  Request a Personalized Demo
                </Link>
              </div>
            </div>

            {/* expertise grid */}
            <div className="grid grid-cols-2 gap-3">
              {OUR_EXPERTISE.map((e, i) => (
                <motion.div key={e} initial={{ opacity: 0, y: 8 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                  className="flex items-start gap-2 bg-white/8 border border-white/10 rounded-xl p-3 hover:bg-white/12 transition-colors">
                  <CheckCircle2 size={13} className="text-[#D4920C] flex-shrink-0 mt-0.5"/>
                  <span className="text-xs text-gray-300 leading-relaxed">{e}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── FINAL CTA ────────────────────────────────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden border-t border-gray-100">
        <svg className="absolute -top-10 -right-10 opacity-[0.04] w-80 h-80" viewBox="0 0 200 200" fill="none">
          <path d="M100 10 L180 50 L180 130 L100 180 L20 130 L20 50 Z" stroke="#3D4FA0" strokeWidth="2" strokeDasharray="6 4"/>
        </svg>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <div className="inline-flex items-center gap-2 mb-4">
            <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Ready to Find the Right SAP Solution?</span>
            <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold mb-4" style={{ color: accentColor }}>
            Whether it's your first ERP or your next upgrade — we're ready
          </h2>
          <p className="text-gray-500 max-w-2xl mx-auto mb-8 text-sm leading-relaxed">
            Whether you're implementing your first ERP system, upgrading to SAP S/4HANA, extending your existing SAP environment, or moving to the cloud, CtrlA Tech Solutions has the expertise and product portfolio to help you succeed.
          </p>
          {/* quick links to featured pages */}
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {FEATURED.map(f => (
              <Link key={f.href} href={f.href}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold border transition-all hover:-translate-y-0.5"
                style={{ borderColor: f.accent + "40", color: f.accent, backgroundColor: f.accent + "08" }}>
                {f.title} <ChevronRight size={11}/>
              </Link>
            ))}
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl text-sm font-bold text-white shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all bg-[#E84821]">
              Schedule a Free SAP Product Consultation <ArrowRight size={15}/>
            </Link>
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl text-sm font-bold border-2 border-gray-200 text-gray-700 hover:border-[#D4920C] hover:text-[#D4920C] transition-all">
              Request a Personalized Demo
            </Link>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
