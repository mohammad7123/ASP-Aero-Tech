import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  ArrowRight, CheckCircle2, Globe2, ShoppingCart, LayoutDashboard,
  Code2, FileText, Palette, Zap, Shield, Cloud, Search,
  Smartphone, Settings, ChevronRight, Layers,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

const SERVICES = [
  {
    icon: Globe2,
    title: "Corporate Websites",
    color: "#E84821",
    bg: "#FFF4F1",
    desc: "Professional websites designed to strengthen your brand, generate leads, and improve online visibility.",
    features: ["Brand-Aligned Design", "Lead Generation Forms", "SEO-Optimized Pages", "Analytics Integration", "Social Media Integration", "Multi-Language Support"],
  },
  {
    icon: LayoutDashboard,
    title: "Business Portals",
    color: "#3D4FA0",
    bg: "#F0F3FF",
    desc: "Customer, vendor, employee, dealer, and partner portals with secure login and workflow automation.",
    features: ["Secure Role-Based Login", "Workflow Automation", "Document Management", "Notifications & Alerts", "Real-Time Dashboards", "API Integration"],
  },
  {
    icon: ShoppingCart,
    title: "eCommerce Development",
    color: "#D4920C",
    bg: "#FFFBEB",
    desc: "Build powerful online stores with secure payment gateways, inventory synchronization, and marketplace integration.",
    features: ["Payment Gateway Integration", "Inventory Sync", "Marketplace Integration", "Order Management", "Mobile Commerce", "Cart & Checkout Optimization"],
  },
  {
    icon: Code2,
    title: "Custom Web Applications",
    color: "#059669",
    bg: "#ECFDF5",
    desc: "Develop web-based business applications tailored to your unique workflows and operational requirements.",
    features: ["Workflow-Specific Modules", "Data Processing", "Reporting & Analytics", "Third-Party API Connections", "Scalable Architecture", "Multi-User Support"],
  },
  {
    icon: FileText,
    title: "CMS Development",
    color: "#7C3AED",
    bg: "#F5F3FF",
    desc: "Manage your website content easily with WordPress, headless CMS, or custom-built content management systems.",
    features: ["WordPress Development", "Headless CMS", "Custom CMS Build", "Content Workflows", "Media Management", "SEO Tools Built-In"],
  },
  {
    icon: Palette,
    title: "UI/UX Design",
    color: "#0F766E",
    bg: "#F0FDFA",
    desc: "Modern, responsive, and user-friendly interfaces designed to maximize engagement and conversions.",
    features: ["Wireframing & Prototyping", "Responsive Layouts", "Conversion-Focused Design", "Brand Style Guides", "User Research", "A/B Testing Support"],
  },
];

const TECHNOLOGIES = [
  { name: "React.js", cat: "Frontend" },
  { name: "Next.js", cat: "Frontend" },
  { name: "Angular", cat: "Frontend" },
  { name: "Vue.js", cat: "Frontend" },
  { name: "Node.js", cat: "Backend" },
  { name: "ASP.NET Core", cat: "Backend" },
  { name: "PHP / Laravel", cat: "Backend" },
  { name: "Python", cat: "Backend" },
  { name: "PostgreSQL", cat: "Database" },
  { name: "MySQL", cat: "Database" },
  { name: "MongoDB", cat: "Database" },
  { name: "AWS", cat: "Cloud" },
  { name: "Azure", cat: "Cloud" },
];

const WHY = [
  { icon: Smartphone, label: "Responsive & Mobile-Friendly Designs" },
  { icon: Search, label: "SEO-Optimized Development" },
  { icon: Zap, label: "Lightning-Fast Performance" },
  { icon: Shield, label: "Secure & Scalable Architecture" },
  { icon: Settings, label: "API & Third-Party Integrations" },
  { icon: Cloud, label: "Cloud Deployment Ready" },
  { icon: Layers, label: "Ongoing Maintenance & Support" },
];

const CAT_COLORS: Record<string, string> = {
  Frontend: "#3D4FA0",
  Backend: "#E84821",
  Database: "#D4920C",
  Cloud: "#059669",
};

export default function WebDevelopmentPage() {
  const { primaryColor, accentColor } = useSiteConfig();

  return (
    <PublicLayout>
      <SEO
        title="Web Development Services — Modern Websites & Web Applications | CtrlA Tech Solutions"
        description="CtrlA Tech Solutions builds fast, secure, and responsive websites and web applications — from corporate websites and eCommerce to custom portals and CMS platforms."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: "Web Development Services",
          description: "CtrlA Tech Solutions builds fast, secure, and responsive websites and web applications — from corporate websites and eCommerce to custom portals and CMS platforms.",
          provider: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
          areaServed: ["IN", "GB"],
          serviceType: ["Corporate Website Development", "eCommerce Development", "Business Portal Development", "CMS Development", "Custom Web Applications"],
          url: window.location.href,
        }}
      />

      {/* ── HERO ─────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden" style={{ background: "linear-gradient(140deg, #0d1225 0%, #1A1F36 55%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 1200 500" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="950" cy="250" r="320" stroke="#E84821" strokeWidth="0.7" strokeDasharray="10 7"/>
          <circle cx="950" cy="250" r="200" stroke={primaryColor} strokeWidth="0.5" strokeDasharray="5 9"/>
          <path d="M0 350 Q300 300 600 340 Q900 380 1200 330" stroke="white" strokeWidth="0.5" fill="none" strokeDasharray="6 6"/>
          {[[70,60],[180,280],[320,80],[200,180],[480,320],[600,100]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-6 L2-2 L6-2 L3 2 L4 6 L0 3 L-4 6 L-3 2 L-6-2 L-2-2Z" fill="white" opacity="0.5"/></g>
          ))}
        </svg>

        <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <Link href="/services" className="inline-flex items-center gap-1.5 text-white/40 text-xs mb-5 hover:text-white/70 transition-colors">← IT Services</Link>
              <div className="inline-flex items-center gap-2 mb-4 px-3 py-1.5 rounded-full border border-[#E84821]/40 bg-[#E84821]/12">
                <Globe2 size={13} className="text-[#E84821]"/>
                <span className="text-xs font-black uppercase tracking-widest text-[#E84821]">Web Development</span>
              </div>
              <h1 className="text-4xl sm:text-5xl font-black leading-[1.06] text-white mb-3">
                Modern Websites &<br/>
                <span style={{ color: primaryColor }}>Web Applications</span><br/>
                <span className="text-white/80 text-3xl sm:text-4xl font-bold">That Drive Business Growth</span>
              </h1>
              <div className="flex gap-2 my-5">
                <span className="h-1 w-12 rounded-full bg-[#E84821]"/>
                <span className="h-1 w-7 rounded-full" style={{ backgroundColor: primaryColor }}/>
                <span className="h-1 w-4 rounded-full bg-[#3D4FA0]"/>
              </div>
              <p className="text-gray-300 text-sm leading-relaxed mb-3 max-w-lg">
                Your website is more than an online presence — it's your digital storefront, sales engine, and customer engagement platform.
              </p>
              <p className="text-gray-400 text-sm leading-relaxed mb-8 max-w-lg">
                We design and develop <strong className="text-white">fast, secure, responsive, and SEO-friendly</strong> websites and web applications that deliver exceptional user experiences and measurable business results.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 shadow-lg transition-all text-sm">
                  Request a Free Consultation <ArrowRight size={15}/>
                </Link>
                <Link href="/portfolio" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
                  View Our Portfolio <ChevronRight size={14}/>
                </Link>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.12 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10">
                <img src="https://images.unsplash.com/photo-1547658719-da2b51169166?auto=format&fit=crop&w=800&q=80"
                  alt="Modern web development workspace" className="w-full h-64 object-cover"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/70 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse flex-shrink-0"/>
                  <span className="text-white text-xs font-semibold">6 web development services · 13 technologies</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
        <div className="h-1 flex"><div className="flex-[3] bg-[#E84821]"/><div className="flex-[2]" style={{ backgroundColor: primaryColor }}/><div className="flex-1 bg-[#3D4FA0]"/></div>
      </section>

      {/* ── SERVICES GRID ─────────────────────────────────────────────── */}
      <section className="py-16 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 700" preserveAspectRatio="xMidYMid slice">
          {Array.from({length:20}).map((_,r)=>Array.from({length:26}).map((_,c)=>(
            <circle key={`${r}-${c}`} cx={c*35+17} cy={r*35+17} r="1.6" fill="#3D4FA0"/>
          )))}
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Our Web Development Services</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>End-to-end web solutions for every business need</h2>
            <p className="mt-2 text-gray-500 text-sm max-w-xl mx-auto">From corporate websites to complex web applications — scalable, secure, and built for results.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {SERVICES.map((s, i) => {
              const Icon = s.icon;
              return (
                <motion.div key={s.title} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }}
                  className="bg-white rounded-2xl border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 overflow-hidden">
                  <div className="h-1.5 w-full" style={{ backgroundColor: s.color }}/>
                  <div className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-11 h-11 rounded-xl flex items-center justify-center" style={{ backgroundColor: s.bg }}>
                        <Icon size={20} style={{ color: s.color }}/>
                      </div>
                      <h3 className="font-bold text-gray-900 text-sm leading-tight">{s.title}</h3>
                    </div>
                    <p className="text-gray-500 text-xs leading-relaxed mb-4">{s.desc}</p>
                    <div className="grid grid-cols-2 gap-1.5">
                      {s.features.map(f => (
                        <div key={f} className="flex items-center gap-1.5 text-xs text-gray-600">
                          <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: s.color }}/>
                          {f}
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── TECHNOLOGIES + WHY CHOOSE ─────────────────────────────────── */}
      <section className="py-16 bg-white border-t border-gray-100 relative overflow-hidden">
        <svg className="absolute -right-16 inset-y-0 h-full opacity-[0.04]" viewBox="0 0 300 600" fill="none">
          <circle cx="250" cy="300" r="220" stroke="#3D4FA0" strokeWidth="1.5" strokeDasharray="8 6"/>
          <circle cx="250" cy="300" r="140" stroke="#E84821" strokeWidth="1" strokeDasharray="5 8"/>
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-14 items-start">
            {/* technologies */}
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Technologies We Use</span>
              </div>
              <h2 className="text-2xl font-bold mb-5" style={{ color: accentColor }}>Modern, future-ready tech stack</h2>
              <div className="flex flex-wrap gap-2">
                {TECHNOLOGIES.map((t, i) => (
                  <motion.div key={t.name} initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}
                    className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-semibold bg-white hover:shadow-md hover:-translate-y-0.5 transition-all"
                    style={{ borderColor: CAT_COLORS[t.cat] + "40", color: CAT_COLORS[t.cat] }}>
                    <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: CAT_COLORS[t.cat] }}/>
                    {t.name}
                  </motion.div>
                ))}
              </div>
              <div className="flex flex-wrap gap-3 mt-5">
                {Object.entries(CAT_COLORS).map(([cat, col]) => (
                  <div key={cat} className="flex items-center gap-1.5 text-xs text-gray-500">
                    <span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: col }}/>
                    {cat}
                  </div>
                ))}
              </div>
            </motion.div>

            {/* why choose */}
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why Choose CtrlA Tech Solutions?</span>
              </div>
              <h2 className="text-2xl font-bold mb-5" style={{ color: accentColor }}>Built for performance, designed for growth</h2>
              <div className="space-y-3">
                {WHY.map((w, i) => {
                  const Icon = w.icon;
                  return (
                    <motion.div key={w.label} initial={{ opacity: 0, x: 12 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.06 }}
                      className="flex items-center gap-3 p-3 rounded-xl bg-gray-50 border border-gray-100 hover:border-[#E84821]/30 hover:bg-[#E84821]/3 transition-all">
                      <div className="w-9 h-9 rounded-lg flex items-center justify-center bg-[#E84821]/10 flex-shrink-0">
                        <Icon size={15} className="text-[#E84821]"/>
                      </div>
                      <span className="text-sm font-semibold text-gray-700">{w.label}</span>
                      <CheckCircle2 size={13} className="text-[#E84821] ml-auto flex-shrink-0"/>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 900 300" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="820" cy="150" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          {[[80,50],[200,220],[350,60],[500,200]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-5 L2-2 L5-2 L3 2 L4 5 L0 3 L-4 5 L-3 2 L-5-2 L-2-2Z" fill="white" opacity="0.5"/></g>
          ))}
        </svg>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <h2 className="text-3xl font-bold text-white mb-3">Ready to build your next web project?</h2>
          <p className="text-gray-400 text-sm mb-8 max-w-xl mx-auto leading-relaxed">
            Whether you need a corporate website, eCommerce platform, or a complex web application — our team is ready to bring your vision to life.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 transition-all text-sm shadow-xl">
              Request a Free Consultation <ArrowRight size={15}/>
            </Link>
            <Link href="/portfolio" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
              View Our Portfolio <ChevronRight size={14}/>
            </Link>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1 flex">
          <div className="flex-[3] bg-[#E84821]"/>
          <div className="flex-[2]" style={{ backgroundColor: primaryColor }}/>
          <div className="flex-1 bg-[#3D4FA0]"/>
        </div>
      </section>
    </PublicLayout>
  );
}
