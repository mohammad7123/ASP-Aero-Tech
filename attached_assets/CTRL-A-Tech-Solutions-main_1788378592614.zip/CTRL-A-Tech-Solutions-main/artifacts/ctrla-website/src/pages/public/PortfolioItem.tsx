import { motion } from "framer-motion";
import { Link, useRoute } from "wouter";
import { ArrowLeft, ExternalLink, Calendar } from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useGetPublicPortfolioItem } from "@/lib/apiClient";

export default function PortfolioItemPage() {
  const [, params] = useRoute("/portfolio/:slug");
  const slug = params?.slug ?? "";
  const { data: item, isLoading, isError } = useGetPublicPortfolioItem(slug);

  if (isLoading) {
    return (
      <PublicLayout>
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="w-8 h-8 border-2 border-[#E84821] border-t-transparent rounded-full animate-spin" />
        </div>
      </PublicLayout>
    );
  }

  if (isError || !item) {
    return (
      <PublicLayout>
        <SEO title="Case Study Not Found" description="This portfolio item could not be found." noindex={true} />
        <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center gap-4">
          <h1 className="text-2xl font-bold text-[#1C1917]">Case Study Not Found</h1>
          <Link href="/portfolio" className="text-[#E84821] hover:underline flex items-center gap-1">
            <ArrowLeft size={16} /> Back to Portfolio
          </Link>
        </div>
      </PublicLayout>
    );
  }

  const techs = item.technologies ? item.technologies.split(",").map(t => t.trim()).filter(Boolean) : [];
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "CreativeWork",
    name: item.title,
    description: item.description ?? undefined,
    url: typeof window !== "undefined" ? window.location.href : "",
    ...(item.clientName ? { author: { "@type": "Organization", name: item.clientName } } : {}),
  };

  return (
    <PublicLayout>
      <SEO
        title={item.title}
        description={item.description ?? `Case study: ${item.title}`}
        jsonLd={jsonLd}
      />

      <section className="bg-[#1C1917] py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/portfolio" className="inline-flex items-center gap-1 text-[#E84821] text-sm mb-8 hover:underline">
            <ArrowLeft size={14} /> Back to Portfolio
          </Link>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            {item.clientName && <p className="text-[#E84821] text-sm font-semibold uppercase tracking-wider mb-3">{item.clientName}</p>}
            <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">{item.title}</h1>
            {item.description && <p className="text-gray-300 text-lg max-w-2xl">{item.description}</p>}
          </motion.div>
        </div>
      </section>

      {item.featuredImage && (
        <div className="bg-gray-100">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8">
            <img src={item.featuredImage} alt={item.title} className="w-full rounded-2xl shadow-xl" />
          </div>
        </div>
      )}

      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <div
                className="prose prose-lg max-w-none prose-headings:text-[#1C1917] prose-a:text-[#E84821]"
                dangerouslySetInnerHTML={{ __html: item.content }}
              />
            </div>
            <div className="space-y-6">
              <div className="bg-white rounded-2xl border border-gray-100 p-6 space-y-4">
                <h3 className="font-bold text-[#1C1917] text-sm uppercase tracking-wider">Project Details</h3>
                {item.clientName && (
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Client</p>
                    <p className="font-medium text-[#1C1917]">{item.clientName}</p>
                  </div>
                )}
                {item.completedAt && (
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Completed</p>
                    <p className="font-medium text-[#1C1917] flex items-center gap-1">
                      <Calendar size={14} />
                      {new Date(item.completedAt).toLocaleDateString("en-IN", { month: "long", year: "numeric" })}
                    </p>
                  </div>
                )}
                {techs.length > 0 && (
                  <div>
                    <p className="text-xs text-gray-500 mb-2">Technologies</p>
                    <div className="flex flex-wrap gap-1.5">
                      {techs.map(t => (
                        <span key={t} className="px-2 py-0.5 bg-[#E84821]/10 text-[#E84821] text-xs rounded-md font-medium">{t}</span>
                      ))}
                    </div>
                  </div>
                )}
                {item.projectUrl && (
                  <a href={item.projectUrl} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-2 text-sm font-semibold text-[#E84821] hover:underline pt-2">
                    <ExternalLink size={14} /> View Live Project
                  </a>
                )}
              </div>
              <div className="bg-[#1C1917] rounded-2xl p-6 text-center">
                <p className="text-white font-semibold mb-2">Start a similar project?</p>
                <Link href="/contact" className="inline-block bg-[#E84821] text-white px-5 py-2.5 rounded-xl text-sm font-bold hover:bg-[#c73d1a] transition-all">
                  Talk to Us
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
