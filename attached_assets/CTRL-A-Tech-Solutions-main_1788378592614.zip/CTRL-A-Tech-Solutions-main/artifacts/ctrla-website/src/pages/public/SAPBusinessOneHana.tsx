import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  ArrowRight, CheckCircle2, Zap, TrendingUp, Brain, Database,
  BarChart3, Sparkles, Search, X, Monitor, LayoutDashboard,
  Award, HeadphonesIcon, TrendingDown, Clock,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import PageHero from "@/components/public/PageHero";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

/* ── Data ─────────────────────────────────────────────────────────────── */

const STATS = [
  { label: "Faster Analytics", value: "100×" },
  { label: "Data Compression Ratio", value: "10:1" },
  { label: "Real-Time Report Types", value: "1,500+" },
  { label: "Avg. ROI Timeline", value: "12 mo." },
];

const VALUE_PILLARS = [
  {
    icon: BarChart3,
    title: "Real-Time Analytics",
    desc: "Generate reports instantly without waiting for lengthy database processing.",
    accent: "#E84821",
    bg: "#FFF4F1",
  },
  {
    icon: Zap,
    title: "In-Memory Computing",
    desc: "Experience lightning-fast performance by processing data directly in memory instead of traditional disk-based databases.",
    accent: "#3D4FA0",
    bg: "#F0F3FF",
  },
  {
    icon: Brain,
    title: "Smart Business Decisions",
    desc: "Access live dashboards and KPIs that help management make informed decisions in real time.",
    accent: "#D4920C",
    bg: "#FFFBEB",
  },
  {
    icon: TrendingUp,
    title: "Scalable ERP Platform",
    desc: "Built to support growing businesses with increasing transaction volumes and complex business processes.",
    accent: "#059669",
    bg: "#F0FDF6",
  },
];

const CAPABILITIES = [
  {
    icon: BarChart3,
    title: "Real-Time Reporting",
    desc: "Generate financial, operational, inventory, and sales reports instantly without impacting system performance.",
    accent: "#E84821",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=700&q=80",
    features: ["Live Financial Reports", "Real-Time Inventory Reports", "Sales Performance Analysis", "Profitability Reports", "Customer Analytics", "Purchase Analysis", "Interactive Dashboards"],
  },
  {
    icon: TrendingUp,
    title: "Advanced Business Analytics",
    desc: "Turn business data into actionable insights with powerful analytics and KPI monitoring.",
    accent: "#3D4FA0",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=700&q=80",
    features: ["Executive Dashboards", "Interactive KPIs", "Performance Monitoring", "Business Trends", "Profit & Loss Analysis", "Revenue Analysis", "Department-wise Analytics"],
  },
  {
    icon: Zap,
    title: "Lightning Fast Performance",
    desc: "Process millions of records within seconds using SAP HANA's in-memory database architecture.",
    accent: "#D4920C",
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=700&q=80",
    features: ["Faster Document Processing", "Instant Search Results", "High-Speed Transactions", "Reduced Report Execution Time", "Improved User Experience", "Better System Performance"],
  },
  {
    icon: LayoutDashboard,
    title: "Intelligent Dashboards",
    desc: "Monitor your business with customizable dashboards that provide a complete overview of business performance.",
    accent: "#7C3AED",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=700&q=80",
    features: ["Sales Dashboard", "Finance Dashboard", "Inventory Dashboard", "Purchasing Dashboard", "Production Dashboard", "Cash Flow Dashboard", "Executive Summary Dashboard"],
  },
  {
    icon: Search,
    title: "Enterprise Search",
    desc: "Find customers, items, invoices, purchase orders, or business documents instantly using intelligent enterprise search.",
    accent: "#0F766E",
    image: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?auto=format&fit=crop&w=700&q=80",
    features: ["Global Search", "Document Search", "Customer Search", "Item Search", "Transaction Search", "Advanced Filtering"],
  },
  {
    icon: Brain,
    title: "Predictive Analytics",
    desc: "Make proactive business decisions with predictive insights generated from historical and real-time business data.",
    accent: "#E84821",
    image: "https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&w=700&q=80",
    features: ["Sales Forecasting", "Demand Planning", "Inventory Forecasting", "Trend Analysis", "Business Performance Indicators", "Decision Support"],
  },
];

const COMPARISON = [
  { metric: "Query Speed", b1: "Seconds to minutes", hana: "Milliseconds", icon: Clock },
  { metric: "Analytics Type", b1: "Historical (batch)", hana: "Real-time + predictive", icon: BarChart3 },
  { metric: "Report Building", b1: "IT-dependent", hana: "Self-service live", icon: Monitor },
  { metric: "Data Volume", b1: "Moderate", hana: "Massive scale", icon: Database },
  { metric: "Embedded AI", b1: "Limited", hana: "Native ML & forecasting", icon: Brain },
];

const KEY_BENEFITS = [
  "Real-Time Business Intelligence",
  "High-Speed Reporting & Analytics",
  "Instant Dashboard Refresh",
  "Faster Month-End Closing",
  "Improved Business Visibility",
  "Better Decision Making",
  "Simplified IT Infrastructure",
  "Reduced Database Processing Time",
  "Enhanced User Productivity",
  "Future-Ready ERP Platform",
];

const EXPERTISE = [
  "SAP Business One HANA Implementation",
  "Database Migration to SAP HANA",
  "ERP Performance Optimization",
  "Dashboard & KPI Development",
  "Crystal Reports & HANA Analytics",
  "Custom Report Development",
  "Enterprise Integrations",
  "Cloud Deployment & Hosting",
  "User Training & Knowledge Transfer",
  "Annual Maintenance & Support",
];

const METHODOLOGY = [
  { step: "01", label: "Business Process Assessment" },
  { step: "02", label: "HANA Readiness Analysis" },
  { step: "03", label: "System Design & Planning" },
  { step: "04", label: "SAP B1 HANA Implementation" },
  { step: "05", label: "Data Migration & Validation" },
  { step: "06", label: "Dashboard & Report Configuration" },
  { step: "07", label: "User Acceptance Testing (UAT)" },
  { step: "08", label: "User Training" },
  { step: "09", label: "Go-Live Support" },
  { step: "10", label: "Continuous Optimization & AMC" },
];

const REPORTING_BULLETS = [
  "Monitor sales performance in real time",
  "Track inventory movement instantly",
  "Analyze profitability by customer, product, or region",
  "View financial KPIs with live dashboards",
  "Generate reports within seconds instead of minutes",
  "Drill down from summary reports to transaction-level details",
  "Make faster, data-driven business decisions",
];

/* ── Component ────────────────────────────────────────────────────────── */

export default function SAPBusinessOneHanaPage() {
  const { primaryColor, accentColor } = useSiteConfig();

  return (
    <PublicLayout>
      <SEO
        title="SAP Business One HANA — In-Memory ERP at Lightning Speed"
        description="Accelerate your business with SAP Business One HANA. Real-time reporting, instant analytics, faster transactions, and intelligent decision-making from a single integrated ERP platform."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "SoftwareApplication",
          name: "SAP Business One HANA",
          applicationCategory: "BusinessApplication",
          description: "Accelerate your business with SAP Business One HANA. Real-time reporting, instant analytics, faster transactions, and intelligent decision-making from a single integrated ERP platform.",
          operatingSystem: "SAP HANA, Cloud",
          offers: {
            "@type": "Offer",
            seller: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
          },
          url: window.location.href,
        }}
      />

      {/* ── HERO ─────────────────────────────────────────────────────────── */}
      <PageHero
        eyebrow="ERP Solutions"
        title={<><span style={{ color: "#E84821" }}>SAP Business One HANA</span> — In-Memory ERP at Lightning Speed</>}
        subtitle="Accelerate your business with SAP Business One HANA—the next generation ERP platform powered by SAP HANA's in-memory computing technology. Experience real-time reporting, instant analytics, faster transaction processing, and intelligent decision-making."
        heroImage="https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=1200&q=80"
        heroImageAlt="SAP HANA in-memory database server infrastructure"
        cta={
          <div className="flex flex-wrap gap-3 mt-6">
            <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5 bg-[#E84821]">
              Request a Demo <ArrowRight size={16} />
            </Link>
            <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border-2 border-white/40 text-white hover:bg-white/15 transition-all">
              Talk to an ERP Expert
            </Link>
          </div>
        }
      />

      {/* ── STATS BAR ────────────────────────────────────────────────────── */}
      <section className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <p className="text-center text-xs font-bold uppercase tracking-widest text-gray-400 mb-6">Transform Data into Real-Time Business Intelligence</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {STATS.map(s => (
              <div key={s.label}>
                <div className="text-3xl sm:text-4xl font-black" style={{ color: "#E84821" }}>{s.value}</div>
                <div className="text-xs text-gray-500 mt-1.5 font-medium leading-tight">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="h-1 flex"><div className="flex-[3] bg-[#E84821]" /><div className="flex-[2]" style={{ backgroundColor: primaryColor }} /><div className="flex-1 bg-[#3D4FA0]" /></div>
      </section>

      {/* ── VALUE PILLARS ─────────────────────────────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden">
        {/* Circuit doodle */}
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 300" fill="none" preserveAspectRatio="xMidYMid slice">
          <path d="M0 150h200l40-50h120l40 50h200l30-30h120l30 30h120" stroke="#3D4FA0" strokeWidth="2"/>
          <circle cx="200" cy="150" r="7" fill="#3D4FA0"/><circle cx="560" cy="150" r="7" fill="#3D4FA0"/>
          <rect x="820" y="90" width="14" height="14" stroke="#E84821" strokeWidth="1.5"/>
          <path d="M750 0v80l40 30" stroke="#D4920C" strokeWidth="1.5"/>
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why SAP Business One HANA?</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>The intelligence your business deserves</h2>
            <p className="mt-2 text-gray-500 max-w-2xl mx-auto text-sm">Unlike traditional ERP databases, SAP HANA processes massive amounts of business data in memory, delivering real-time insights across every department.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {VALUE_PILLARS.map((p, i) => {
              const Icon = p.icon;
              return (
                <motion.div key={p.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }}
                  className="group rounded-2xl p-6 border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 relative overflow-hidden"
                  style={{ backgroundColor: p.bg }}>
                  {/* corner doodle */}
                  <svg className="absolute -bottom-3 -right-3 w-16 h-16 opacity-20" viewBox="0 0 60 60" fill="none">
                    <circle cx="30" cy="30" r="28" stroke={p.accent} strokeWidth="1.5" strokeDasharray="5 4"/>
                    <circle cx="30" cy="30" r="16" stroke={p.accent} strokeWidth="1"/>
                  </svg>
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 bg-white shadow-sm">
                    <Icon size={22} style={{ color: p.accent }}/>
                  </div>
                  <h3 className="font-bold text-gray-900 mb-2">{p.title}</h3>
                  <p className="text-sm text-gray-600 leading-relaxed">{p.desc}</p>
                </motion.div>
              );
            })}
          </div>

          {/* Why narrative */}
          <div className="mt-10 bg-gradient-to-r from-[#1A1F36] to-[#2D3561] rounded-2xl p-8 grid lg:grid-cols-2 gap-8 items-center relative overflow-hidden">
            <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 700 200" fill="none" preserveAspectRatio="xMidYMid slice">
              <circle cx="350" cy="100" r="80" stroke="white" strokeWidth="0.5" strokeDasharray="5 5"/>
              {[[50,30],[120,150],[580,40],[640,160],[300,50],[420,160]].map(([cx,cy],i) => (
                <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-5 L2-2 L5-2 L3 2 L4 5 L0 3 L-4 5 L-3 2 L-5-2 L-2-2Z" fill="white" opacity="0.6"/></g>
              ))}
            </svg>
            <div className="relative">
              <h3 className="text-xl font-bold text-white mb-3">Stay ahead in today's competitive marketplace</h3>
              <p className="text-gray-300 text-sm leading-relaxed">With SAP Business One HANA, your business gains the <strong className="text-white">speed, intelligence, and flexibility</strong> needed to analyse large volumes of data within seconds while improving operational efficiency across every department.</p>
            </div>
            <div className="relative grid grid-cols-2 gap-3">
              {[
                { label: "Query Time", before: "Minutes", after: "Milliseconds", color: "#E84821" },
                { label: "Reports", before: "Batch/overnight", after: "Instant live", color: "#D4920C" },
                { label: "Analytics", before: "Historical", after: "Predictive", color: "#3D4FA0" },
                { label: "AI/ML", before: "Separate tool", after: "Native built-in", color: "#059669" },
              ].map(item => (
                <div key={item.label} className="bg-white/10 border border-white/15 rounded-xl p-3">
                  <div className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: item.color }}>{item.label}</div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-400 line-through">{item.before}</span>
                    <ArrowRight size={10} className="text-gray-500 flex-shrink-0"/>
                    <span className="text-xs font-bold text-white">{item.after}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── CAPABILITIES ─────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.04]" viewBox="0 0 900 800" preserveAspectRatio="xMidYMid slice">
          {Array.from({ length: 22 }).map((_, row) => Array.from({ length: 30 }).map((_, col) => (
            <circle key={`${row}-${col}`} cx={col * 30 + 15} cy={row * 30 + 15} r="1.8" fill="#3D4FA0"/>
          )))}
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Powerful Business Capabilities</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Six pillars of HANA-powered intelligence</h2>
            <p className="mt-2 text-gray-500 max-w-xl mx-auto text-sm">Every capability designed to turn raw data into real-time decisions.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {CAPABILITIES.map((cap, i) => {
              const Icon = cap.icon;
              return (
                <motion.div key={cap.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.07 }}
                  className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 overflow-hidden flex flex-col">
                  {/* image */}
                  <div className="relative h-40 overflow-hidden flex-shrink-0">
                    <img src={cap.image} alt={cap.title} className="w-full h-full object-cover" loading="lazy"/>
                    <div className="absolute inset-0" style={{ background: `linear-gradient(to bottom, ${cap.accent}40, #1A1F3680)` }}/>
                    <div className="absolute top-3 left-3 w-9 h-9 rounded-xl flex items-center justify-center bg-white shadow-md">
                      <Icon size={17} style={{ color: cap.accent }}/>
                    </div>
                    <div className="absolute top-0 left-0 right-0 h-1" style={{ backgroundColor: cap.accent }}/>
                    {/* wavy doodle at bottom of image */}
                    <svg className="absolute bottom-0 left-0 right-0" viewBox="0 0 400 24" fill="white" preserveAspectRatio="none">
                      <path d="M0 24 Q100 8 200 16 Q300 24 400 8 L400 24 Z"/>
                    </svg>
                  </div>
                  {/* content */}
                  <div className="p-5 flex flex-col flex-1">
                    <h3 className="font-bold text-gray-900 mb-1.5">{cap.title}</h3>
                    <p className="text-xs text-gray-500 leading-relaxed mb-4">{cap.desc}</p>
                    <div className="mt-auto">
                      <div className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2">Key Features</div>
                      <div className="grid grid-cols-2 gap-x-3 gap-y-1.5">
                        {cap.features.map(f => (
                          <div key={f} className="flex items-center gap-1.5 text-[11px] text-gray-700">
                            <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: cap.accent }}/>
                            {f}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── COMPARISON TABLE ─────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 900 500" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="450" cy="250" r="220" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          <circle cx="450" cy="250" r="340" stroke="white" strokeWidth="0.5" strokeDasharray="4 8" opacity="0.5"/>
          {[[80,60],[200,380],[700,60],[820,380],[350,50],[600,440]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-6 L2-2 L6-2 L3 2 L4 6 L0 3 L-4 6 L-3 2 L-6-2 L-2-2Z" fill="white" opacity="0.5"/></g>
          ))}
        </svg>
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#D4920C]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#D4920C]">Performance Comparison</span>
              <span className="w-6 h-0.5 rounded bg-[#D4920C]"/>
            </div>
            <h2 className="text-3xl font-bold text-white">SAP B1 Standard vs HANA</h2>
            <p className="mt-2 text-gray-400 text-sm">See exactly what HANA's in-memory engine unlocks for your business.</p>
          </div>

          <div className="rounded-2xl overflow-hidden border border-white/15 shadow-2xl">
            {/* Header */}
            <div className="grid grid-cols-3 bg-white/10 backdrop-blur border-b border-white/15">
              <div className="p-5 text-xs font-bold uppercase tracking-widest text-gray-400">Metric</div>
              <div className="p-5 border-l border-white/10">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-gray-500/30 flex items-center justify-center">
                    <X size={13} className="text-gray-400"/>
                  </div>
                  <span className="text-sm font-bold text-gray-300">SAP B1 Standard</span>
                </div>
              </div>
              <div className="p-5 border-l border-white/10" style={{ background: "rgba(232,72,33,0.12)" }}>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg flex items-center justify-center bg-[#E84821]">
                    <Zap size={13} className="text-white"/>
                  </div>
                  <span className="text-sm font-bold text-white">SAP B1 HANA</span>
                </div>
              </div>
            </div>
            {/* Rows */}
            {COMPARISON.map((row, i) => {
              const Icon = row.icon;
              return (
                <motion.div key={row.metric} initial={{ opacity: 0, x: -10 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.06 }}
                  className={`grid grid-cols-3 border-b border-white/10 last:border-0 ${i % 2 === 0 ? "bg-white/5" : "bg-transparent"}`}>
                  <div className="p-5 flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: "rgba(255,255,255,0.1)" }}>
                      <Icon size={15} className="text-gray-300"/>
                    </div>
                    <span className="text-sm font-semibold text-white">{row.metric}</span>
                  </div>
                  <div className="p-5 border-l border-white/10 flex items-center">
                    <span className="text-sm text-gray-400">{row.b1}</span>
                  </div>
                  <div className="p-5 border-l border-white/10 flex items-center gap-2" style={{ background: "rgba(232,72,33,0.07)" }}>
                    <CheckCircle2 size={15} className="flex-shrink-0 text-[#E84821]"/>
                    <span className="text-sm font-bold text-white">{row.hana}</span>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* shape callouts */}
          <div className="mt-8 grid sm:grid-cols-3 gap-4">
            {[
              { icon: Zap, label: "Instant results", sub: "No waiting for batch jobs", color: "#E84821" },
              { icon: Brain, label: "Built-in AI/ML", sub: "Native predictive engine", color: "#D4920C" },
              { icon: TrendingDown, label: "Lower TCO", sub: "Simplified IT infrastructure", color: "#059669" },
            ].map(item => {
              const Icon = item.icon;
              return (
                <div key={item.label} className="bg-white/10 border border-white/15 rounded-2xl p-5 flex items-start gap-4 hover:bg-white/15 transition-colors">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: item.color + "30" }}>
                    <Icon size={18} style={{ color: item.color }}/>
                  </div>
                  <div>
                    <div className="text-white font-bold text-sm">{item.label}</div>
                    <div className="text-gray-400 text-xs mt-0.5">{item.sub}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── KEY BENEFITS ─────────────────────────────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden">
        <svg className="absolute -top-8 -right-8 opacity-[0.05] w-72 h-72" viewBox="0 0 200 200" fill="none">
          <path d="M40 40 L80 20 L160 60 L180 140 L120 180 L40 160 L20 80 Z" stroke="#3D4FA0" strokeWidth="2.5" strokeDasharray="6 4"/>
          <circle cx="100" cy="100" r="30" stroke="#E84821" strokeWidth="1.5" strokeDasharray="4 3"/>
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Key Benefits</span>
              </div>
              <h2 className="text-3xl font-bold mb-3" style={{ color: accentColor }}>What your business gains with HANA</h2>
              <p className="text-gray-500 text-sm leading-relaxed mb-6">Ten transformative outcomes that HANA brings to every growing enterprise.</p>
              <div className="grid grid-cols-2 gap-3">
                {KEY_BENEFITS.map((b, i) => (
                  <motion.div key={b} initial={{ opacity: 0, y: 8 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}
                    className="flex items-start gap-2.5 bg-gray-50 rounded-xl p-3 border border-gray-100 hover:border-[#E84821]/30 hover:bg-[#FFF4F1] transition-colors">
                    <CheckCircle2 size={14} className="flex-shrink-0 mt-0.5 text-[#E84821]"/>
                    <span className="text-xs text-gray-700 leading-relaxed">{b}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[4/3]">
                <img src="https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&w=900&q=80" alt="Real-time data analytics dashboard" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/60 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4 grid grid-cols-2 gap-2">
                  {[
                    { v: "100×", l: "Faster queries" },
                    { v: "<1s", l: "Report generation" },
                    { v: "Live", l: "Dashboard refresh" },
                    { v: "Zero", l: "Batch jobs needed" },
                  ].map(item => (
                    <div key={item.l} className="bg-white/90 rounded-lg p-2.5 text-center">
                      <div className="text-base font-black" style={{ color: "#E84821" }}>{item.v}</div>
                      <div className="text-[10px] text-gray-600">{item.l}</div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── REPORTING EXCELLENCE ──────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 100%)" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[4/3]">
                <img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=900&q=80" alt="Business analytics and live reporting" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-tr from-[#1A1F36]/50 to-transparent"/>
                {/* animated ticker doodle */}
                <div className="absolute top-4 left-4 right-4 bg-white/90 rounded-xl p-3 flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-[#059669] animate-pulse"/>
                  <span className="text-xs font-bold text-gray-800">Live analytics active</span>
                  <span className="ml-auto text-[10px] text-gray-400 font-mono">0ms latency</span>
                </div>
                <div className="absolute bottom-4 left-4 bg-white/90 rounded-xl px-4 py-2.5">
                  <div className="text-[10px] font-bold uppercase tracking-widest text-gray-500">Reporting Engine</div>
                  <div className="text-sm font-bold text-gray-900 mt-0.5">Crystal Reports + HANA Analytics</div>
                </div>
              </div>
            </motion.div>
            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Reporting & Analytics Excellence</span>
              </div>
              <h2 className="text-3xl font-bold mb-3" style={{ color: accentColor }}>Live operational data — not yesterday's numbers</h2>
              <p className="text-gray-600 text-sm leading-relaxed mb-6">
                One of the biggest advantages of SAP Business One HANA is its powerful reporting engine. Instead of relying on static reports, decision-makers gain access to live operational data through interactive dashboards and real-time analytics.
              </p>
              <div className="space-y-2.5">
                {REPORTING_BULLETS.map((b, i) => (
                  <motion.div key={b} initial={{ opacity: 0, x: 10 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                    className="flex items-start gap-3 bg-white rounded-xl p-3.5 border border-gray-100 shadow-sm">
                    <CheckCircle2 size={15} className="flex-shrink-0 mt-0.5 text-[#3D4FA0]"/>
                    <span className="text-sm text-gray-700">{b}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── WHY CTRLA ────────────────────────────────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why CtrlA Tech Solutions?</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Unlock the full potential of SAP Business One HANA</h2>
            <p className="mt-2 text-gray-500 max-w-2xl mx-auto text-sm">Strategic consulting, seamless implementation, system optimization, and ongoing support — all under one roof.</p>
          </div>

          <div className="grid lg:grid-cols-12 gap-10 items-start">
            <div className="lg:col-span-5">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[3/4]">
                <img src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&w=800&q=80" alt="CtrlA tech consultants implementing SAP HANA" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/60 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4 bg-white/95 rounded-xl p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-[#E84821] flex-shrink-0">
                      <Award size={18} className="text-white"/>
                    </div>
                    <div>
                      <div className="text-xs font-bold text-gray-900">Certified SAP Professionals</div>
                      <div className="text-[10px] text-gray-500 mt-0.5">SAP Implementation Consultants • India & UK</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="lg:col-span-7">
              <div className="grid sm:grid-cols-2 gap-3">
                {EXPERTISE.map((e, i) => (
                  <motion.div key={e} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}
                    className="flex items-start gap-2.5 bg-gray-50 rounded-xl p-3.5 border border-gray-100 hover:border-[#E84821]/30 hover:bg-[#FFF4F1] transition-colors">
                    <CheckCircle2 size={14} className="flex-shrink-0 mt-0.5 text-[#E84821]"/>
                    <span className="text-xs text-gray-700 leading-relaxed">{e}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── METHODOLOGY ──────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 100%)" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Our Implementation Approach</span>
              </div>
              <h2 className="text-3xl font-bold mb-3" style={{ color: accentColor }}>A proven path to HANA success</h2>
              <p className="text-gray-500 text-sm leading-relaxed mb-7">Our structured 10-step methodology ensures a smooth, successful deployment with maximum ROI from day one.</p>
              <div className="grid grid-cols-2 gap-3">
                {METHODOLOGY.map((m, i) => (
                  <motion.div key={m.step} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                    className="flex items-center gap-3 bg-white rounded-xl p-3 border border-gray-100 shadow-sm hover:border-[#3D4FA0]/30 transition-colors">
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-black flex-shrink-0" style={{ background: "linear-gradient(135deg, #3D4FA0, #E84821)" }}>
                      {m.step}
                    </div>
                    <span className="text-xs font-semibold text-gray-700 leading-snug">{m.label}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[4/3]">
                <img src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=900&q=80" alt="ERP implementation project planning board" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/50 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4 grid grid-cols-3 gap-2">
                  {[
                    { icon: Award, label: "Certified", sub: "Team" },
                    { icon: Sparkles, label: "Agile", sub: "Delivery" },
                    { icon: HeadphonesIcon, label: "24×7", sub: "Support" },
                  ].map(item => {
                    const Icon = item.icon;
                    return (
                      <div key={item.label} className="bg-white/90 rounded-lg p-2.5 text-center">
                        <Icon size={14} className="mx-auto mb-1 text-[#E84821]"/>
                        <div className="text-xs font-bold text-gray-900">{item.label}</div>
                        <div className="text-[9px] text-gray-500">{item.sub}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────────── */}
      <section className="py-16 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 900 300" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="450" cy="150" r="120" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          <circle cx="450" cy="150" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="4 8" opacity="0.6"/>
          {[[100,40],[200,220],[700,50],[800,230],[300,120],[600,170]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-5 L2-2 L5-2 L3 2 L4 5 L0 3 L-4 5 L-3 2 L-5-2 L-2-2Z" fill="white" opacity="0.5"/></g>
          ))}
        </svg>
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Zap size={36} className="mx-auto mb-4 text-[#E84821]"/>
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Ready to Experience Real-Time ERP?</h2>
          <p className="text-gray-300 max-w-2xl mx-auto mb-8 leading-relaxed">
            Empower your business with SAP Business One HANA and transform the way you analyze data, monitor performance, and make strategic decisions. Let CtrlA Tech Solutions build a <strong className="text-white">high-performance ERP environment</strong> that delivers speed, intelligence, and measurable business outcomes.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl text-sm font-bold text-white shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all bg-[#E84821]">
              Request a Demo <ArrowRight size={16} />
            </Link>
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl text-sm font-bold border border-white/30 text-white hover:bg-white/10 transition-all">
              Speak with Our SAP HANA Experts
            </Link>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
