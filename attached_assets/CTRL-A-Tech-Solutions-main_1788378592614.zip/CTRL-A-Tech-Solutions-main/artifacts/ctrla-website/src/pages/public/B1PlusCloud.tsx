import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  ArrowRight, Server, CheckCircle2, Shield, Zap, RefreshCw,
  Settings, BarChart3, HardDrive, Cloud, Lock, Wifi,
  Database, Globe2, ChevronRight, ArrowUpRight, Package,
  Building2, ShoppingCart, Cpu,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

const INFRA_FEATURES = [
  "Tier III & Tier IV Certified Data Centers",
  "N+1 Redundant Power Infrastructure",
  "Dual Power Feeds & UPS Systems",
  "Diesel Generator Backup",
  "Multiple ISP Connectivity",
  "Redundant Network Architecture",
  "Enterprise SSD Storage",
  "High-Speed Fibre Network",
  "24×7 Network Operations Center (NOC)",
  "Continuous Infrastructure Monitoring",
];

const SECURITY_FEATURES = [
  "Multi-Layer Firewall Protection",
  "Enterprise DDoS Protection",
  "End-to-End Data Encryption",
  "Multi-Factor Authentication (MFA)",
  "Secure VPN Connectivity",
  "Role-Based Access Control",
  "Intrusion Detection & Prevention",
  "Continuous Security Monitoring",
  "Regular Security Updates & Patch Management",
];

const HA_FEATURES = [
  "High Availability Infrastructure",
  "Automatic Failover",
  "Daily Automated Backups",
  "Disaster Recovery Options",
  "Geo-Redundant Storage",
  "Business Continuity Planning",
  "Proactive Health Monitoring",
  "Rapid Recovery Services",
];

const MANAGED_FEATURES = [
  "Server Administration",
  "Infrastructure Monitoring",
  "Performance Optimization",
  "OS & Security Updates",
  "Backup Management",
  "Capacity Planning",
  "Database Administration",
  "Technical Support",
  "Cloud Migration Assistance",
];

const WORKLOADS = [
  { icon: Database, label: "ERP Applications" },
  { icon: Building2, label: "Business Management Software" },
  { icon: Globe2, label: "CRM Platforms" },
  { icon: Package, label: "Warehouse Management (WMS)" },
  { icon: ShoppingCart, label: "Order Management (OMS)" },
  { icon: Globe2, label: "eCommerce Applications" },
  { icon: Globe2, label: "Corporate Websites" },
  { icon: Cpu, label: "Mobile App Backends" },
  { icon: Wifi, label: "APIs & Integration Platforms" },
  { icon: Database, label: "SQL & NoSQL Databases" },
  { icon: BarChart3, label: "Business Intelligence" },
  { icon: Settings, label: "Custom Enterprise Applications" },
];

const SCALE_FEATURES = [
  "Instantly Scale CPU & Memory",
  "Expand Storage on Demand",
  "Multi-Server Architecture",
  "Private & Dedicated Cloud Options",
  "Hybrid Cloud Deployments",
  "Load Balancing",
  "High-Speed Resource Provisioning",
];

const WHY_CHOOSE = [
  "Enterprise-Grade Infrastructure without Capital Investment",
  "Hosted on World-Class Tier III & Tier IV Data Centers",
  "99.9%+ Infrastructure Availability",
  "Enterprise Security & Compliance",
  "High-Speed Performance",
  "Fully Managed Cloud Services",
  "Flexible Monthly Pricing",
  "Rapid Deployment",
  "Scalable Cloud Architecture",
  "Expert Technical Support",
];

const PILLARS = [
  {
    icon: Server,
    title: "World-Class Data Centers",
    color: "#3D4FA0",
    bg: "#F0F3FF",
    desc: "Tier III & Tier IV certified data centers engineered for maximum availability and performance.",
    features: INFRA_FEATURES,
  },
  {
    icon: Shield,
    title: "Enterprise Security",
    color: "#DC2626",
    bg: "#FFF1F1",
    desc: "Security embedded into every layer to protect your applications and business data.",
    features: SECURITY_FEATURES,
  },
  {
    icon: RefreshCw,
    title: "High Availability",
    color: "#059669",
    bg: "#ECFDF5",
    desc: "Designed to keep your business running around the clock with minimal downtime.",
    features: HA_FEATURES,
  },
  {
    icon: Settings,
    title: "Fully Managed Services",
    color: "#D4920C",
    bg: "#FFFBEB",
    desc: "Focus on your business while our cloud experts manage the entire infrastructure.",
    features: MANAGED_FEATURES,
  },
];

export default function B1PlusCloudPage() {
  const { primaryColor, accentColor } = useSiteConfig();

  return (
    <PublicLayout>
      <SEO
        title="B1Plus Cloud — Enterprise Cloud Platform for SAP & Business Applications | CtrlA Tech Solutions"
        description="B1Plus Cloud is CtrlA's fully managed enterprise cloud platform on Tier III/IV data centers — built for SAP Business One, ERP, WMS, eCommerce, and all business-critical applications."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "SoftwareApplication",
          name: "B1Plus Cloud",
          applicationCategory: "BusinessApplication",
          description: "B1Plus Cloud is CtrlA's fully managed enterprise cloud platform on Tier III/IV data centers — built for SAP Business One, ERP, WMS, eCommerce, and all business-critical applications.",
          operatingSystem: "Cloud",
          offers: {
            "@type": "Offer",
            seller: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
          },
          url: window.location.href,
        }}
      />

      {/* ── HERO ─────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden" style={{ background: "linear-gradient(140deg, #0d1225 0%, #1A1F36 55%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 1200 520" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="970" cy="260" r="340" stroke="#D4920C" strokeWidth="0.8" strokeDasharray="12 8"/>
          <circle cx="970" cy="260" r="210" stroke={primaryColor} strokeWidth="0.5" strokeDasharray="6 10"/>
          <rect x="810" y="60" width="160" height="160" rx="22" stroke="#3D4FA0" strokeWidth="0.6" strokeDasharray="8 6"/>
          <path d="M0 380 Q300 330 600 360 Q900 390 1200 350" stroke="white" strokeWidth="0.5" fill="none" strokeDasharray="7 7"/>
          {[[60,55],[190,290],[320,85],[220,195],[510,330],[640,110],[770,265]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-7 L2-2.5 L7-2.5 L3.5 2 L5 7 L0 4 L-5 7 L-3.5 2 L-7-2.5 L-2-2.5Z" fill="white" opacity="0.45"/>
            </g>
          ))}
        </svg>

        <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-22">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <div className="flex items-center gap-3 mb-2">
                <Link href="/products/cloud-platforms" className="inline-flex items-center gap-1.5 text-white/40 text-xs hover:text-white/70 transition-colors">← Cloud Platforms</Link>
                <span className="text-white/20 text-xs">·</span>
                <Link href="/services/cloud-solutions" className="inline-flex items-center gap-1.5 text-white/40 text-xs hover:text-white/70 transition-colors">Cloud Solutions</Link>
              </div>
              <div className="inline-flex items-center gap-2 mb-4 mt-3 px-3 py-1.5 rounded-full border border-[#D4920C]/40 bg-[#D4920C]/12">
                <Server size={13} className="text-[#D4920C]"/>
                <span className="text-xs font-black uppercase tracking-widest text-[#D4920C]">B1Plus Cloud</span>
              </div>
              <h1 className="text-4xl sm:text-5xl font-black leading-[1.06] text-white mb-3">
                Enterprise Cloud Platform<br/>
                <span style={{ color: primaryColor }}>Built for Performance,</span><br/>
                <span className="text-white/80 text-3xl sm:text-4xl font-bold">Security & Business Continuity</span>
              </h1>
              <div className="flex gap-2 my-5">
                <span className="h-1 w-12 rounded-full bg-[#E84821]"/>
                <span className="h-1 w-7 rounded-full" style={{ backgroundColor: primaryColor }}/>
                <span className="h-1 w-4 rounded-full bg-[#3D4FA0]"/>
              </div>
              <p className="text-gray-300 text-sm leading-relaxed mb-3 max-w-lg">
                B1Plus Cloud is CtrlA Tech Solutions' fully managed cloud platform, hosted on world-class Tier III and Tier IV data centers — providing businesses with secure, high-performance, and highly available infrastructure.
              </p>
              <p className="text-gray-400 text-sm leading-relaxed mb-8 max-w-lg">
                Whether you're hosting <strong className="text-white">ERP solutions, custom applications, eCommerce platforms, databases, or business-critical systems</strong> — B1Plus Cloud delivers enterprise-grade reliability without the complexity of managing physical infrastructure.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 shadow-lg transition-all text-sm">
                  Get Started with B1Plus Cloud <ArrowRight size={15}/>
                </Link>
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
                  Talk to Our Cloud Team <ChevronRight size={14}/>
                </Link>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.12 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10">
                <img
                  src="https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80"
                  alt="B1Plus Cloud enterprise data center"
                  className="w-full h-64 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/80 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse flex-shrink-0"/>
                    <span className="text-white text-xs font-semibold">Tier III & Tier IV data centers · 99.9%+ availability</span>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3 mt-4">
                {[{ n: "99.9%+", label: "Availability" }, { n: "Tier IV", label: "Data Centers" }, { n: "24×7", label: "NOC Support" }].map(s => (
                  <div key={s.label} className="bg-white/5 border border-white/10 rounded-xl p-3 text-center">
                    <div className="text-lg font-black text-white leading-tight">{s.n}</div>
                    <div className="text-white/50 text-xs mt-0.5">{s.label}</div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
        <div className="h-1 flex">
          <div className="flex-[3] bg-[#E84821]"/><div className="flex-[2]" style={{ backgroundColor: primaryColor }}/><div className="flex-1 bg-[#3D4FA0]"/>
        </div>
      </section>

      {/* ── FOUR PILLARS ─────────────────────────────────────────────── */}
      <section className="py-16 md:py-20 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFFBEB 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 700" preserveAspectRatio="xMidYMid slice">
          {Array.from({length:20}).map((_,r)=>Array.from({length:26}).map((_,c)=>(
            <circle key={`${r}-${c}`} cx={c*35+17} cy={r*35+17} r="1.6" fill="#D4920C"/>
          )))}
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why Choose B1Plus Cloud?</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Four pillars of enterprise cloud excellence</h2>
            <p className="text-gray-500 text-sm mt-2 max-w-xl mx-auto">Every aspect of B1Plus Cloud is engineered for maximum reliability, security, and performance.</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {PILLARS.map((p, i) => {
              const Icon = p.icon;
              return (
                <motion.div key={p.title} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.09 }}
                  className="bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                  <div className="h-1.5" style={{ backgroundColor: p.color }}/>
                  <div className="p-5">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: p.bg }}>
                        <Icon size={18} style={{ color: p.color }}/>
                      </div>
                      <h3 className="font-bold text-gray-900 text-sm leading-tight">{p.title}</h3>
                    </div>
                    <p className="text-gray-500 text-xs leading-relaxed mb-4">{p.desc}</p>
                    <div className="space-y-1.5">
                      {p.features.slice(0, 6).map(f => (
                        <div key={f} className="flex items-center gap-1.5 text-xs text-gray-600">
                          <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: p.color }}/>
                          {f}
                        </div>
                      ))}
                      {p.features.length > 6 && (
                        <div className="text-xs font-semibold mt-1" style={{ color: p.color }}>+{p.features.length - 6} more</div>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── WORKLOADS + SCALE ────────────────────────────────────────── */}
      <section className="py-16 bg-white border-t border-gray-100 relative overflow-hidden">
        <svg className="absolute -right-16 inset-y-0 h-full opacity-[0.04]" viewBox="0 0 300 600" fill="none">
          <circle cx="250" cy="300" r="220" stroke="#D4920C" strokeWidth="1.5" strokeDasharray="8 6"/>
          <circle cx="250" cy="300" r="140" stroke="#3D4FA0" strokeWidth="1" strokeDasharray="5 8"/>
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-14 items-start">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-6 h-0.5 rounded bg-[#D4920C]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#D4920C]">Flexible Hosting for Every Business</span>
              </div>
              <h2 className="text-2xl font-bold mb-5" style={{ color: accentColor }}>Supports every type of business workload</h2>
              <div className="grid grid-cols-2 gap-2">
                {WORKLOADS.map((w, i) => {
                  const Icon = w.icon;
                  return (
                    <motion.div key={w.label} initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}
                      className="flex items-center gap-2.5 p-2.5 rounded-xl bg-gray-50 border border-gray-100 hover:border-[#D4920C]/30 hover:bg-[#D4920C]/3 transition-all">
                      <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 bg-[#D4920C]/10">
                        <Icon size={13} className="text-[#D4920C]"/>
                      </div>
                      <span className="text-xs font-semibold text-gray-700">{w.label}</span>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Built to Scale</span>
              </div>
              <h2 className="text-2xl font-bold mb-2" style={{ color: accentColor }}>As your business grows, B1Plus Cloud grows with you</h2>
              <p className="text-gray-500 text-sm leading-relaxed mb-5">Scale resources instantly — no hardware procurement, no long lead times, no capital expenditure.</p>
              <div className="space-y-2.5">
                {SCALE_FEATURES.map((f, i) => (
                  <motion.div key={f} initial={{ opacity: 0, x: 12 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.07 }}
                    className="flex items-center gap-3 p-3 rounded-xl bg-gray-50 border border-gray-100 hover:border-[#3D4FA0]/30 hover:bg-[#3D4FA0]/3 transition-all">
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-[#3D4FA0]/10 flex-shrink-0">
                      <Zap size={14} className="text-[#3D4FA0]"/>
                    </div>
                    <span className="text-sm font-semibold text-gray-700">{f}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── WHY BUSINESSES CHOOSE ────────────────────────────────────── */}
      <section className="py-16 border-t border-gray-100 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #EFF2FF 100%)" }}>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why Businesses Choose B1Plus Cloud</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Enterprise infrastructure. Zero complexity.</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {WHY_CHOOSE.map((w, i) => (
              <motion.div key={w} initial={{ opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                className="flex items-start gap-2.5 p-4 rounded-2xl bg-white border border-gray-100 hover:shadow-md hover:-translate-y-0.5 transition-all">
                <CheckCircle2 size={15} className="text-[#E84821] flex-shrink-0 mt-0.5"/>
                <span className="text-xs font-semibold text-gray-700 leading-relaxed">{w}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── RELATED LINKS ────────────────────────────────────────────── */}
      <section className="py-12 bg-white border-t border-gray-100">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-3 gap-4">
            {[
              { title: "Cloud Solutions", desc: "AWS, Azure, GCP & full cloud consulting services", href: "/services/cloud-solutions", color: "#059669" },
              { title: "Cloud Platforms", desc: "All 8 cloud products — managed hosting, DR & more", href: "/products/cloud-platforms", color: "#3D4FA0" },
              { title: "SAP Business One", desc: "ERP implementation by certified SAP professionals", href: "/sap-business-one", color: "#D4920C" },
            ].map(l => (
              <Link key={l.title} href={l.href}
                className="group flex items-center gap-4 p-4 rounded-2xl border border-gray-100 hover:shadow-lg hover:-translate-y-0.5 transition-all bg-white">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${l.color}15` }}>
                  <ArrowUpRight size={16} style={{ color: l.color }}/>
                </div>
                <div>
                  <div className="font-bold text-gray-900 text-sm group-hover:text-[#D4920C] transition-colors">{l.title}</div>
                  <div className="text-gray-500 text-xs mt-0.5">{l.desc}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 900 280" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="820" cy="140" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          {[[80,50],[200,210],[370,60],[520,190]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-5 L2-2 L5-2 L3 2 L4 5 L0 3 L-4 5 L-3 2 L-5-2 L-2-2Z" fill="white" opacity="0.5"/>
            </g>
          ))}
        </svg>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <h2 className="text-3xl font-bold text-white mb-3">Start Your B1Plus Cloud Journey</h2>
          <p className="text-gray-400 text-sm mb-8 max-w-2xl mx-auto leading-relaxed">
            Run your ERP securely from anywhere, reduce infrastructure costs, and improve business continuity — with B1Plus Cloud managing everything so you can focus on growth.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 transition-all text-sm shadow-xl">
              Get Started with B1Plus Cloud <ArrowRight size={15}/>
            </Link>
            <Link href="/services/cloud-solutions" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
              Explore Cloud Solutions <ChevronRight size={14}/>
            </Link>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1 flex">
          <div className="flex-[3] bg-[#E84821]"/>
          <div className="flex-[2]" style={{ backgroundColor: primaryColor }}/>
          <div className="flex-1 bg-[#3D4FA0]"/>
        </div>
      </section>
    </PublicLayout>
  );
}
