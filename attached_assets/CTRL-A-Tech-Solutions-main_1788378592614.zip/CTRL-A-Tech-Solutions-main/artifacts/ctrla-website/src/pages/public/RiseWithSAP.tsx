import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  ArrowRight, CheckCircle2, Rocket, Cloud, Brain, RefreshCw,
  BarChart3, Shield, Sparkles, Server, Layers, Award,
  HeadphonesIcon, TrendingUp, ChevronRight,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import PageHero from "@/components/public/PageHero";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

/* ── Data ─────────────────────────────────────────────────────────────── */

const INCLUDED = [
  {
    icon: Cloud,
    title: "SAP S/4HANA Cloud",
    tagline: "Next-generation intelligent ERP",
    desc: "Run your business on SAP's next-generation intelligent ERP platform with real-time analytics, automation, and scalable cloud infrastructure.",
    accent: "#E84821",
    bg: "#FFF4F1",
    image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=700&q=80",
    points: ["Public & Private Cloud Options", "Modern ERP Platform", "Real-Time Business Insights", "AI & Machine Learning Ready", "Continuous Innovation", "Enterprise-Grade Performance"],
  },
  {
    icon: BarChart3,
    title: "Business Process Intelligence",
    tagline: "Data-driven process benchmarking",
    desc: "Understand how your business processes perform using data-driven insights and industry benchmarks.",
    accent: "#3D4FA0",
    bg: "#F0F3FF",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=700&q=80",
    points: ["Process Discovery", "Performance Benchmarking", "Bottleneck Identification", "Process Optimization", "Best Practice Recommendations", "Continuous Process Improvement"],
  },
  {
    icon: Server,
    title: "Cloud Infrastructure & Managed Services",
    tagline: "Enterprise-grade cloud without the overhead",
    desc: "Deploy SAP S/4HANA on secure, enterprise-grade cloud infrastructure while reducing infrastructure management overhead.",
    accent: "#D4920C",
    bg: "#FFFBEB",
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=700&q=80",
    points: ["Fully Managed Cloud Environment", "High Availability", "Disaster Recovery", "Automated Backups", "Performance Monitoring", "Infrastructure Scalability"],
  },
  {
    icon: Layers,
    title: "Business Technology Platform (BTP)",
    tagline: "Extend, integrate, and innovate",
    desc: "Extend and innovate your ERP landscape using SAP Business Technology Platform.",
    accent: "#7C3AED",
    bg: "#F5F3FF",
    image: "https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&w=700&q=80",
    points: ["Application Development", "API Integration", "Workflow Automation", "Data Management", "Analytics", "AI & Intelligent Technologies"],
  },
  {
    icon: Shield,
    title: "Enterprise Security & Compliance",
    tagline: "Built-in security at every layer",
    desc: "Protect your business with enterprise-grade security, compliance standards, and proactive monitoring.",
    accent: "#059669",
    bg: "#F0FDF6",
    image: "https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?auto=format&fit=crop&w=700&q=80",
    points: ["End-to-End Encryption", "Identity & Access Management", "Regulatory Compliance", "Continuous Security Monitoring", "Secure Cloud Operations", "Business Continuity"],
  },
  {
    icon: RefreshCw,
    title: "Continuous Innovation",
    tagline: "Always current, never disruptive",
    desc: "Stay ahead with regular SAP innovations without the complexity of traditional ERP upgrade projects.",
    accent: "#0F766E",
    bg: "#F0FDFA",
    image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=700&q=80",
    points: ["Quarterly Feature Updates", "Automatic Enhancements", "Reduced Upgrade Costs", "Access to Latest SAP Innovations", "Future-Ready ERP Platform"],
  },
];

const BENEFITS = [
  "Accelerate Digital Transformation",
  "Simplify ERP Migration",
  "Reduce Total Cost of Ownership (TCO)",
  "Increase Business Agility",
  "Standardize Business Processes",
  "Improve Operational Efficiency",
  "Enable Data-Driven Decision Making",
  "Support Global Business Expansion",
  "Faster Time-to-Value",
  "Continuous Innovation Without Major Upgrades",
];

const OUR_SERVICES = [
  "Digital Transformation Consulting",
  "ERP Readiness Assessment",
  "SAP S/4HANA Cloud Implementation",
  "Business Process Re-engineering",
  "Data Migration & Validation",
  "SAP Integration Services",
  "Custom Extensions & Development",
  "User Training & Change Management",
  "Go-Live Support",
  "Application Management & AMC",
];

const WHY_US = [
  "Experienced SAP & Enterprise Technology Consultants",
  "End-to-End Digital Transformation Expertise",
  "Business Process Consulting",
  "Cloud ERP Implementation Specialists",
  "Enterprise Integration & API Development",
  "Data Migration & Modernization",
  "Industry Best Practices",
  "Dedicated Project Management",
  "Post Go-Live Managed Services",
  "Customer-First Delivery Approach",
];

const JOURNEY = [
  {
    step: "01",
    title: "Discovery & Business Assessment",
    desc: "We evaluate your existing ERP landscape, business processes, IT infrastructure, and digital transformation goals to create a customized roadmap.",
    accent: "#E84821",
  },
  {
    step: "02",
    title: "Business Case & Transformation Strategy",
    desc: "Our consultants develop a comprehensive transformation strategy, including ROI analysis, cloud readiness, deployment options, and project planning.",
    accent: "#D4920C",
  },
  {
    step: "03",
    title: "Migration Planning",
    desc: "We prepare a detailed migration plan covering data migration, system integrations, security, testing, custom developments, and business continuity.",
    accent: "#3D4FA0",
  },
  {
    step: "04",
    title: "Implementation & Deployment",
    desc: "Using SAP Activate methodology and industry best practices, we configure, deploy, test, and implement SAP S/4HANA Cloud with minimal disruption.",
    accent: "#7C3AED",
  },
  {
    step: "05",
    title: "Go-Live, Optimization & Managed Support",
    desc: "After successful go-live, our team provides hypercare support, performance optimization, continuous monitoring, and long-term application management.",
    accent: "#059669",
  },
];

/* ── Component ────────────────────────────────────────────────────────── */

export default function RiseWithSAPPage() {
  const { primaryColor, accentColor } = useSiteConfig();

  return (
    <PublicLayout>
      <SEO
        title="RISE with SAP — Accelerate Your Business Transformation with Cloud ERP"
        description="RISE with SAP is an end-to-end Business Transformation as a Service (BTaaS) solution. Migrate to SAP S/4HANA Cloud, modernize your ERP landscape, and embrace digital innovation with CtrlA Tech Solutions."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: "RISE with SAP",
          description: "RISE with SAP is an end-to-end Business Transformation as a Service (BTaaS) solution. Migrate to SAP S/4HANA Cloud, modernize your ERP landscape, and embrace digital innovation with CtrlA Tech Solutions.",
          provider: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
          areaServed: ["IN", "GB"],
          serviceType: ["SAP S/4HANA Cloud Migration", "Business Transformation as a Service", "ERP Modernisation"],
          url: window.location.href,
        }}
      />

      {/* ── HERO ─────────────────────────────────────────────────────────── */}
      <PageHero
        eyebrow="Cloud ERP"
        title={<><span style={{ color: "#E84821" }}>RISE with SAP</span> — Accelerate Your Business Transformation with Cloud ERP</>}
        subtitle="RISE with SAP is an end-to-end Business Transformation as a Service (BTaaS) solution designed to help organizations modernize their ERP landscape, migrate to SAP S/4HANA Cloud, and embrace digital innovation with confidence."
        heroImage="https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=1200&q=80"
        heroImageAlt="Digital transformation team planning cloud ERP migration"
        cta={
          <div className="flex flex-wrap gap-3 mt-6">
            <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5 bg-[#E84821]">
              Start Your Transformation <ArrowRight size={16} />
            </Link>
            <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border-2 border-white/40 text-white hover:bg-white/15 transition-all">
              Talk to Our SAP Experts
            </Link>
          </div>
        }
      />

      {/* ── WHY RISE ─────────────────────────────────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden">
        {/* circuit doodle */}
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 300" fill="none" preserveAspectRatio="xMidYMid slice">
          <path d="M0 150h200l40-50h120l40 50h200l30-30h120l30 30h120" stroke="#3D4FA0" strokeWidth="2"/>
          <circle cx="200" cy="150" r="7" fill="#3D4FA0"/><circle cx="560" cy="150" r="7" fill="#3D4FA0"/>
          <rect x="820" y="90" width="14" height="14" stroke="#E84821" strokeWidth="1.5"/>
          <path d="M750 0v80l40 30" stroke="#D4920C" strokeWidth="1.5"/>
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why Choose RISE with SAP?</span>
              </div>
              <h2 className="text-3xl font-bold mb-4" style={{ color: accentColor }}>More than an ERP upgrade — a complete transformation strategy</h2>
              <p className="text-gray-600 text-sm leading-relaxed mb-4">
                Modern businesses require more than just an ERP upgrade. RISE with SAP enables organizations to simplify operations, improve agility, reduce IT complexity, and continuously innovate while lowering the total cost of ownership.
              </p>
              <p className="text-gray-600 text-sm leading-relaxed">
                With <strong>one subscription, one contract, and one strategic roadmap</strong>, your organization can focus on business growth while SAP manages the technology foundation.
              </p>
            </motion.div>
            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[4/3]">
                <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=900&q=80" alt="Business strategy team planning digital transformation" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-tr from-[#1A1F36]/40 to-transparent"/>
                <div className="absolute bottom-4 left-4 bg-white/95 rounded-xl px-4 py-2.5 shadow-lg">
                  <div className="text-[10px] font-bold uppercase tracking-widest text-gray-500">Business Transformation as a Service</div>
                  <div className="text-sm font-bold text-gray-900 mt-0.5">One Subscription · One Contract · One Roadmap</div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* quick stat chips */}
          <div className="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { v: "1", l: "Subscription", sub: "All-inclusive" },
              { v: "1", l: "Contract", sub: "Simplified vendor" },
              { v: "S/4HANA", l: "Cloud", sub: "Next-gen ERP" },
              { v: "24×7", l: "Managed Services", sub: "Peace of mind" },
            ].map(item => (
              <div key={item.l} className="bg-gray-50 border border-gray-100 rounded-2xl p-4 text-center hover:border-[#E84821]/30 hover:bg-[#FFF4F1] transition-colors">
                <div className="text-2xl font-black" style={{ color: "#E84821" }}>{item.v}</div>
                <div className="text-sm font-bold text-gray-800">{item.l}</div>
                <div className="text-[10px] text-gray-400 mt-0.5">{item.sub}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── WHAT'S INCLUDED ──────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.04]" viewBox="0 0 900 900" preserveAspectRatio="xMidYMid slice">
          {Array.from({ length: 25 }).map((_, row) => Array.from({ length: 30 }).map((_, col) => (
            <circle key={`${row}-${col}`} cx={col * 30 + 15} cy={row * 30 + 15} r="1.8" fill="#3D4FA0"/>
          )))}
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">What's Included in RISE with SAP?</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Six pillars of business transformation</h2>
            <p className="mt-2 text-gray-500 max-w-xl mx-auto text-sm">Everything you need to modernize, scale, and innovate — bundled in one subscription.</p>
          </div>

          <div className="space-y-6">
            {INCLUDED.map((item, i) => {
              const Icon = item.icon;
              const isEven = i % 2 === 0;
              return (
                <motion.div key={item.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.08 }}
                  className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden">
                  <div className="grid lg:grid-cols-12 items-stretch">
                    {/* Image */}
                    <div className={`lg:col-span-4 relative ${isEven ? "order-first" : "order-first lg:order-last"}`}>
                      <div className="relative h-52 lg:h-full min-h-[200px]">
                        <img src={item.image} alt={item.title} className="w-full h-full object-cover" loading="lazy"/>
                        <div className="absolute inset-0" style={{ background: `linear-gradient(135deg, ${item.accent}55 0%, transparent 60%)` }}/>
                        <div className={`absolute top-4 ${isEven ? "left-4" : "left-4 lg:left-auto lg:right-4"} w-11 h-11 rounded-xl flex items-center justify-center bg-white shadow-lg`}>
                          <Icon size={20} style={{ color: item.accent }}/>
                        </div>
                        {/* wavy bottom */}
                        <svg className={`absolute bottom-0 ${isEven ? "left-0 right-0" : "left-0 right-0"}`} viewBox="0 0 400 20" fill="white" preserveAspectRatio="none">
                          <path d="M0 20 Q100 6 200 12 Q300 20 400 6 L400 20 Z"/>
                        </svg>
                      </div>
                    </div>
                    {/* Content */}
                    <div className={`lg:col-span-8 p-7 flex flex-col justify-center ${isEven ? "order-last" : "order-last lg:order-first"}`}>
                      <div className="flex items-center gap-2 mb-2">
                        <span className="w-4 h-0.5 rounded" style={{ backgroundColor: item.accent }}/>
                        <span className="text-[10px] font-bold uppercase tracking-widest" style={{ color: item.accent }}>Included</span>
                        <span className="ml-auto text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full" style={{ backgroundColor: item.accent + "18", color: item.accent }}>{item.tagline}</span>
                      </div>
                      <h3 className="text-xl font-bold mb-2" style={{ color: accentColor }}>{item.title}</h3>
                      <p className="text-gray-600 text-sm leading-relaxed mb-4">{item.desc}</p>
                      <div>
                        <div className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2">Key Benefits & Features</div>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2">
                          {item.points.map(pt => (
                            <div key={pt} className="flex items-center gap-1.5 text-xs text-gray-700">
                              <ChevronRight size={12} style={{ color: item.accent }} className="flex-shrink-0"/>
                              {pt}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── BENEFITS ─────────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 900 500" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="450" cy="250" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          <circle cx="450" cy="250" r="310" stroke="white" strokeWidth="0.5" strokeDasharray="4 8" opacity="0.5"/>
          {[[80,60],[210,390],[700,60],[820,390],[320,50],[580,430]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-6 L2-2 L6-2 L3 2 L4 6 L0 3 L-4 6 L-3 2 L-6-2 L-2-2Z" fill="white" opacity="0.5"/></g>
          ))}
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#D4920C]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#D4920C]">Benefits of RISE with SAP</span>
              </div>
              <h2 className="text-3xl font-bold text-white mb-3">Ten transformation outcomes for your business</h2>
              <p className="text-gray-300 text-sm leading-relaxed mb-7">Whether moving from legacy ERP, planning your S/4HANA journey, or adopting a cloud-first strategy — RISE delivers a simplified, future-ready path.</p>
              <div className="grid sm:grid-cols-2 gap-3">
                {BENEFITS.map((b, i) => (
                  <motion.div key={b} initial={{ opacity: 0, y: 8 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}
                    className="flex items-start gap-2.5 bg-white/10 border border-white/15 rounded-xl p-3 hover:bg-white/15 transition-colors">
                    <CheckCircle2 size={14} className="flex-shrink-0 mt-0.5 text-[#D4920C]"/>
                    <span className="text-xs text-gray-200 leading-relaxed">{b}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[4/3]">
                <img src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=900&q=80" alt="Cloud ERP transformation globe" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/60 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4 grid grid-cols-2 gap-2">
                  {[
                    { v: "↓ TCO", l: "Lower costs" },
                    { v: "↑ Agility", l: "Faster response" },
                    { v: "24×7", l: "Managed cloud" },
                    { v: "Quarterly", l: "Innovation cycles" },
                  ].map(item => (
                    <div key={item.l} className="bg-white/90 rounded-lg p-2.5 text-center">
                      <div className="text-sm font-black" style={{ color: "#E84821" }}>{item.v}</div>
                      <div className="text-[10px] text-gray-600">{item.l}</div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── OUR SERVICES ─────────────────────────────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden">
        <svg className="absolute -top-8 -right-8 opacity-[0.05] w-72 h-72" viewBox="0 0 200 200" fill="none">
          <path d="M40 40 L80 20 L160 60 L180 140 L120 180 L40 160 L20 80 Z" stroke="#3D4FA0" strokeWidth="2.5" strokeDasharray="6 4"/>
          <circle cx="100" cy="100" r="30" stroke="#E84821" strokeWidth="1.5" strokeDasharray="4 3"/>
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Our RISE with SAP Services</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Comprehensive consulting &amp; implementation</h2>
            <p className="mt-2 text-gray-500 max-w-xl mx-auto text-sm">CtrlA Tech Solutions provides end-to-end services to ensure a successful transformation journey.</p>
          </div>

          <div className="grid lg:grid-cols-12 gap-10 items-start">
            <div className="lg:col-span-5">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[3/4]">
                <img src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&w=800&q=80" alt="CtrlA consultants planning SAP RISE transformation" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/60 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4 bg-white/95 rounded-xl p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-[#E84821] flex-shrink-0">
                      <Award size={18} className="text-white"/>
                    </div>
                    <div>
                      <div className="text-xs font-bold text-gray-900">Certified SAP Professionals</div>
                      <div className="text-[10px] text-gray-500 mt-0.5">SAP Implementation Consultants • India & UK</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="lg:col-span-7">
              <div className="grid sm:grid-cols-2 gap-3">
                {OUR_SERVICES.map((s, i) => (
                  <motion.div key={s} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                    className="flex items-start gap-2.5 bg-gray-50 rounded-xl p-3.5 border border-gray-100 hover:border-[#E84821]/30 hover:bg-[#FFF4F1] transition-colors">
                    <CheckCircle2 size={14} className="flex-shrink-0 mt-0.5 text-[#E84821]"/>
                    <span className="text-xs text-gray-700 leading-relaxed">{s}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── JOURNEY ──────────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 100%)" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Our Transformation Approach</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Your structured path to SAP S/4HANA Cloud</h2>
            <p className="mt-2 text-gray-500 max-w-xl mx-auto text-sm">A proven 5-phase approach refined across dozens of enterprise cloud ERP transformations.</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-10 items-center">
            <div className="space-y-4">
              {JOURNEY.map((j, i) => (
                <motion.div key={j.step} initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                  className="group flex gap-5 bg-white rounded-2xl p-5 border border-gray-100 shadow-sm hover:shadow-lg hover:border-opacity-50 transition-all duration-300"
                  style={{ borderColor: j.accent + "30" }}>
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-black text-sm shadow-md group-hover:scale-110 transition-transform"
                      style={{ background: `linear-gradient(135deg, ${j.accent}, ${j.accent}99)` }}>
                      {j.step}
                    </div>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-1.5">{j.title}</h4>
                    <p className="text-xs text-gray-600 leading-relaxed">{j.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[4/3]">
                <img src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=900&q=80" alt="SAP RISE transformation planning session" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/50 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4 grid grid-cols-3 gap-2">
                  {[
                    { icon: TrendingUp, label: "ROI-first", sub: "Approach" },
                    { icon: Sparkles, label: "SAP Activate", sub: "Methodology" },
                    { icon: HeadphonesIcon, label: "Hypercare", sub: "Post-Go-Live" },
                  ].map(item => {
                    const Icon = item.icon;
                    return (
                      <div key={item.label} className="bg-white/90 rounded-lg p-2.5 text-center">
                        <Icon size={14} className="mx-auto mb-1 text-[#E84821]"/>
                        <div className="text-xs font-bold text-gray-900">{item.label}</div>
                        <div className="text-[9px] text-gray-500">{item.sub}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── WHY CTRLA ────────────────────────────────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why CtrlA Tech Solutions?</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl font-bold mb-2" style={{ color: accentColor }}>Digital transformation requires a trusted partner</h2>
            <p className="text-gray-500 max-w-2xl mx-auto text-sm">With 22+ years of combined ERP consulting experience, CtrlA Tech Solutions helps organizations successfully modernize their ERP landscape through structured planning, proven methodologies, and long-term support.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3 mb-10">
            {WHY_US.map((w, i) => (
              <motion.div key={w} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                className="flex items-start gap-2.5 bg-gray-50 rounded-xl p-3.5 border border-gray-100 hover:border-[#E84821]/30 hover:bg-[#FFF4F1] transition-colors">
                <CheckCircle2 size={14} className="flex-shrink-0 mt-0.5 text-[#E84821]"/>
                <span className="text-xs text-gray-700 leading-relaxed">{w}</span>
              </motion.div>
            ))}
          </div>

          {/* Supporting image strip */}
          <div className="grid grid-cols-3 gap-4 rounded-2xl overflow-hidden h-40">
            <div className="relative overflow-hidden rounded-2xl">
              <img src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=500&q=80" alt="Cloud technology team" className="w-full h-full object-cover"/>
              <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/50 to-transparent"/>
              <div className="absolute bottom-3 left-3 text-white text-xs font-bold">Expert Team</div>
            </div>
            <div className="relative overflow-hidden rounded-2xl">
              <img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=500&q=80" alt="Real-time ERP analytics" className="w-full h-full object-cover"/>
              <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/50 to-transparent"/>
              <div className="absolute bottom-3 left-3 text-white text-xs font-bold">Live Analytics</div>
            </div>
            <div className="relative overflow-hidden rounded-2xl">
              <img src="https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&w=500&q=80" alt="Enterprise cloud platform" className="w-full h-full object-cover"/>
              <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/50 to-transparent"/>
              <div className="absolute bottom-3 left-3 text-white text-xs font-bold">Cloud Platform</div>
            </div>
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────────── */}
      <section className="py-16 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 900 300" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="450" cy="150" r="120" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          <circle cx="450" cy="150" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="4 8" opacity="0.6"/>
          {[[100,40],[800,240],[300,110],[600,170]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-5 L2-2 L5-2 L3 2 L4 5 L0 3 L-4 5 L-3 2 L-5-2 L-2-2Z" fill="white" opacity="0.5"/></g>
          ))}
        </svg>
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Rocket size={36} className="mx-auto mb-4 text-[#E84821]"/>
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Ready to RISE?</h2>
          <p className="text-gray-300 max-w-2xl mx-auto mb-8 leading-relaxed">
            Let's build your RISE with SAP transformation roadmap together. Whether you're ready to start or still evaluating, our consultants will help you make the right decision for your business.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl text-sm font-bold text-white shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all bg-[#E84821]">
              Start Your Transformation <ArrowRight size={16} />
            </Link>
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl text-sm font-bold border border-white/30 text-white hover:bg-white/10 transition-all">
              Talk to Our SAP Experts
            </Link>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
