import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  ArrowRight, CheckCircle2, Cloud, Lock, Zap, Globe2,
  RefreshCw, DollarSign, Server, Shield, Database,
  MonitorCheck, Award, ChevronRight, HeadphonesIcon,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import PageHero from "@/components/public/PageHero";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

/* ── Data ─────────────────────────────────────────────────────────────── */

const STATS = [
  { label: "Uptime SLA", value: "99.9%" },
  { label: "Setup Time", value: "< 1 wk" },
  { label: "Data Center Tier", value: "III–IV" },
  { label: "Cost Savings vs On-Prem", value: "↓40%" },
];

const CLOUD_SERVICES = [
  "SAP Business One SQL Cloud Hosting",
  "SAP Business One HANA Cloud Hosting",
  "SQL to SQL Migration",
  "HANA to HANA Migration",
  "On-Premise to Cloud Migration",
  "Server Migration & Upgrade",
  "Database Optimization",
  "Disaster Recovery Planning",
  "Performance Monitoring",
  "Managed Cloud Services",
];

const INFRA_HIGHLIGHTS = [
  "High Availability Infrastructure",
  "Redundant Power & Network Connectivity",
  "24×7 Infrastructure Monitoring",
  "Enterprise SSD Storage",
  "High-Speed Network Connectivity",
  "Automatic Failover",
  "Disaster Recovery Ready",
  "Environment Monitoring",
  "Scalable Computing Resources",
];

const SECURITY_FEATURES = [
  "Advanced Firewall Protection",
  "Multi-Layer Network Security",
  "End-to-End Data Encryption",
  "Secure VPN & Remote Access",
  "Multi-Factor Authentication (MFA)",
  "Role-Based User Access",
  "Daily Automated Backups",
  "Anti-Ransomware Protection",
  "Continuous Security Monitoring",
  "Disaster Recovery & Business Continuity",
];

const KEY_BENEFITS = [
  {
    icon: Server,
    title: "No Infrastructure Investment",
    desc: "Avoid purchasing servers, storage, networking equipment, UPS systems, and expensive IT infrastructure. Simply subscribe and start using SAP Business One in the cloud.",
    accent: "#E84821",
    bg: "#FFF4F1",
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=700&q=80",
  },
  {
    icon: Globe2,
    title: "Access Anywhere",
    desc: "Work securely from your office, home, warehouse, branch offices, or while travelling using laptops, desktops, tablets, or mobile devices.",
    accent: "#3D4FA0",
    bg: "#F0F3FF",
    image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=700&q=80",
  },
  {
    icon: Zap,
    title: "High Performance",
    desc: "Enjoy fast application response, optimized databases, enterprise-grade hardware, and dedicated cloud resources for consistent ERP performance.",
    accent: "#D4920C",
    bg: "#FFFBEB",
    image: "https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&w=700&q=80",
  },
  {
    icon: RefreshCw,
    title: "Automatic Backup & Recovery",
    desc: "Your databases and files are backed up automatically with quick recovery options to minimize downtime and protect your business.",
    accent: "#059669",
    bg: "#F0FDF6",
    image: "https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?auto=format&fit=crop&w=700&q=80",
  },
  {
    icon: Cloud,
    title: "Instant Scalability",
    desc: "Increase users, storage, memory, or computing resources whenever your business grows — without replacing hardware or interrupting operations.",
    accent: "#7C3AED",
    bg: "#F5F3FF",
    image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=700&q=80",
  },
  {
    icon: DollarSign,
    title: "Affordable Monthly Pricing",
    desc: "Reduce capital expenditure by moving to a predictable monthly subscription model with no hidden maintenance or hardware replacement costs.",
    accent: "#0F766E",
    bg: "#F0FDFA",
    image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?auto=format&fit=crop&w=700&q=80",
  },
];

const COMPARISON = [
  { aspect: "Initial Investment", onprem: "High", cloud: "Low Monthly Subscription" },
  { aspect: "Hardware Maintenance", onprem: "Customer Responsibility", cloud: "Fully Managed" },
  { aspect: "Server Upgrades", onprem: "Manual", cloud: "Managed by Experts" },
  { aspect: "Remote Access", onprem: "Limited", cloud: "Secure Access from Anywhere" },
  { aspect: "Backup & Disaster Recovery", onprem: "Manual", cloud: "Automated & Managed" },
  { aspect: "Security", onprem: "Depends on Local Infrastructure", cloud: "Enterprise-Grade Security" },
  { aspect: "Scalability", onprem: "Hardware Dependent", cloud: "Instant Resource Scaling" },
  { aspect: "Business Continuity", onprem: "Limited", cloud: "High Availability Infrastructure" },
];

const MANAGED_SERVICES = [
  "24×7 Infrastructure Monitoring",
  "Database Administration",
  "Performance Tuning",
  "Operating System Updates",
  "Security Patch Management",
  "Backup Verification",
  "Disaster Recovery Support",
  "Technical Helpdesk",
  "Server Health Monitoring",
  "Annual Maintenance & Support",
];

const WHY_US = [
  "Hosting for SAP Business One SQL & SAP Business One HANA",
  "Complete Cloud Migration Services",
  "World-Class Tier III & Tier IV Data Centers",
  "Enterprise-Level Security & Compliance",
  "High Availability Infrastructure",
  "Affordable Monthly Subscription Plans",
  "Dedicated Technical Support",
  "Performance Optimization & Monitoring",
  "Backup, Disaster Recovery & Business Continuity",
  "End-to-End Managed Cloud Services",
];

/* ── Component ────────────────────────────────────────────────────────── */

export default function SAPB1OnCloudPage() {
  const { primaryColor, accentColor } = useSiteConfig();

  return (
    <PublicLayout>
      <SEO
        title="SAP Business One on Cloud — Secure, Scalable & Affordable Cloud ERP"
        description="Move your SAP Business One (SQL or HANA) to a fully managed cloud environment. Enterprise-grade security, 99.9% uptime, Tier III/IV data centers, and affordable monthly pricing."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: "SAP Business One on Cloud",
          description: "Move your SAP Business One (SQL or HANA) to a fully managed cloud environment. Enterprise-grade security, 99.9% uptime, Tier III/IV data centers, and affordable monthly pricing.",
          provider: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
          areaServed: ["IN", "GB"],
          serviceType: ["SAP Business One Cloud Hosting", "Cloud ERP Migration", "Managed SAP Hosting"],
          url: window.location.href,
        }}
      />

      {/* ── HERO ─────────────────────────────────────────────────────────── */}
      <PageHero
        eyebrow="Cloud ERP"
        title={<><span style={{ color: "#E84821" }}>SAP Business One on Cloud</span> — Secure, Scalable &amp; Affordable</>}
        subtitle="Move your SAP Business One (SQL or SAP HANA) to a fully managed cloud environment and eliminate the cost and complexity of maintaining on-premise infrastructure. Access your ERP securely from anywhere, improve business continuity, and let our cloud experts manage your infrastructure while you focus on growing your business."
        heroImage="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1200&q=80"
        heroImageAlt="Enterprise cloud infrastructure for SAP Business One"
        cta={
          <div className="flex flex-wrap gap-3 mt-6">
            <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5 bg-[#E84821]">
              Get Started <ArrowRight size={16} />
            </Link>
            <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border-2 border-white/40 text-white hover:bg-white/15 transition-all">
              Request a Cloud Assessment
            </Link>
          </div>
        }
      />

      {/* ── STATS BAR ────────────────────────────────────────────────────── */}
      <section className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <p className="text-center text-xs font-bold uppercase tracking-widest text-gray-400 mb-6">Cloud Platform Highlights</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {STATS.map(s => (
              <div key={s.label}>
                <div className="text-3xl sm:text-4xl font-black" style={{ color: "#E84821" }}>{s.value}</div>
                <div className="text-xs text-gray-500 mt-1.5 font-medium leading-tight">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="h-1 flex"><div className="flex-[3] bg-[#E84821]" /><div className="flex-[2]" style={{ backgroundColor: primaryColor }} /><div className="flex-1 bg-[#3D4FA0]" /></div>
      </section>

      {/* ── WHY CLOUD + SQL & HANA BOTH ──────────────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden">
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 300" fill="none" preserveAspectRatio="xMidYMid slice">
          <path d="M0 150h200l40-50h120l40 50h200l30-30h120l30 30h120" stroke="#3D4FA0" strokeWidth="2"/>
          <circle cx="200" cy="150" r="7" fill="#3D4FA0"/><circle cx="560" cy="150" r="7" fill="#3D4FA0"/>
          <rect x="820" y="90" width="14" height="14" stroke="#E84821" strokeWidth="1.5"/>
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why Move to the Cloud?</span>
              </div>
              <h2 className="text-3xl font-bold mb-4" style={{ color: accentColor }}>Flexibility, security &amp; high availability — without the IT burden</h2>
              <p className="text-gray-600 text-sm leading-relaxed mb-4">
                Modern businesses require flexibility, security, and high availability. Hosting SAP Business One in the cloud allows your employees to securely access business data from anywhere while reducing IT costs and improving system reliability.
              </p>
              <p className="text-gray-600 text-sm leading-relaxed">
                Our cloud platform is designed to deliver <strong>enterprise-class performance for businesses of all sizes</strong> without requiring investment in expensive servers, networking equipment, or dedicated IT resources.
              </p>
            </motion.div>
            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[4/3]">
                <img src="https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=900&q=80" alt="Business team using cloud ERP from anywhere" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-tr from-[#1A1F36]/40 to-transparent"/>
                <div className="absolute bottom-4 left-4 bg-white/95 rounded-xl px-4 py-2.5 shadow-lg">
                  <div className="text-[10px] font-bold uppercase tracking-widest text-gray-500">Fully Managed Cloud Platform</div>
                  <div className="text-sm font-bold text-gray-900 mt-0.5">SAP B1 SQL &amp; HANA — Both Supported</div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* SQL & HANA both supported */}
          <div className="mt-12 rounded-2xl border border-gray-100 overflow-hidden shadow-sm">
            <div className="grid lg:grid-cols-2">
              <div className="p-8 border-b lg:border-b-0 lg:border-r border-gray-100">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-[#E84821]/10 flex items-center justify-center flex-shrink-0">
                    <Database size={18} className="text-[#E84821]"/>
                  </div>
                  <h3 className="font-bold text-gray-900">SQL &amp; SAP HANA — We Support Both</h3>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed mb-5">Whether your business is currently using SAP Business One SQL or SAP Business One HANA, we provide complete migration and hosting services with minimal downtime.</p>
                <div className="grid grid-cols-2 gap-2">
                  {CLOUD_SERVICES.map(s => (
                    <div key={s} className="flex items-start gap-1.5 text-xs text-gray-700">
                      <ChevronRight size={12} className="text-[#E84821] flex-shrink-0 mt-0.5"/>
                      {s}
                    </div>
                  ))}
                </div>
              </div>
              <div className="p-8" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #F0F3FF 100%)" }}>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-[#3D4FA0]/10 flex items-center justify-center flex-shrink-0">
                    <Server size={18} className="text-[#3D4FA0]"/>
                  </div>
                  <h3 className="font-bold text-gray-900">Enterprise-Class Data Centers</h3>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed mb-5">Your SAP Business One environment is hosted in world-class Tier III and Tier IV data centers, designed to deliver maximum availability, security, and business continuity.</p>
                <div className="grid grid-cols-2 gap-2">
                  {INFRA_HIGHLIGHTS.map(s => (
                    <div key={s} className="flex items-start gap-1.5 text-xs text-gray-700">
                      <ChevronRight size={12} className="text-[#3D4FA0] flex-shrink-0 mt-0.5"/>
                      {s}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── KEY BENEFITS (alternating image cards) ───────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.04]" viewBox="0 0 900 900" preserveAspectRatio="xMidYMid slice">
          {Array.from({ length: 25 }).map((_, row) => Array.from({ length: 30 }).map((_, col) => (
            <circle key={`${row}-${col}`} cx={col * 30 + 15} cy={row * 30 + 15} r="1.8" fill="#3D4FA0"/>
          )))}
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Key Benefits</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Everything managed. Nothing to worry about.</h2>
            <p className="mt-2 text-gray-500 max-w-xl mx-auto text-sm">Six core advantages of running SAP Business One in the cloud with CtrlA Tech Solutions.</p>
          </div>

          <div className="space-y-5">
            {KEY_BENEFITS.map((b, i) => {
              const Icon = b.icon;
              const isEven = i % 2 === 0;
              return (
                <motion.div key={b.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.06 }}
                  className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden">
                  <div className="grid lg:grid-cols-12 items-stretch">
                    <div className={`lg:col-span-4 relative ${isEven ? "order-first" : "order-first lg:order-last"}`}>
                      <div className="relative h-44 lg:h-full min-h-[180px]">
                        <img src={b.image} alt={b.title} className="w-full h-full object-cover" loading="lazy"/>
                        <div className="absolute inset-0" style={{ background: `linear-gradient(135deg, ${b.accent}55 0%, transparent 60%)` }}/>
                        <div className={`absolute top-4 ${isEven ? "left-4" : "left-4 lg:left-auto lg:right-4"} w-11 h-11 rounded-xl flex items-center justify-center bg-white shadow-lg`}>
                          <Icon size={20} style={{ color: b.accent }}/>
                        </div>
                        <svg className="absolute bottom-0 left-0 right-0" viewBox="0 0 400 20" fill="white" preserveAspectRatio="none">
                          <path d="M0 20 Q100 6 200 12 Q300 20 400 6 L400 20 Z"/>
                        </svg>
                      </div>
                    </div>
                    <div className={`lg:col-span-8 p-7 flex flex-col justify-center ${isEven ? "order-last" : "order-last lg:order-first"}`}>
                      <div className="flex items-center gap-2 mb-2">
                        <span className="w-4 h-0.5 rounded" style={{ backgroundColor: b.accent }}/>
                        <span className="text-[10px] font-bold uppercase tracking-widest" style={{ color: b.accent }}>Key Benefit</span>
                      </div>
                      <h3 className="text-xl font-bold mb-2" style={{ color: accentColor }}>{b.title}</h3>
                      <p className="text-gray-600 text-sm leading-relaxed">{b.desc}</p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── SECURITY ─────────────────────────────────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden">
        <svg className="absolute -top-8 -right-8 opacity-[0.05] w-72 h-72" viewBox="0 0 200 200" fill="none">
          <path d="M100 10 L180 50 L180 130 L100 180 L20 130 L20 50 Z" stroke="#3D4FA0" strokeWidth="2" strokeDasharray="6 4"/>
          <circle cx="100" cy="100" r="30" stroke="#E84821" strokeWidth="1.5" strokeDasharray="4 3"/>
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Enterprise-Grade Security</span>
              </div>
              <h2 className="text-3xl font-bold mb-3" style={{ color: accentColor }}>Protecting your business data is our highest priority</h2>
              <p className="text-gray-500 text-sm leading-relaxed mb-7">Our cloud platform follows industry best practices to ensure your ERP environment remains secure, compliant, and resilient. Your critical business data is protected by enterprise-grade security standards trusted by organizations worldwide.</p>
              <div className="grid grid-cols-2 gap-3">
                {SECURITY_FEATURES.map((f, i) => (
                  <motion.div key={f} initial={{ opacity: 0, y: 8 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}
                    className="flex items-start gap-2.5 bg-gray-50 rounded-xl p-3 border border-gray-100 hover:border-[#E84821]/30 hover:bg-[#FFF4F1] transition-colors">
                    <Shield size={13} className="flex-shrink-0 mt-0.5 text-[#E84821]"/>
                    <span className="text-xs text-gray-700 leading-relaxed">{f}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[4/3]">
                <img src="https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?auto=format&fit=crop&w=900&q=80" alt="Enterprise cloud security and data protection" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/60 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4 grid grid-cols-2 gap-2">
                  {[
                    { v: "AES-256", l: "Encryption" },
                    { v: "MFA", l: "Multi-Factor Auth" },
                    { v: "Daily", l: "Auto Backups" },
                    { v: "24×7", l: "Security Monitoring" },
                  ].map(item => (
                    <div key={item.l} className="bg-white/90 rounded-lg p-2.5 text-center">
                      <div className="text-sm font-black" style={{ color: "#E84821" }}>{item.v}</div>
                      <div className="text-[10px] text-gray-600">{item.l}</div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── COMPARISON TABLE ─────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 900 500" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="450" cy="250" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          <circle cx="450" cy="250" r="320" stroke="white" strokeWidth="0.5" strokeDasharray="4 8" opacity="0.5"/>
          {[[80,60],[200,380],[700,60],[820,380]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-6 L2-2 L6-2 L3 2 L4 6 L0 3 L-4 6 L-3 2 L-6-2 L-2-2Z" fill="white" opacity="0.5"/></g>
          ))}
        </svg>
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#D4920C]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#D4920C]">Cloud vs On-Premise</span>
              <span className="w-6 h-0.5 rounded bg-[#D4920C]"/>
            </div>
            <h2 className="text-3xl font-bold text-white">The real comparison — Cloud wins on every dimension</h2>
            <p className="mt-2 text-gray-400 max-w-xl mx-auto text-sm">See exactly how cloud hosting stacks up against maintaining your own on-premise SAP Business One environment.</p>
          </div>

          <div className="rounded-2xl overflow-hidden border border-white/15 shadow-2xl">
            {/* header */}
            <div className="grid grid-cols-3 bg-white/10 border-b border-white/15">
              <div className="p-4 text-xs font-bold uppercase tracking-widest text-gray-400">Feature</div>
              <div className="p-4 text-xs font-bold uppercase tracking-widest text-gray-400 border-x border-white/10">On-Premise</div>
              <div className="p-4 text-xs font-bold uppercase tracking-widest text-[#E84821]">SAP B1 on Cloud</div>
            </div>
            {COMPARISON.map((row, i) => (
              <div key={i} className={`grid grid-cols-3 border-b border-white/10 last:border-0 ${i % 2 === 0 ? "bg-white/5" : "bg-transparent"}`}>
                <div className="p-4 text-sm font-semibold text-gray-200">{row.aspect}</div>
                <div className="p-4 text-sm text-gray-500 border-x border-white/10">{row.onprem}</div>
                <div className="p-4 text-sm font-semibold text-white flex items-center gap-2">
                  <CheckCircle2 size={13} className="text-[#E84821] flex-shrink-0"/>{row.cloud}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── MANAGED SERVICES ─────────────────────────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Managed Cloud Services</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
            </div>
            <h2 className="text-3xl font-bold mb-2" style={{ color: accentColor }}>Your SAP environment, expertly managed 24×7</h2>
            <p className="text-gray-500 max-w-xl mx-auto text-sm">Our experienced cloud engineers continuously monitor and manage your SAP Business One environment to ensure maximum uptime and performance.</p>
          </div>

          <div className="grid lg:grid-cols-12 gap-10 items-start">
            <div className="lg:col-span-5">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[3/4]">
                <img src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=800&q=80" alt="CtrlA cloud management team" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/60 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4 bg-white/95 rounded-xl p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-[#E84821] flex-shrink-0">
                      <MonitorCheck size={18} className="text-white"/>
                    </div>
                    <div>
                      <div className="text-xs font-bold text-gray-900">24×7 Monitoring & Support</div>
                      <div className="text-[10px] text-gray-500 mt-0.5">Certified SAP Professionals • Dedicated Team</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="lg:col-span-7">
              <div className="grid sm:grid-cols-2 gap-3">
                {MANAGED_SERVICES.map((s, i) => (
                  <motion.div key={s} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}
                    className="flex items-start gap-2.5 bg-gray-50 rounded-xl p-3.5 border border-gray-100 hover:border-[#3D4FA0]/30 hover:bg-[#F0F3FF] transition-colors">
                    <CheckCircle2 size={14} className="flex-shrink-0 mt-0.5 text-[#3D4FA0]"/>
                    <span className="text-xs text-gray-700 leading-relaxed">{s}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── WHY CTRLA ────────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 100%)" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why Choose CtrlA Tech Solutions?</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl font-bold mb-2" style={{ color: accentColor }}>ERP expertise + enterprise cloud infrastructure</h2>
            <p className="text-gray-500 max-w-2xl mx-auto text-sm">We combine deep SAP Business One experience with world-class cloud infrastructure to deliver a reliable, secure, and cost-effective hosting solution.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3 mb-10">
            {WHY_US.map((w, i) => (
              <motion.div key={w} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}
                className="flex items-start gap-2.5 bg-white rounded-xl p-3.5 border border-gray-100 shadow-sm hover:border-[#E84821]/30 hover:shadow-md transition-all">
                <CheckCircle2 size={14} className="flex-shrink-0 mt-0.5 text-[#E84821]"/>
                <span className="text-xs text-gray-700 leading-relaxed">{w}</span>
              </motion.div>
            ))}
          </div>

          {/* image strip */}
          <div className="grid grid-cols-3 gap-4 rounded-2xl overflow-hidden h-40">
            {[
              { src: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=500&q=80", label: "Tier IV Data Center" },
              { src: "https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&w=500&q=80", label: "Real-Time Monitoring" },
              { src: "https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?auto=format&fit=crop&w=500&q=80", label: "Enterprise Security" },
            ].map(item => (
              <div key={item.label} className="relative overflow-hidden rounded-2xl">
                <img src={item.src} alt={item.label} className="w-full h-full object-cover"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/50 to-transparent"/>
                <div className="absolute bottom-3 left-3 text-white text-xs font-bold">{item.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────────── */}
      <section className="py-16 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 900 300" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="450" cy="150" r="120" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          <circle cx="450" cy="150" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="4 8" opacity="0.6"/>
          {[[100,40],[800,240],[300,110],[600,170]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-5 L2-2 L5-2 L3 2 L4 5 L0 3 L-4 5 L-3 2 L-5-2 L-2-2Z" fill="white" opacity="0.5"/></g>
          ))}
        </svg>
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Cloud size={36} className="mx-auto mb-4 text-[#E84821]"/>
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Move Your SAP Business One to the Cloud</h2>
          <p className="text-gray-300 max-w-2xl mx-auto mb-8 leading-relaxed">
            Whether you're planning a new SAP Business One deployment or migrating an existing SQL Server or SAP HANA environment, CtrlA Tech Solutions provides a secure, high-performance, and affordable cloud platform tailored to your business needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl text-sm font-bold text-white shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all bg-[#E84821]">
              Request a Free Cloud Assessment <ArrowRight size={16} />
            </Link>
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl text-sm font-bold border border-white/30 text-white hover:bg-white/10 transition-all">
              <HeadphonesIcon size={16}/> Talk to Our Cloud ERP Specialists
            </Link>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
