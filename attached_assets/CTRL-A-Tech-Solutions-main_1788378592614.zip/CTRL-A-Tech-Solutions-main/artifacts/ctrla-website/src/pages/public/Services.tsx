import { Link } from "wouter";
import {
  ArrowRight, Database, Globe, Smartphone, Cloud, Shield, Code2,
  Lightbulb, Brain, Server, Wrench, ChevronRight, ArrowUpRight,
  LayoutGrid, CheckCircle2, Package, Building2, Layers,
  Zap, HeadphonesIcon, TrendingUp,
} from "lucide-react";
import { motion } from "framer-motion";
import { useTranslation } from "react-i18next";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";
import { useGetPublicPage } from "@/lib/apiClient";
import { usePageContent } from "@/lib/usePageContent";

/* ── IT Services — all sub-pages now live ────────────────────── */
const IT_SERVICES = [
  {
    icon: Globe,
    title: "Web Development",
    color: "#E84821",
    bg: "#FFF4F1",
    href: "/services/web-development",
    desc: "Corporate websites, eCommerce platforms, business portals, and custom web applications built for performance and scale.",
    features: ["Corporate Websites", "eCommerce Stores", "Business Portals", "CMS Development", "UI/UX Design"],
  },
  {
    icon: Smartphone,
    title: "Mobile Apps",
    color: "#3D4FA0",
    bg: "#F0F3FF",
    href: "/services/mobile-apps",
    desc: "Native Android & iOS apps, cross-platform solutions, and enterprise mobile applications with offline capability.",
    features: ["Android & iOS Apps", "Cross-Platform (Flutter)", "Enterprise Mobile", "PWA Development", "App Maintenance"],
  },
  {
    icon: Code2,
    title: "Custom Software",
    color: "#D4920C",
    bg: "#FFFBEB",
    href: "/services/custom-software",
    desc: "Bespoke business software — ERPs, CRMs, automation tools, and workflow systems tailored to your operations.",
    features: ["Business Automation", "ERP & CRM Systems", "API Development", "System Integration", "Legacy Modernization"],
  },
  {
    icon: Cloud,
    title: "Cloud Solutions",
    color: "#059669",
    bg: "#ECFDF5",
    href: "/services/cloud-solutions",
    desc: "Cloud migration, managed infrastructure, DevOps, and multi-cloud architecture across AWS, Azure, and GCP.",
    features: ["Cloud Migration", "Managed Infrastructure", "DevOps & CI/CD", "Cloud Security", "Cost Optimisation"],
  },
  {
    icon: Shield,
    title: "Cybersecurity",
    color: "#7C3AED",
    bg: "#F5F3FF",
    href: "/services/cybersecurity",
    desc: "End-to-end cybersecurity — vulnerability assessments, endpoint protection, 24×7 threat monitoring, and compliance.",
    features: ["Vulnerability Assessment", "Compliance (ISO/GDPR)", "Endpoint Protection", "SIEM & SOC", "Incident Response"],
  },
  {
    icon: Lightbulb,
    title: "IT Consulting",
    color: "#B45309",
    bg: "#FFF8EC",
    href: "/services/it-consulting",
    desc: "Strategic technology consulting: IT strategy, digital roadmap, vendor selection, ROI analysis, and process automation.",
    features: ["Technology Strategy", "Digital Roadmap", "Vendor Selection", "Process Automation", "AI & BI Integration"],
  },
  {
    icon: TrendingUp,
    title: "Digital Marketing",
    color: "#0891B2",
    bg: "#ECFEFF",
    href: "/services/digital-marketing",
    desc: "Data-driven digital marketing — SEO, PPC, social media, AI-powered automation, and content strategies that deliver measurable ROI.",
    features: ["Search Engine Optimisation", "Google & Social Ads", "Social Media Marketing", "Content Marketing", "AI Marketing Automation"],
  },
];

/* ── ERP & SAP Solutions ─────────────────────────────────────── */
const ERP_SERVICES = [
  {
    icon: LayoutGrid,
    title: "SAP Business One",
    color: "#E84821",
    href: "/sap-business-one",
    desc: "Complete ERP for SMEs — finance, inventory, sales, and production on a single integrated platform.",
  },
  {
    icon: Database,
    title: "SAP Business One HANA",
    color: "#3D4FA0",
    href: "/sap-business-one-hana",
    desc: "High-performance SAP B1 on in-memory HANA database for real-time analytics and faster processing.",
  },
  {
    icon: Cloud,
    title: "SAP B1 on Cloud",
    color: "#059669",
    href: "/sap-b1-on-cloud",
    desc: "Cloud-hosted SAP Business One — flexible, scalable, and accessible from anywhere with zero infrastructure overhead.",
  },
  {
    icon: Layers,
    title: "RISE with SAP",
    color: "#7C3AED",
    href: "/rise-with-sap",
    desc: "Business transformation as a service — migrate to S/4HANA cloud with SAP's RISE subscription model.",
  },
  {
    icon: Building2,
    title: "SAP S/4HANA",
    color: "#0F766E",
    href: "/s4-hana",
    desc: "Enterprise-grade next-generation ERP on S/4HANA — the digital core for large organisations.",
  },
  {
    icon: Zap,
    title: "ERP Solutions Overview",
    color: "#D4920C",
    href: "/services/erp-solutions",
    desc: "Full-cycle SAP ERP implementation, consulting, customisation, migration, and go-live support across India.",
  },
  {
    icon: Package,
    title: "WMS 360",
    color: "#B45309",
    href: "/wms360",
    desc: "India's most advanced Warehouse Management System with OMS, mobile apps, and native SAP B1 integration.",
  },
  {
    icon: Wrench,
    title: "SAP Support Services",
    color: "#DC2626",
    href: "/support-service",
    desc: "Dedicated SAP AMC, upgrades, 24×7 functional helpdesk, and SLA-backed support across India & UK.",
  },
];

/* ── Why Choose ─────────────────────────────────────────────── */
const WHY = [
  "Certified SAP Professionals with 15+ years of experience",
  "500+ successful implementations across India & UK",
  "End-to-end delivery — from strategy to go-live and beyond",
  "Dedicated support team with rapid SLA response",
  "India-specific compliance — GST, TDS, e-invoicing built-in",
  "Transparent pricing with no hidden costs",
];

/* ── Quick links to all sub-pages ───────────────────────────── */
const ALL_PAGES = [
  { label: "Web Development", href: "/services/web-development", color: "#E84821" },
  { label: "Mobile Apps", href: "/services/mobile-apps", color: "#3D4FA0" },
  { label: "Custom Software", href: "/services/custom-software", color: "#D4920C" },
  { label: "Cloud Solutions", href: "/services/cloud-solutions", color: "#059669" },
  { label: "Cybersecurity", href: "/services/cybersecurity", color: "#7C3AED" },
  { label: "IT Consulting", href: "/services/it-consulting", color: "#B45309" },
  { label: "Digital Marketing", href: "/services/digital-marketing", color: "#0891B2" },
  { label: "ERP Solutions", href: "/services/erp-solutions", color: "#E84821" },
  { label: "SAP Business One", href: "/sap-business-one", color: "#3D4FA0" },
  { label: "B1Plus Cloud", href: "/b1plus-cloud", color: "#059669" },
  { label: "WMS 360", href: "/wms360", color: "#D4920C" },
];

export default function ServicesPage() {
  const { t } = useTranslation();
  const config = useSiteConfig();
  const { data: cmsPage } = useGetPublicPage("services");
  const { field, blocks } = usePageContent("services");
  const { primaryColor, accentColor } = config;

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Service",
    name: `${config.siteName} — Services`,
    url: typeof window !== "undefined" ? window.location.href : "",
    description: "Comprehensive IT services: web development, mobile apps, custom software, cloud, cybersecurity, SAP ERP, and IT consulting.",
  };

  return (
    <PublicLayout>
      <SEO
        title={cmsPage?.metaTitle ?? "Our Services — IT, ERP & SAP Solutions"}
        description={cmsPage?.metaDescription ?? "Comprehensive technology solutions: web development, mobile apps, custom software, cloud, cybersecurity, SAP ERP, and IT consulting for Indian businesses."}
        jsonLd={jsonLd}
      />

      {/* ── HERO ────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden" style={{ background: "linear-gradient(140deg, #0d1225 0%, #1A1F36 55%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 1200 520" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="960" cy="260" r="340" stroke="#E84821" strokeWidth="0.8" strokeDasharray="12 8"/>
          <circle cx="960" cy="260" r="200" stroke={primaryColor} strokeWidth="0.5" strokeDasharray="6 10"/>
          <rect x="820" y="60" width="160" height="160" rx="22" stroke="#3D4FA0" strokeWidth="0.6" strokeDasharray="8 6"/>
          <path d="M0 380 Q300 330 600 360 Q900 390 1200 350" stroke="white" strokeWidth="0.5" fill="none" strokeDasharray="7 7"/>
          {[[60,55],[190,290],[320,85],[220,195],[510,330],[640,110],[770,265]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-7 L2-2.5 L7-2.5 L3.5 2 L5 7 L0 4 L-5 7 L-3.5 2 L-7-2.5 L-2-2.5Z" fill="white" opacity="0.45"/>
            </g>
          ))}
          <path d="M-10 140 L80 110 L170 160 L270 120 L360 155" stroke={primaryColor} strokeWidth="0.5" strokeDasharray="5 8" fill="none"/>
        </svg>

        <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-22">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <div className="inline-flex items-center gap-2 mb-4 px-3 py-1.5 rounded-full border border-[#E84821]/40 bg-[#E84821]/12">
                <Lightbulb size={13} className="text-[#E84821]"/>
                <span className="text-xs font-black uppercase tracking-widest text-[#E84821]">{field("hero_eyebrow", "What We Do")}</span>
              </div>
              <h1 className="text-4xl sm:text-5xl font-black leading-[1.06] text-white mb-3">
                Comprehensive IT &<br/>
                <span style={{ color: primaryColor }}>ERP Services</span><br/>
                <span className="text-white/80 text-3xl sm:text-4xl font-bold">for India & the UK</span>
              </h1>
              <div className="flex gap-2 my-5">
                <span className="h-1 w-12 rounded-full bg-[#E84821]"/>
                <span className="h-1 w-7 rounded-full" style={{ backgroundColor: primaryColor }}/>
                <span className="h-1 w-4 rounded-full bg-[#3D4FA0]"/>
              </div>
              <p className="text-gray-300 text-sm leading-relaxed mb-2 max-w-lg">
                {field("hero_desc1", "From building modern websites and mobile apps to implementing SAP ERP — we deliver end-to-end technology solutions that help businesses across India and the UK scale, automate, and lead.")}
              </p>
              {blocks.hero_desc2 ? (
                <p className="text-gray-400 text-sm leading-relaxed mb-8 max-w-lg">{blocks.hero_desc2}</p>
              ) : (
                <p className="text-gray-400 text-sm leading-relaxed mb-8 max-w-lg">
                  <strong className="text-white">15+ years of expertise</strong> across IT services, SAP implementations, and digital transformation for 500+ businesses.
                </p>
              )}
              <div className="flex flex-wrap gap-3">
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 shadow-lg transition-all text-sm">
                  Get a Free Consultation <ArrowRight size={15}/>
                </Link>
                <Link href="/portfolio" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
                  View Our Work <ChevronRight size={14}/>
                </Link>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.12 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10">
                <img
                  src={field("hero_image", cmsPage?.heroImage ?? "https://images.unsplash.com/photo-1531403009284-440f080d1e12?auto=format&fit=crop&w=800&q=80")}
                  alt="CtrlA Tech Solutions IT and SAP services"
                  className="w-full h-64 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/80 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse flex-shrink-0"/>
                    <span className="text-white text-xs font-semibold">IT Services + ERP & SAP Solutions under one roof</span>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3 mt-4">
                {[{ n: "500+", label: "Projects" }, { n: "15+", label: "Years" }, { n: "8+", label: "Industries" }].map(s => (
                  <div key={s.label} className="bg-white/5 border border-white/10 rounded-xl p-3 text-center">
                    <div className="text-2xl font-black text-white">{s.n}</div>
                    <div className="text-white/50 text-xs mt-0.5">{s.label}</div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>

        {/* Quick nav to all sub-pages */}
        <div className="relative border-t border-white/10 bg-white/4">
          <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex flex-wrap gap-2 items-center">
              <span className="text-white/40 text-xs font-semibold mr-1 uppercase tracking-widest">Explore:</span>
              {ALL_PAGES.map(p => (
                <Link key={p.href} href={p.href}
                  className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold border border-white/15 text-white/70 hover:text-white hover:border-white/40 transition-all">
                  <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: p.color }}/>
                  {p.label}
                </Link>
              ))}
            </div>
          </div>
        </div>

        <div className="h-1 flex">
          <div className="flex-[3] bg-[#E84821]"/><div className="flex-[2]" style={{ backgroundColor: primaryColor }}/><div className="flex-1 bg-[#3D4FA0]"/>
        </div>
      </section>

      {/* ── IT SERVICES ─────────────────────────────────────────────── */}
      <section className="py-16 md:py-20 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 700" preserveAspectRatio="xMidYMid slice">
          {Array.from({length:20}).map((_,r)=>Array.from({length:26}).map((_,c)=>(
            <circle key={`${r}-${c}`} cx={c*35+17} cy={r*35+17} r="1.6" fill="#3D4FA0"/>
          )))}
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">IT Services</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold" style={{ color: accentColor }}>Software & Technology Services</h2>
            <p className="text-gray-500 text-sm mt-2 max-w-xl mx-auto">Modern, scalable technology solutions built for every stage of your digital journey. Each service has a dedicated page with full details.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {IT_SERVICES.map((s, i) => {
              const Icon = s.icon;
              return (
                <motion.div key={s.title} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.07 }}>
                  <Link href={s.href}
                    className="group flex flex-col h-full bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                    <div className="h-1.5 w-full" style={{ backgroundColor: s.color }}/>
                    <div className="p-6 flex flex-col flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: s.bg }}>
                          <Icon size={20} style={{ color: s.color }}/>
                        </div>
                        <div>
                          <h3 className="font-bold text-gray-900 text-sm group-hover:text-[#D4920C] transition-colors leading-tight">{s.title}</h3>
                          <span className="text-[10px] font-bold text-[#E84821]">Full Details →</span>
                        </div>
                      </div>
                      <p className="text-gray-500 text-xs leading-relaxed mb-4 flex-1">{s.desc}</p>
                      <div className="space-y-1">
                        {s.features.map(f => (
                          <div key={f} className="flex items-center gap-1.5 text-xs text-gray-600">
                            <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: s.color }}/>
                            {f}
                          </div>
                        ))}
                      </div>
                      <div className="mt-4 flex items-center gap-1 text-xs font-semibold group-hover:gap-2 transition-all" style={{ color: s.color }}>
                        Learn more <ArrowRight size={12} className="group-hover:translate-x-0.5 transition-transform"/>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── ERP & SAP SOLUTIONS ─────────────────────────────────────── */}
      <section className="py-16 md:py-20 bg-white border-t border-gray-100 relative overflow-hidden">
        <svg className="absolute -right-16 inset-y-0 h-full opacity-[0.04]" viewBox="0 0 300 600" fill="none">
          <circle cx="250" cy="300" r="220" stroke="#3D4FA0" strokeWidth="1.5" strokeDasharray="8 6"/>
          <circle cx="250" cy="300" r="140" stroke="#E84821" strokeWidth="1" strokeDasharray="5 8"/>
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">ERP & SAP Solutions</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold" style={{ color: accentColor }}>SAP & Enterprise Resource Planning</h2>
            <p className="text-gray-500 text-sm mt-2 max-w-xl mx-auto">Certified SAP professionals delivering end-to-end ERP implementation, migration, and support across India.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {ERP_SERVICES.map((s, i) => {
              const Icon = s.icon;
              return (
                <motion.div key={s.title} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.06 }}>
                  <Link href={s.href}
                    className="group flex flex-col h-full bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                    <div className="h-1.5 w-full" style={{ backgroundColor: s.color }}/>
                    <div className="p-5 flex flex-col flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="p-2 rounded-lg flex-shrink-0" style={{ backgroundColor: `${s.color}15` }}>
                          <Icon size={18} style={{ color: s.color }}/>
                        </div>
                        <h3 className="font-bold text-gray-900 text-sm group-hover:text-[#D4920C] transition-colors leading-tight">{s.title}</h3>
                      </div>
                      <p className="text-gray-500 text-xs leading-relaxed flex-1">{s.desc}</p>
                      <div className="mt-4 flex items-center gap-1 text-xs font-semibold" style={{ color: s.color }}>
                        Learn more <ArrowUpRight size={12} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform"/>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── WHY CTRLA ────────────────────────────────────────────────── */}
      <section className="py-16 relative overflow-hidden border-t border-gray-100" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #EFF2FF 100%)" }}>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-14 items-center">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why CtrlA Tech Solutions?</span>
              </div>
              <h2 className="text-3xl font-bold mb-4" style={{ color: accentColor }}>
                Your trusted technology partner<br/>
                <span style={{ color: "#E84821" }}>from strategy to go-live</span>
              </h2>
              <p className="text-gray-500 text-sm leading-relaxed mb-6">
                We combine deep SAP expertise with modern software engineering to deliver end-to-end solutions that drive measurable business outcomes — not just technology for technology's sake.
              </p>
              <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white shadow-lg hover:-translate-y-0.5 transition-all text-sm" style={{ backgroundColor: primaryColor }}>
                Start a Conversation <ArrowRight size={15}/>
              </Link>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="space-y-3">
                {WHY.map((w, i) => (
                  <motion.div key={w} initial={{ opacity: 0, x: 12 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.07 }}
                    className="flex items-center gap-3 p-3 rounded-xl bg-white border border-gray-100 hover:border-[#E84821]/30 hover:bg-[#E84821]/3 transition-all">
                    <div className="w-9 h-9 rounded-lg flex items-center justify-center bg-[#E84821]/10 flex-shrink-0">
                      <CheckCircle2 size={15} className="text-[#E84821]"/>
                    </div>
                    <span className="text-sm font-semibold text-gray-700">{w}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>


      {/* ── CTA ─────────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 900 280" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="820" cy="140" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          {[[80,50],[200,210],[370,60],[520,190]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-5 L2-2 L5-2 L3 2 L4 5 L0 3 L-4 5 L-3 2 L-5-2 L-2-2Z" fill="white" opacity="0.5"/>
            </g>
          ))}
        </svg>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <h2 className="text-3xl font-bold text-white mb-3">Ready to Transform Your Business?</h2>
          <p className="text-gray-400 text-sm mb-8 max-w-2xl mx-auto leading-relaxed">
            Whether you need a new website, a mobile app, an SAP ERP implementation, cloud infrastructure, cybersecurity protection, or end-to-end IT consulting — CtrlA Tech Solutions has the expertise to deliver.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 transition-all text-sm shadow-xl">
              Get a Free Consultation <ArrowRight size={15}/>
            </Link>
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
              View Portfolio <ChevronRight size={14}/>
            </Link>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1 flex">
          <div className="flex-[3] bg-[#E84821]"/>
          <div className="flex-[2]" style={{ backgroundColor: primaryColor }}/>
          <div className="flex-1 bg-[#3D4FA0]"/>
        </div>
      </section>
    </PublicLayout>
  );
}
