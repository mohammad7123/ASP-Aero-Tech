import { motion } from "framer-motion";
import { Link } from "wouter";
import { ExternalLink, ArrowRight } from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import PageHero from "@/components/public/PageHero";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";
import { useListPublicPortfolio } from "@/lib/apiClient";

export default function PortfolioPage() {
  const config = useSiteConfig();
  const { data: items = [], isLoading } = useListPublicPortfolio();

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name: `Portfolio — ${config.siteName}`,
    url: typeof window !== "undefined" ? window.location.href : "",
    description: "Case studies and portfolio of technology projects delivered by CtrlA Tech Solutions.",
  };

  return (
    <PublicLayout>
      <SEO
        title="Portfolio"
        description="Explore our case studies and portfolio of successful technology projects delivered across India and beyond."
        jsonLd={jsonLd}
      />

      <PageHero
        eyebrow="Our Work"
        title={<>Our <span style={{ color: "#E84821" }}>Portfolio</span></>}
        subtitle="Explore our case studies and successful projects delivered for clients across India and beyond."
        heroImage="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&w=1200&q=80"
        heroImageAlt="Team reviewing project work on screens"
      />

      <section className="py-16 bg-gray-50">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="bg-white rounded-2xl h-72 animate-pulse border border-gray-100" />
              ))}
            </div>
          ) : items.length === 0 ? (
            <div className="text-center py-16">
              <p className="text-gray-400 text-lg">No case studies published yet.</p>
              <Link href="/contact" className="inline-flex items-center gap-2 mt-6 bg-[#E84821] text-white px-6 py-3 rounded-xl font-bold hover:bg-[#c73d1a] transition-all">
                Discuss your project <ArrowRight size={16} />
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {items.map((item, i) => {
                const techs = item.technologies
                  ? item.technologies.split(",").map(t => t.trim()).filter(Boolean)
                  : [];
                return (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.07 }}
                    viewport={{ once: true }}
                    className="bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-lg hover:border-[#D4920C]/30 transition-all group"
                  >
                    {item.featuredImage ? (
                      <div className="h-48 overflow-hidden">
                        <img
                          src={item.featuredImage}
                          alt={item.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      </div>
                    ) : (
                      <div className="h-48 bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center border-b border-gray-100">
                        <span className="text-[#E84821] text-5xl font-bold opacity-40">{item.title.charAt(0)}</span>
                      </div>
                    )}
                    <div className="p-6">
                      {item.clientName && (
                        <p className="text-[#E84821] text-xs font-semibold uppercase tracking-wider mb-2">{item.clientName}</p>
                      )}
                      <h3 className="text-lg font-bold text-[#1A1F36] mb-2">{item.title}</h3>
                      {item.description && (
                        <p className="text-gray-600 text-sm mb-4 line-clamp-2">{item.description}</p>
                      )}
                      {techs.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 mb-4">
                          {techs.slice(0, 4).map(t => (
                            <span key={t} className="px-2 py-0.5 bg-[#E84821]/10 text-[#E84821] text-xs rounded-md font-medium">{t}</span>
                          ))}
                        </div>
                      )}
                      <div className="flex items-center gap-3 mt-auto pt-2">
                        <Link href={`/portfolio/${item.slug}`} className="text-sm font-semibold text-[#1A1F36] hover:text-[#D4920C] transition-colors flex items-center gap-1">
                          View Case Study <ArrowRight size={14} />
                        </Link>
                        {item.projectUrl && (
                          <a href={item.projectUrl} target="_blank" rel="noopener noreferrer" className="ml-auto text-gray-400 hover:text-[#D4920C] transition-colors">
                            <ExternalLink size={16} />
                          </a>
                        )}
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      <section className="relative bg-white py-16 border-t border-gray-100">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4" style={{ color: config.accentColor }}>Start Your Success Story</h2>
          <p className="text-gray-600 mb-8 max-w-xl mx-auto">
            Ready to join our portfolio of successful projects? Let's discuss what we can build together.
          </p>
          <Link href="/contact" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-lg font-bold text-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5" style={{ backgroundColor: config.primaryColor }}>
            Get in Touch <ArrowRight size={18} />
          </Link>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1 flex">
          <div className="flex-[3] bg-[#E84821]" />
          <div className="flex-[2]" style={{ backgroundColor: config.primaryColor }} />
          <div className="flex-1 bg-[#3D4FA0]" />
        </div>
      </section>
    </PublicLayout>
  );
}
