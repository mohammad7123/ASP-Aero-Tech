import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Star, Quote, ExternalLink, Building2, Users } from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { useSiteConfig } from "@/contexts/SiteConfigContext";
import { SEO } from "@/components/SEO";

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";

type CmsPage = { metaTitle?: string | null; metaDescription?: string | null };
async function fetchCmsPage(slug: string): Promise<CmsPage> {
  const res = await fetch(`${BASE}/api/pages/${slug}`);
  if (!res.ok) return {};
  return res.json();
}

type Client = {
  id: number;
  name: string;
  logoUrl: string | null;
  websiteUrl: string | null;
  industry: string | null;
  testimonial: string | null;
  testimonialPerson: string | null;
  testimonialRole: string | null;
};

async function fetchClients(): Promise<Client[]> {
  const base = import.meta.env.BASE_URL.replace(/\/$/, "");
  const res = await fetch(`${base}/api/public/clients`);
  if (!res.ok) throw new Error("Failed to fetch clients");
  return res.json();
}

export default function ClientsPage() {
  const config = useSiteConfig();
  const primary = config.primaryColor ?? "#D4920C";
  const accent = config.accentColor ?? "#1A1F36";

  const { data: clients = [], isLoading } = useQuery<Client[]>({
    queryKey: ["public-clients"],
    queryFn: fetchClients,
  });

  const { data: cmsPage } = useQuery<CmsPage>({
    queryKey: ["pages", "clients"],
    queryFn: () => fetchCmsPage("clients"),
    staleTime: 60_000,
  });

  const withTestimonials = clients.filter(c => c.testimonial);
  const logoClients = clients;

  return (
    <PublicLayout>
      <SEO
        title={cmsPage?.metaTitle ?? "Our Clients — CtrlA Tech Solutions"}
        description={cmsPage?.metaDescription ?? "Trusted by 500+ businesses across India and the UK. See our client portfolio and testimonials."}
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "WebPage",
          name: cmsPage?.metaTitle ?? "Our Clients — CtrlA Tech Solutions",
          description: cmsPage?.metaDescription ?? "Trusted by 500+ businesses across India and the UK. See our client portfolio and testimonials.",
          url: window.location.href,
          publisher: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
        }}
      />
      {/* Hero */}
      <div className="bg-gradient-to-br from-[#1A1F36] via-[#2a3366] to-[#3D4FA0] pt-28 pb-20 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-20 w-72 h-72 rounded-full bg-white/20 blur-3xl" />
          <div className="absolute bottom-10 right-20 w-96 h-96 rounded-full blur-3xl" style={{ backgroundColor: `${primary}40` }} />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 relative">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold mb-6 bg-white/15 backdrop-blur-sm">
              <Users size={12} /> Our Valued Clients
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-5 leading-tight">
              Trusted by <span style={{ color: primary }}>Leading Businesses</span>
              <br />Across India &amp; the UK
            </h1>
            <p className="text-white/75 text-lg max-w-2xl leading-relaxed">
              We partner with enterprises, SMEs, and growing businesses to deliver transformative SAP and technology solutions that drive real results.
            </p>
            <div className="flex flex-wrap gap-8 mt-10">
              {[
                { value: "500+", label: "Happy Clients" },
                { value: "15+", label: "Industries Served" },
                { value: "98%", label: "Client Retention" },
              ].map(s => (
                <div key={s.label}>
                  <div className="text-3xl font-bold" style={{ color: primary }}>{s.value}</div>
                  <div className="text-sm text-white/60 font-medium mt-0.5">{s.label}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      {/* Client Logos Grid */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <div className="text-xs font-bold uppercase tracking-widest mb-3" style={{ color: primary }}>Our Clients</div>
            <h2 className="text-3xl font-bold text-gray-900">Companies That Trust Us</h2>
            <div className="mt-3 flex items-center justify-center gap-1.5">
              <div className="h-1 w-10 rounded-full bg-[#E84821]" />
              <div className="h-1 w-6 rounded-full" style={{ backgroundColor: primary }} />
              <div className="h-1 w-3 rounded-full bg-[#3D4FA0]" />
            </div>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
              {Array.from({ length: 10 }).map((_, i) => (
                <div key={i} className="h-24 bg-white rounded-xl border border-gray-100 animate-pulse" />
              ))}
            </div>
          ) : logoClients.length === 0 ? (
            <div className="text-center py-20">
              <Building2 size={48} className="mx-auto text-gray-300 mb-4" />
              <p className="text-gray-400 text-lg">Client showcase coming soon</p>
              <p className="text-gray-300 text-sm mt-1">Our client logos and testimonials will appear here</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-5">
              {logoClients.map((client, i) => (
                <motion.div
                  key={client.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true, margin: "-40px" }}
                  transition={{ duration: 0.3, delay: i * 0.04 }}
                >
                  {client.websiteUrl ? (
                    <a href={client.websiteUrl} target="_blank" rel="noopener noreferrer" className="group block">
                      <ClientLogoCard client={client} />
                    </a>
                  ) : (
                    <ClientLogoCard client={client} />
                  )}
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Testimonials */}
      {withTestimonials.length > 0 && (
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-14">
              <div className="text-xs font-bold uppercase tracking-widest mb-3" style={{ color: primary }}>Testimonials</div>
              <h2 className="text-3xl font-bold" style={{ color: accent }}>What Our Clients Say</h2>
              <div className="mt-3 flex items-center justify-center gap-1.5">
                <div className="h-1 w-10 rounded-full bg-[#E84821]" />
                <div className="h-1 w-6 rounded-full" style={{ backgroundColor: primary }} />
                <div className="h-1 w-3 rounded-full bg-[#3D4FA0]" />
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {withTestimonials.map((client, i) => (
                <motion.div
                  key={client.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-50px" }}
                  transition={{ duration: 0.4, delay: i * 0.08 }}
                  className="bg-white rounded-2xl border border-gray-100 p-7 shadow-sm hover:shadow-lg transition-shadow relative"
                >
                  <div className="absolute top-5 right-6 opacity-10">
                    <Quote size={48} style={{ color: accent }} />
                  </div>
                  <div className="flex gap-1 mb-5">
                    {Array.from({ length: 5 }).map((_, j) => (
                      <Star key={j} size={14} className="fill-current text-amber-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-sm leading-relaxed mb-6 italic">
                    "{client.testimonial}"
                  </p>
                  <div className="flex items-center gap-3 pt-4 border-t border-gray-50">
                    {client.logoUrl ? (
                      <img src={client.logoUrl} alt={client.name} className="w-10 h-10 rounded-lg object-contain border border-gray-100 bg-white" />
                    ) : (
                      <div className="w-10 h-10 rounded-lg flex items-center justify-center text-white text-sm font-bold flex-shrink-0" style={{ backgroundColor: accent }}>
                        {client.name[0]}
                      </div>
                    )}
                    <div>
                      <div className="font-bold text-gray-900 text-sm">{client.testimonialPerson ?? client.name}</div>
                      {client.testimonialRole && (
                        <div className="text-xs text-gray-500">{client.testimonialRole}</div>
                      )}
                      {client.industry && (
                        <div className="text-xs font-semibold mt-0.5" style={{ color: primary }}>{client.industry}</div>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA */}
      <section className="py-16 bg-gray-50 border-t border-gray-100">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-3">Ready to Join Our Client Family?</h2>
          <p className="text-gray-500 mb-8">Let's discuss how {config.siteName} can transform your business with the right technology.</p>
          <a
            href="/contact"
            className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl text-sm font-bold text-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5"
            style={{ backgroundColor: primary }}
          >
            Start a Conversation <ExternalLink size={15} />
          </a>
        </div>
      </section>
    </PublicLayout>
  );
}

function ClientLogoCard({ client }: { client: Client }) {
  return (
    <div className="group flex flex-col items-center justify-center gap-3 bg-white rounded-xl border border-gray-100 p-5 h-24 hover:border-[#D4920C]/40 hover:shadow-md transition-all">
      {client.logoUrl ? (
        <img
          src={client.logoUrl}
          alt={client.name}
          className="max-h-12 max-w-full object-contain filter grayscale group-hover:grayscale-0 transition-all duration-300"
        />
      ) : (
        <div className="text-sm font-bold text-gray-600 group-hover:text-[#D4920C] text-center transition-colors leading-tight px-2">
          {client.name}
        </div>
      )}
    </div>
  );
}
