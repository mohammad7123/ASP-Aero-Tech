import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowRight, Cloud, CheckCircle2, Server, Shield,
  HardDrive, ArrowUpRight, ChevronRight, Zap,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";
import ProductItemModal from "@/components/public/ProductItemModal";
import { getIcon } from "@/lib/iconMap";
import type { ProductItem } from "@/types/productItem";

const BENEFITS = [
  "99.9% uptime SLA guarantee",
  "Indian data residency available",
  "24×7 NOC monitoring and support",
  "Auto-scaling for peak workloads",
  "Cost optimisation & reserved instance planning",
  "Compliance: ISO 27001, SOC 2 certified partners",
];

/* Products with dedicated pages */
const PRODUCT_PAGE_MAP: Record<string, string> = {
  "B1Plus Cloud": "/b1plus-cloud",
  "B1PlusCloud":  "/b1plus-cloud",
  "b1plus-cloud": "/b1plus-cloud",
};

function getProductPageUrl(product: ProductItem): string | null {
  for (const [key, url] of Object.entries(PRODUCT_PAGE_MAP)) {
    if (
      product.name?.toLowerCase().includes(key.toLowerCase()) ||
      (product as any).slug?.toLowerCase().includes(key.toLowerCase())
    ) return url;
  }
  return null;
}

/* Static featured products (shown even when DB is empty / loading) */
const FEATURED_PRODUCTS = [
  {
    icon: Server,
    title: "B1Plus Cloud",
    color: "#D4920C",
    bg: "#FFFBEB",
    href: "/b1plus-cloud",
    desc: "Purpose-built managed cloud for SAP Business One — Tier III/IV data centers, HA infrastructure, automatic backups, and 24×7 support.",
    badge: "SAP-Ready",
    hasPage: true,
  },
  {
    icon: Cloud,
    title: "Managed AWS Hosting",
    color: "#FF9900",
    bg: "#FFF8EB",
    href: "/contact",
    desc: "Fully managed Amazon Web Services infrastructure — EC2, S3, RDS, VPC, and Auto Scaling with 24×7 NOC monitoring.",
    badge: null,
    hasPage: false,
  },
  {
    icon: Cloud,
    title: "Managed Azure Hosting",
    color: "#0078D4",
    bg: "#EEF6FF",
    href: "/contact",
    desc: "Enterprise Microsoft Azure infrastructure management — VMs, Azure SQL, Active Directory, Kubernetes, and Azure Backup.",
    badge: null,
    hasPage: false,
  },
  {
    icon: HardDrive,
    title: "Backup & Disaster Recovery",
    color: "#7C3AED",
    bg: "#F5F3FF",
    href: "/contact",
    desc: "Automated daily backups, geo-redundant storage, DR planning, and rapid recovery to protect your critical business data.",
    badge: null,
    hasPage: false,
  },
];

export default function ProductsCloudPage() {
  const config = useSiteConfig();
  const primary = config.primaryColor;
  const accent = config.accentColor;
  const [selected, setSelected] = useState<ProductItem | null>(null);

  const base = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";
  const { data: items = [], isLoading } = useQuery<ProductItem[]>({
    queryKey: ["product-items", "cloud-platforms"],
    queryFn: () => fetch(`${base}/api/public/product-items?category=cloud-platforms`).then(r => r.json()),
  });

  return (
    <PublicLayout>
      <SEO
        title="Cloud Platforms — Managed AWS, Azure & SAP Cloud | CtrlA Tech Solutions"
        description="8 cloud platform products including B1Plus Cloud, Managed AWS & Azure hosting, Backup & DR, High Availability, and Cloud Migration from CtrlA Tech Solutions."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "Cloud Platforms — CtrlA Tech Solutions",
          description: "8 cloud platform products including B1Plus Cloud, Managed AWS & Azure hosting, Backup & DR, High Availability, and Cloud Migration from CtrlA Tech Solutions.",
          url: window.location.href,
          publisher: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
        }}
      />

      {/* ── HERO ─────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden" style={{ background: "linear-gradient(140deg, #0d1225 0%, #1A1F36 55%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 1200 520" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="970" cy="260" r="340" stroke="#059669" strokeWidth="0.8" strokeDasharray="12 8"/>
          <circle cx="970" cy="260" r="200" stroke={primary} strokeWidth="0.5" strokeDasharray="6 10"/>
          <rect x="810" y="60" width="160" height="160" rx="22" stroke="#D4920C" strokeWidth="0.6" strokeDasharray="8 6"/>
          <path d="M0 380 Q300 330 600 360 Q900 390 1200 350" stroke="white" strokeWidth="0.5" fill="none" strokeDasharray="7 7"/>
          {[[60,55],[190,290],[320,85],[220,195],[510,330],[640,110],[770,265]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-7 L2-2.5 L7-2.5 L3.5 2 L5 7 L0 4 L-5 7 L-3.5 2 L-7-2.5 L-2-2.5Z" fill="white" opacity="0.45"/>
            </g>
          ))}
        </svg>

        <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-22">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <Link href="/products" className="inline-flex items-center gap-1.5 text-white/40 text-xs mb-5 hover:text-white/70 transition-colors">← Products</Link>
              <div className="inline-flex items-center gap-2 mb-4 px-3 py-1.5 rounded-full border border-[#059669]/40 bg-[#059669]/12">
                <Cloud size={13} className="text-[#059669]"/>
                <span className="text-xs font-black uppercase tracking-widest text-[#059669]">Cloud Platforms</span>
              </div>
              <h1 className="text-4xl sm:text-5xl font-black leading-[1.06] text-white mb-3">
                Managed Cloud<br/>
                <span style={{ color: primary }}>Infrastructure</span><br/>
                <span className="text-white/80 text-3xl sm:text-4xl font-bold">Built for Reliability</span>
              </h1>
              <div className="flex gap-2 my-5">
                <span className="h-1 w-12 rounded-full bg-[#E84821]"/>
                <span className="h-1 w-7 rounded-full" style={{ backgroundColor: primary }}/>
                <span className="h-1 w-4 rounded-full bg-[#3D4FA0]"/>
              </div>
              <p className="text-gray-300 text-sm leading-relaxed mb-3 max-w-lg">
                Fully managed cloud infrastructure for SAP and enterprise workloads — on AWS, Azure, or our dedicated SAP cloud platform, B1Plus Cloud.
              </p>
              <p className="text-gray-400 text-sm leading-relaxed mb-8 max-w-lg">
                <strong className="text-white">AWS & Azure certified engineers</strong> proactively monitor, optimize, and secure your cloud infrastructure 24×7.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 shadow-lg transition-all text-sm">
                  Get Cloud Assessment <ArrowRight size={15}/>
                </Link>
                <Link href="/b1plus-cloud" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
                  Explore B1Plus Cloud <ChevronRight size={14}/>
                </Link>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.12 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10">
                <img src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=700&q=80" alt="Cloud Infrastructure" className="w-full h-60 object-cover"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/80 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse flex-shrink-0"/>
                    <span className="text-white text-xs font-semibold">AWS · Azure · B1Plus Cloud</span>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3 mt-4">
                {[{ n: "100+", label: "Migrations" }, { n: "99.9%", label: "Uptime SLA" }, { n: "24×7", label: "NOC" }].map(s => (
                  <div key={s.label} className="bg-white/5 border border-white/10 rounded-xl p-3 text-center">
                    <div className="text-xl font-black text-white">{s.n}</div>
                    <div className="text-white/50 text-xs mt-0.5">{s.label}</div>
                  </div>
                ))}
              </div>

              {/* benefits */}
              <div className="mt-4 grid grid-cols-2 gap-1.5">
                {BENEFITS.map(b => (
                  <div key={b} className="flex items-center gap-1.5 text-xs text-white/60">
                    <CheckCircle2 size={11} className="text-[#059669] flex-shrink-0"/>
                    {b}
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
        <div className="h-1 flex">
          <div className="flex-[3] bg-[#E84821]"/><div className="flex-[2]" style={{ backgroundColor: primary }}/><div className="flex-1 bg-[#3D4FA0]"/>
        </div>
      </section>

      {/* ── FEATURED PRODUCTS ────────────────────────────────────────── */}
      <section className="py-16 md:py-20 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #ECFDF5 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 500" preserveAspectRatio="xMidYMid slice">
          {Array.from({length:14}).map((_,r)=>Array.from({length:26}).map((_,c)=>(
            <circle key={`${r}-${c}`} cx={c*35+17} cy={r*35+17} r="1.6" fill="#059669"/>
          )))}
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Cloud Platforms</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold" style={{ color: accent }}>B1Plus Cloud · AWS · Azure · Backup & DR</h2>
            <p className="text-gray-400 text-sm mt-2">View all 8 products →</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-6">
            {FEATURED_PRODUCTS.map((p, i) => {
              const Icon = p.icon;
              return (
                <motion.div key={p.title} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }}>
                  {p.hasPage ? (
                    <Link href={p.href}
                      className="group flex flex-col h-full bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all">
                      <div className="h-1.5" style={{ backgroundColor: p.color }}/>
                      <div className="p-5 flex flex-col flex-1">
                        <div className="flex items-center gap-2 mb-3">
                          <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: p.bg }}>
                            <Icon size={18} style={{ color: p.color }}/>
                          </div>
                          <div>
                            <h3 className="font-bold text-gray-900 text-sm group-hover:text-[#D4920C] transition-colors leading-tight">{p.title}</h3>
                            {p.badge && <span className="text-[10px] font-bold" style={{ color: p.color }}>{p.badge}</span>}
                          </div>
                          <span className="ml-auto text-[9px] font-bold text-[#E84821] bg-[#E84821]/8 px-1.5 py-0.5 rounded-full flex-shrink-0">Page →</span>
                        </div>
                        <p className="text-gray-500 text-xs leading-relaxed flex-1">{p.desc}</p>
                        <div className="mt-4 flex items-center gap-1 text-xs font-semibold text-[#D4920C]">
                          Explore <ArrowUpRight size={12}/>
                        </div>
                      </div>
                    </Link>
                  ) : (
                    <div className="group flex flex-col h-full bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all">
                      <div className="h-1.5" style={{ backgroundColor: p.color }}/>
                      <div className="p-5 flex flex-col flex-1">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: p.bg }}>
                            <Icon size={18} style={{ color: p.color }}/>
                          </div>
                          <h3 className="font-bold text-gray-900 text-sm leading-tight">{p.title}</h3>
                        </div>
                        <p className="text-gray-500 text-xs leading-relaxed flex-1">{p.desc}</p>
                        <Link href="/contact" className="mt-4 flex items-center gap-1 text-xs font-semibold" style={{ color: p.color }}>
                          Get in touch <ArrowRight size={12}/>
                        </Link>
                      </div>
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── ALL DB PRODUCTS ──────────────────────────────────────────── */}
      <section className="py-16 md:py-20 bg-white border-t border-gray-100">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-10 text-center">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Full Product Range</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold" style={{ color: accent }}>All 8 Cloud Products</h2>
            <p className="text-gray-400 text-sm mt-2">Click any product to learn more · Products with dedicated pages link directly</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {isLoading
              ? Array.from({ length: 6 }).map((_, i) => <div key={i} className="rounded-2xl border border-gray-100 bg-gray-50 animate-pulse h-36"/>)
              : items.map((p, i) => {
                  const Icon = getIcon(p.iconName);
                  const pageUrl = getProductPageUrl(p);
                  return (
                    <motion.div key={p.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-40px" }} transition={{ duration: 0.4, delay: i * 0.04 }}>
                      {pageUrl ? (
                        <Link href={pageUrl}
                          className="group flex flex-col h-full text-left rounded-2xl border border-gray-100 overflow-hidden hover:border-transparent hover:shadow-xl transition-all hover:-translate-y-0.5 bg-white">
                          <div className="h-1.5 w-full" style={{ backgroundColor: p.accentColor || primary }}/>
                          <div className="p-6 flex flex-col flex-1">
                            <div className="flex items-center gap-3 mb-3">
                              <div className="p-2 rounded-lg flex-shrink-0" style={{ backgroundColor: `${p.accentColor || primary}15` }}>
                                <Icon size={18} style={{ color: p.accentColor || primary }}/>
                              </div>
                              <h3 className="font-bold text-gray-900 text-sm group-hover:text-[#E84821] transition-colors leading-tight">{p.name}</h3>
                              <span className="ml-auto text-[9px] font-bold text-[#E84821] bg-[#E84821]/8 px-1.5 py-0.5 rounded-full flex-shrink-0">Page →</span>
                            </div>
                            <p className="text-gray-500 text-xs leading-relaxed flex-1">{p.shortDesc}</p>
                            <div className="mt-3 flex items-center gap-1 text-xs font-semibold text-[#E84821]">
                              View full details <ArrowUpRight size={12}/>
                            </div>
                          </div>
                        </Link>
                      ) : (
                        <button onClick={() => setSelected(p)}
                          className="group flex flex-col h-full w-full text-left rounded-2xl border border-gray-100 overflow-hidden hover:border-transparent hover:shadow-xl transition-all hover:-translate-y-0.5 bg-white cursor-pointer">
                          <div className="h-1.5 w-full" style={{ backgroundColor: p.accentColor || primary }}/>
                          <div className="p-6 flex flex-col flex-1">
                            <div className="flex items-center gap-3 mb-3">
                              <div className="p-2 rounded-lg flex-shrink-0" style={{ backgroundColor: `${p.accentColor || primary}15` }}>
                                <Icon size={18} style={{ color: p.accentColor || primary }}/>
                              </div>
                              <h3 className="font-bold text-gray-900 text-sm group-hover:text-[#D4920C] transition-colors leading-tight">{p.name}</h3>
                            </div>
                            <p className="text-gray-500 text-xs leading-relaxed flex-1">{p.shortDesc}</p>
                            <div className="mt-3 flex items-center gap-1 text-xs font-semibold" style={{ color: p.accentColor || primary }}>
                              Learn more <ArrowRight size={12} className="group-hover:translate-x-0.5 transition-transform"/>
                            </div>
                          </div>
                        </button>
                      )}
                    </motion.div>
                  );
                })
            }
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 900 280" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="820" cy="140" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          {[[80,50],[200,210],[370,60],[520,190]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-5 L2-2 L5-2 L3 2 L4 5 L0 3 L-4 5 L-3 2 L-5-2 L-2-2Z" fill="white" opacity="0.5"/>
            </g>
          ))}
        </svg>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <h2 className="text-3xl font-bold text-white mb-3">Move to the Cloud with Confidence</h2>
          <p className="text-gray-400 text-sm mb-8 max-w-xl mx-auto leading-relaxed">
            Get a free cloud readiness assessment and migration plan from our certified AWS and Azure architects.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 transition-all text-sm shadow-xl">
              Book Free Cloud Assessment <ArrowRight size={15}/>
            </Link>
            <Link href="/b1plus-cloud" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
              Explore B1Plus Cloud <ChevronRight size={14}/>
            </Link>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1 flex">
          <div className="flex-[3] bg-[#E84821]"/>
          <div className="flex-[2]" style={{ backgroundColor: primary }}/>
          <div className="flex-1 bg-[#3D4FA0]"/>
        </div>
      </section>

      {selected && <ProductItemModal open product={selected} onClose={() => setSelected(null)}/>}
    </PublicLayout>
  );
}
