import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  ArrowRight, CheckCircle2, Package, RefreshCw, Truck,
  Brain, BarChart3, Smartphone, Link2, Building2,
  ShieldCheck, Settings, Sparkles, Boxes, Cloud,
  Globe2, GitBranch, Zap, LayoutGrid, ArrowUpRight,
  ChevronRight, MapPin, Store,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

/* ── HIGHLIGHTS (10) ─────────────────────────────────────────────── */
const HIGHLIGHTS = [
  { icon: LayoutGrid, label: "Complete Warehouse Management Solution" },
  { icon: Store, label: "Built-in Order Management System (OMS)" },
  { icon: Smartphone, label: "Native Android & iOS Mobile Apps" },
  { icon: Brain, label: "AI-Powered Inventory Intelligence" },
  { icon: Boxes, label: "Barcode & QR Code Enabled Operations" },
  { icon: Building2, label: "Multi-Warehouse & Multi-Company Support" },
  { icon: Zap, label: "Real-Time Inventory Visibility" },
  { icon: Cloud, label: "Cloud & On-Premise Deployment" },
  { icon: Link2, label: "Open API Integration Platform" },
  { icon: ShieldCheck, label: "Enterprise Security & Audit Trails" },
];

/* ── CORE OPERATIONS (3 modules) ───────────────────────────────── */
const OPERATIONS = [
  {
    icon: Package,
    title: "Inbound Operations",
    color: "#E84821",
    bg: "#FFF4F1",
    desc: "Manage every inbound activity with complete traceability from gate to bin.",
    features: ["Gate Entry Management","Purchase Order Receiving","Goods Receipt Note (GRN)","Quality Inspection","Putaway Management","Bin Allocation","Barcode Scanning","Batch & Serial Number Management"],
  },
  {
    icon: RefreshCw,
    title: "Inventory Management",
    color: "#D4920C",
    bg: "#FFFBEB",
    desc: "Maintain accurate inventory across multiple warehouses with live stock visibility.",
    features: ["Bin-Level Inventory","Stock Transfers","Stock Adjustments","Cycle Counting","Physical Inventory","Batch Tracking","Serial Number Tracking","Inventory Valuation"],
  },
  {
    icon: Truck,
    title: "Outbound Operations",
    color: "#3D4FA0",
    bg: "#F0F3FF",
    desc: "Improve picking accuracy and order fulfillment speed at every step.",
    features: ["Picklist Generation","Pick & Pack","Packing Validation","Delivery Management","Shipment Processing","Dispatch Confirmation","Return Merchandise Authorization (RMA)","Customer Returns"],
  },
];

/* ── OMS CAPABILITIES ───────────────────────────────────────────── */
const OMS_CAPS = [
  "Centralized Order Dashboard","Marketplace Order Management","Order Status Tracking",
  "Auto Order Allocation","Backorder Management","Shipment Tracking","Invoice Generation","Customer Notifications",
];

/* ── MARKETPLACES ───────────────────────────────────────────────── */
const MARKETPLACES = [
  { name: "Flipkart", emoji: "🛒" },
  { name: "Amazon", emoji: "📦" },
  { name: "Blinkit", emoji: "⚡" },
  { name: "Haldiram", emoji: "🏪" },
  { name: "Wipro", emoji: "💼" },
  { name: "Zepto", emoji: "🚀" },
  { name: "Shopify", emoji: "🛍️" },
  { name: "WooCommerce", emoji: "🌐" },
  { name: "Magento", emoji: "🔧" },
  { name: "BigCommerce", emoji: "📊" },
  { name: "OpenCart", emoji: "🔓" },
];

/* ── ERP INTEGRATIONS ───────────────────────────────────────────── */
const ERPS = [
  "SAP Business One","SAP Business One HANA","SAP S/4HANA","TallyPrime",
  "Microsoft Dynamics 365","Oracle ERP","ERPNext","Odoo",
  "Busy Accounting Software","Marg ERP","Custom ERP Solutions",
];

const ERP_DOCS = [
  "Purchase Orders","Sales Orders","Goods Receipts","Inventory Transfers",
  "Delivery Notes","Stock Updates","Customer & Vendor Masters","Item Masters",
  "Warehouse Masters","Financial Posting",
];

/* ── AI FEATURES ─────────────────────────────────────────────────── */
const AI_FEATURES = [
  { icon: Brain, title: "Demand Forecasting", desc: "AI analyzes historical sales, seasonality, and trends to predict what stock you'll need — and when." },
  { icon: GitBranch, title: "Smart Reorder Suggestions", desc: "Receive intelligent purchase recommendations based on forecasted demand, lead times, and safety stock levels." },
  { icon: BarChart3, title: "Inventory Optimization", desc: "Identify slow movers, dead stock, and high-turnover SKUs so you can make better replenishment decisions." },
  { icon: Zap, title: "Slow Moving & Dead Stock Analysis", desc: "Automatically flag ageing inventory to free up working capital and warehouse space." },
  { icon: MapPin, title: "Warehouse Performance Analytics", desc: "Track receiving accuracy, pick rates, order fulfillment speed, and warehouse productivity in real time." },
  { icon: Sparkles, title: "Predictive Inventory Planning", desc: "Dynamic safety stock calculations that adjust in real time based on demand variability and supplier performance." },
];

/* ── DASHBOARDS ──────────────────────────────────────────────────── */
const DASHBOARDS = [
  "Inventory Dashboard","Warehouse Performance","Stock Ageing Analysis",
  "Order Fulfillment Dashboard","Purchase Dashboard","Dispatch Dashboard","KPI Monitoring","Executive Analytics",
];

/* ── MOBILE FEATURES ──────────────────────────────────────────────── */
const MOBILE = [
  "Barcode Scanning","QR Code Scanning","Offline Working Mode","Live Inventory Lookup",
  "Mobile Goods Receipt","Mobile Picking","Mobile Stock Transfer","Bin Verification","Push Notifications",
];

/* ── SECURITY ────────────────────────────────────────────────────── */
const SECURITY = [
  "Role-Based Access Control","Multi-Level User Permissions","Audit Trail",
  "Session Management","Secure API Authentication","Data Encryption","Backup & Recovery","Activity Logging",
];

/* ── DEPLOYMENT ──────────────────────────────────────────────────── */
const DEPLOY = ["Cloud Hosted","On-Premise","Hybrid Deployment","Private Cloud","Multi-Tenant Cloud","Dedicated Server"];

/* ── CHALLENGE/SOLUTION TABLE ────────────────────────────────────── */
const COMPARISON = [
  { challenge: "Inventory inaccuracies", solution: "Real-time inventory with barcode validation" },
  { challenge: "Multiple disconnected systems", solution: "Built-in OMS + ERP Integration" },
  { challenge: "Marketplace order management", solution: "Centralized order processing from multiple channels" },
  { challenge: "Manual warehouse operations", solution: "Mobile-first, paperless workflows" },
  { challenge: "Delayed dispatches", solution: "Intelligent pick, pack & shipment management" },
  { challenge: "No inventory visibility", solution: "Live dashboards & warehouse analytics" },
  { challenge: "Stock shortages", solution: "AI-powered demand forecasting & reorder suggestions" },
  { challenge: "Scaling operations", solution: "Multi-company & multi-warehouse architecture" },
];

/* ── OUR SERVICES ──────────────────────────────────────────────── */
const SERVICES = [
  "WMS Consulting","Warehouse Process Study","ERP Integration","Data Migration",
  "Barcode Implementation","Mobile Deployment","User Training","Cloud Hosting",
  "Annual Maintenance & Support","Custom Development",
];

/* ── COMPONENT ───────────────────────────────────────────────────── */
export default function WMS360Page() {
  const { primaryColor, accentColor } = useSiteConfig();

  return (
    <PublicLayout>
      <SEO
        title="WMS 360 — Intelligent Warehouse Management Platform | CtrlA Tech Solutions"
        description="WMS 360 is CtrlA's flagship Warehouse Management System with built-in OMS, AI-powered intelligence, marketplace integrations, SAP/ERP connectivity, and native mobile apps."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "Product",
          name: "WMS 360",
          description: "Intelligent Warehouse Management Platform with built-in OMS, AI intelligence, and ERP integration.",
          brand: { "@type": "Brand", name: "CtrlA Tech Solutions" },
        }}
      />

      {/* ━━━ HERO — full-width dark ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="relative overflow-hidden min-h-[88vh] flex flex-col justify-center"
        style={{ background: "linear-gradient(140deg, #080C1F 0%, #111627 45%, #1C2340 100%)" }}>

        {/* SVG circuit doodle */}
        <svg className="absolute inset-0 w-full h-full opacity-[0.08]" viewBox="0 0 1200 700" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="1000" cy="180" r="300" stroke="#E84821" strokeWidth="0.6" strokeDasharray="8 6"/>
          <circle cx="1000" cy="180" r="180" stroke={primaryColor} strokeWidth="0.4" strokeDasharray="4 8"/>
          <circle cx="1000" cy="180" r="80" stroke="white" strokeWidth="0.3" strokeDasharray="3 5"/>
          <path d="M0 400 Q200 350 400 380 Q600 410 800 360 Q1000 310 1200 340" stroke="white" strokeWidth="0.4" fill="none" strokeDasharray="5 5"/>
          <path d="M0 500 Q300 470 500 490 Q700 510 900 480 Q1100 450 1200 460" stroke="#E84821" strokeWidth="0.3" fill="none" strokeDasharray="4 7"/>
          {[[60,80],[180,220],[340,60],[120,400],[480,300],[260,480],[700,120]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-7 L2.5-2.5 L7-2.5 L3.5 2 L5 7 L0 4 L-5 7 L-3.5 2 L-7-2.5 L-2.5-2.5Z" fill="white" opacity="0.5"/>
            </g>
          ))}
          {[[150,150],[350,280],[500,100],[680,200]].map(([cx,cy],i) => (
            <rect key={i} x={cx-15} y={cy-15} width="30" height="30" stroke="white" strokeWidth="0.3" opacity="0.25" rx="4"/>
          ))}
        </svg>

        <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-20 flex-1 flex items-center">
          <div className="grid lg:grid-cols-2 gap-14 items-center w-full">
            {/* LEFT */}
            <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.65 }}>
              <div className="inline-flex items-center gap-2 mb-5 px-4 py-2 rounded-full border border-[#E84821]/40 bg-[#E84821]/10">
                <Sparkles size={13} className="text-[#E84821]"/>
                <span className="text-xs font-black uppercase tracking-widest text-[#E84821]">CtrlA Flagship Product</span>
              </div>

              <h1 className="text-5xl sm:text-6xl lg:text-7xl font-black leading-[1.0] tracking-tight mb-3">
                <span className="text-white">WMS</span>
                <span style={{ color: "#E84821" }}> 360</span>
              </h1>
              <h2 className="text-xl sm:text-2xl font-bold text-gray-300 mb-2 leading-snug">
                Intelligent Warehouse Management Platform
              </h2>
              <h3 className="text-base text-gray-500 font-medium mb-6">Built for Modern Supply Chains</h3>

              <div className="flex gap-2 mb-6">
                <span className="h-1 w-14 rounded-full bg-[#E84821]"/>
                <span className="h-1 w-8 rounded-full" style={{ backgroundColor: primaryColor }}/>
                <span className="h-1 w-4 rounded-full bg-[#3D4FA0]"/>
              </div>

              <p className="text-gray-300 text-base leading-relaxed mb-4 max-w-lg">
                WMS 360 digitizes, automates, and optimizes every warehouse operation — from inbound receiving to outbound dispatch. Built with a mobile-first architecture, AI-powered intelligence, and seamless ERP integration.
              </p>
              <p className="text-gray-400 text-sm leading-relaxed mb-8 max-w-lg">
                Unlike traditional warehouse software, WMS 360 comes with a <strong className="text-white">built-in Order Management System (OMS)</strong>, powerful marketplace integrations, barcode mobility, real-time dashboards, and enterprise-grade security — making it a complete warehouse and order fulfillment platform.
              </p>

              <div className="flex flex-wrap gap-3">
                <Link href="/contact"
                  className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl font-black text-white shadow-2xl hover:shadow-[#E84821]/30 hover:-translate-y-1 transition-all bg-[#E84821] text-sm">
                  Request a Live Demo <ArrowRight size={16}/>
                </Link>
                <a href="#features"
                  className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl font-bold border border-white/20 text-white hover:bg-white/8 hover:border-white/40 transition-all text-sm">
                  Explore WMS 360 <ChevronRight size={15}/>
                </a>
              </div>
            </motion.div>

            {/* RIGHT — highlights card */}
            <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.65, delay: 0.15 }}>
              <div className="bg-white/5 border border-white/10 rounded-3xl p-7 backdrop-blur-sm">
                <div className="text-xs font-black uppercase tracking-widest text-[#D4920C] mb-5">Key Highlights</div>
                <div className="grid grid-cols-1 gap-3">
                  {HIGHLIGHTS.map(({ icon: Icon, label }, i) => (
                    <motion.div key={label} initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 + i * 0.05 }}
                      className="flex items-center gap-3 group">
                      <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 bg-white/8 group-hover:bg-[#E84821]/15 transition-colors">
                        <Icon size={14} className="text-[#E84821]"/>
                      </div>
                      <span className="text-sm text-gray-300 group-hover:text-white transition-colors">{label}</span>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* bottom accent bar */}
        <div className="h-1 flex">
          <div className="flex-[3] bg-[#E84821]"/>
          <div className="flex-[2]" style={{ backgroundColor: primaryColor }}/>
          <div className="flex-1 bg-[#3D4FA0]"/>
        </div>
      </section>

      {/* ━━━ ONE PLATFORM INTRO ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="py-14 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 mb-3">
            <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">One Platform. Complete Warehouse & Order Management.</span>
            <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold mb-4" style={{ color: accentColor }}>
            Whether you operate a distribution center, manufacturing warehouse,<br className="hidden xl:block"/> retail chain, or 3PL business
          </h2>
          <p className="text-gray-500 max-w-3xl mx-auto text-sm leading-relaxed">
            WMS 360 helps you eliminate manual processes, reduce errors, increase inventory accuracy, and accelerate order fulfillment — all from a single intelligent platform.
          </p>
        </div>
      </section>

      {/* ━━━ CORE OPERATIONS — 3-column card grid ━━━━━━━━━━━━━━━━━━━━ */}
      <section id="features" className="py-16 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 60%, #FFFBEB 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 800" preserveAspectRatio="xMidYMid slice">
          {Array.from({ length: 22 }).map((_, r) => Array.from({ length: 28 }).map((_, c) => (
            <circle key={`${r}-${c}`} cx={c*33+16} cy={r*33+16} r="1.6" fill="#3D4FA0"/>
          )))}
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Complete Warehouse Operations</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Manage every warehouse activity from a single platform</h2>
            <p className="mt-2 text-gray-500 text-sm">With complete traceability and real-time visibility at every step.</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {OPERATIONS.map((op, i) => {
              const Icon = op.icon;
              return (
                <motion.div key={op.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                  className="bg-white rounded-2xl border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 overflow-hidden">
                  {/* colored top strip */}
                  <div className="h-1.5 w-full" style={{ backgroundColor: op.color }}/>
                  <div className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-11 h-11 rounded-xl flex items-center justify-center" style={{ backgroundColor: op.bg }}>
                        <Icon size={20} style={{ color: op.color }}/>
                      </div>
                      <div>
                        <div className="font-black text-gray-900 text-sm">{op.title}</div>
                      </div>
                    </div>
                    <p className="text-gray-500 text-xs mb-4 leading-relaxed">{op.desc}</p>
                    <div className="grid grid-cols-2 gap-1.5">
                      {op.features.map(f => (
                        <div key={f} className="flex items-center gap-1.5 text-xs text-gray-600">
                          <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: op.color }}/>
                          {f}
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ━━━ BUILT-IN OMS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="py-16 bg-white border-t border-b border-gray-100 relative overflow-hidden">
        <svg className="absolute -right-20 top-0 bottom-0 h-full opacity-[0.04]" viewBox="0 0 300 600" fill="none">
          <circle cx="250" cy="300" r="220" stroke="#3D4FA0" strokeWidth="1.5" strokeDasharray="8 6"/>
          <circle cx="250" cy="300" r="140" stroke="#E84821" strokeWidth="1" strokeDasharray="5 8"/>
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Built-in OMS</span>
              </div>
              <h2 className="text-3xl font-bold mb-3" style={{ color: accentColor }}>
                No separate OMS software required
              </h2>
              <p className="text-gray-600 text-sm leading-relaxed mb-4">
                Unlike traditional WMS solutions, WMS 360 includes a <strong>fully integrated Order Management System</strong>, allowing businesses to manage orders from multiple sales channels through one centralized platform.
              </p>
              <p className="text-gray-500 text-sm leading-relaxed mb-6">
                Manage centralized orders, marketplace channels, backorders, shipment tracking, invoices, and customer notifications — all from the same place you run your warehouse.
              </p>
              <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 transition-all text-sm">
                Book a Demo <ArrowRight size={15}/>
              </Link>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="bg-gradient-to-br from-[#1A1F36] to-[#2D3561] rounded-2xl p-6 text-white">
                <div className="text-xs font-bold uppercase tracking-widest text-[#D4920C] mb-5">OMS Capabilities</div>
                <div className="grid grid-cols-2 gap-3">
                  {OMS_CAPS.map(cap => (
                    <div key={cap} className="flex items-center gap-2 bg-white/8 rounded-xl p-3 text-xs font-medium text-gray-300">
                      <CheckCircle2 size={13} className="text-[#E84821] flex-shrink-0"/>
                      {cap}
                    </div>
                  ))}
                </div>
                <div className="mt-4 pt-4 border-t border-white/10 text-center text-xs text-gray-500 font-medium">
                  Centralized order management across all your sales channels
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ━━━ MARKETPLACE INTEGRATIONS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F0F3FF 0%, #F8F9FF 100%)" }}>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Marketplace & eCommerce Integrations</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Connect all your online sales channels into one intelligent platform</h2>
            <p className="mt-2 text-gray-500 text-sm">Pre-built integrations ready out of the box — plus open API for custom channels.</p>
          </div>

          <div className="flex flex-wrap justify-center gap-3 mb-8">
            {MARKETPLACES.map((m, i) => (
              <motion.div key={m.name} initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                className="flex items-center gap-2.5 bg-white border border-gray-200 rounded-xl px-4 py-3 shadow-sm hover:shadow-md hover:border-[#3D4FA0]/40 hover:-translate-y-0.5 transition-all">
                <span className="text-xl">{m.emoji}</span>
                <span className="font-bold text-gray-800 text-sm">{m.name}</span>
              </motion.div>
            ))}
          </div>

          <div className="text-center text-sm text-gray-500 bg-white border border-gray-100 rounded-xl px-6 py-3 inline-block mx-auto">
            🔌 <strong>Open API architecture</strong> also supports custom integrations with any eCommerce platform or marketplace
          </div>
        </div>
      </section>

      {/* ━━━ ERP INTEGRATION ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="py-16 bg-white border-t border-gray-100 relative overflow-hidden">
        <svg className="absolute -left-16 inset-y-0 h-full opacity-[0.04]" viewBox="0 0 300 600" fill="none">
          <circle cx="50" cy="300" r="220" stroke="#E84821" strokeWidth="1.5" strokeDasharray="8 6"/>
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">ERP Integration Made Easy</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>
              Seamlessly integrated with leading ERP systems
            </h2>
            <p className="mt-2 text-gray-500 text-sm max-w-xl mx-auto">Eliminate duplicate data entry and ensure synchronized business operations. All transactions synchronized in real time using secure APIs and middleware.</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* ERP list */}
            <div>
              <div className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0] mb-4">Supported ERP Integrations</div>
              <div className="grid grid-cols-2 gap-2">
                {ERPS.map((e, i) => (
                  <motion.div key={e} initial={{ opacity: 0, x: -8 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                    className="flex items-center gap-2 bg-gray-50 border border-gray-100 rounded-xl p-3 text-xs font-semibold text-gray-700 hover:border-[#E84821]/30 hover:bg-[#E84821]/4 transition-all">
                    <Link2 size={12} className="text-[#E84821] flex-shrink-0"/>
                    {e}
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Integrated business processes */}
            <div>
              <div className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0] mb-4">Integrated Business Processes</div>
              <div className="grid grid-cols-2 gap-2">
                {ERP_DOCS.map((d, i) => (
                  <motion.div key={d} initial={{ opacity: 0, x: 8 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                    className="flex items-center gap-2 bg-gray-50 border border-gray-100 rounded-xl p-3 text-xs font-semibold text-gray-700 hover:border-[#3D4FA0]/30 hover:bg-[#3D4FA0]/4 transition-all">
                    <CheckCircle2 size={12} className="text-[#3D4FA0] flex-shrink-0"/>
                    {d}
                  </motion.div>
                ))}
              </div>
              <div className="mt-4 p-4 bg-[#3D4FA0]/6 border border-[#3D4FA0]/15 rounded-xl text-xs text-[#3D4FA0] font-medium">
                🔒 All transactions synchronized in real time using secure APIs and middleware
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ━━━ AI-POWERED INTELLIGENCE — dark section ━━━━━━━━━━━━━━━━━━ */}
      <section className="py-16 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.08]" viewBox="0 0 900 500" fill="none" preserveAspectRatio="xMidYMid slice">
          {[[80,60],[200,350],[420,80],[300,250],[650,150],[780,380]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-7 L2.5-2.5 L7-2.5 L3.5 2 L5 7 L0 4 L-5 7 L-3.5 2 L-7-2.5 L-2.5-2.5Z" fill="white" opacity="0.4"/></g>
          ))}
          <circle cx="820" cy="100" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#D4920C]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#D4920C]">AI-Powered Warehouse Intelligence</span>
              <span className="w-6 h-0.5 rounded bg-[#D4920C]"/>
            </div>
            <h2 className="text-3xl font-bold text-white mb-2">Transform warehouse data into actionable business insights</h2>
            <p className="text-gray-400 text-sm max-w-xl mx-auto">Stop guessing. Start predicting. Machine learning that turns your historical data into tomorrow's competitive edge.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-10">
            {AI_FEATURES.map((feat, i) => {
              const Icon = feat.icon;
              return (
                <motion.div key={feat.title} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }}
                  className="bg-white/6 border border-white/10 rounded-2xl p-5 hover:bg-white/10 transition-colors">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-[#D4920C]/15 mb-3">
                    <Icon size={18} className="text-[#D4920C]"/>
                  </div>
                  <h4 className="font-bold text-white text-sm mb-2">{feat.title}</h4>
                  <p className="text-gray-400 text-xs leading-relaxed">{feat.desc}</p>
                </motion.div>
              );
            })}
          </div>

          {/* Dashboards sub-panel */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
            <div className="text-xs font-bold uppercase tracking-widest text-[#D4920C] mb-4">Business Intelligence & Analytics — Dashboard Highlights</div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
              {DASHBOARDS.map(d => (
                <div key={d} className="flex items-center gap-2 text-xs text-gray-300">
                  <BarChart3 size={11} className="text-[#D4920C] flex-shrink-0"/>
                  {d}
                </div>
              ))}
            </div>
            <div className="text-xs text-gray-500 border-t border-white/10 pt-3">
              📤 Export reports instantly to <strong className="text-gray-400">Excel, PDF, or Power BI</strong>
            </div>
          </div>
        </div>
      </section>

      {/* ━━━ MOBILE + SECURITY + DEPLOYMENT — 3-col ━━━━━━━━━━━━━━━━━ */}
      <section className="py-16 bg-white border-t border-gray-100 relative overflow-hidden">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Platform Capabilities</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Built for scale, security, and flexibility</h2>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Mobile */}
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
              className="rounded-2xl overflow-hidden border border-gray-100 hover:shadow-xl transition-all duration-300 group">
              <div className="relative h-36 overflow-hidden">
                <img src="https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&w=600&q=80" alt="Mobile warehouse operations" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#3D4FA0]/80 to-[#3D4FA0]/20"/>
                <div className="absolute bottom-3 left-4 flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center"><Smartphone size={14} className="text-white"/></div>
                  <span className="text-white font-bold text-sm">Mobile Warehouse Operations</span>
                </div>
              </div>
              <div className="p-5">
                <p className="text-gray-500 text-xs mb-4 leading-relaxed">Empower warehouse staff with fast, paperless operations on any Android or iOS device.</p>
                <div className="grid grid-cols-2 gap-1.5">
                  {MOBILE.map(f => (
                    <div key={f} className="flex items-center gap-1.5 text-xs text-gray-600">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#3D4FA0] flex-shrink-0"/>
                      {f}
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Security */}
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}
              className="rounded-2xl overflow-hidden border border-gray-100 hover:shadow-xl transition-all duration-300 group">
              <div className="relative h-36 overflow-hidden">
                <img src="https://images.unsplash.com/photo-1563013544-824ae1b704d3?auto=format&fit=crop&w=600&q=80" alt="Enterprise security" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/80 to-[#1A1F36]/20"/>
                <div className="absolute bottom-3 left-4 flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center"><ShieldCheck size={14} className="text-white"/></div>
                  <span className="text-white font-bold text-sm">Security You Can Trust</span>
                </div>
              </div>
              <div className="p-5">
                <p className="text-gray-500 text-xs mb-4 leading-relaxed">Enterprise-grade security built into every layer of the platform, from floor operator to CFO.</p>
                <div className="grid grid-cols-2 gap-1.5">
                  {SECURITY.map(f => (
                    <div key={f} className="flex items-center gap-1.5 text-xs text-gray-600">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#1A1F36] flex-shrink-0"/>
                      {f}
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Multi-warehouse + Deployment */}
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.2 }}>
              {/* Multi-warehouse */}
              <div className="rounded-2xl border border-gray-100 p-5 mb-5 hover:shadow-lg transition-all">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-[#D4920C]/12 flex items-center justify-center"><Building2 size={18} className="text-[#D4920C]"/></div>
                  <div className="font-bold text-gray-900 text-sm">Multi-Warehouse Management</div>
                </div>
                <p className="text-gray-500 text-xs mb-3 leading-relaxed">Scale from one site to a national distribution network without changing systems.</p>
                <div className="space-y-1.5">
                  {["Multiple Warehouses","Multiple Companies","Multiple Branches","Warehouse-Specific Users","Centralized Inventory","Inter-Warehouse Transfers","Warehouse Performance Comparison"].map(f => (
                    <div key={f} className="flex items-center gap-1.5 text-xs text-gray-600">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#D4920C] flex-shrink-0"/>
                      {f}
                    </div>
                  ))}
                </div>
              </div>

              {/* Deployment */}
              <div className="rounded-2xl border border-gray-100 p-5 hover:shadow-lg transition-all">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-[#059669]/12 flex items-center justify-center"><Cloud size={18} className="text-[#059669]"/></div>
                  <div className="font-bold text-gray-900 text-sm">Cloud or On-Premise — Your Choice</div>
                </div>
                <p className="text-gray-500 text-xs mb-3">Deploy WMS 360 the way your business prefers.</p>
                <div className="grid grid-cols-2 gap-1.5">
                  {DEPLOY.map(d => (
                    <div key={d} className="flex items-center gap-1.5 text-xs text-gray-600">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#059669] flex-shrink-0"/>
                      {d}
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ━━━ WHY BUSINESSES CHOOSE WMS 360 — challenge/solution ━━━━━━ */}
      <section className="py-16 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #F0F3FF 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 600" preserveAspectRatio="xMidYMid slice">
          {Array.from({ length: 16 }).map((_, r) => Array.from({ length: 22 }).map((_, c) => (
            <circle key={`${r}-${c}`} cx={c*42+21} cy={r*38+19} r="1.8" fill="#3D4FA0"/>
          )))}
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why Businesses Choose WMS 360</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Built to solve real warehouse problems</h2>
          </div>

          <div className="rounded-2xl overflow-hidden shadow-sm border border-gray-100">
            <div className="grid grid-cols-12 bg-gradient-to-r from-[#1A1F36] to-[#2D3561] text-xs font-black uppercase tracking-widest">
              <div className="col-span-5 p-4 text-gray-400">Business Challenge</div>
              <div className="col-span-7 p-4 text-[#D4920C]">WMS 360 Solution</div>
            </div>
            {COMPARISON.map((row, i) => (
              <motion.div key={i} initial={{ opacity: 0, x: -10 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.06 }}
                className={`grid grid-cols-12 border-b border-gray-100 last:border-0 ${i % 2 === 0 ? "bg-white" : "bg-gray-50/60"} hover:bg-[#E84821]/3 transition-colors`}>
                <div className="col-span-5 p-4 text-sm text-gray-700 border-r border-gray-100">{row.challenge}</div>
                <div className="col-span-7 p-4 text-sm font-semibold flex items-start gap-2" style={{ color: accentColor }}>
                  <CheckCircle2 size={15} className="flex-shrink-0 mt-0.5 text-[#E84821]"/>
                  {row.solution}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ━━━ WHY CTRLA + SERVICES ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="py-16 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 900 450" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="820" cy="225" r="280" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          <circle cx="820" cy="225" r="180" stroke="#E84821" strokeWidth="0.4" strokeDasharray="4 8"/>
          {[[80,60],[160,310],[280,80],[200,220]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-6 L2-2 L6-2 L3 2 L4 6 L0 3 L-4 6 L-3 2 L-6-2 L-2-2Z" fill="white" opacity="0.5"/></g>
          ))}
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <div>
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#D4920C]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#D4920C]">Why CtrlA Tech Solutions?</span>
              </div>
              <h2 className="text-3xl font-bold text-white mb-4">Developed by experts. Backed by implementation support.</h2>
              <p className="text-gray-400 text-sm leading-relaxed mb-4">
                WMS 360 is developed by CtrlA Tech Solutions, combining years of expertise in ERP, warehouse automation, cloud technologies, and enterprise software development.
              </p>
              <p className="text-gray-400 text-sm leading-relaxed mb-6">
                Our implementation team works closely with your business to configure warehouse processes, integrate existing ERP systems, migrate data, train users, and provide long-term support.
              </p>

              <div className="grid grid-cols-2 gap-2">
                {SERVICES.map((s, i) => (
                  <motion.div key={s} initial={{ opacity: 0, x: -8 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                    className="flex items-center gap-2 bg-white/8 border border-white/10 rounded-xl p-3 hover:bg-white/12 transition-colors">
                    <CheckCircle2 size={12} className="text-[#D4920C] flex-shrink-0"/>
                    <span className="text-xs text-gray-300">{s}</span>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* right — final summary */}
            <div className="space-y-5">
              <div className="bg-white/6 border border-white/10 rounded-2xl p-6">
                <div className="text-sm font-bold text-white mb-2">Built for Every Warehouse. Ready for Every Business.</div>
                <p className="text-gray-400 text-xs leading-relaxed">
                  Whether you manage a single warehouse or a nationwide distribution network, WMS 360 provides the intelligence, flexibility, and scalability required to optimize inventory, streamline order fulfillment, and accelerate business growth.
                </p>
              </div>
              <div className="bg-[#E84821]/10 border border-[#E84821]/20 rounded-2xl p-6">
                <div className="text-sm font-bold text-white mb-2">More than a Warehouse Management System</div>
                <p className="text-gray-400 text-xs leading-relaxed">
                  With built-in OMS, AI-powered inventory intelligence, seamless ERP connectivity, marketplace integrations, and enterprise-grade mobility, WMS 360 is your <strong className="text-white">complete digital supply chain platform</strong>.
                </p>
              </div>
              <div className="flex flex-col gap-3">
                <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-black text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 transition-all text-sm shadow-xl">
                  Request a Live Demo <ArrowRight size={16}/>
                </Link>
                <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold border border-white/20 text-white hover:bg-white/10 transition-all text-sm">
                  Schedule a Free Warehouse Assessment
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ━━━ FINAL CTA ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="py-14 bg-white border-t border-gray-100 text-center relative overflow-hidden">
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 200" fill="none" preserveAspectRatio="xMidYMid slice">
          <path d="M0 80 Q225 40 450 80 Q675 120 900 80" stroke="#E84821" strokeWidth="1.5" fill="none" strokeDasharray="8 6"/>
          <path d="M0 120 Q225 80 450 120 Q675 160 900 120" stroke="#3D4FA0" strokeWidth="1" fill="none" strokeDasharray="5 8"/>
        </svg>
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="inline-flex items-center gap-2 mb-4">
            <span className="w-5 h-0.5 rounded bg-[#E84821]"/>
            <Globe2 size={14} className="text-[#E84821]"/>
            <span className="w-5 h-0.5 rounded bg-[#E84821]"/>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black mb-3" style={{ color: accentColor }}>
            Ready to transform your warehouse operations?
          </h2>
          <p className="text-gray-500 text-sm mb-8 max-w-xl mx-auto leading-relaxed">
            From the first truck at the gate to the last parcel out the door — WMS 360 gives you complete control, on any device, at any scale.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl font-black text-white bg-[#E84821] shadow-xl hover:shadow-[#E84821]/30 hover:-translate-y-1 transition-all text-sm">
              Request a Live Demo <ArrowRight size={16}/>
            </Link>
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl font-bold border-2 border-gray-200 text-gray-700 hover:border-[#D4920C] hover:text-[#D4920C] transition-all text-sm">
              Schedule a Free Warehouse Assessment
            </Link>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1 flex">
          <div className="flex-[3] bg-[#E84821]"/>
          <div className="flex-[2]" style={{ backgroundColor: primaryColor }}/>
          <div className="flex-1 bg-[#3D4FA0]"/>
        </div>
      </section>
    </PublicLayout>
  );
}
