import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import {
  Handshake, ArrowRight, CheckCircle2, Globe, Users, Zap,
  TrendingUp, Award, ChevronRight,
} from "lucide-react";
import { motion } from "framer-motion";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";
import { useToast } from "@/hooks/use-toast";
import CaptchaWidget from "@/components/public/CaptchaWidget";
import SuccessModal from "@/components/public/SuccessModal";

function isValidPhone(phone: string): boolean {
  if (!phone.trim()) return true;
  const digits = phone.replace(/[^0-9]/g, "");
  return /^[+]?[0-9\s\-().]{7,20}$/.test(phone.trim()) && digits.length >= 7;
}

const _B_BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";
type CmsPage = { metaTitle?: string | null; metaDescription?: string | null };
async function _fetchCmsPage(slug: string): Promise<CmsPage> {
  const res = await fetch(`${_B_BASE}/api/pages/${slug}`);
  if (!res.ok) return {};
  return res.json();
}

const PRODUCTS = [
  { id: "wms360",     label: "WMS 360" },
  { id: "oms360",     label: "OMS 360" },
  { id: "syncai",     label: "SyncAI" },
  { id: "pos360",     label: "POS 360" },
  { id: "ecommerce",  label: "Ecommerce" },
  { id: "myhrone",    label: "MyHROne (HRMS)" },
];

const BENEFITS = [
  { icon: TrendingUp, title: "Revenue Growth",     desc: "Earn competitive margins and recurring commissions on every deal." },
  { icon: Award,      title: "Certified Partner",  desc: "Co-branded marketing, certified partner badge, and joint go-to-market." },
  { icon: Users,      title: "Dedicated Support",  desc: "Dedicated partner success manager and priority technical support." },
  { icon: Globe,      title: "Global Reach",       desc: "Access to CtrlA's network across India, UK, and expanding markets." },
  { icon: Zap,        title: "Training & Enablement", desc: "Product training, demo environments, and sales enablement kits." },
  { icon: Handshake,  title: "Deal Registration",  desc: "Deal protection, co-selling opportunities, and lead sharing." },
];

const BASE_URL = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";

type Form = {
  fullName: string;
  company: string;
  email: string;
  phone: string;
  country: string;
  city: string;
  products: string[];
  description: string;
};

const INITIAL: Form = {
  fullName: "", company: "", email: "", phone: "",
  country: "", city: "", products: [], description: "",
};

export default function BecomeAPartnerPage() {
  const { primaryColor, accentColor } = useSiteConfig();
  const { toast } = useToast();
  const [form, setForm] = useState<Form>(INITIAL);
  const [submitting, setSubmitting] = useState(false);
  const [captchaToken, setCaptchaToken] = useState("");
  const [captchaAnswer, setCaptchaAnswer] = useState("");
  const [captchaKey, setCaptchaKey] = useState(0);
  const [phoneError, setPhoneError] = useState("");
  const [captchaError, setCaptchaError] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);
  const { data: cmsPage } = useQuery<CmsPage>({ queryKey: ["pages", "become-a-partner"], queryFn: () => _fetchCmsPage("become-a-partner"), staleTime: 60_000 });

  function toggleProduct(id: string) {
    setForm(f => ({
      ...f,
      products: f.products.includes(id)
        ? f.products.filter(p => p !== id)
        : [...f.products, id],
    }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (form.phone && !isValidPhone(form.phone)) {
      setPhoneError("Please enter a valid phone number (digits, +, -, spaces; min 7 digits).");
      return;
    }
    setSubmitting(true);
    const selectedProducts = form.products
      .map(id => PRODUCTS.find(p => p.id === id)?.label)
      .filter(Boolean)
      .join(", ");

    const message = [
      `Company: ${form.company}`,
      `Country: ${form.country}`,
      `City: ${form.city}`,
      selectedProducts ? `Products of Interest: ${selectedProducts}` : "",
      form.description ? `Message: ${form.description}` : "",
    ].filter(Boolean).join("\n");

    setCaptchaError("");
    try {
      const res = await fetch(`${BASE_URL}/api/public/contacts`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.fullName,
          email: form.email,
          phone: form.phone,
          message,
          subject: "Partner Application",
          captchaToken,
          captchaAnswer,
        }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        const msg: string = body.error ?? "";
        if (msg.toLowerCase().includes("security check") || msg.toLowerCase().includes("captcha")) {
          setCaptchaError("Wrong answer — a new question has been loaded. Please try again.");
          setCaptchaToken("");
          setCaptchaAnswer("");
          setCaptchaKey(k => k + 1);
        } else {
          toast({ title: "Submission failed", description: msg || "Please try again or email us directly.", variant: "destructive" });
        }
        return;
      }
      setForm(INITIAL);
      setPhoneError("");
      setCaptchaError("");
      setCaptchaToken("");
      setCaptchaAnswer("");
      setCaptchaKey(k => k + 1);
      setShowSuccess(true);
    } catch {
      toast({ title: "Submission failed", description: "Please try again or email us directly.", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <PublicLayout>
      <SuccessModal
        open={showSuccess}
        onClose={() => setShowSuccess(false)}
        title="Thank You!"
        message="Thank you for your interest in partnering with us! Our partnerships team will review your application and reach out to you within 24 hours."
      />
      <SEO
        title={cmsPage?.metaTitle ?? "Become a Partner — CtrlA Tech Solutions"}
        description={cmsPage?.metaDescription ?? "Join the CtrlA Tech Solutions partner programme. Grow your business by reselling WMS 360, OMS 360, SyncAI, POS 360, and more across India & the UK."}
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "WebPage",
          name: cmsPage?.metaTitle ?? "Become a Partner — CtrlA Tech Solutions",
          description: cmsPage?.metaDescription ?? "Join the CtrlA Tech Solutions partner programme. Grow your business by reselling WMS 360, OMS 360, SyncAI, POS 360, and more across India & the UK.",
          url: window.location.href,
          publisher: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
        }}
      />

      {/* ── HERO ── */}
      <section className="relative overflow-hidden" style={{ background: "linear-gradient(140deg, #0d1225 0%, #1A1F36 55%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.06]" viewBox="0 0 1200 480" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="1000" cy="240" r="320" stroke="#E84821" strokeWidth="0.8" strokeDasharray="12 8"/>
          <circle cx="1000" cy="240" r="180" stroke={primaryColor} strokeWidth="0.5" strokeDasharray="6 10"/>
        </svg>
        <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-22">
          <motion.div initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.55 }} className="max-w-2xl">
            <div className="inline-flex items-center gap-2 mb-4 px-3 py-1.5 rounded-full border border-[#E84821]/40 bg-[#E84821]/10">
              <Handshake size={13} className="text-[#E84821]" />
              <span className="text-xs font-black uppercase tracking-widest text-[#E84821]">Partner Programme</span>
            </div>
            <h1 className="text-4xl sm:text-5xl font-black leading-[1.06] text-white mb-3">
              Become a Partner<br/>
              <span style={{ color: "#E84821" }}>Grow Together</span>
            </h1>
            <div className="flex gap-2 my-5">
              <span className="h-1 w-12 rounded-full bg-[#E84821]" />
              <span className="h-1 w-7 rounded-full" style={{ backgroundColor: primaryColor }} />
              <span className="h-1 w-4 rounded-full bg-[#3D4FA0]" />
            </div>
            <p className="text-gray-300 text-sm leading-relaxed max-w-lg">
              Join CtrlA Tech Solutions' growing partner network and unlock new revenue streams by reselling our suite of enterprise products — WMS 360, OMS 360, SyncAI, POS 360, and more — across India, UK, and beyond.
            </p>
          </motion.div>
        </div>
        <div className="h-1 flex">
          <div className="flex-[3] bg-[#E84821]" />
          <div className="flex-[2]" style={{ backgroundColor: primaryColor }} />
          <div className="flex-1 bg-[#3D4FA0]" />
        </div>
      </section>

      {/* ── BENEFITS ── */}
      <section className="py-14 bg-white border-b border-gray-100">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded" style={{ backgroundColor: primaryColor }} />
              <span className="text-xs font-bold uppercase tracking-widest" style={{ color: primaryColor }}>Why Partner with CtrlA?</span>
              <span className="w-6 h-0.5 rounded" style={{ backgroundColor: primaryColor }} />
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Partner benefits that drive real results</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {BENEFITS.map((b, i) => {
              const Icon = b.icon;
              return (
                <motion.div
                  key={b.title}
                  initial={{ opacity: 0, y: 14 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.07 }}
                  className="flex items-start gap-4 p-5 rounded-2xl border border-gray-100 hover:border-gray-200 hover:shadow-md transition-all bg-gray-50"
                >
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 bg-[#E84821]/10">
                    <Icon size={18} className="text-[#E84821]" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-gray-900 mb-1">{b.title}</h3>
                    <p className="text-xs text-gray-500 leading-relaxed">{b.desc}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── FORM ── */}
      <section className="py-16" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #F0F3FF 100%)" }}>
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]" />
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Apply Now</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]" />
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Become a Partner Today!</h2>
            <p className="text-gray-500 text-sm mt-2">Fill in the form below and our partnership team will get back to you within 24 hours.</p>
          </div>

          {(
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-2xl border border-gray-100 shadow-sm p-8"
            >
              <form onSubmit={handleSubmit} className="space-y-5">

                {/* Row 1: Full Name + Company */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Full Name <span className="text-[#E84821]">*</span></label>
                    <input
                      required
                      value={form.fullName}
                      onChange={e => setForm(f => ({ ...f, fullName: e.target.value }))}
                      placeholder="Enter your name here"
                      className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/40 focus:border-[#E84821] transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Company Name <span className="text-[#E84821]">*</span></label>
                    <input
                      required
                      value={form.company}
                      onChange={e => setForm(f => ({ ...f, company: e.target.value }))}
                      placeholder="Enter your company name here"
                      className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/40 focus:border-[#E84821] transition-all"
                    />
                  </div>
                </div>

                {/* Row 2: Email + Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Email <span className="text-[#E84821]">*</span></label>
                    <input
                      required
                      type="email"
                      value={form.email}
                      onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                      placeholder="Enter your email here"
                      className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/40 focus:border-[#E84821] transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Phone No. <span className="text-[#E84821]">*</span></label>
                    <input
                      required
                      type="tel"
                      value={form.phone}
                      onChange={e => {
                        const val = e.target.value;
                        setForm(f => ({ ...f, phone: val }));
                        setPhoneError(val && !isValidPhone(val) ? "Enter a valid phone number (7–15 digits, may include +, -, spaces)." : "");
                      }}
                      placeholder="Enter your phone number here"
                      className={`w-full border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/40 focus:border-[#E84821] transition-all ${phoneError ? "border-red-400" : "border-gray-200"}`}
                    />
                    {phoneError && <p className="text-xs text-red-500 mt-1">{phoneError}</p>}
                  </div>
                </div>

                {/* Row 3: Country + City */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Country <span className="text-[#E84821]">*</span></label>
                    <select
                      required
                      value={form.country}
                      onChange={e => setForm(f => ({ ...f, country: e.target.value }))}
                      className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/40 focus:border-[#E84821] transition-all bg-white text-gray-700"
                    >
                      <option value="">Select your country here</option>
                      <option>India</option>
                      <option>United Kingdom</option>
                      <option>United States</option>
                      <option>United Arab Emirates</option>
                      <option>Saudi Arabia</option>
                      <option>Singapore</option>
                      <option>Australia</option>
                      <option>Canada</option>
                      <option>Germany</option>
                      <option>France</option>
                      <option>Netherlands</option>
                      <option>South Africa</option>
                      <option>Kenya</option>
                      <option>Nigeria</option>
                      <option>Bangladesh</option>
                      <option>Sri Lanka</option>
                      <option>Malaysia</option>
                      <option>Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">City <span className="text-[#E84821]">*</span></label>
                    <input
                      required
                      value={form.city}
                      onChange={e => setForm(f => ({ ...f, city: e.target.value }))}
                      placeholder="Enter your city here"
                      className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/40 focus:border-[#E84821] transition-all"
                    />
                  </div>
                </div>

                {/* Products */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">Products</label>
                  <div className="flex flex-wrap gap-3">
                    {PRODUCTS.map(p => {
                      const checked = form.products.includes(p.id);
                      return (
                        <label
                          key={p.id}
                          className={`flex items-center gap-2.5 px-4 py-2.5 rounded-xl border-2 cursor-pointer select-none transition-all text-sm font-semibold ${
                            checked
                              ? "border-[#E84821] bg-[#E84821]/8 text-[#E84821]"
                              : "border-gray-200 bg-white text-gray-600 hover:border-gray-300"
                          }`}
                        >
                          <input
                            type="checkbox"
                            className="sr-only"
                            checked={checked}
                            onChange={() => toggleProduct(p.id)}
                          />
                          <span className={`w-4 h-4 rounded flex items-center justify-center border-2 flex-shrink-0 transition-all ${checked ? "border-[#E84821] bg-[#E84821]" : "border-gray-300"}`}>
                            {checked && (
                              <svg width="10" height="8" viewBox="0 0 10 8" fill="none">
                                <path d="M1 4L3.5 6.5L9 1" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
                              </svg>
                            )}
                          </span>
                          {p.label}
                        </label>
                      );
                    })}
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Description</label>
                  <textarea
                    rows={4}
                    value={form.description}
                    onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                    placeholder="Tell us about your business, your target market, and what you're looking to achieve through this partnership..."
                    className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/40 focus:border-[#E84821] transition-all resize-none"
                  />
                </div>

                <CaptchaWidget
                  key={captchaKey}
                  onVerify={(tok, ans) => { setCaptchaToken(tok); setCaptchaAnswer(ans); setCaptchaError(""); }}
                  onExpire={() => { setCaptchaToken(""); setCaptchaAnswer(""); }}
                  theme="light"
                />
                {captchaError && (
                  <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                    {captchaError}
                  </p>
                )}
                <button
                  type="submit"
                  disabled={submitting || !captchaAnswer}
                  className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-white text-sm transition-all hover:-translate-y-0.5 shadow-lg disabled:opacity-60 disabled:cursor-not-allowed"
                  style={{ backgroundColor: "#E84821" }}
                >
                  {submitting ? "Submitting…" : <>Submit Partner Application <ArrowRight size={15} /></>}
                </button>
              </form>
            </motion.div>
          )}
        </div>
      </section>

      {/* ── Bottom CTA ── */}
      <section className="py-12 border-t border-gray-100 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-gray-500 text-sm mb-3">Already a partner or have questions?</p>
          <Link href="/contact" className="inline-flex items-center gap-2 text-sm font-semibold hover:gap-3 transition-all" style={{ color: primaryColor }}>
            Contact our partnerships team <ChevronRight size={14} />
          </Link>
        </div>
      </section>
    </PublicLayout>
  );
}
