import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { Calendar, ArrowRight } from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import PageHero from "@/components/public/PageHero";
import { useListPublicBlogPosts } from "@/lib/apiClient";
import { SEO } from "@/components/SEO";

const _BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";
type CmsPage = { metaTitle?: string | null; metaDescription?: string | null };
async function _fetchCmsPage(slug: string): Promise<CmsPage> {
  const res = await fetch(`${_BASE}/api/pages/${slug}`);
  if (!res.ok) return {};
  return res.json();
}

export default function BlogListPage() {
  const { data, isLoading } = useListPublicBlogPosts({});
  const { data: cmsPage } = useQuery<CmsPage>({ queryKey: ["pages", "blog"], queryFn: () => _fetchCmsPage("blog"), staleTime: 60_000 });
  const posts = data?.posts;

  return (
    <PublicLayout>
      <SEO
        title={cmsPage?.metaTitle ?? "Blog — CtrlA Tech Solutions"}
        description={cmsPage?.metaDescription ?? "Insights, tutorials, and news from the world of technology — brought to you by CtrlA Tech Solutions."}
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: cmsPage?.metaTitle ?? "Blog — CtrlA Tech Solutions",
          description: cmsPage?.metaDescription ?? "Insights, tutorials, and news from the world of technology — brought to you by CtrlA Tech Solutions.",
          url: window.location.href,
          publisher: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
        }}
      />

      <PageHero
        eyebrow="Insights"
        title={<>Our <span style={{ color: "#E84821" }}>Blog</span></>}
        subtitle="Insights, tutorials, and news from the world of technology."
        heroImage="https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?auto=format&fit=crop&w=1200&q=80"
        heroImageAlt="Modern workspace with code on screens"
      />

      <section className="py-16 bg-gray-50">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="h-64 bg-white rounded-2xl animate-pulse border border-gray-100" />
              ))}
            </div>
          ) : !posts?.length ? (
            <div className="text-center py-24 text-gray-500">
              <p className="text-xl">No blog posts yet. Check back soon!</p>
            </div>
          ) : (
            <div className={
            posts.length === 1
              ? "flex justify-center"
              : posts.length === 2
                ? "grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto"
                : "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          }>
              {posts.map((post, i) => (
                <motion.article
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  viewport={{ once: true }}
                  className={`bg-white border border-gray-100 rounded-2xl overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all group${posts.length === 1 ? " w-full max-w-md" : ""}`}
                >
                  {post.featuredImage ? (
                    <div className="h-48 overflow-hidden">
                      <img
                        src={post.featuredImage}
                        alt={post.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  ) : (
                    <div className="h-48 bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center border-b border-gray-100">
                      <span className="text-[#E84821] text-5xl font-bold opacity-40">{post.title[0]}</span>
                    </div>
                  )}
                  <div className="p-6">
                    <div className="flex items-center gap-2 text-xs text-gray-500 mb-3">
                      <Calendar size={12} />
                      {post.publishedAt ? new Date(post.publishedAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : ""}
                    </div>
                    <h2 className="font-bold text-[#1A1F36] text-lg mb-2 line-clamp-2">{post.title}</h2>
                    {post.excerpt && <p className="text-gray-600 text-sm mb-4 line-clamp-3">{post.excerpt}</p>}
                    <Link
                      href={`/blog/${post.slug}`}
                      className="inline-flex items-center gap-1 text-[#E84821] text-sm font-semibold hover:gap-2 transition-all"
                    >
                      Read More <ArrowRight size={14} />
                    </Link>
                  </div>
                </motion.article>
              ))}
            </div>
          )}
        </div>
      </section>
    </PublicLayout>
  );
}
