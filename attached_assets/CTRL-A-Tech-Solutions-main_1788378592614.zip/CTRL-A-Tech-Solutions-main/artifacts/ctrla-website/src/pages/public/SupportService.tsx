import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  ArrowRight, CheckCircle2, HeadphonesIcon, Clock, Shield,
  BookOpen, RefreshCw, Users, MonitorCheck, Wrench,
  TrendingUp, Award, ChevronRight, Zap,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import PageHero from "@/components/public/PageHero";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

/* ── Data ─────────────────────────────────────────────────────────────── */

const WHY_OUTSOURCE = [
  "Reduce hiring and recruitment costs",
  "Access experienced SAP functional and technical consultants",
  "No dependency on a single employee",
  "Faster issue resolution with SLA-backed support",
  "Flexible support plans based on your business needs",
  "Lower operational costs with predictable monthly pricing",
  "Continuous support without managing internal resources",
  "Access to specialists across multiple SAP modules",
  "Focus your internal team on core business activities",
];

const SUPPORT_MODELS = [
  {
    icon: HeadphonesIcon,
    title: "Remote SAP Support",
    tagline: "Immediate assistance, no on-site visit needed",
    desc: "Our remote support services provide immediate assistance without requiring an on-site visit. Using secure remote access, our consultants diagnose and resolve issues quickly, minimizing downtime.",
    accent: "#E84821",
    bg: "#FFF4F1",
    image: "https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&w=700&q=80",
    points: [
      "SAP Functional Support", "SAP Technical Support", "User Assistance",
      "Error Resolution", "Database Support", "Performance Optimization",
      "Report & Query Support", "Authorization Issues", "Integration Support", "Configuration Assistance",
    ],
  },
  {
    icon: Users,
    title: "Dedicated SAP Resource (Staff Augmentation)",
    tagline: "Your consultant, your team, your outcomes",
    desc: "Need an SAP consultant working exclusively for your organization? We provide experienced SAP consultants who work as an extension of your internal team — either remotely or at your office — for ongoing projects, daily operations, or long-term support.",
    accent: "#3D4FA0",
    bg: "#F0F3FF",
    image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=700&q=80",
    points: [
      "Full-Time SAP Consultant", "Part-Time SAP Consultant", "Project-Based Consultants",
      "Functional Consultants", "Technical Consultants", "SAP Business One Consultants",
      "SAP S/4HANA Consultants", "SAP HANA Database Experts",
    ],
  },
  {
    icon: Award,
    title: "On-Site SAP Support",
    tagline: "Hands-on assistance at your premises",
    desc: "For organizations requiring hands-on assistance, our consultants can work directly from your office for implementation support, user training, system optimization, and business process improvements.",
    accent: "#D4920C",
    bg: "#FFFBEB",
    image: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&w=700&q=80",
    points: [
      "On-Site Implementation Support", "User Training & Workshops",
      "System Optimization", "Business Process Improvements",
      "Go-Live Support", "Knowledge Transfer",
    ],
  },
];

const SERVICE_AREAS = [
  {
    icon: HeadphonesIcon,
    title: "Helpdesk & Incident Management",
    desc: "Our dedicated SAP support desk provides timely assistance through phone, email, remote sessions, and ticketing systems to ensure quick issue resolution.",
    accent: "#E84821",
    points: ["Ticket Management", "Functional Support", "Technical Support", "Remote Assistance", "User Guidance", "Issue Escalation", "SLA Monitoring"],
  },
  {
    icon: MonitorCheck,
    title: "System Health Monitoring",
    desc: "Prevent issues before they impact your business through proactive monitoring of your SAP environment.",
    accent: "#3D4FA0",
    points: ["Database Performance", "Server Health", "Integration Monitoring", "Background Jobs", "License Monitoring", "Storage Management", "Performance Analysis"],
  },
  {
    icon: RefreshCw,
    title: "Patch Management & Upgrades",
    desc: "Stay current with SAP updates while minimizing business disruption.",
    accent: "#D4920C",
    points: ["SAP Patch Installation", "Feature Pack Updates", "Version Upgrades", "Security Updates", "Upgrade Testing", "Go-Live Support"],
  },
  {
    icon: BookOpen,
    title: "User Training & Knowledge Transfer",
    desc: "Empower your team with structured SAP training programs designed for both new and existing users.",
    accent: "#7C3AED",
    points: ["New Employee Training", "Refresher Sessions", "Module-Specific Workshops", "Administrator Training", "Best Practice Sessions", "Online & On-Site Training"],
  },
  {
    icon: Wrench,
    title: "Continuous System Improvements",
    desc: "As your business grows, your ERP should evolve too. Our support services include continuous improvements to keep your SAP system aligned with changing business needs.",
    accent: "#059669",
    points: ["Custom Reports", "New Print Layouts", "Approval Workflow Changes", "Dashboard Enhancements", "Master Data Improvements", "Business Process Optimization", "Minor Customizations"],
  },
];

const PLANS = [
  {
    name: "Essential Support",
    tagline: "Ideal for businesses requiring reliable day-to-day SAP assistance.",
    accent: "#3D4FA0",
    features: [
      "Business Hours Support",
      "Email & Remote Assistance",
      "Issue Resolution",
      "Bug Fixes",
      "Quarterly Health Check",
      "Basic User Guidance",
    ],
  },
  {
    name: "Professional Support",
    tagline: "Designed for organizations requiring faster response times and proactive system management.",
    accent: "#D4920C",
    featured: true,
    features: [
      "Priority Ticket Handling",
      "Phone, Email & Remote Support",
      "Monthly Health Checks",
      "Performance Optimization",
      "User Training",
      "Minor System Enhancements",
      "Dedicated Support Consultant",
    ],
  },
  {
    name: "Enterprise Support",
    tagline: "Comprehensive support for mission-critical SAP environments.",
    accent: "#E84821",
    features: [
      "Priority SLA",
      "Extended Support Hours",
      "Dedicated Account Manager",
      "On-Site & Remote Support",
      "Proactive Monitoring",
      "Performance Tuning",
      "Unlimited User Assistance",
      "Continuous System Improvements",
      "Strategic ERP Advisory",
    ],
  },
];

const WHY_US = [
  "Experienced SAP Functional & Technical Consultants",
  "Remote & On-Site Support Options",
  "Dedicated SAP Resources Available",
  "Flexible AMC & Support Contracts",
  "Fast Response & Resolution",
  "Proactive System Monitoring",
  "Business Process Expertise",
  "Affordable Support Plans",
  "Transparent SLA-Based Service Delivery",
  "Long-Term Technology Partner",
];

/* ── Component ────────────────────────────────────────────────────────── */

export default function SupportServicePage() {
  const { primaryColor, accentColor } = useSiteConfig();

  return (
    <PublicLayout>
      <SEO
        title="SAP Support Services — Keep Your SAP Business Running"
        description="CtrlA Tech Solutions offers flexible SAP Support Services including remote helpdesk, dedicated SAP consultants, on-site support, system monitoring, patch management, and AMC plans."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: "SAP Support Services",
          description: "CtrlA Tech Solutions offers flexible SAP Support Services including remote helpdesk, dedicated SAP consultants, on-site support, system monitoring, patch management, and AMC plans.",
          provider: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
          areaServed: ["IN", "GB"],
          serviceType: ["Remote SAP Support", "Dedicated SAP Consultant", "On-Site SAP Support", "SAP System Monitoring", "AMC Plans"],
          url: window.location.href,
        }}
      />

      {/* ── HERO ─────────────────────────────────────────────────────────── */}
      <PageHero
        eyebrow="SAP Support"
        title={<><span style={{ color: "#E84821" }}>SAP Support Services</span> — Keep Your SAP Business Running</>}
        subtitle="Your SAP ERP is the backbone of your business. When it slows down, your operations slow down. At CtrlA Tech Solutions, our SAP Support Services are designed to keep your ERP environment secure, optimized, and available whenever your business needs it."
        heroImage="https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&w=1200&q=80"
        heroImageAlt="SAP support team providing helpdesk and managed services"
        cta={
          <div className="flex flex-wrap gap-3 mt-6">
            <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5 bg-[#E84821]">
              Request a Support Quote <ArrowRight size={16} />
            </Link>
            <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border-2 border-white/40 text-white hover:bg-white/15 transition-all">
              Talk to Our SAP Experts
            </Link>
          </div>
        }
      />

      {/* ── WHY OUTSOURCE ────────────────────────────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden">
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 300" fill="none" preserveAspectRatio="xMidYMid slice">
          <path d="M0 150h200l40-50h120l40 50h200l30-30h120l30 30h120" stroke="#3D4FA0" strokeWidth="2"/>
          <circle cx="200" cy="150" r="7" fill="#3D4FA0"/><circle cx="560" cy="150" r="7" fill="#3D4FA0"/>
          <rect x="820" y="90" width="14" height="14" stroke="#E84821" strokeWidth="1.5"/>
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why Choose SAP Support from CtrlA?</span>
              </div>
              <h2 className="text-3xl font-bold mb-4" style={{ color: accentColor }}>Expert SAP support at a fraction of the cost of in-house hiring</h2>
              <p className="text-gray-600 text-sm leading-relaxed mb-4">
                Hiring and retaining experienced SAP professionals can be expensive, time-consuming, and challenging. Businesses often struggle with high recruitment costs, employee turnover, ongoing training, and the availability of skilled SAP consultants.
              </p>
              <p className="text-gray-600 text-sm leading-relaxed mb-6">
                Instead of building an in-house SAP team, let our experienced consultants support your business at a fraction of the cost.
              </p>
              <div className="space-y-2">
                {WHY_OUTSOURCE.map((w, i) => (
                  <motion.div key={w} initial={{ opacity: 0, x: -10 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}
                    className="flex items-center gap-2.5 text-sm text-gray-700">
                    <CheckCircle2 size={14} className="flex-shrink-0 text-[#E84821]"/>
                    {w}
                  </motion.div>
                ))}
              </div>
            </motion.div>
            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[4/3]">
                <img src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&w=900&q=80" alt="SAP consultant team providing support" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-tr from-[#1A1F36]/40 to-transparent"/>
                <div className="absolute bottom-4 left-4 bg-white/95 rounded-xl px-4 py-2.5 shadow-lg">
                  <div className="text-[10px] font-bold uppercase tracking-widest text-gray-500">Flexible Support Models</div>
                  <div className="text-sm font-bold text-gray-900 mt-0.5">Remote · Dedicated · On-Site</div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── FLEXIBLE SUPPORT MODELS ──────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.04]" viewBox="0 0 900 900" preserveAspectRatio="xMidYMid slice">
          {Array.from({ length: 25 }).map((_, row) => Array.from({ length: 30 }).map((_, col) => (
            <circle key={`${row}-${col}`} cx={col * 30 + 15} cy={row * 30 + 15} r="1.8" fill="#3D4FA0"/>
          )))}
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Flexible Support Models</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Support the way your business needs it</h2>
            <p className="mt-2 text-gray-500 max-w-xl mx-auto text-sm">Whether you need a few hours of expert assistance each month or a full-time SAP resource, we become an extension of your IT team.</p>
          </div>

          <div className="space-y-6">
            {SUPPORT_MODELS.map((model, i) => {
              const Icon = model.icon;
              const isEven = i % 2 === 0;
              return (
                <motion.div key={model.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.06 }}
                  className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden">
                  <div className="grid lg:grid-cols-12 items-stretch">
                    <div className={`lg:col-span-4 relative ${isEven ? "order-first" : "order-first lg:order-last"}`}>
                      <div className="relative h-48 lg:h-full min-h-[200px]">
                        <img src={model.image} alt={model.title} className="w-full h-full object-cover" loading="lazy"/>
                        <div className="absolute inset-0" style={{ background: `linear-gradient(135deg, ${model.accent}55 0%, transparent 60%)` }}/>
                        <div className={`absolute top-4 ${isEven ? "left-4" : "left-4 lg:left-auto lg:right-4"} w-11 h-11 rounded-xl flex items-center justify-center bg-white shadow-lg`}>
                          <Icon size={20} style={{ color: model.accent }}/>
                        </div>
                        <svg className="absolute bottom-0 left-0 right-0" viewBox="0 0 400 20" fill="white" preserveAspectRatio="none">
                          <path d="M0 20 Q100 6 200 12 Q300 20 400 6 L400 20 Z"/>
                        </svg>
                      </div>
                    </div>
                    <div className={`lg:col-span-8 p-7 flex flex-col justify-center ${isEven ? "order-last" : "order-last lg:order-first"}`}>
                      <div className="flex items-center gap-2 mb-2">
                        <span className="w-4 h-0.5 rounded" style={{ backgroundColor: model.accent }}/>
                        <span className="text-[10px] font-bold uppercase tracking-widest" style={{ color: model.accent }}>Support Model</span>
                        <span className="ml-auto text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full" style={{ backgroundColor: model.accent + "18", color: model.accent }}>{model.tagline}</span>
                      </div>
                      <h3 className="text-xl font-bold mb-2" style={{ color: accentColor }}>{model.title}</h3>
                      <p className="text-gray-600 text-sm leading-relaxed mb-4">{model.desc}</p>
                      <div>
                        <div className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2">{i === 0 ? "Remote Support Includes" : i === 1 ? "Resource Options" : "Includes"}</div>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2">
                          {model.points.map(pt => (
                            <div key={pt} className="flex items-center gap-1.5 text-xs text-gray-700">
                              <ChevronRight size={12} style={{ color: model.accent }} className="flex-shrink-0"/>
                              {pt}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── WHAT'S INCLUDED ──────────────────────────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden">
        <svg className="absolute -top-8 -right-8 opacity-[0.05] w-72 h-72" viewBox="0 0 200 200" fill="none">
          <path d="M40 40 L80 20 L160 60 L180 140 L120 180 L40 160 L20 80 Z" stroke="#3D4FA0" strokeWidth="2.5" strokeDasharray="6 4"/>
          <circle cx="100" cy="100" r="30" stroke="#E84821" strokeWidth="1.5" strokeDasharray="4 3"/>
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">What's Included in Our SAP Support Services?</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Complete care for your SAP investment</h2>
            <p className="mt-2 text-gray-500 max-w-xl mx-auto text-sm">Five pillars of ongoing SAP support that keep your system secure, performant, and aligned with your business growth.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {SERVICE_AREAS.map((s, i) => {
              const Icon = s.icon;
              return (
                <motion.div key={s.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }}
                  className="bg-white rounded-2xl p-6 border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all relative overflow-hidden">
                  <div className="absolute top-0 left-0 right-0 h-1" style={{ backgroundColor: s.accent }}/>
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4" style={{ backgroundColor: `${s.accent}15` }}>
                    <Icon size={22} style={{ color: s.accent }}/>
                  </div>
                  <h3 className="text-base font-bold mb-1.5" style={{ color: accentColor }}>{s.title}</h3>
                  <p className="text-xs text-gray-600 leading-relaxed mb-4">{s.desc}</p>
                  <div className="space-y-1.5">
                    {s.points.map(pt => (
                      <div key={pt} className="flex items-center gap-1.5 text-xs text-gray-600">
                        <ChevronRight size={11} style={{ color: s.accent }} className="flex-shrink-0"/>
                        {pt}
                      </div>
                    ))}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── SUPPORT PLANS ────────────────────────────────────────────────── */}
      <section id="plans" className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 900 500" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="450" cy="250" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          <circle cx="450" cy="250" r="320" stroke="white" strokeWidth="0.5" strokeDasharray="4 8" opacity="0.5"/>
          {[[80,60],[200,380],[700,60],[820,380],[320,50],[580,440]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-6 L2-2 L6-2 L3 2 L4 6 L0 3 L-4 6 L-3 2 L-6-2 L-2-2Z" fill="white" opacity="0.5"/></g>
          ))}
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#D4920C]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#D4920C]">Our Support Plans</span>
              <span className="w-6 h-0.5 rounded bg-[#D4920C]"/>
            </div>
            <h2 className="text-3xl font-bold text-white">Choose the right support level for your business</h2>
            <p className="mt-2 text-gray-400 max-w-xl mx-auto text-sm">Flexible support plans designed for every stage of your SAP journey.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {PLANS.map((plan, i) => (
              <motion.div key={plan.name} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                className={`rounded-2xl overflow-hidden border transition-all duration-300 hover:-translate-y-1 ${plan.featured ? "border-[#D4920C]/60 shadow-2xl scale-[1.02]" : "border-white/15 hover:border-white/30"}`}
                style={{ backgroundColor: plan.featured ? "rgba(212,146,12,0.12)" : "rgba(255,255,255,0.07)" }}>
                {plan.featured && (
                  <div className="py-2 text-center text-[10px] font-bold uppercase tracking-widest bg-[#D4920C] text-white">
                    Most Popular
                  </div>
                )}
                <div className="p-6">
                  <div className="w-8 h-1 rounded-full mb-4" style={{ backgroundColor: plan.accent }}/>
                  <h3 className="text-xl font-bold text-white mb-2">{plan.name}</h3>
                  <p className="text-gray-400 text-xs leading-relaxed mb-5">{plan.tagline}</p>
                  <div className="space-y-2.5 mb-6">
                    {plan.features.map(f => (
                      <div key={f} className="flex items-start gap-2 text-xs text-gray-300">
                        <CheckCircle2 size={13} className="flex-shrink-0 mt-0.5" style={{ color: plan.accent }}/>
                        {f}
                      </div>
                    ))}
                  </div>
                  <Link href="/contact"
                    className="block text-center py-2.5 rounded-xl font-bold text-sm transition-all hover:-translate-y-0.5"
                    style={plan.featured
                      ? { backgroundColor: plan.accent, color: "#fff" }
                      : { backgroundColor: `${plan.accent}25`, color: plan.accent }}>
                    Get a Quote
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── WHY CTRLA ────────────────────────────────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why CtrlA Tech Solutions?</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl font-bold mb-2" style={{ color: accentColor }}>Our SAP support team delivers maximum business value</h2>
            <p className="text-gray-500 max-w-2xl mx-auto text-sm">We combine deep functional knowledge with technical expertise to ensure your ERP system continues to perform at its best.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3 mb-10">
            {WHY_US.map((w, i) => (
              <motion.div key={w} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}
                className="flex items-start gap-2.5 bg-gray-50 rounded-xl p-3.5 border border-gray-100 hover:border-[#E84821]/30 hover:bg-[#FFF4F1] transition-colors">
                <CheckCircle2 size={14} className="flex-shrink-0 mt-0.5 text-[#E84821]"/>
                <span className="text-xs text-gray-700 leading-relaxed">{w}</span>
              </motion.div>
            ))}
          </div>

          {/* image strip */}
          <div className="grid grid-cols-3 gap-4 rounded-2xl overflow-hidden h-40">
            {[
              { src: "https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&w=500&q=80", label: "Helpdesk Support" },
              { src: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=500&q=80", label: "Expert Consultants" },
              { src: "https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&w=500&q=80", label: "System Monitoring" },
            ].map(item => (
              <div key={item.label} className="relative overflow-hidden rounded-2xl">
                <img src={item.src} alt={item.label} className="w-full h-full object-cover"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/50 to-transparent"/>
                <div className="absolute bottom-3 left-3 text-white text-xs font-bold">{item.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────────── */}
      <section className="py-16 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 900 300" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="450" cy="150" r="120" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          <circle cx="450" cy="150" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="4 8" opacity="0.6"/>
          {[[100,40],[800,240],[300,110],[600,170]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-5 L2-2 L5-2 L3 2 L4 5 L0 3 L-4 5 L-3 2 L-5-2 L-2-2Z" fill="white" opacity="0.5"/></g>
          ))}
        </svg>
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <HeadphonesIcon size={36} className="mx-auto mb-4 text-[#E84821]"/>
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Focus on Your Business — We'll Manage Your SAP</h2>
          <p className="text-gray-300 max-w-2xl mx-auto mb-8 leading-relaxed">
            Whether you need remote SAP support, dedicated SAP consultants, annual maintenance services, or staff augmentation, CtrlA Tech Solutions provides flexible and cost-effective support models that ensure your ERP system remains <strong className="text-white">secure, optimized, and always available</strong>.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl text-sm font-bold text-white shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all bg-[#E84821]">
              Get a Free Support Assessment <ArrowRight size={16} />
            </Link>
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl text-sm font-bold border border-white/30 text-white hover:bg-white/10 transition-all">
              Request an AMC Quote
            </Link>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
