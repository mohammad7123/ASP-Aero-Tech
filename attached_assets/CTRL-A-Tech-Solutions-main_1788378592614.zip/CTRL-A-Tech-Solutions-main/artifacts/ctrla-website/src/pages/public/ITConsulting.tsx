import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  ArrowRight, Lightbulb, CheckCircle2, Map, Users, BarChart3,
  TrendingUp, Settings, Zap, Brain, Database, ChevronRight,
  Building2, ShoppingCart, Truck, HeartPulse, Globe2,
  Briefcase, GraduationCap, Factory,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

const CONSULTING_SERVICES = [
  {
    icon: Map,
    title: "Technology Strategy",
    color: "#E84821",
    bg: "#FFF4F1",
    desc: "Build a future-ready IT strategy that aligns technology investments with your business goals — from IT landscape assessment to a clear growth roadmap.",
    features: ["IT Strategy Planning", "Enterprise Architecture", "Technology Assessment", "Infrastructure Planning", "Cloud Adoption Strategy", "IT Governance"],
  },
  {
    icon: TrendingUp,
    title: "Digital Roadmap",
    color: "#3D4FA0",
    bg: "#F0F3FF",
    desc: "Every successful digital transformation starts with a clear roadmap. We help businesses prioritize initiatives, define phases, and establish measurable outcomes.",
    features: ["Current State Assessment", "Future Technology Vision", "Digital Transformation Planning", "Project Prioritization", "Risk Assessment", "Implementation Timeline"],
  },
  {
    icon: Users,
    title: "Vendor Selection",
    color: "#D4920C",
    bg: "#FFFBEB",
    desc: "Choosing the right technology partner is critical. We provide independent consulting to evaluate vendors, compare solutions, and negotiate the best value.",
    features: ["Requirements Analysis", "Vendor Evaluation", "Solution Comparison", "RFP & RFQ Support", "Product Demonstrations", "Contract Advisory"],
  },
  {
    icon: BarChart3,
    title: "ROI Analysis",
    color: "#059669",
    bg: "#ECFDF5",
    desc: "Ensure your technology investments deliver measurable business value through rigorous financial and operational impact analysis.",
    features: ["Total Cost of Ownership (TCO)", "Return on Investment (ROI)", "Cost-Benefit Analysis", "Business Case Development", "Investment Planning", "Performance Metrics"],
  },
  {
    icon: Zap,
    title: "Digital Transformation",
    color: "#7C3AED",
    bg: "#F5F3FF",
    desc: "Transform your organization by adopting modern technologies that improve efficiency, enhance customer experiences, and create new business opportunities.",
    features: ["ERP Modernization", "Cloud Transformation", "Business Process Digitization", "AI & Automation Strategy", "Data-Driven Decision Making", "Enterprise Integration"],
  },
  {
    icon: Settings,
    title: "Business Process Automation",
    color: "#DC2626",
    bg: "#FFF1F1",
    desc: "Digitize and automate repetitive business processes across finance, procurement, sales, HR, manufacturing, warehouse, and customer service.",
    features: ["Workflow Automation", "Document Approval Workflows", "Purchase & Sales Automation", "Invoice Processing", "Employee Onboarding", "Notifications & Alerts"],
  },
  {
    icon: Brain,
    title: "AI & Machine Learning Integration",
    color: "#0F766E",
    bg: "#F0FDFA",
    desc: "Embed Artificial Intelligence into your business applications to automate decisions, predict trends, and improve operational efficiency.",
    features: ["Intelligent Chatbots", "OCR & Document Processing", "Predictive Analytics", "AI Assistants", "Demand Forecasting", "Machine Learning Models"],
  },
  {
    icon: Database,
    title: "Data Analytics & Business Intelligence",
    color: "#B45309",
    bg: "#FFFBEB",
    desc: "Convert business data into actionable insights that support faster, more informed decision-making across every department.",
    features: ["Executive Dashboards", "Business KPIs", "Sales & Financial Analytics", "Inventory Analytics", "Predictive Reporting", "Power BI Integration"],
  },
];

const TRANSFORMATION_CAPABILITIES = [
  "ERP Implementation Advisory",
  "Legacy System Modernization",
  "Application Reengineering",
  "UI/UX Modernization",
  "Database Migration",
  "API Enablement",
  "Cloud Migration Planning",
  "Performance Optimization",
  "Change Management Strategy",
  "Business Technology Alignment",
  "Enterprise Integration",
  "Scalable Architecture Design",
];

const INDUSTRIES = [
  { icon: Factory,      label: "Manufacturing",         color: "#3D4FA0" },
  { icon: ShoppingCart, label: "Retail & Distribution",  color: "#E84821" },
  { icon: Truck,        label: "Warehousing & Logistics", color: "#D4920C" },
  { icon: HeartPulse,   label: "Healthcare",             color: "#DC2626" },
  { icon: BarChart3,    label: "Financial Services",      color: "#059669" },
  { icon: Globe2,       label: "eCommerce",               color: "#7C3AED" },
  { icon: GraduationCap,label: "Education",              color: "#0F766E" },
  { icon: Briefcase,    label: "Professional Services",   color: "#B45309" },
];

const WHY_CTRLA = [
  "Business-First Consulting Approach",
  "Technology-Neutral Recommendations",
  "Industry-Specific Expertise",
  "ERP, Cloud & AI Specialists",
  "End-to-End Project Guidance",
  "Proven Digital Transformation Experience",
  "Scalable & Future-Ready Solutions",
  "Long-Term Strategic Partnership",
  "Reduce Manual Work & Operational Costs",
  "Leverage AI & Intelligent Automation",
];

export default function ITConsultingPage() {
  const { primaryColor, accentColor } = useSiteConfig();

  return (
    <PublicLayout>
      <SEO
        title="IT Consulting & Digital Transformation — CtrlA Tech Solutions"
        description="Strategic IT consulting services: technology strategy, digital roadmap, vendor selection, ROI analysis, process automation, AI integration, and end-to-end digital transformation for Indian businesses."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: "IT Consulting & Digital Transformation",
          description: "Strategic IT consulting services: technology strategy, digital roadmap, vendor selection, ROI analysis, process automation, AI integration, and end-to-end digital transformation for Indian businesses.",
          provider: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
          areaServed: ["IN", "GB"],
          serviceType: ["Technology Strategy", "Digital Transformation", "IT Roadmap Planning", "Process Automation", "AI Integration"],
          url: window.location.href,
        }}
      />

      {/* ── HERO ─────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden" style={{ background: "linear-gradient(140deg, #0d1225 0%, #1A1F36 55%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 1200 520" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="960" cy="260" r="340" stroke="#D4920C" strokeWidth="0.8" strokeDasharray="12 8"/>
          <circle cx="960" cy="260" r="200" stroke={primaryColor} strokeWidth="0.5" strokeDasharray="6 10"/>
          <path d="M80 120 L200 80 L280 140 L400 90 L500 150 L620 100" stroke="#E84821" strokeWidth="0.5" fill="none" strokeDasharray="6 8"/>
          <path d="M0 380 Q300 330 600 360 Q900 390 1200 350" stroke="white" strokeWidth="0.5" fill="none" strokeDasharray="7 7"/>
          <rect x="820" y="80" width="140" height="140" rx="20" stroke="#D4920C" strokeWidth="0.6" strokeDasharray="8 6"/>
          <rect x="880" y="300" width="100" height="100" rx="14" stroke={primaryColor} strokeWidth="0.5" strokeDasharray="5 7"/>
          {[[55,55],[180,290],[310,90],[220,195],[490,330],[640,110],[770,265],[410,200]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-7 L2-2.5 L7-2.5 L3.5 2 L5 7 L0 4 L-5 7 L-3.5 2 L-7-2.5 L-2-2.5Z" fill="white" opacity="0.45"/>
            </g>
          ))}
        </svg>

        <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-22">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <Link href="/services" className="inline-flex items-center gap-1.5 text-white/40 text-xs mb-5 hover:text-white/70 transition-colors">← IT Services</Link>
              <div className="inline-flex items-center gap-2 mb-4 px-3 py-1.5 rounded-full border border-[#D4920C]/40 bg-[#D4920C]/12">
                <Lightbulb size={13} className="text-[#D4920C]"/>
                <span className="text-xs font-black uppercase tracking-widest text-[#D4920C]">IT Consulting</span>
              </div>
              <h1 className="text-4xl sm:text-5xl font-black leading-[1.06] text-white mb-3">
                Strategic Technology<br/>
                <span style={{ color: primaryColor }}>Consulting for</span><br/>
                <span className="text-white/80 text-3xl sm:text-4xl font-bold">Sustainable Business Growth</span>
              </h1>
              <div className="flex gap-2 my-5">
                <span className="h-1 w-12 rounded-full bg-[#E84821]"/>
                <span className="h-1 w-7 rounded-full" style={{ backgroundColor: primaryColor }}/>
                <span className="h-1 w-4 rounded-full bg-[#3D4FA0]"/>
              </div>
              <p className="text-gray-300 text-sm leading-relaxed mb-3 max-w-lg">
                Technology is evolving rapidly, and choosing the right digital strategy can define your business's future. At CtrlA Tech Solutions, we help organizations align technology with business objectives through strategic IT consulting.
              </p>
              <p className="text-gray-400 text-sm leading-relaxed mb-8 max-w-lg">
                Whether you're planning an <strong className="text-white">ERP implementation, cloud migration, AI adoption</strong>, or enterprise-wide digital transformation — our consultants provide practical, business-focused guidance for informed technology decisions.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 shadow-lg transition-all text-sm">
                  Schedule a Free Consultation <ArrowRight size={15}/>
                </Link>
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
                  Talk to Our IT Experts <ChevronRight size={14}/>
                </Link>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.12 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10">
                <img
                  src="https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=800&q=80"
                  alt="IT consulting strategy session"
                  className="w-full h-64 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/80 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#D4920C] animate-pulse flex-shrink-0"/>
                    <span className="text-white text-xs font-semibold">Business-first · Technology-neutral · End-to-end guidance</span>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3 mt-4">
                {[{ n: "8+", label: "Service Areas" }, { n: "50+", label: "Projects Delivered" }, { n: "9", label: "Industries Served" }].map(s => (
                  <div key={s.label} className="bg-white/5 border border-white/10 rounded-xl p-3 text-center">
                    <div className="text-xl font-black text-white">{s.n}</div>
                    <div className="text-white/50 text-xs mt-0.5">{s.label}</div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
        <div className="h-1 flex">
          <div className="flex-[3] bg-[#E84821]"/><div className="flex-[2]" style={{ backgroundColor: primaryColor }}/><div className="flex-1 bg-[#3D4FA0]"/>
        </div>
      </section>

      {/* ── CONSULTING SERVICES GRID ─────────────────────────────────── */}
      <section className="py-16 md:py-20 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFFBEB 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 700" preserveAspectRatio="xMidYMid slice">
          {Array.from({length:20}).map((_,r)=>Array.from({length:26}).map((_,c)=>(
            <circle key={`${r}-${c}`} cx={c*35+17} cy={r*35+17} r="1.6" fill="#D4920C"/>
          )))}
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Our IT Consulting Services</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>From strategy to execution — full-spectrum IT consulting</h2>
            <p className="text-gray-500 text-sm mt-2 max-w-xl mx-auto">We align technology with your business objectives through practical, vendor-neutral guidance across strategy, transformation, automation, and analytics.</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {CONSULTING_SERVICES.map((s, i) => {
              const Icon = s.icon;
              return (
                <motion.div key={s.title} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.07 }}
                  className="bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                  <div className="h-1.5 w-full" style={{ backgroundColor: s.color }}/>
                  <div className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: s.bg }}>
                        <Icon size={20} style={{ color: s.color }}/>
                      </div>
                      <h3 className="font-bold text-gray-900 text-sm leading-tight">{s.title}</h3>
                    </div>
                    <p className="text-gray-500 text-xs leading-relaxed mb-4">{s.desc}</p>
                    <div className="grid grid-cols-2 gap-1.5">
                      {s.features.map(f => (
                        <div key={f} className="flex items-center gap-1.5 text-xs text-gray-600">
                          <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: s.color }}/>
                          {f}
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── CAPABILITIES + INDUSTRIES ─────────────────────────────────── */}
      <section className="py-16 bg-white border-t border-gray-100 relative overflow-hidden">
        <svg className="absolute -right-16 inset-y-0 h-full opacity-[0.04]" viewBox="0 0 300 600" fill="none">
          <circle cx="250" cy="300" r="220" stroke="#D4920C" strokeWidth="1.5" strokeDasharray="8 6"/>
          <circle cx="250" cy="300" r="140" stroke="#E84821" strokeWidth="1" strokeDasharray="5 8"/>
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-14">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-6 h-0.5 rounded bg-[#D4920C]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#D4920C]">Transformation Capabilities</span>
              </div>
              <h2 className="text-2xl font-bold mb-5" style={{ color: accentColor }}>12 consulting capabilities across the digital stack</h2>
              <div className="grid sm:grid-cols-2 gap-2">
                {TRANSFORMATION_CAPABILITIES.map((s, i) => (
                  <motion.div key={s} initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}
                    className="flex items-center gap-2 p-2.5 rounded-xl bg-gray-50 border border-gray-100 text-xs font-semibold text-gray-700 hover:border-[#D4920C]/30 hover:bg-[#D4920C]/3 transition-all">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#D4920C] flex-shrink-0"/>
                    {s}
                  </motion.div>
                ))}
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Industries We Serve</span>
              </div>
              <h2 className="text-2xl font-bold mb-5" style={{ color: accentColor }}>Consulting for every industry</h2>
              <div className="grid grid-cols-2 gap-3">
                {INDUSTRIES.map((ind, i) => {
                  const Icon = ind.icon;
                  return (
                    <motion.div key={ind.label} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.06 }}
                      className="flex items-center gap-3 p-3 rounded-xl bg-gray-50 border border-gray-100 hover:shadow-md hover:-translate-y-0.5 transition-all">
                      <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${ind.color}15` }}>
                        <Icon size={16} style={{ color: ind.color }}/>
                      </div>
                      <span className="text-sm font-semibold text-gray-700">{ind.label}</span>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── WHY CTRLA ────────────────────────────────────────────────── */}
      <section className="py-16 border-t border-gray-100 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF8EC 100%)" }}>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-14 items-center">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why CtrlA Tech Solutions?</span>
              </div>
              <h2 className="text-3xl font-bold mb-4" style={{ color: accentColor }}>
                Business-first consulting.<br/>
                <span style={{ color: "#E84821" }}>Technology-neutral recommendations.</span>
              </h2>
              <p className="text-gray-500 text-sm leading-relaxed mb-6">
                Our experienced consultants bring deep expertise in ERP, cloud, AI, and enterprise integration — providing practical, vendor-neutral guidance that helps you make confident technology decisions and achieve measurable business outcomes.
              </p>
              <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white shadow-lg hover:-translate-y-0.5 transition-all text-sm" style={{ backgroundColor: primaryColor }}>
                Book a Strategy Session <ArrowRight size={15}/>
              </Link>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="space-y-2.5">
                {WHY_CTRLA.map((w, i) => (
                  <motion.div key={w} initial={{ opacity: 0, x: 12 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.07 }}
                    className="flex items-center gap-3 p-3 rounded-xl bg-white border border-gray-100 hover:border-[#D4920C]/30 hover:bg-[#D4920C]/3 transition-all">
                    <div className="w-9 h-9 rounded-lg flex items-center justify-center bg-[#D4920C]/10 flex-shrink-0">
                      <CheckCircle2 size={15} className="text-[#D4920C]"/>
                    </div>
                    <span className="text-sm font-semibold text-gray-700">{w}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 900 280" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="820" cy="140" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          {[[80,50],[200,210],[370,60],[520,190],[650,80]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-5 L2-2 L5-2 L3 2 L4 5 L0 3 L-4 5 L-3 2 L-5-2 L-2-2Z" fill="white" opacity="0.5"/>
            </g>
          ))}
        </svg>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <h2 className="text-3xl font-bold text-white mb-3">Transform Ideas into Business Value</h2>
          <p className="text-gray-400 text-sm mb-8 max-w-2xl mx-auto leading-relaxed">
            Whether you're planning a new ERP implementation, modernizing legacy systems, adopting cloud technologies, or building a long-term digital strategy — CtrlA Tech Solutions provides the expertise to help you make confident technology decisions and achieve measurable business outcomes.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 transition-all text-sm shadow-xl">
              Book a Strategy Session <ArrowRight size={15}/>
            </Link>
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
              Request a Technology Assessment <ChevronRight size={14}/>
            </Link>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1 flex">
          <div className="flex-[3] bg-[#E84821]"/>
          <div className="flex-[2]" style={{ backgroundColor: primaryColor }}/>
          <div className="flex-1 bg-[#3D4FA0]"/>
        </div>
      </section>
    </PublicLayout>
  );
}
