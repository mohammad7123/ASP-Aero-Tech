import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  ArrowRight, CheckCircle2, BarChart3, Users, Package,
  ShoppingCart, Factory, FileText, Sparkles, Globe2,
  Cloud, Smartphone, TrendingUp, Award, HeadphonesIcon,
  ChevronRight,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import PageHero from "@/components/public/PageHero";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

const STATS = [
  { label: "Countries Worldwide", value: "170+" },
  { label: "Businesses Running SAP B1", value: "80,000+" },
  { label: "Years Combined ERP Experience", value: "22+" },
  { label: "Successful Implementations", value: "200+" },
];

const MODULES = [
  {
    icon: BarChart3,
    title: "Financial Management",
    desc: "Gain complete control over your financial operations with integrated accounting, banking, budgeting, fixed assets, and financial reporting. Automate routine accounting tasks while maintaining complete visibility into your organization's financial health.",
    accent: "#E84821",
    bg: "#FFF4F1",
    image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?auto=format&fit=crop&w=600&q=80",
    features: ["General Ledger", "Accounts Payable & Receivable", "Banking & Reconciliation", "Fixed Assets", "Budget Management", "Multi-Currency Support", "Financial Reporting"],
  },
  {
    icon: Users,
    title: "Sales & Customer Relationship Management",
    desc: "Manage your complete sales lifecycle from lead generation to quotation, order processing, delivery, invoicing, and customer service—all from a single platform.",
    accent: "#D4920C",
    bg: "#FFFBEB",
    image: "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=600&q=80",
    features: ["Lead & Opportunity Management", "Quotations & Sales Orders", "Customer Management", "Pricing & Discounts", "Customer Service", "Sales Analytics", "Sales Forecasting"],
  },
  {
    icon: Package,
    title: "Inventory & Warehouse Management",
    desc: "Maintain real-time inventory visibility across multiple warehouses while improving stock accuracy and reducing inventory costs.",
    accent: "#3D4FA0",
    bg: "#F0F3FF",
    image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=600&q=80",
    features: ["Multi-Warehouse Management", "Bin Location Management", "Batch & Serial Number Tracking", "Stock Transfers", "Inventory Counting", "Goods Receipt & Issue", "Automatic Replenishment"],
  },
  {
    icon: ShoppingCart,
    title: "Purchasing & Procurement",
    desc: "Optimize procurement processes with automated purchase requests, approvals, vendor management, and purchasing workflows.",
    accent: "#059669",
    bg: "#F0FDF6",
    image: "https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=600&q=80",
    features: ["Purchase Requests", "Purchase Orders", "Goods Receipt PO", "Vendor Management", "Approval Workflows", "Purchase Analysis", "Cost Control"],
  },
  {
    icon: Factory,
    title: "Production & Material Planning",
    desc: "Improve manufacturing efficiency with integrated production planning, Bill of Materials (BOM), Material Requirements Planning (MRP), and shop floor management.",
    accent: "#7C3AED",
    bg: "#F5F3FF",
    image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=600&q=80",
    features: ["Bill of Materials (BOM)", "Production Orders", "Material Requirements Planning (MRP)", "Resource Planning", "Production Costing", "Work Order Tracking"],
  },
  {
    icon: FileText,
    title: "Reporting & Business Intelligence",
    desc: "Make informed business decisions with real-time dashboards, customizable reports, and powerful business analytics.",
    accent: "#0F766E",
    bg: "#F0FDFA",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=600&q=80",
    features: ["Interactive Dashboards", "Crystal Reports", "KPI Monitoring", "Financial Reports", "Inventory Reports", "Sales Reports", "Executive Analytics"],
  },
];

const SAP_BENEFITS = [
  "Single integrated platform for all business operations",
  "Real-time visibility into every department",
  "Faster and more informed decision-making",
  "Improved operational efficiency",
  "Reduced manual work through automation",
  "Better inventory and financial control",
  "Scalable platform that grows with your business",
  "Mobile access for business on the go",
  "Cloud and On-Premise deployment options",
  "Secure, reliable, and future-ready architecture",
];

const CTRLA_STRENGTHS = [
  "22+ years of combined ERP consulting experience",
  "Proven expertise in ERP implementation, customization, and integration",
  "Industry-specific business process knowledge",
  "End-to-end project management from planning to go-live",
  "Seamless integration with WMS, OMS, CRM, eCommerce, and third-party applications",
  "Cloud migration and managed hosting services",
  "User training and knowledge transfer",
  "Dedicated post-implementation support and AMC services",
  "Customer-focused approach with 90% customer retention",
];

const METHODOLOGY = [
  { step: "01", label: "Business Process Assessment" },
  { step: "02", label: "Solution Design & Planning" },
  { step: "03", label: "System Configuration" },
  { step: "04", label: "Customization & Development" },
  { step: "05", label: "Data Migration" },
  { step: "06", label: "Integration with Existing Systems" },
  { step: "07", label: "User Acceptance Testing (UAT)" },
  { step: "08", label: "User Training" },
  { step: "09", label: "Go-Live Support" },
  { step: "10", label: "Continuous Improvement & AMC" },
];

export default function SAPBusinessOnePage() {
  const { primaryColor, accentColor } = useSiteConfig();

  return (
    <PublicLayout>
      <SEO
        title="SAP Business One — Complete ERP for Growing Businesses"
        description="One intelligent ERP platform to manage your entire business—from finance and sales to inventory, purchasing, production, and customer relationships. Implemented by CtrlA Tech Solutions, certified SAP partner."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "SoftwareApplication",
          name: "SAP Business One",
          applicationCategory: "BusinessApplication",
          description: "One intelligent ERP platform to manage your entire business—from finance and sales to inventory, purchasing, production, and customer relationships. Implemented by CtrlA Tech Solutions, certified SAP partner.",
          operatingSystem: "Windows, Cloud",
          offers: {
            "@type": "Offer",
            seller: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
          },
          url: window.location.href,
        }}
      />

      {/* ── HERO ─────────────────────────────────────────────────────────── */}
      <PageHero
        eyebrow="ERP Solutions"
        title={<><span style={{ color: "#E84821" }}>SAP Business One</span> — Complete ERP for Growing Businesses</>}
        subtitle="One intelligent ERP platform to manage your entire business—from finance and sales to inventory, purchasing, production, and customer relationships. SAP Business One empowers small and medium-sized enterprises with real-time visibility, streamlined operations, and the scalability needed for sustainable growth."
        heroImage="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80"
        heroImageAlt="SAP Business One ERP dashboard and analytics"
        cta={
          <div className="flex flex-wrap gap-3 mt-6">
            <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5 bg-[#E84821]">
              Request a Demo <ArrowRight size={16} />
            </Link>
            <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border-2 border-white/40 text-white hover:bg-white/15 transition-all">
              Talk to an Expert
            </Link>
          </div>
        }
      />

      {/* ── STATS BAR ────────────────────────────────────────────────────── */}
      <section className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <p className="text-center text-xs font-bold uppercase tracking-widest text-gray-400 mb-6">Trusted ERP Solution for Growing Enterprises</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {STATS.map(s => (
              <div key={s.label}>
                <div className="text-3xl sm:text-4xl font-black" style={{ color: "#E84821" }}>{s.value}</div>
                <div className="text-xs text-gray-500 mt-1.5 font-medium leading-tight">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="h-1 flex"><div className="flex-[3] bg-[#E84821]" /><div className="flex-[2]" style={{ backgroundColor: primaryColor }} /><div className="flex-1 bg-[#3D4FA0]" /></div>
      </section>

      {/* ── INTRO ────────────────────────────────────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden">
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 400" fill="none" preserveAspectRatio="xMidYMid slice">
          <path d="M0 200h180l40-60h120l40 60h200l30-30h120l30 30h140" stroke="#3D4FA0" strokeWidth="2"/>
          <circle cx="180" cy="200" r="8" fill="#3D4FA0"/><circle cx="540" cy="200" r="8" fill="#3D4FA0"/>
          <path d="M700 0v120l50 50v120" stroke="#E84821" strokeWidth="2"/>
          <rect x="820" y="100" width="16" height="16" stroke="#D4920C" strokeWidth="2"/>
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#E84821]" />
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why SAP Business One?</span>
              </div>
              <h2 className="text-3xl font-bold mb-4" style={{ color: accentColor }}>One platform for every business operation</h2>
              <p className="text-gray-600 leading-relaxed mb-4">
                Whether you're looking to replace disconnected systems, automate manual processes, or gain better control over your business, SAP Business One provides everything you need in a single, integrated solution.
              </p>
              <p className="text-gray-600 leading-relaxed">
                Designed specifically for growing businesses that need enterprise-class functionality without the complexity of large-scale ERP systems.
              </p>
            </motion.div>
            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[4/3]">
                <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=900&q=80" alt="Team using SAP Business One ERP" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-tr from-[#1A1F36]/30 to-transparent"/>
                <div className="absolute bottom-4 left-4 bg-white/95 rounded-lg px-4 py-2.5 shadow-lg">
                  <div className="text-[10px] font-bold uppercase tracking-widest text-gray-500">SAP Implementation Consultant</div>
                  <div className="text-sm font-bold text-gray-900 mt-0.5">End-to-End Implementation</div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── CORE MODULES ─────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.04]" viewBox="0 0 900 600" preserveAspectRatio="xMidYMid slice">
          {Array.from({ length: 18 }).map((_, row) =>
            Array.from({ length: 30 }).map((_, col) => (
              <circle key={`${row}-${col}`} cx={col * 30 + 15} cy={row * 30 + 15} r="2" fill="#3D4FA0"/>
            ))
          )}
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]" />
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Core Business Modules</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]" />
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>22+ business processes. One system.</h2>
            <p className="mt-2 text-gray-500 max-w-xl mx-auto text-sm">Every department connected, every process integrated — from day one.</p>
          </div>

          <div className="space-y-8">
            {MODULES.map((m, i) => {
              const Icon = m.icon;
              const isEven = i % 2 === 0;
              return (
                <motion.div
                  key={m.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.1 }}
                  className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden"
                >
                  <div className={`grid lg:grid-cols-12 gap-0 items-stretch ${isEven ? "" : "lg:flex-row-reverse"}`}>
                    {/* Image */}
                    <div className={`lg:col-span-4 relative ${isEven ? "order-first" : "order-first lg:order-last"}`}>
                      <div className="relative h-52 lg:h-full min-h-[200px]">
                        <img src={m.image} alt={m.title} className="w-full h-full object-cover" loading="lazy"/>
                        <div className="absolute inset-0" style={{ background: `linear-gradient(135deg, ${m.accent}55 0%, transparent 60%)` }}/>
                        <div className={`absolute top-4 ${isEven ? "left-4" : "left-4 lg:left-auto lg:right-4"} w-11 h-11 rounded-xl flex items-center justify-center bg-white shadow-lg`}>
                          <Icon size={20} style={{ color: m.accent }}/>
                        </div>
                      </div>
                    </div>
                    {/* Content */}
                    <div className={`lg:col-span-8 p-7 flex flex-col justify-center ${isEven ? "order-last" : "order-last lg:order-first"}`}>
                      <div className="flex items-center gap-2 mb-3">
                        <span className="w-4 h-0.5 rounded" style={{ backgroundColor: m.accent }}/>
                        <span className="text-[10px] font-bold uppercase tracking-widest" style={{ color: m.accent }}>Module</span>
                      </div>
                      <h3 className="text-xl font-bold mb-2" style={{ color: accentColor }}>{m.title}</h3>
                      <p className="text-gray-600 text-sm leading-relaxed mb-5">{m.desc}</p>
                      <div>
                        <div className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-3">Key Features</div>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2">
                          {m.features.map(f => (
                            <div key={f} className="flex items-center gap-1.5 text-xs text-gray-700">
                              <ChevronRight size={12} style={{ color: m.accent }} className="flex-shrink-0"/>
                              {f}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── WHY SAP B1 ───────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 900 500" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="450" cy="250" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          <circle cx="450" cy="250" r="300" stroke="white" strokeWidth="0.5" strokeDasharray="4 8" opacity="0.5"/>
          {[[80,60],[250,100],[700,80],[860,30],[60,420],[600,380],[800,180]].map(([cx, cy], i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-6 L2-2 L6-2 L3 2 L4 6 L0 3 L-4 6 L-3 2 L-6-2 L-2-2Z" fill="white" opacity="0.5"/>
            </g>
          ))}
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#D4920C]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#D4920C]">Why Choose SAP Business One?</span>
              </div>
              <h2 className="text-3xl font-bold text-white mb-4">Built for growing businesses. Trusted worldwide.</h2>
              <p className="text-gray-300 text-sm leading-relaxed mb-6">
                SAP Business One is designed specifically for growing businesses that need enterprise-class functionality without the complexity of large-scale ERP systems.
              </p>
              <div className="space-y-2.5">
                {SAP_BENEFITS.map((b, i) => (
                  <motion.div key={b} initial={{ opacity: 0, x: -10 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }} className="flex items-start gap-3">
                    <CheckCircle2 size={16} className="flex-shrink-0 mt-0.5 text-[#D4920C]"/>
                    <span className="text-gray-200 text-sm">{b}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }} className="space-y-4">
              {/* Deployment cards */}
              {[
                { icon: Cloud, label: "Cloud Deployment", desc: "Fully managed, auto-scaled, and accessible from anywhere.", color: "#3D4FA0" },
                { icon: Globe2, label: "On-Premise Deployment", desc: "Full control over your infrastructure and data residency.", color: "#E84821" },
                { icon: Smartphone, label: "Mobile Access", desc: "Manage operations on iOS and Android — anytime, anywhere.", color: "#059669" },
              ].map(item => {
                const Icon = item.icon;
                return (
                  <div key={item.label} className="bg-white/10 border border-white/15 rounded-2xl p-5 flex items-start gap-4 hover:bg-white/15 transition-colors">
                    <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: item.color + "30" }}>
                      <Icon size={20} style={{ color: item.color }}/>
                    </div>
                    <div>
                      <div className="text-white font-bold text-sm mb-1">{item.label}</div>
                      <div className="text-gray-400 text-xs leading-relaxed">{item.desc}</div>
                    </div>
                  </div>
                );
              })}
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-video mt-2">
                <img src="https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?auto=format&fit=crop&w=900&q=80" alt="Modern SAP ERP dashboard" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/60 to-transparent"/>
                <div className="absolute bottom-4 left-4 text-white">
                  <div className="text-[10px] font-bold uppercase tracking-widest text-gray-300">SAP Business One</div>
                  <div className="text-sm font-bold">Real-Time Business Intelligence</div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── WHY CTRLA ────────────────────────────────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden">
        <svg className="absolute -bottom-6 -left-6 opacity-[0.05] w-72 h-72" viewBox="0 0 200 200" fill="none">
          <path d="M20 180 Q60 140 100 160 Q140 180 160 140 Q180 100 160 60" stroke="#3D4FA0" strokeWidth="3" strokeLinecap="round"/>
          <circle cx="50" cy="60" r="12" stroke="#E84821" strokeWidth="2" strokeDasharray="4 3"/>
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="lg:col-span-5">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[3/4]">
                <img src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&w=800&q=80" alt="CtrlA Tech Solutions team implementing SAP ERP" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/50 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="bg-white/95 rounded-xl p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-[#E84821]">
                        <Award size={18} className="text-white"/>
                      </div>
                      <div>
                        <div className="text-xs font-bold text-gray-900">Certified SAP Professionals</div>
                        <div className="text-[10px] text-gray-500 mt-0.5">SAP Implementation Consultants • India & UK</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }} className="lg:col-span-7">
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why CtrlA Tech Solutions?</span>
              </div>
              <h2 className="text-3xl font-bold mb-3" style={{ color: accentColor }}>Choosing the right implementation partner matters</h2>
              <p className="text-gray-600 text-sm leading-relaxed mb-6">
                At CtrlA Tech Solutions, we combine deep business process expertise with technical excellence to deliver ERP solutions that create measurable business value.
              </p>
              <div className="grid sm:grid-cols-2 gap-3">
                {CTRLA_STRENGTHS.map((s, i) => (
                  <motion.div key={s} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }} className="flex items-start gap-2.5 bg-gray-50 rounded-xl p-3.5 border border-gray-100 hover:border-[#E84821]/30 hover:bg-[#FFF4F1] transition-colors">
                    <CheckCircle2 size={15} className="flex-shrink-0 mt-0.5" style={{ color: "#E84821" }}/>
                    <span className="text-xs text-gray-700 leading-relaxed">{s}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── METHODOLOGY ──────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 100%)" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Our Implementation Methodology</span>
              </div>
              <h2 className="text-3xl font-bold mb-3" style={{ color: accentColor }}>Our structured approach ensures a smooth, successful ERP deployment</h2>
              <p className="text-gray-500 text-sm leading-relaxed mb-8">A proven 10-step methodology refined over hundreds of ERP implementations across industries.</p>
              <div className="grid grid-cols-2 gap-3">
                {METHODOLOGY.map((m, i) => (
                  <motion.div key={m.step} initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }} className="flex items-center gap-3 bg-white rounded-xl p-3 border border-gray-100 shadow-sm">
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-black flex-shrink-0" style={{ background: "linear-gradient(135deg, #E84821, #D4920C)" }}>
                      {m.step}
                    </div>
                    <span className="text-xs font-semibold text-gray-700 leading-snug">{m.label}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }} className="relative">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[4/3]">
                <img src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=900&q=80" alt="ERP implementation project planning" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/50 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4 grid grid-cols-3 gap-2">
                  {[
                    { icon: TrendingUp, label: "On-Time", sub: "Delivery" },
                    { icon: Award, label: "Certified", sub: "Consultants" },
                    { icon: HeadphonesIcon, label: "24×7", sub: "Support" },
                  ].map(item => {
                    const Icon = item.icon;
                    return (
                      <div key={item.label} className="bg-white/90 rounded-lg p-2.5 text-center">
                        <Icon size={14} className="mx-auto mb-1" style={{ color: "#E84821" }}/>
                        <div className="text-xs font-bold text-gray-900">{item.label}</div>
                        <div className="text-[9px] text-gray-500">{item.sub}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────────── */}
      <section className="py-16 relative overflow-hidden bg-white border-t border-gray-100">
        <div className="pointer-events-none absolute inset-0 opacity-[0.05]" style={{ backgroundImage: `radial-gradient(circle at 30% 50%, #E84821 0%, transparent 50%), radial-gradient(circle at 70% 50%, #3D4FA0 0%, transparent 50%)` }}/>
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 mb-4 px-4 py-1.5 rounded-full bg-gray-50 border border-gray-200">
            <Sparkles size={13} style={{ color: "#E84821" }}/>
            <span className="text-xs font-bold uppercase tracking-widest text-gray-700">Ready to Transform Your Business?</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold mb-4" style={{ color: accentColor }}>
            Whether you're implementing ERP for the first time or upgrading your existing systems
          </h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto leading-relaxed">
            CtrlA Tech Solutions can help you maximize the value of SAP Business One with a solution tailored to your business goals.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Link href="/contact" className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl font-bold text-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5 bg-[#E84821]">
              Request a Demo <ArrowRight size={16} />
            </Link>
            <Link href="/contact" className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl font-semibold border-2 border-gray-200 hover:border-[#D4920C] text-gray-800 hover:text-[#D4920C] transition-all">
              Schedule a Free ERP Consultation <ArrowRight size={16} />
            </Link>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1 flex"><div className="flex-[3] bg-[#E84821]"/><div className="flex-[2]" style={{ backgroundColor: primaryColor }}/><div className="flex-1 bg-[#3D4FA0]"/></div>
      </section>
    </PublicLayout>
  );
}
