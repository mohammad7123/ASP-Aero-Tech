import { useRoute, Link } from "wouter";
import { Calendar, ArrowLeft } from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { useGetPublicBlogPost } from "@/lib/apiClient";
import { SEO } from "@/components/SEO";

export default function BlogPostPage() {
  const [, params] = useRoute("/blog/:slug");
  const slug = params?.slug ?? "";
  const { data: post, isLoading, isError } = useGetPublicBlogPost(slug);

  return (
    <PublicLayout>
      {post && (
        <SEO
          title={post.metaTitle ?? post.title}
          description={(post.metaDescription ?? post.excerpt) ?? undefined}
          ogImage={post.featuredImage ?? undefined}
          type="article"
          jsonLd={{
            "@context": "https://schema.org",
            "@type": "BlogPosting",
            headline: post.title,
            description: (post.metaDescription ?? post.excerpt) ?? undefined,
            image: post.featuredImage ?? undefined,
            datePublished: post.publishedAt ?? undefined,
            dateModified: post.updatedAt ?? undefined,
            mainEntityOfPage: {
              "@type": "WebPage",
              "@id": window.location.href,
            },
            author: { "@type": "Organization", name: "CtrlA Tech Solutions" },
            publisher: {
              "@type": "Organization",
              name: "CtrlA Tech Solutions",
              logo: {
                "@type": "ImageObject",
                url: `${window.location.origin}/logo.png`,
              },
            },
          }}
        />
      )}
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <Link href="/blog" className="inline-flex items-center gap-2 text-[#E84821] mb-8 hover:underline text-sm">
          <ArrowLeft size={16} /> Back to Blog
        </Link>

        {isLoading && (
          <div className="space-y-4 animate-pulse">
            <div className="h-10 bg-gray-200 rounded w-3/4" />
            <div className="h-4 bg-gray-100 rounded w-1/4" />
            <div className="h-64 bg-gray-100 rounded" />
          </div>
        )}

        {isError && (
          <>
            <SEO title="Post Not Found" noindex={true} />
            <div className="text-center py-12 text-gray-400">
              <p>Post not found.</p>
            </div>
          </>
        )}

        {post && (
          <article>
            <h1 className="text-4xl font-bold text-[#1C1917] mb-4">{post.title}</h1>
            <div className="flex items-center gap-2 text-sm text-gray-400 mb-8">
              <Calendar size={14} />
              {post.publishedAt ? new Date(post.publishedAt).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" }) : ""}
            </div>
            {post.featuredImage && (
              <img
                src={post.featuredImage}
                alt={post.title}
                className="w-full h-64 object-cover rounded-2xl mb-8"
              />
            )}
            <div
              className="prose prose-lg max-w-none prose-headings:text-[#1C1917] prose-a:text-[#E84821]"
              dangerouslySetInnerHTML={{ __html: post.content }}
            />
          </article>
        )}
      </div>
    </PublicLayout>
  );
}
