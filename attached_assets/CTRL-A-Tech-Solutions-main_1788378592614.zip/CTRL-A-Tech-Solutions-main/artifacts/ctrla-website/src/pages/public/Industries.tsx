import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "wouter";
import {
  X, ArrowRight, CheckCircle2, AlertTriangle, Lightbulb,
  Factory, ShoppingBag, HardHat, Utensils, Briefcase, Settings,
  FlaskConical, Package, Pill, Truck, Car, Shirt, Key, Leaf,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";
import PageHero from "@/components/public/PageHero";

// ── Types ────────────────────────────────────────────────────────────────────

type Challenge  = { title: string; desc: string };
type SolutionCard = { title: string; desc: string };

type IndustryData = {
  slug: string;
  name: string;
  Icon: React.ElementType;
  accent: string;
  tagline: string;
  brief: string;
  gap: string;
  close: string;
  challenges: Challenge[];
  solutions: SolutionCard[];
  offerings: string[];
  cta: string;
};

// ── Industry Dataset ──────────────────────────────────────────────────────────

const INDUSTRIES: IndustryData[] = [
  {
    slug: "manufacturing",
    name: "Manufacturing",
    Icon: Factory,
    accent: "#E84821",
    tagline: "From Production Bottlenecks to Smart Manufacturing",
    brief:
      "Manufacturing businesses require effective planning and strategizing of resources for smooth deployment of inventory, process management and production. CtrlA delivers an integrated ERP and WMS 360 platform covering procurement, shop floor, quality, and dispatch — giving management real-time visibility at every stage.",
    gap: "Production bottlenecks, inventory shortages, and quality control issues driven by disconnected systems.",
    close: "End-to-end ERP for production, inventory & supply chain combined with AI Demand Forecasting and WMS 360.",
    challenges: [
      { title: "Manual Production Planning", desc: "Relying on spreadsheets leads to inaccurate demand forecasting and missed schedules." },
      { title: "Inventory Inaccuracies",     desc: "Frequent shortages of raw materials or excess stock of finished goods drain working capital." },
      { title: "No Real-Time Shop-Floor View", desc: "Management cannot see machine utilization or WIP in real-time, causing costly delays." },
      { title: "Quality Control Gaps",        desc: "Defects detected late result in rework, waste, and customer dissatisfaction." },
    ],
    solutions: [
      { title: "Production Planning & MRP",  desc: "Optimize scheduling, reduce downtime and align procurement with actual demand." },
      { title: "AI Demand Forecasting",       desc: "Predict customer demand accurately to prevent stockouts and overproduction." },
      { title: "WMS 360 — Warehouse Control", desc: "Bin-location management, FIFO/FEFO, and real-time stock movement across stores." },
      { title: "Quality Management",          desc: "Track quality at every stage of the production lifecycle with auto-holds and inspections." },
      { title: "Real-Time OEE Dashboards",    desc: "Monitor Overall Equipment Effectiveness and machine utilization live." },
      { title: "Integrated Mobility",         desc: "Shop-floor workers capture transactions on mobile — no paper, no lag." },
    ],
    offerings: ["SAP Business One", "SAP S/4HANA", "WMS 360", "AI Demand Forecasting", "Quality Management", "Production Analytics"],
    cta: "Get a Manufacturing Assessment",
  },
  {
    slug: "retail",
    name: "Retail",
    Icon: ShoppingBag,
    accent: "#D4920C",
    tagline: "Build a Connected Omnichannel Retail Business",
    brief:
      "The global retail market demands multi-channel agility. Customers shop across physical stores, e-commerce, and marketplaces. CtrlA delivers OMS 360, WMS 360, and SAP Business One to unify your inventory, orders, POS, and financials into a single source of truth.",
    gap: "Inventory mismatches across channels, fulfillment delays, and pricing inconsistencies.",
    close: "Omnichannel OMS, WMS 360, POS integration, and AI-driven demand planning.",
    challenges: [
      { title: "Channel Inventory Conflict",  desc: "Stock mismatches between physical stores, e-commerce, and marketplaces like Amazon and Flipkart." },
      { title: "Logistics Chaos",             desc: "Delayed order fulfillment and high shipping costs due to poor warehouse organisation." },
      { title: "Pricing Inconsistencies",     desc: "Confusing pricing across channels harms brand reputation and erodes margins." },
      { title: "Poor Customer Intelligence",  desc: "Lack of purchase history analytics prevents personalised promotions and loyalty programs." },
    ],
    solutions: [
      { title: "OMS 360 — Order Hub",         desc: "Manage orders from all channels in one interface with real-time status updates." },
      { title: "WMS 360 — Smart Warehouse",   desc: "Pick, pack, and dispatch optimisation to eliminate fulfillment errors and delays." },
      { title: "AI Inventory Optimisation",   desc: "Auto-replenishment ensures the right stock is in the right place at the right time." },
      { title: "POS Integration",             desc: "Sync point-of-sale data instantly with back-office financials and inventory." },
      { title: "Marketplace Connectors",      desc: "Native integrations with Amazon, Flipkart, Shopify, Magento, and more." },
      { title: "Retail Analytics",            desc: "Personalise customer experiences using purchase history and basket analysis." },
    ],
    offerings: ["OMS 360", "WMS 360", "SAP Business One", "Marketplace Integration", "AI Inventory Optimisation", "POS Integration", "Retail Analytics"],
    cta: "Book a Retail Demo",
  },
  {
    slug: "construction",
    name: "Construction",
    Icon: HardHat,
    accent: "#3D4FA0",
    tagline: "Complete Visibility Across Every Project",
    brief:
      "Construction and real estate firms deal with multi-site projects, subcontractor coordination, and tight margins where even small cost overruns can eliminate profitability. CtrlA digitises project planning, procurement, budgeting, and contract billing to give project directors full control.",
    gap: "Budget overruns, project delays, material wastage, and complex contract management.",
    close: "Project costing, contracts & asset management with executive dashboards for real-time project oversight.",
    challenges: [
      { title: "Budget Overruns",             desc: "Uncontrolled costs and change orders eat into project margins without early warning." },
      { title: "Material Wastage & Theft",    desc: "Misuse of materials on-site is common without systematic tracking." },
      { title: "Contract Complexity",         desc: "Tracking variations, certifications, and retention across multiple contracts is labour-intensive." },
      { title: "Equipment Idle Time",         desc: "Machinery sits unused or breaks down without planned maintenance schedules." },
    ],
    solutions: [
      { title: "Project Costing & Budgeting", desc: "Track costs against budget in real-time to prevent overspending before it happens." },
      { title: "Contract Management",         desc: "Manage tenders, awards, progress claims, and retention centrally." },
      { title: "Procurement & Material Control", desc: "GRN-matched procurement with site issue tracking to eliminate wastage." },
      { title: "Equipment & Asset Tracking",  desc: "GPS and IoT integration to track asset location, utilisation, and maintenance." },
      { title: "Subcontractor Management",    desc: "Rate cards, work orders, and certification payments managed in one system." },
      { title: "Executive Dashboards",        desc: "Bird's-eye view of all ongoing projects — budget, schedule, and resource status." },
    ],
    offerings: ["SAP Business One", "Project Costing", "Procurement", "Asset Management", "Contract Management", "Executive Dashboards"],
    cta: "Plan Your Project Digitally",
  },
  {
    slug: "food-and-beverages",
    name: "Food & Beverages",
    Icon: Utensils,
    accent: "#E84821",
    tagline: "Ensure Quality, Compliance & Farm-to-Fork Traceability",
    brief:
      "Food and beverage businesses face the dual challenge of managing perishable inventory with FIFO/FEFO discipline while meeting increasingly stringent FSSAI, FDA, and global food safety regulations. CtrlA automates batch tracking, recipe costing, compliance reporting, and quality testing.",
    gap: "Traceability gaps, expiry management failures, and difficulty adapting to regulatory changes.",
    close: "Batch traceability, recipe & formula management, expiry automation and integrated quality assurance.",
    challenges: [
      { title: "Traceability Gaps",           desc: "Inability to trace ingredients from farm to fork in case of a product recall." },
      { title: "Shelf-Life Mismanagement",    desc: "High wastage due to poor inventory turnover of perishable items." },
      { title: "Recipe Cost Variability",     desc: "Inconsistent recipes lead to quality issues and uncontrolled production costs." },
      { title: "Regulatory Compliance",       desc: "Difficulty adapting to changing FSSAI, FDA, and HACCP standards in real-time." },
    ],
    solutions: [
      { title: "Batch Traceability",          desc: "Track raw materials through every processing step to final shipment with one click." },
      { title: "Recipe & Formula Management", desc: "Standardise recipes to ensure consistent taste, quality, and costing at scale." },
      { title: "FIFO/FEFO Expiry Automation", desc: "WMS 360 enforces expiry-based picking automatically to eliminate spoilage." },
      { title: "Quality & Lab Integration",   desc: "Integrated lab testing, hold/release processes, and quality checkpoints." },
      { title: "WMS 360 Cold Chain",          desc: "Temperature-zone warehouse management with real-time stock visibility." },
      { title: "Compliance Reporting",        desc: "Auto-generate FSSAI, HACCP, and FDA-mandated reports from live data." },
    ],
    offerings: ["SAP Business One", "WMS 360", "Batch Management", "Recipe Management", "Traceability", "Quality Management", "Demand Fluctuation Analysis"],
    cta: "Discuss Your F&B Challenges",
  },
  {
    slug: "professional-services",
    name: "Professional Services",
    Icon: Briefcase,
    accent: "#D4920C",
    tagline: "Project Management, Billing & Resource Planning",
    brief:
      "Consulting, IT services, and professional services firms live and die by project profitability, resource utilisation, and billing accuracy. CtrlA integrates CRM, project management, and ERP to ensure every project is delivered on time, on budget, and billed correctly.",
    gap: "Inefficient billing, resource conflicts, and project scope creep that erode profitability.",
    close: "Integrated project management, resource planning, and timesheet-based billing.",
    challenges: [
      { title: "Poor Resource Allocation",    desc: "Staff are either overworked or underutilised — skills aren't matched to project demands." },
      { title: "Billing Disputes",            desc: "Time tracking inaccuracies lead to revenue leakage and client disputes." },
      { title: "Scope Creep",                 desc: "Uncontrolled changes in project scope harm profitability without change-order tracking." },
      { title: "Project Visibility Gaps",     desc: "Management cannot see project health, margin, or resource load in real time." },
    ],
    solutions: [
      { title: "Resource Planning",           desc: "Assign the right talent to the right project based on skills, availability, and cost rate." },
      { title: "Time & Expense Management",   desc: "Mobile timesheet capture for accurate client billing and cost recovery." },
      { title: "Project Profitability",       desc: "Real-time tracking of project margin, revenue recognition, and budget variance." },
      { title: "CRM Integration",             desc: "Opportunity-to-invoice pipeline with full client history and touchpoints." },
      { title: "Billing Automation",          desc: "T&M, fixed-price, and milestone billing with automated invoice generation." },
      { title: "Executive Dashboards",        desc: "Portfolio-level view of all active projects — health, margin, and delivery status." },
    ],
    offerings: ["SAP Business One", "Project Management", "Billing Integration", "Resource Planning", "Time Tracking", "CRM Integration"],
    cta: "Streamline Your Projects",
  },
  {
    slug: "engineering",
    name: "Engineering",
    Icon: Settings,
    accent: "#3D4FA0",
    tagline: "Smart ERP for Engineer-to-Order & Project Manufacturing",
    brief:
      "Engineering companies — from heavy fabrication to precision machining — deal with complex Bills of Materials, MRP-driven procurement, project scheduling, and after-sales service management. CtrlA brings ERP and WMS 360 that connect engineering design with procurement, production, and service delivery.",
    gap: "Complex BOM management, MRP inaccuracies, and untracked service contracts reduce efficiency.",
    close: "Engineering BOM, MRP-driven procurement, service management, and WMS 360 for spare parts.",
    challenges: [
      { title: "Complex Multi-Level BOMs",    desc: "Engineering BOMs change frequently with design revisions causing procurement chaos." },
      { title: "MRP Inaccuracies",            desc: "Incorrect material requirements planning leads to shortages or excess procurement." },
      { title: "Service Contract Tracking",   desc: "After-sales service contracts, warranties, and AMCs are tracked on spreadsheets." },
      { title: "Spare Parts Availability",    desc: "Critical spare parts out-of-stock cause unacceptable machine downtime for customers." },
    ],
    solutions: [
      { title: "Engineering BOM Management",  desc: "Multi-level BOM with revision control, alternates, and production routings." },
      { title: "MRP & Procurement",           desc: "Demand-driven MRP ensures the right materials are ordered at the right time." },
      { title: "WMS 360 — Spare Parts Store", desc: "Bin-managed spare parts inventory with critical stock level alerts." },
      { title: "Service & AMC Management",    desc: "Track service contracts, warranty claims, and planned maintenance schedules." },
      { title: "Project Cost Control",        desc: "ETO project costing with real-time budget vs actual variance tracking." },
      { title: "Quality & Testing",           desc: "Inspection checkpoints, non-conformance reports, and supplier quality ratings." },
    ],
    offerings: ["SAP Business One", "Engineering BOM", "MRP", "WMS 360", "Service Management", "Quality Management", "Project Costing"],
    cta: "Discuss Your Engineering Needs",
  },
  {
    slug: "chemicals-dyes",
    name: "Chemicals & Dyes",
    Icon: FlaskConical,
    accent: "#E84821",
    tagline: "Batch Processing, Compliance & Quality Management",
    brief:
      "Chemical and dye manufacturers deal with complex batch formulations, strict quality mandates, MSDS requirements, and hazardous material compliance. CtrlA manages the entire lifecycle of process manufacturing — from formula development through batch processing to final certification.",
    gap: "Complex batch processing, quality hold-ups, and strict hazardous material compliance requirements.",
    close: "Batch processing, EH&S compliance, formula management, and quality lab integration.",
    challenges: [
      { title: "Complex Formulations",        desc: "Managing thousands of ingredient combinations, variants, and batch sizes." },
      { title: "Quality Release Bottlenecks", desc: "Lab testing delays hold up batch release and disrupt customer delivery schedules." },
      { title: "Hazardous Material Compliance", desc: "MSDS tracking, safety data, and regulatory compliance for dangerous goods." },
      { title: "Batch Genealogy & Recall",    desc: "Inability to quickly trace a recalled batch back to its raw material lots." },
    ],
    solutions: [
      { title: "Batch Processing & Tracking", desc: "Track every step of the chemical reaction, mixing, and blending process." },
      { title: "Formula & Recipe Management", desc: "Manage complex formulations with ingredient substitution and batch scaling." },
      { title: "EH&S Compliance",             desc: "Environmental Health & Safety management with MSDS and regulatory reporting." },
      { title: "Quality Lab Integration",     desc: "Connect laboratories with production to speed up batch release cycles." },
      { title: "WMS 360 — Chemical Stores",   desc: "Hazardous material zone management, FIFO enforcement, and safety stock alerts." },
      { title: "Batch Genealogy & Recall",    desc: "One-click forward and backward traceability for any batch component." },
    ],
    offerings: ["SAP Business One", "WMS 360", "Batch Processing", "EH&S Compliance", "Quality Management", "Inventory Control", "Analytics"],
    cta: "Discuss Compliance Requirements",
  },
  {
    slug: "packaging",
    name: "Packaging",
    Icon: Package,
    accent: "#D4920C",
    tagline: "End-to-End Packaging Operations Management",
    brief:
      "Packaging manufacturers deal with customer-specific designs, tight tolerances, high material consumption rates, and competitive pricing pressure. CtrlA streamlines operations from raw material procurement through production planning to finished goods dispatch — with full material consumption accounting.",
    gap: "Customer-specific pricing complexity, material consumption tracking, and order scheduling challenges.",
    close: "Production planning, material consumption tracking, customer-specific pricing, and quality control.",
    challenges: [
      { title: "Customer-Specific SKU Complexity", desc: "Each customer has unique designs, sizes, and specifications requiring dedicated tracking." },
      { title: "Material Yield & Wastage",    desc: "Paper, board, and film wastage is difficult to measure and control without MIS." },
      { title: "Order Scheduling Conflicts",  desc: "Rush orders disrupt machine schedules causing overtime and customer dissatisfaction." },
      { title: "Quality Rejections",          desc: "Print defects, dimensional errors, and coating failures cause costly rejections." },
    ],
    solutions: [
      { title: "Customer-Specific Pricing",   desc: "Maintain separate price lists, job cost templates, and margin rules per customer." },
      { title: "Production Scheduling",       desc: "Machine-wise scheduling with setup time, run rates, and priority management." },
      { title: "Material Yield Tracking",     desc: "Capture actual vs standard material consumption to identify and reduce wastage." },
      { title: "WMS 360 — Finished Goods",    desc: "Pallet management, customer-wise stock allocation, and dispatch scheduling." },
      { title: "Quality Control",             desc: "Inspection at each stage — pre-press, print, lamination, and cutting." },
      { title: "Delivery Performance KPIs",   desc: "OTIF (On Time In Full) dashboards to monitor and improve customer satisfaction." },
    ],
    offerings: ["SAP Business One", "WMS 360", "Production Planning", "Customer Pricing", "Quality Management", "Dispatch Management"],
    cta: "Optimise Your Packaging Operations",
  },
  {
    slug: "pharma",
    name: "Pharma",
    Icon: Pill,
    accent: "#3D4FA0",
    tagline: "Regulatory Compliance, Serialisation & Cold-Chain Control",
    brief:
      "Pharmaceutical companies operate under the most demanding regulatory environments globally — FDA, cGMP, WHO-GMP, and Schedule M compliance. CtrlA provides Clinical ERP with serialisation, batch genealogy, cold-chain WMS 360, and automated regulatory reporting that ensures audit-readiness at all times.",
    gap: "Regulatory non-compliance risks, supply chain integrity issues, and disconnected clinical data systems.",
    close: "Clinical ERP, regulatory compliance automation, serialisation, and cold-chain warehouse management.",
    challenges: [
      { title: "Regulatory Non-Compliance",   desc: "Keeping pace with FDA, cGMP, Schedule M, and WHO-GMP requirements manually is unsustainable." },
      { title: "Serialisation & Traceability", desc: "Drug serialisation and anti-counterfeiting requirements demand robust track-and-trace." },
      { title: "Cold Chain Integrity",        desc: "Vaccines and biologics must remain in temperature-controlled supply chains throughout." },
      { title: "Batch Recall Readiness",      desc: "Inability to quickly identify and isolate affected batches in a recall situation." },
    ],
    solutions: [
      { title: "Regulatory Compliance Automation", desc: "Built-in protocols for FDA 21 CFR Part 11, cGMP, and Schedule M documentation." },
      { title: "Serialisation & Track-and-Trace",  desc: "Unit-level serialisation and aggregation for anti-counterfeiting compliance." },
      { title: "WMS 360 — Cold Chain",        desc: "Temperature-zone warehousing with real-time monitoring and chain-of-custody alerts." },
      { title: "Batch Genealogy & Recall",    desc: "Forward and backward batch traceability — identify affected lots in minutes." },
      { title: "Quality Lab Integration",     desc: "Stability testing, lab results, and CoA generation integrated with production." },
      { title: "Controlled Substance Management", desc: "Narcotic register, dual authorisation, and dispensing controls built in." },
    ],
    offerings: ["SAP Business One", "WMS 360 Cold Chain", "Serialisation", "Regulatory Compliance", "Batch Management", "Quality Management", "Clinical Reporting"],
    cta: "Get a Compliance Assessment",
  },
  {
    slug: "wholesale-distribution",
    name: "Wholesale & Distribution",
    Icon: Truck,
    accent: "#E84821",
    tagline: "Multi-Warehouse Inventory & Smart Distribution",
    brief:
      "Wholesale and distribution companies manage large SKU counts, multi-level pricing, vendor credit lines, and last-mile delivery coordination. CtrlA's WMS 360 and SAP Business One deliver real-time inventory visibility, automated replenishment, and distribution efficiency across multiple warehouses and depots.",
    gap: "Multi-warehouse inventory complexity, manual route planning, and credit control failures.",
    close: "WMS 360 multi-warehouse management, AI demand planning, route optimisation, and credit control.",
    challenges: [
      { title: "Multi-Warehouse Inventory",   desc: "Tracking stock across warehouses, depots, and consignment locations is error-prone." },
      { title: "Multi-Level Pricing Complexity", desc: "Maintaining customer-specific, quantity-based, and promotional price lists manually." },
      { title: "Route Planning Inefficiency", desc: "Manual delivery scheduling increases fuel costs and delivery lead times." },
      { title: "Credit Exposure Risk",        desc: "Distributors exceeding credit limits or overdue outstanding without real-time alerts." },
    ],
    solutions: [
      { title: "WMS 360 — Multi-Warehouse",   desc: "Real-time stock across all warehouses, depots, and transit locations in one view." },
      { title: "AI Demand Planning",          desc: "Predict demand by SKU, region, and season to automate replenishment orders." },
      { title: "Multi-Level Price Lists",     desc: "Customer tier pricing, quantity breaks, promotions, and scheme management." },
      { title: "Route Optimisation",          desc: "AI-powered delivery route planning to reduce fuel cost and improve OTIF." },
      { title: "Credit Control & Alerts",     desc: "Real-time credit utilisation dashboards with auto-hold on overdue accounts." },
      { title: "Vendor Managed Inventory",    desc: "Automate supplier replenishment based on real-time stock and demand signals." },
    ],
    offerings: ["SAP Business One", "WMS 360", "Multi-Warehouse Management", "Route Optimisation", "Credit Control", "AI Demand Planning", "Distributor Management"],
    cta: "Optimise Your Distribution Network",
  },
  {
    slug: "automotive",
    name: "Automotive",
    Icon: Car,
    accent: "#D4920C",
    tagline: "Dealer Management, Parts Logistics & Service Scheduling",
    brief:
      "Automotive businesses span OEM supply, dealer networks, spare parts distribution, warranty processing, and service bay management. CtrlA connects all these moving parts into one integrated ERP with WMS 360 for spare parts stores — ensuring parts availability, warranty accuracy, and service profitability.",
    gap: "Spare parts stockouts, dealer coordination gaps, and manual warranty processing drive revenue loss.",
    close: "Integrated dealer management, WMS 360 for spare parts, warranty tracking, and service scheduling.",
    challenges: [
      { title: "Spare Parts Stockouts",       desc: "Critical spare parts unavailable when needed cause unacceptable service delays." },
      { title: "Dealer Network Coordination", desc: "Tracking orders, payments, and performance across a dealer network manually is inefficient." },
      { title: "Warranty Claim Processing",   desc: "Manual warranty tracking leads to underpaid claims or fraudulent submissions." },
      { title: "Service Bay Scheduling",      desc: "Ad-hoc scheduling wastes technician time and reduces workshop throughput." },
    ],
    solutions: [
      { title: "WMS 360 — Spare Parts Store", desc: "Bin-managed spare parts with critical stock alerts, FIFO, and fast bin picking." },
      { title: "Dealer Management System",    desc: "Order management, invoicing, returns, and performance tracking for dealer network." },
      { title: "Warranty Management",         desc: "Claim submission, validation, approval, and credit note processing — automated." },
      { title: "Service Scheduling",          desc: "Workshop job cards, technician allocation, and bay utilisation management." },
      { title: "Vehicle History Tracking",    desc: "Complete service and warranty history linked to VIN/chassis numbers." },
      { title: "Parts Demand Forecasting",    desc: "AI-driven forecasting to maintain right spare parts inventory at each location." },
    ],
    offerings: ["SAP Business One", "WMS 360", "Dealer Management", "Warranty Tracking", "Service Management", "Parts Forecasting", "Workshop Analytics"],
    cta: "Connect Your Automotive Operations",
  },
  {
    slug: "textile",
    name: "Textile",
    Icon: Shirt,
    accent: "#3D4FA0",
    tagline: "From Yarn to Fabric — Complete Textile Value Chain ERP",
    brief:
      "Textile manufacturing involves complex size-colour-denier variants, job work coordination with weavers and dyers, loom efficiency tracking, and tight customer delivery windows. CtrlA delivers specialised ERP that handles the complete textile value chain — from yarn procurement to finished fabric dispatch.",
    gap: "Size-colour matrix complexity, job work coordination, and lot-level inventory tracking challenges.",
    close: "Size-colour BOM, job work management, loom efficiency tracking, and lot/roll inventory control.",
    challenges: [
      { title: "Size-Colour-Denier Matrix",   desc: "Managing thousands of variant combinations in inventory and orders without errors." },
      { title: "Job Work Coordination",       desc: "Tracking yarn given to contract weavers/dyers and receiving finished goods back." },
      { title: "Loom Efficiency Tracking",    desc: "Without OEE monitoring, loom downtime and wastage go undetected and uncorrected." },
      { title: "Lot & Roll Inventory",        desc: "Fabric tracked in rolls with different lengths requires lot-level inventory accuracy." },
    ],
    solutions: [
      { title: "Size-Colour Matrix BOM",      desc: "Manage all variants with a single product template — auto-generated SKUs." },
      { title: "Job Work Management",         desc: "Issue yarn to job workers, track processing, and receive finished goods with reconciliation." },
      { title: "WMS 360 — Roll & Lot Tracking", desc: "Warehouse management for rolls, bales, and lots with exact metreage tracking." },
      { title: "Loom & Machine OEE",          desc: "Real-time production efficiency, downtime, and wastage tracking by loom." },
      { title: "Quality & Shade Matching",    desc: "Shade band approval, quality checkpoints, and hold/release processes." },
      { title: "Export Documentation",        desc: "Integrated export order management with packing lists, invoices, and shipping docs." },
    ],
    offerings: ["SAP Business One", "WMS 360", "Job Work Management", "Size-Colour Matrix", "Loom OEE", "Quality Management", "Export Documentation"],
    cta: "Digitise Your Textile Operations",
  },
  {
    slug: "rental-services",
    name: "Rental Services",
    Icon: Key,
    accent: "#E84821",
    tagline: "Asset Lifecycle, Utilisation Tracking & Rental Billing",
    brief:
      "Equipment and asset rental businesses must manage asset availability, preventive maintenance schedules, rental contract terms, security deposits, damage assessments, and accurate billing. CtrlA brings operational discipline to rental operations — reducing idle time, preventing revenue leakage, and maximising asset ROI.",
    gap: "Asset idle time, manual contract management, and billing errors drive revenue leakage.",
    close: "Asset lifecycle management, rental contract automation, maintenance scheduling, and utilisation analytics.",
    challenges: [
      { title: "Asset Availability Tracking", desc: "No real-time view of which assets are rented, returned, under maintenance, or available." },
      { title: "Maintenance Scheduling",      desc: "Reactive maintenance instead of preventive servicing increases breakdown risk and repair costs." },
      { title: "Rental Contract Management",  desc: "Contract terms, rate escalations, extensions, and early returns handled on spreadsheets." },
      { title: "Damage & Deposit Management", desc: "Security deposit accounting, damage assessments, and deductions tracked manually." },
    ],
    solutions: [
      { title: "Asset Lifecycle Management",  desc: "Track every asset from acquisition through to disposal with full history." },
      { title: "Rental Contract Automation",  desc: "Contract terms, billing cycles, rate escalations, and renewals managed automatically." },
      { title: "Preventive Maintenance",      desc: "Scheduled maintenance by date or usage hours with auto-alerts and work orders." },
      { title: "Deposit & Damage Control",    desc: "Security deposit accounting, damage grading, and deduction processing built in." },
      { title: "Utilisation Analytics",       desc: "Asset utilisation rates, idle time, and revenue-per-asset dashboards." },
      { title: "Mobile Asset Inspection",     desc: "Technicians capture condition reports and photos on mobile at pickup and return." },
    ],
    offerings: ["SAP Business One", "Asset Management", "Rental Contract Management", "Maintenance Scheduling", "Deposit Management", "Utilisation Analytics"],
    cta: "Maximise Your Asset ROI",
  },
  {
    slug: "agriculture-horticulture",
    name: "Agriculture & Horticulture",
    Icon: Leaf,
    accent: "#D4920C",
    tagline: "Smart Agri-ERP for Modern Farming Operations",
    brief:
      "Agriculture and Horticulture have evolved far beyond crop production to include poultry, beekeeping, dairy, forestry, and fruit cultivation. The industry requires season-wise forecasting, cold chain management, quality assurance, and financial management across multiple farms and locations. CtrlA delivers SAP Business One tailored for agri-businesses.",
    gap: "Season-dependent demand, perishable inventory management, and multi-location farm coordination.",
    close: "Season-wise forecasting, cold-chain WMS 360, quality assurance, and integrated agri-ERP.",
    challenges: [
      { title: "Season-Dependent Demand",     desc: "Forecasting based on history alone fails — crop yield and market demand vary by season." },
      { title: "Perishable Inventory",        desc: "Produce spoils rapidly without FIFO-enforced cold chain and expiry tracking." },
      { title: "Multi-Farm Coordination",     desc: "Soil preparation, planting, harvesting, and logistics across multiple locations is complex." },
      { title: "Input Cost Control",          desc: "Fertiliser, pesticide, and seed procurement without MRP leads to over-purchasing." },
    ],
    solutions: [
      { title: "Season-Wise Demand Forecasting", desc: "MRP wizard uses seasonal forecast models — not just historical orders." },
      { title: "WMS 360 — Cold Chain & FIFO", desc: "Temperature-zone warehousing with expiry-enforced picking for perishable produce." },
      { title: "Crop & Harvest Planning",     desc: "Project-based crop planning with soil preparation, planting, and harvest milestones." },
      { title: "Agri-Input Procurement",      desc: "Vendor comparison, purchase contracts, and quality certification for seeds and inputs." },
      { title: "Quality Assurance",           desc: "Crop quality inspection, certification, and grading at harvest and dispatch." },
      { title: "Multi-Currency Financials",   desc: "Export-ready financials with multi-currency, bank reconciliation, and budgeting." },
    ],
    offerings: ["SAP Business One", "WMS 360", "Season-Wise Forecasting", "Crop Planning", "Quality Assurance", "Agri-Input Procurement", "Cash Flow Management"],
    cta: "Grow Your Agri-Business",
  },
];

// ── Gap Table Data ──────────────────────────────────────────────────────────

const GAP_ROWS = [
  { industry: "Manufacturing",           gap: "Production bottlenecks, inventory shortages, quality control issues.",       solution: "End-to-end ERP, WMS 360, MRP & AI Demand Forecasting." },
  { industry: "Retail & Distribution",   gap: "Inventory mismatches, marketplace chaos, and fulfillment delays.",           solution: "OMS 360, WMS 360, POS integration & real-time analytics." },
  { industry: "Construction",            gap: "Budget overruns, project delays, and material wastage.",                     solution: "Project costing, contracts & asset management; Executive Dashboards." },
  { industry: "Food & Beverages",        gap: "Traceability gaps, expiry management failures, regulatory risks.",           solution: "Batch traceability, FIFO/FEFO WMS 360 & compliance reporting." },
  { industry: "Pharma",                  gap: "Regulatory non-compliance, serialisation needs, cold-chain failures.",       solution: "Clinical ERP, serialisation, cold-chain WMS 360 & compliance automation." },
  { industry: "Chemicals & Dyes",        gap: "Complex batch processing, lab bottlenecks, hazardous material compliance.",  solution: "Batch processing, EH&S compliance & quality lab integration." },
  { industry: "Wholesale & Distribution",gap: "Multi-warehouse complexity, route planning, credit control failures.",       solution: "WMS 360 multi-warehouse, route optimisation & credit control." },
  { industry: "Professional Services",   gap: "Inefficient billing, resource conflicts, and project scope creep.",          solution: "Project management, resource planning & T&M billing integration." },
];

// ── Industry Modal ──────────────────────────────────────────────────────────

function IndustryModal({ ind, onClose }: { ind: IndustryData; onClose: () => void }) {
  useEffect(() => {
    document.body.style.overflow = "hidden";
    const handleKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", handleKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", handleKey);
    };
  }, [onClose]);

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
        style={{ backgroundColor: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)" }}
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, y: 60, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 40, scale: 0.97 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="relative w-full sm:max-w-3xl max-h-[92vh] overflow-y-auto rounded-t-3xl sm:rounded-2xl shadow-2xl bg-white"
          onClick={e => e.stopPropagation()}
        >
          {/* Modal Header */}
          <div
            className="relative px-6 pt-8 pb-6 text-white"
            style={{ background: `linear-gradient(135deg, #0d1225 0%, #1A1F36 60%, ${ind.accent}55 100%)` }}
          >
            {/* 3-color bar */}
            <div className="absolute top-0 left-0 right-0 h-1 flex">
              <div className="flex-[3]" style={{ backgroundColor: ind.accent }} />
              <div className="flex-[2] bg-[#1A1F36]" />
              <div className="flex-1 bg-[#3D4FA0]" />
            </div>

            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
            >
              <X size={18} />
            </button>

            <div className="flex items-center gap-4 mb-4">
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0"
                style={{ backgroundColor: `${ind.accent}30` }}
              >
                <ind.Icon size={26} style={{ color: ind.accent }} />
              </div>
              <div>
                <div
                  className="text-xs font-bold uppercase tracking-widest mb-1"
                  style={{ color: ind.accent }}
                >
                  Industry Solutions
                </div>
                <h2 className="text-2xl font-bold">{ind.name}</h2>
              </div>
            </div>

            <p className="text-sm font-semibold text-white/70 mb-3">{ind.tagline}</p>
            <p className="text-sm text-white/60 leading-relaxed">{ind.brief}</p>
          </div>

          {/* Modal Body */}
          <div className="p-6 space-y-6">
            {/* Two-column: Challenges + How We Help */}
            <div className="grid sm:grid-cols-2 gap-4">
              {/* Challenges */}
              <div className="bg-red-50 rounded-2xl p-5 border border-red-100">
                <div className="flex items-center gap-2 mb-4">
                  <AlertTriangle size={16} className="text-red-500" />
                  <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider">The Gap — Challenges</h3>
                </div>
                <ul className="space-y-3">
                  {ind.challenges.map((c) => (
                    <li key={c.title}>
                      <div className="font-semibold text-gray-800 text-sm">{c.title}</div>
                      <div className="text-xs text-gray-500 leading-relaxed mt-0.5">{c.desc}</div>
                    </li>
                  ))}
                </ul>
              </div>

              {/* How CtrlA Closes the Gap */}
              <div className="rounded-2xl p-5 border" style={{ backgroundColor: `${ind.accent}08`, borderColor: `${ind.accent}25` }}>
                <div className="flex items-center gap-2 mb-4">
                  <Lightbulb size={16} style={{ color: ind.accent }} />
                  <h3 className="text-sm font-bold uppercase tracking-wider" style={{ color: ind.accent }}>How CtrlA Closes the Gap</h3>
                </div>
                <div className="space-y-3">
                  {ind.solutions.map((s) => (
                    <div key={s.title} className="flex gap-2.5">
                      <CheckCircle2 size={15} className="flex-shrink-0 mt-0.5" style={{ color: ind.accent }} />
                      <div>
                        <div className="font-semibold text-gray-800 text-sm">{s.title}</div>
                        <div className="text-xs text-gray-500 leading-relaxed mt-0.5">{s.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Solution Offerings */}
            <div className="bg-gray-50 rounded-2xl p-5 border border-gray-100">
              <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-3">Solutions We Offer</h3>
              <div className="flex flex-wrap gap-2">
                {ind.offerings.map((o) => (
                  <span
                    key={o}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-semibold border"
                    style={{ backgroundColor: `${ind.accent}10`, borderColor: `${ind.accent}30`, color: ind.accent }}
                  >
                    {o}
                  </span>
                ))}
              </div>
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-3">
              <Link
                href="/contact"
                className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl font-bold text-white text-sm shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5"
                style={{ backgroundColor: ind.accent }}
                onClick={onClose}
              >
                {ind.cta} <ArrowRight size={16} />
              </Link>
              <Link
                href="/contact"
                className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl font-bold text-sm border-2 transition-all hover:-translate-y-0.5"
                style={{ borderColor: ind.accent, color: ind.accent }}
                onClick={onClose}
              >
                Schedule a Free Consultation
              </Link>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────

export default function IndustriesPage() {
  const { primaryColor } = useSiteConfig();
  const [selected, setSelected] = useState<IndustryData | null>(null);

  return (
    <PublicLayout>
      <SEO
        title="Industries We Serve — CtrlA Tech Solutions"
        description="Every industry faces unique challenges. CtrlA delivers tailored ERP, WMS 360, AI, and automation solutions for Manufacturing, Retail, Pharma, Construction, Chemicals, Textile, and more."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "Industries We Serve — CtrlA Tech Solutions",
          description: "Every industry faces unique challenges. CtrlA delivers tailored ERP, WMS 360, AI, and automation solutions for Manufacturing, Retail, Pharma, Construction, Chemicals, Textile, and more.",
          url: window.location.href,
          publisher: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
        }}
      />

      <PageHero
        eyebrow="Industries"
        title={<>Industry Expertise That Delivers <span style={{ color: "#E84821" }}>Measurable Outcomes</span></>}
        subtitle="Every industry faces unique operational challenges — disconnected systems, manual processes, inventory inaccuracies, and limited business visibility. We solve them all."
      />

      {/* ── Intro strip ──────────────────────────────────────────────────── */}
      <section className="py-12 bg-white border-b border-gray-100">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-3 gap-6 text-center">
            {[
              { stat: "14+", label: "Industries Served" },
              { stat: "500+", label: "Successful Implementations" },
              { stat: "25+", label: "Years Combined Expertise" },
            ].map(({ stat, label }) => (
              <div key={label} className="p-6 rounded-2xl bg-gray-50 border border-gray-100">
                <div className="text-3xl font-black mb-1" style={{ color: "#E84821" }}>{stat}</div>
                <div className="text-sm font-semibold text-gray-500">{label}</div>
              </div>
            ))}
          </div>

          <div className="mt-10 max-w-3xl mx-auto text-center">
            <p className="text-gray-600 leading-relaxed">
              At CtrlA Tech Solutions, we don't believe in one-size-fits-all solutions. We combine deep
              industry expertise with <strong>ERP, WMS 360, AI, Cloud, Mobility,</strong> and Process
              Automation to solve real business problems and accelerate digital transformation.
            </p>
          </div>
        </div>
      </section>

      {/* ── Gap Analysis Table ────────────────────────────────────────────── */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="text-xs font-bold uppercase tracking-widest mb-2" style={{ color: "#E84821" }}>
              The CtrlA Difference
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900">
              How CtrlA <span style={{ color: "#E84821" }}>Fills the Gap</span> Across Industries
            </h2>
            <div className="flex justify-center gap-1.5 mt-3">
              <div className="h-1 w-12 rounded-full bg-[#E84821]" />
              <div className="h-1 w-6 rounded-full" style={{ backgroundColor: primaryColor }} />
              <div className="h-1 w-3 rounded-full bg-[#3D4FA0]" />
            </div>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-gray-200 shadow-sm">
            <table className="w-full text-sm">
              <thead>
                <tr style={{ background: "linear-gradient(135deg, #0d1225 0%, #1A1F36 100%)" }}>
                  <th className="text-left px-5 py-4 text-xs font-bold uppercase tracking-widest text-white/60 w-1/4">Industry</th>
                  <th className="text-left px-5 py-4 text-xs font-bold uppercase tracking-widest text-red-400 w-[37.5%]">
                    <span className="flex items-center gap-1.5"><AlertTriangle size={12} />The Gap</span>
                  </th>
                  <th className="text-left px-5 py-4 text-xs font-bold uppercase tracking-widest text-green-400 w-[37.5%]">
                    <span className="flex items-center gap-1.5"><CheckCircle2 size={12} />How CtrlA Closes It</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {GAP_ROWS.map((row, i) => (
                  <tr
                    key={row.industry}
                    className={`border-t border-gray-100 hover:bg-orange-50/50 transition-colors cursor-pointer ${i % 2 === 0 ? "bg-white" : "bg-gray-50/50"}`}
                    onClick={() => {
                      const found = INDUSTRIES.find(ind =>
                        ind.name.toLowerCase().includes(row.industry.toLowerCase().split(" ")[0].toLowerCase())
                      );
                      if (found) setSelected(found);
                    }}
                  >
                    <td className="px-5 py-4 font-bold text-gray-800">{row.industry}</td>
                    <td className="px-5 py-4 text-gray-500 leading-relaxed">{row.gap}</td>
                    <td className="px-5 py-4 text-gray-600 leading-relaxed font-medium">{row.solution}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* ── Industry Cards Grid ───────────────────────────────────────────── */}
      <section className="py-16 bg-white">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="text-xs font-bold uppercase tracking-widest mb-2" style={{ color: "#E84821" }}>
              {INDUSTRIES.length} Industries
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900">
              Every Industry Has Unique Challenges.{" "}
              <span style={{ color: "#E84821" }}>We've Solved Them.</span>
            </h2>
            <p className="text-gray-500 mt-3 max-w-xl mx-auto text-sm">
              Click any industry to learn about the specific challenges and how CtrlA's ERP, WMS 360, and AI solutions address them.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {INDUSTRIES.map((ind, i) => (
              <motion.button
                key={ind.slug}
                onClick={() => setSelected(ind)}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.35, delay: (i % 4) * 0.06 }}
                className="group text-left bg-white rounded-2xl p-5 border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all overflow-hidden relative w-full"
              >
                {/* Accent top bar */}
                <div className="absolute top-0 left-0 right-0 h-1 rounded-t-2xl" style={{ backgroundColor: ind.accent }} />

                {/* Icon */}
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300"
                  style={{ backgroundColor: `${ind.accent}15` }}
                >
                  <ind.Icon size={22} style={{ color: ind.accent }} />
                </div>

                <h3 className="font-bold text-gray-900 mb-1.5 group-hover:text-[#E84821] transition-colors">
                  {ind.name}
                </h3>
                <p className="text-xs text-gray-500 leading-relaxed line-clamp-2 mb-3">
                  {ind.tagline}
                </p>

                <div
                  className="flex items-center gap-1 text-xs font-semibold"
                  style={{ color: ind.accent }}
                >
                  Explore Solutions <ArrowRight size={12} className="group-hover:translate-x-1 transition-transform" />
                </div>

                {/* Hover overlay */}
                <div
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none rounded-2xl"
                  style={{ background: `radial-gradient(circle at top left, ${ind.accent}08, transparent 70%)` }}
                />
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      {/* ── Why CtrlA strip ───────────────────────────────────────────────── */}
      <section
        className="py-14"
        style={{ background: "linear-gradient(140deg, #0d1225 0%, #1A1F36 55%, #2D3561 100%)" }}
      >
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="text-xs font-bold uppercase tracking-widest text-[#E84821] mb-3">Why CtrlA</div>
          <h2 className="text-2xl sm:text-3xl font-bold text-white mb-4">
            One Partner for Every Industry
          </h2>
          <p className="text-white/60 max-w-2xl mx-auto text-sm leading-relaxed mb-8">
            Our consultants work closely with your team to identify operational gaps, streamline workflows, automate business processes, and deliver technology solutions that reduce costs and drive sustainable growth.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            {["SAP Business One", "SAP S/4HANA", "WMS 360", "OMS 360", "AI & ML Solutions", "Odoo ERP", "Mobile Apps", "Cloud Deployment"].map(tag => (
              <span
                key={tag}
                className="px-4 py-2 rounded-full border border-white/20 text-sm text-white/70 font-medium hover:border-[#E84821] hover:text-white transition-colors"
              >
                {tag}
              </span>
            ))}
          </div>
          <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl font-bold text-white bg-[#E84821] hover:bg-[#d43e1d] shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5"
            >
              Discuss Your Industry Challenges <ArrowRight size={16} />
            </Link>
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl font-bold text-white border-2 border-white/20 hover:border-white/50 transition-all hover:-translate-y-0.5"
            >
              Schedule a Free Consultation
            </Link>
          </div>
        </div>
      </section>

      {/* ── Modal ─────────────────────────────────────────────────────────── */}
      {selected && <IndustryModal ind={selected} onClose={() => setSelected(null)} />}
    </PublicLayout>
  );
}
