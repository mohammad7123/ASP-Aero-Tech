import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  ArrowRight, CheckCircle2, Brain, Zap, Globe2, BarChart3,
  RefreshCw, Database, Sparkles, Layers, Shield, TrendingUp,
  Award, HeadphonesIcon, ChevronRight,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import PageHero from "@/components/public/PageHero";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

/* ── Data ─────────────────────────────────────────────────────────────── */

const STATS = [
  { label: "Faster Reporting", value: "6×" },
  { label: "Data Footprint Reduction", value: "75%" },
  { label: "Business Processes Covered", value: "500+" },
  { label: "Countries Supported", value: "100+" },
];

const CAPABILITIES = [
  {
    icon: Brain,
    title: "Embedded Artificial Intelligence",
    desc: "Leverage built-in AI and Machine Learning to automate repetitive processes, predict business outcomes, and improve decision-making across finance, procurement, manufacturing, sales, and supply chain operations.",
    accent: "#E84821",
    bg: "#FFF4F1",
    image: "https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&w=700&q=80",
    points: ["Intelligent Process Automation", "Predictive Analytics", "Smart Recommendations", "Invoice Matching", "Cash Flow Prediction", "Demand Forecasting", "Exception Management"],
  },
  {
    icon: Zap,
    title: "SAP HANA In-Memory Database",
    desc: "Experience lightning-fast performance powered by SAP HANA's in-memory computing architecture. Process millions of transactions and generate reports instantly without waiting for batch jobs.",
    accent: "#3D4FA0",
    bg: "#F0F3FF",
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=700&q=80",
    points: ["Real-Time Data Processing", "High-Speed Reporting", "Instant Analytics", "Faster Financial Closing", "Improved User Experience", "Enterprise-Scale Performance"],
  },
  {
    icon: Globe2,
    title: "Universal Journal",
    desc: "Simplify financial management with the Universal Journal, bringing Finance, Controlling, Asset Accounting, Material Ledger, and Profitability Analysis into one integrated data model.",
    accent: "#D4920C",
    bg: "#FFFBEB",
    image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?auto=format&fit=crop&w=700&q=80",
    points: ["Single Source of Financial Truth", "Real-Time Financial Reporting", "Faster Period-End Closing", "Improved Compliance", "Better Audit Transparency"],
  },
  {
    icon: BarChart3,
    title: "Real-Time Analytics & Reporting",
    desc: "Make informed decisions using live dashboards, embedded analytics, and role-based reports that provide actionable insights across every business function.",
    accent: "#7C3AED",
    bg: "#F5F3FF",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=700&q=80",
    points: ["Executive Dashboards", "Financial Analytics", "Operational KPIs", "Supply Chain Visibility", "Sales Performance Reports", "Interactive Business Insights"],
  },
  {
    icon: Layers,
    title: "Digital Core for Intelligent Enterprises",
    desc: "SAP S/4HANA seamlessly integrates with modern enterprise technologies, creating a connected digital ecosystem that spans every business domain.",
    accent: "#059669",
    bg: "#F0FDF6",
    image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=700&q=80",
    points: ["SAP Business Technology Platform (BTP)", "SAP Analytics Cloud", "SAP Ariba", "SAP SuccessFactors", "SAP Concur", "Third-Party Applications", "API & Middleware Integrations"],
  },
  {
    icon: Database,
    title: "Simplified Data Model",
    desc: "Reduce database complexity with SAP S/4HANA's simplified architecture, enabling improved system performance, lower storage requirements, and easier maintenance.",
    accent: "#0F766E",
    bg: "#F0FDFA",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=700&q=80",
    points: ["Faster Transactions", "Reduced Data Footprint", "Simplified Architecture", "Lower Infrastructure Costs", "Enhanced Scalability", "Better System Performance"],
  },
];

const BUSINESS_BENEFITS = [
  "Real-Time Enterprise Visibility",
  "Intelligent Business Automation",
  "Faster Business Processes",
  "Improved Operational Efficiency",
  "Better Customer Experience",
  "Simplified IT Landscape",
  "Reduced Total Cost of Ownership (TCO)",
  "Scalable Cloud & On-Premise Deployment",
  "Enterprise-Wide Digital Transformation",
  "Future-Ready Business Platform",
];

const MIGRATION_PATHS = [
  {
    title: "Greenfield Implementation",
    tagline: "Fresh start, maximum transformation",
    desc: "Start with a fresh SAP S/4HANA implementation by redesigning business processes using SAP best practices. Ideal for organizations seeking complete digital transformation and process optimization.",
    accent: "#E84821",
    bg: "#FFF4F1",
    bestFor: ["New ERP Implementations", "Business Process Re-engineering", "Rapid Business Growth", "Cloud-First Organizations"],
    image: "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=600&q=80",
  },
  {
    title: "Brownfield Conversion",
    tagline: "Preserve data, accelerate migration",
    desc: "Convert your existing SAP ECC environment to SAP S/4HANA while preserving your business data, configurations, and core processes. This approach minimizes disruption and accelerates migration.",
    accent: "#3D4FA0",
    bg: "#F0F3FF",
    bestFor: ["Existing SAP ECC Customers", "Faster Migration Projects", "Lower Implementation Risk", "Reduced Project Timeline"],
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=600&q=80",
    recommended: true,
  },
  {
    title: "Selective Data Transition",
    tagline: "Migrate only what you need",
    desc: "Migrate only selected business data, processes, or company entities while cleaning historical data and optimizing your ERP landscape.",
    accent: "#D4920C",
    bg: "#FFFBEB",
    bestFor: ["Business Mergers & Acquisitions", "Data Cleansing Initiatives", "Phased Digital Transformation", "Hybrid ERP Environments"],
    image: "https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?auto=format&fit=crop&w=600&q=80",
  },
];

const OUR_EXPERTISE = [
  "SAP S/4HANA Consulting",
  "Business Process Assessment",
  "ERP Roadmap & Strategy",
  "Greenfield & Brownfield Implementations",
  "SAP ECC to S/4HANA Migration",
  "System Integration & API Development",
  "Data Migration & Validation",
  "SAP Fiori Implementation",
  "Performance Optimization",
  "User Training & Change Management",
  "Managed Support & AMC",
];

const METHODOLOGY = [
  {
    step: "1",
    title: "Discovery & Assessment",
    desc: "Evaluate your current ERP landscape, business processes, infrastructure, and transformation goals.",
    accent: "#E84821",
  },
  {
    step: "2",
    title: "Solution Design",
    desc: "Develop a tailored SAP S/4HANA roadmap, deployment strategy, architecture, and migration plan.",
    accent: "#D4920C",
  },
  {
    step: "3",
    title: "System Implementation",
    desc: "Configure, customize, and integrate SAP S/4HANA using SAP Activate methodology and industry best practices.",
    accent: "#3D4FA0",
  },
  {
    step: "4",
    title: "Testing & User Enablement",
    desc: "Conduct comprehensive testing, user acceptance validation, and end-user training to ensure a smooth transition.",
    accent: "#7C3AED",
  },
  {
    step: "5",
    title: "Go-Live & Continuous Support",
    desc: "Successfully deploy your solution with dedicated hypercare support, performance monitoring, and ongoing optimization.",
    accent: "#059669",
  },
];

const WHY_US = [
  "22+ Years of Combined ERP Consulting Experience",
  "End-to-End SAP S/4HANA Implementation Services",
  "Industry-Specific Business Process Expertise",
  "Proven Migration & Modernization Strategies",
  "Enterprise Integration & Automation Capabilities",
  "Cloud & Hybrid Deployment Expertise",
  "Dedicated Project Management & Governance",
  "Comprehensive Training & Change Management",
  "Reliable Post Go-Live Support & Managed Services",
  "Customer-First Approach Focused on Long-Term Success",
];

/* ── Component ────────────────────────────────────────────────────────── */

export default function S4HANAPage() {
  const { primaryColor, accentColor } = useSiteConfig();

  return (
    <PublicLayout>
      <SEO
        title="SAP S/4HANA — The Intelligent ERP for the Digital Enterprise"
        description="SAP S/4HANA is SAP's next-generation ERP suite with embedded AI, real-time analytics, and in-memory computing. Migrate from SAP ECC or start fresh with CtrlA Tech Solutions."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "SoftwareApplication",
          name: "SAP S/4HANA",
          applicationCategory: "BusinessApplication",
          description: "SAP S/4HANA is SAP's next-generation ERP suite with embedded AI, real-time analytics, and in-memory computing. Migrate from SAP ECC or start fresh with CtrlA Tech Solutions.",
          operatingSystem: "Cloud, On-Premise",
          offers: {
            "@type": "Offer",
            seller: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
          },
          url: window.location.href,
        }}
      />

      {/* ── HERO ─────────────────────────────────────────────────────────── */}
      <PageHero
        eyebrow="Enterprise ERP"
        title={<><span style={{ color: "#E84821" }}>SAP S/4HANA</span> — The Intelligent ERP for the Digital Enterprise</>}
        subtitle="SAP S/4HANA is SAP's next-generation Enterprise Resource Planning suite, designed to help organizations become intelligent, agile, and data-driven. Built exclusively on the SAP HANA in-memory platform, it delivers real-time business insights, embedded AI, advanced analytics, and intelligent automation."
        heroImage="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1200&q=80"
        heroImageAlt="SAP S/4HANA intelligent enterprise digital transformation"
        cta={
          <div className="flex flex-wrap gap-3 mt-6">
            <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5 bg-[#E84821]">
              Plan Your Migration <ArrowRight size={16} />
            </Link>
            <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border-2 border-white/40 text-white hover:bg-white/15 transition-all">
              Talk to Our S/4HANA Experts
            </Link>
          </div>
        }
      />

      {/* ── STATS BAR ────────────────────────────────────────────────────── */}
      <section className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <p className="text-center text-xs font-bold uppercase tracking-widest text-gray-400 mb-6">Intelligent Enterprise Capabilities</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {STATS.map(s => (
              <div key={s.label}>
                <div className="text-3xl sm:text-4xl font-black" style={{ color: "#E84821" }}>{s.value}</div>
                <div className="text-xs text-gray-500 mt-1.5 font-medium leading-tight">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="h-1 flex"><div className="flex-[3] bg-[#E84821]" /><div className="flex-[2]" style={{ backgroundColor: primaryColor }} /><div className="flex-1 bg-[#3D4FA0]" /></div>
      </section>

      {/* ── WHY S/4HANA ──────────────────────────────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden">
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 300" fill="none" preserveAspectRatio="xMidYMid slice">
          <path d="M0 150h200l40-50h120l40 50h200l30-30h120l30 30h120" stroke="#3D4FA0" strokeWidth="2"/>
          <circle cx="200" cy="150" r="7" fill="#3D4FA0"/><circle cx="560" cy="150" r="7" fill="#3D4FA0"/>
          <rect x="820" y="90" width="14" height="14" stroke="#E84821" strokeWidth="1.5"/>
          <path d="M750 0v80l40 30" stroke="#D4920C" strokeWidth="1.5"/>
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why SAP S/4HANA?</span>
              </div>
              <h2 className="text-3xl font-bold mb-4" style={{ color: accentColor }}>More than an ERP — a digital core for your enterprise</h2>
              <p className="text-gray-600 text-sm leading-relaxed mb-4">
                Today's enterprises need more than traditional ERP systems. SAP S/4HANA combines intelligent technologies, simplified business processes, and real-time analytics into a single platform that helps organizations make faster decisions, optimize operations, and adapt quickly to changing market demands.
              </p>
              <p className="text-gray-600 text-sm leading-relaxed">
                Whether you're migrating from SAP ECC, modernizing your legacy ERP, or adopting a cloud-first strategy, SAP S/4HANA provides the <strong>digital core for your business transformation</strong>.
              </p>
            </motion.div>
            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[4/3]">
                <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=900&q=80" alt="Enterprise S/4HANA implementation team" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-tr from-[#1A1F36]/40 to-transparent"/>
                <div className="absolute bottom-4 left-4 bg-white/95 rounded-xl px-4 py-2.5 shadow-lg">
                  <div className="text-[10px] font-bold uppercase tracking-widest text-gray-500">SAP S/4HANA Intelligent Suite</div>
                  <div className="text-sm font-bold text-gray-900 mt-0.5">Cloud · On-Premise · Hybrid Deployment</div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── CAPABILITIES ─────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.04]" viewBox="0 0 900 900" preserveAspectRatio="xMidYMid slice">
          {Array.from({ length: 25 }).map((_, row) => Array.from({ length: 30 }).map((_, col) => (
            <circle key={`${row}-${col}`} cx={col * 30 + 15} cy={row * 30 + 15} r="1.8" fill="#3D4FA0"/>
          )))}
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Intelligent Enterprise Capabilities</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Built for the digital enterprise</h2>
            <p className="mt-2 text-gray-500 max-w-xl mx-auto text-sm">Six core capabilities that make SAP S/4HANA the platform of choice for modern enterprises.</p>
          </div>

          <div className="space-y-6">
            {CAPABILITIES.map((cap, i) => {
              const Icon = cap.icon;
              const isEven = i % 2 === 0;
              return (
                <motion.div key={cap.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.08 }}
                  className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden">
                  <div className="grid lg:grid-cols-12 items-stretch">
                    <div className={`lg:col-span-4 relative ${isEven ? "order-first" : "order-first lg:order-last"}`}>
                      <div className="relative h-48 lg:h-full min-h-[200px]">
                        <img src={cap.image} alt={cap.title} className="w-full h-full object-cover" loading="lazy"/>
                        <div className="absolute inset-0" style={{ background: `linear-gradient(135deg, ${cap.accent}55 0%, transparent 60%)` }}/>
                        <div className={`absolute top-4 ${isEven ? "left-4" : "left-4 lg:left-auto lg:right-4"} w-11 h-11 rounded-xl flex items-center justify-center bg-white shadow-lg`}>
                          <Icon size={20} style={{ color: cap.accent }}/>
                        </div>
                        <svg className="absolute bottom-0 left-0 right-0" viewBox="0 0 400 20" fill="white" preserveAspectRatio="none">
                          <path d="M0 20 Q100 6 200 12 Q300 20 400 6 L400 20 Z"/>
                        </svg>
                      </div>
                    </div>
                    <div className={`lg:col-span-8 p-7 flex flex-col justify-center ${isEven ? "order-last" : "order-last lg:order-first"}`}>
                      <div className="flex items-center gap-2 mb-2">
                        <span className="w-4 h-0.5 rounded" style={{ backgroundColor: cap.accent }}/>
                        <span className="text-[10px] font-bold uppercase tracking-widest" style={{ color: cap.accent }}>Core Capability</span>
                      </div>
                      <h3 className="text-xl font-bold mb-2" style={{ color: accentColor }}>{cap.title}</h3>
                      <p className="text-gray-600 text-sm leading-relaxed mb-4">{cap.desc}</p>
                      <div>
                        <div className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2">Key Features</div>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2">
                          {cap.points.map(pt => (
                            <div key={pt} className="flex items-center gap-1.5 text-xs text-gray-700">
                              <ChevronRight size={12} style={{ color: cap.accent }} className="flex-shrink-0"/>
                              {pt}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── BUSINESS BENEFITS ────────────────────────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden">
        <svg className="absolute -top-8 -right-8 opacity-[0.05] w-72 h-72" viewBox="0 0 200 200" fill="none">
          <path d="M40 40 L80 20 L160 60 L180 140 L120 180 L40 160 L20 80 Z" stroke="#3D4FA0" strokeWidth="2.5" strokeDasharray="6 4"/>
          <circle cx="100" cy="100" r="30" stroke="#E84821" strokeWidth="1.5" strokeDasharray="4 3"/>
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Business Benefits</span>
              </div>
              <h2 className="text-3xl font-bold mb-3" style={{ color: accentColor }}>Ten transformative outcomes for your enterprise</h2>
              <p className="text-gray-500 text-sm leading-relaxed mb-7">Designed for the digital era, SAP S/4HANA empowers businesses with greater agility, scalability, and innovation while reducing operational complexity.</p>
              <div className="grid grid-cols-2 gap-3">
                {BUSINESS_BENEFITS.map((b, i) => (
                  <motion.div key={b} initial={{ opacity: 0, y: 8 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}
                    className="flex items-start gap-2.5 bg-gray-50 rounded-xl p-3.5 border border-gray-100 hover:border-[#E84821]/30 hover:bg-[#FFF4F1] transition-colors">
                    <CheckCircle2 size={14} className="flex-shrink-0 mt-0.5 text-[#E84821]"/>
                    <span className="text-xs text-gray-700 leading-relaxed">{b}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[4/3]">
                <img src="https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&w=900&q=80" alt="S/4HANA real-time analytics and dashboards" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/60 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4 grid grid-cols-2 gap-2">
                  {[
                    { v: "Real-Time", l: "Business insights" },
                    { v: "AI-Native", l: "Built-in intelligence" },
                    { v: "↓ 75%", l: "Data footprint" },
                    { v: "6×", l: "Faster reporting" },
                  ].map(item => (
                    <div key={item.l} className="bg-white/90 rounded-lg p-2.5 text-center">
                      <div className="text-sm font-black" style={{ color: "#E84821" }}>{item.v}</div>
                      <div className="text-[10px] text-gray-600">{item.l}</div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── MIGRATION STRATEGIES ─────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 900 500" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="450" cy="250" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          <circle cx="450" cy="250" r="320" stroke="white" strokeWidth="0.5" strokeDasharray="4 8" opacity="0.5"/>
          {[[80,60],[200,380],[700,60],[820,380],[320,50],[580,440]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-6 L2-2 L6-2 L3 2 L4 6 L0 3 L-4 6 L-3 2 L-6-2 L-2-2Z" fill="white" opacity="0.5"/></g>
          ))}
        </svg>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#D4920C]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#D4920C]">SAP S/4HANA Migration Strategies</span>
              <span className="w-6 h-0.5 rounded bg-[#D4920C]"/>
            </div>
            <h2 className="text-3xl font-bold text-white">Three paths to S/4HANA — we help you choose the right one</h2>
            <p className="mt-2 text-gray-400 max-w-xl mx-auto text-sm">Every organization's transformation journey is unique. CtrlA Tech Solutions helps you identify the migration approach that best aligns with your business objectives, timeline, and IT landscape.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {MIGRATION_PATHS.map((mp, i) => (
              <motion.div key={mp.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                className={`rounded-2xl overflow-hidden border transition-all duration-300 hover:-translate-y-1 ${mp.recommended ? "border-[#E84821]/50 shadow-2xl" : "border-white/15 hover:border-white/30"}`}
                style={{ backgroundColor: mp.recommended ? "rgba(232,72,33,0.12)" : "rgba(255,255,255,0.07)" }}>
                {/* image */}
                <div className="relative h-40 overflow-hidden">
                  <img src={mp.image} alt={mp.title} className="w-full h-full object-cover" loading="lazy"/>
                  <div className="absolute inset-0" style={{ background: `linear-gradient(to bottom, ${mp.accent}50, #1A1F3680)` }}/>
                  {mp.recommended && (
                    <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest bg-[#E84821] text-white">
                      Most Common
                    </div>
                  )}
                </div>
                {/* content */}
                <div className="p-6">
                  <div className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: mp.accent }}>{mp.tagline}</div>
                  <h3 className="text-lg font-bold text-white mb-2">{mp.title}</h3>
                  <p className="text-gray-400 text-xs leading-relaxed mb-5">{mp.desc}</p>
                  <div>
                    <div className="text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2">Best For</div>
                    <div className="space-y-1.5">
                      {mp.bestFor.map(item => (
                        <div key={item} className="flex items-center gap-2 text-xs text-gray-300">
                          <CheckCircle2 size={12} style={{ color: mp.accent }} className="flex-shrink-0"/>
                          {item}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── OUR SERVICES ─────────────────────────────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Our SAP S/4HANA Services</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>Comprehensive consulting &amp; implementation</h2>
            <p className="mt-2 text-gray-500 max-w-xl mx-auto text-sm">CtrlA Tech Solutions provides end-to-end services to ensure a smooth and successful SAP S/4HANA journey.</p>
          </div>

          <div className="grid lg:grid-cols-12 gap-10 items-start">
            <div className="lg:col-span-5">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[3/4]">
                <img src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&w=800&q=80" alt="CtrlA S/4HANA consulting team" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/60 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4 bg-white/95 rounded-xl p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-[#E84821] flex-shrink-0">
                      <Award size={18} className="text-white"/>
                    </div>
                    <div>
                      <div className="text-xs font-bold text-gray-900">Certified SAP Professionals</div>
                      <div className="text-[10px] text-gray-500 mt-0.5">SAP Implementation Consultants • India & UK</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="lg:col-span-7">
              <div className="grid sm:grid-cols-2 gap-3">
                {OUR_EXPERTISE.map((e, i) => (
                  <motion.div key={e} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}
                    className="flex items-start gap-2.5 bg-gray-50 rounded-xl p-3.5 border border-gray-100 hover:border-[#E84821]/30 hover:bg-[#FFF4F1] transition-colors">
                    <CheckCircle2 size={14} className="flex-shrink-0 mt-0.5 text-[#E84821]"/>
                    <span className="text-xs text-gray-700 leading-relaxed">{e}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── METHODOLOGY ──────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 100%)" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Our Implementation Methodology</span>
              </div>
              <h2 className="text-3xl font-bold mb-3" style={{ color: accentColor }}>A proven framework that minimizes risk &amp; accelerates value</h2>
              <p className="text-gray-500 text-sm leading-relaxed mb-7">Our structured implementation approach using SAP Activate methodology ensures on-time, on-budget delivery with measurable outcomes.</p>
              <div className="space-y-4">
                {METHODOLOGY.map((m, i) => (
                  <motion.div key={m.step} initial={{ opacity: 0, x: -16 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                    className="group flex gap-5 bg-white rounded-2xl p-5 border border-gray-100 shadow-sm hover:shadow-lg transition-all duration-300"
                    style={{ borderLeftWidth: "3px", borderLeftColor: m.accent }}>
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-black text-sm flex-shrink-0 group-hover:scale-110 transition-transform"
                      style={{ background: `linear-gradient(135deg, ${m.accent}, ${m.accent}99)` }}>
                      {m.step}
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 mb-1">{m.title}</h4>
                      <p className="text-xs text-gray-600 leading-relaxed">{m.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[4/3]">
                <img src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=900&q=80" alt="SAP S/4HANA project implementation planning" className="w-full h-full object-cover" loading="lazy"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/50 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4 grid grid-cols-3 gap-2">
                  {[
                    { icon: TrendingUp, label: "SAP Activate", sub: "Methodology" },
                    { icon: Sparkles, label: "On-Budget", sub: "Delivery" },
                    { icon: HeadphonesIcon, label: "Hypercare", sub: "Post Go-Live" },
                  ].map(item => {
                    const Icon = item.icon;
                    return (
                      <div key={item.label} className="bg-white/90 rounded-lg p-2.5 text-center">
                        <Icon size={14} className="mx-auto mb-1 text-[#E84821]"/>
                        <div className="text-xs font-bold text-gray-900">{item.label}</div>
                        <div className="text-[9px] text-gray-500">{item.sub}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── WHY CTRLA ────────────────────────────────────────────────────── */}
      <section className="py-14 bg-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why CtrlA Tech Solutions?</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl font-bold mb-2" style={{ color: accentColor }}>Digital transformation requires a trusted technology partner</h2>
            <p className="text-gray-500 max-w-2xl mx-auto text-sm">With 22+ years of combined ERP consulting experience, we combine deep expertise with proven methodologies to deliver SAP S/4HANA solutions that drive measurable business outcomes.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3 mb-10">
            {WHY_US.map((w, i) => (
              <motion.div key={w} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}
                className="flex items-start gap-2.5 bg-gray-50 rounded-xl p-3.5 border border-gray-100 hover:border-[#E84821]/30 hover:bg-[#FFF4F1] transition-colors">
                <CheckCircle2 size={14} className="flex-shrink-0 mt-0.5 text-[#E84821]"/>
                <span className="text-xs text-gray-700 leading-relaxed">{w}</span>
              </motion.div>
            ))}
          </div>

          {/* image strip */}
          <div className="grid grid-cols-3 gap-4 rounded-2xl overflow-hidden h-40">
            {[
              { src: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=500&q=80", label: "Expert Team" },
              { src: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=500&q=80", label: "Live Analytics" },
              { src: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=500&q=80", label: "Enterprise Platform" },
            ].map(item => (
              <div key={item.label} className="relative overflow-hidden rounded-2xl">
                <img src={item.src} alt={item.label} className="w-full h-full object-cover"/>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/50 to-transparent"/>
                <div className="absolute bottom-3 left-3 text-white text-xs font-bold">{item.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────────── */}
      <section className="py-16 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 900 300" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="450" cy="150" r="120" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          <circle cx="450" cy="150" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="4 8" opacity="0.6"/>
          {[[100,40],[800,240],[300,110],[600,170]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}><path d="M0-5 L2-2 L5-2 L3 2 L4 5 L0 3 L-4 5 L-3 2 L-5-2 L-2-2Z" fill="white" opacity="0.5"/></g>
          ))}
        </svg>
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Brain size={36} className="mx-auto mb-4 text-[#E84821]"/>
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Transform Your Enterprise with SAP S/4HANA</h2>
          <p className="text-gray-300 max-w-2xl mx-auto mb-8 leading-relaxed">
            Whether you're planning your first SAP implementation or upgrading from SAP ECC, CtrlA Tech Solutions can help you unlock the full potential of SAP S/4HANA. Build a <strong className="text-white">future-ready enterprise</strong> with intelligent automation, real-time analytics, and a scalable ERP platform designed for the next generation of business.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl text-sm font-bold text-white shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all bg-[#E84821]">
              Schedule a Free SAP S/4HANA Assessment <ArrowRight size={16} />
            </Link>
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl text-sm font-bold border border-white/30 text-white hover:bg-white/10 transition-all">
              Start Your Digital Transformation
            </Link>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
