import { useEffect } from "react";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { CheckCircle2, ArrowRight } from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import PageHero from "@/components/public/PageHero";
import { useSiteConfig } from "@/contexts/SiteConfigContext";
import { TechIcon } from "@/components/TechIcon";

type TechItem = {
  name: string;
  slug: string;
  color: string;
  description?: string;
};

type Category = {
  id: string;
  tabLabel: string;
  accent: string;
  eyebrow: string;
  headline: string;
  intro: string;
  items: TechItem[];
  services?: string[];
  tagline?: string;
};

const CATEGORIES: Category[] = [
  {
    id: "microsoft",
    tabLabel: "Microsoft",
    accent: "#0078D4",
    eyebrow: "Microsoft Technologies",
    headline: "Enterprise-Grade Microsoft Solutions for Modern Businesses",
    intro:
      "At CtrlA Tech Solutions, we leverage Microsoft's robust technology ecosystem to build secure, scalable, and high-performance enterprise applications. From legacy .NET Framework applications to modern cloud-native .NET solutions, Azure Cloud, SQL Server, and SharePoint, we help businesses accelerate digital transformation through reliable Microsoft technologies. Our experienced Microsoft developers build business applications, ERP integrations, enterprise portals, APIs, cloud solutions, and workflow automation that deliver long-term business value.",
    items: [
      {
        name: ".NET Framework",
        slug: "dotnet",
        color: "#512BD4",
        description:
          "Develop and maintain enterprise applications built on Microsoft's proven development platform.",
      },
      {
        name: "ASP.NET MVC",
        slug: "dotnet",
        color: "#512BD4",
        description:
          "Build secure, scalable, and responsive web applications using the MVC architecture for better performance and maintainability.",
      },
      {
        name: ".NET Core / .NET 8",
        slug: "dotnet",
        color: "#5C2D91",
        description:
          "Develop high-performance cross-platform applications, REST APIs, microservices, and cloud-native solutions.",
      },
      {
        name: "Microsoft Azure",
        slug: "microsoftazure",
        color: "#0078D4",
        description:
          "Cloud consulting, migration, infrastructure, DevOps, serverless computing, Azure SQL, Kubernetes, and managed cloud services.",
      },
      {
        name: "SQL Server",
        slug: "microsoftsqlserver",
        color: "#CC2927",
        description:
          "Enterprise database development, performance tuning, reporting, high availability, and disaster recovery.",
      },
      {
        name: "SharePoint",
        slug: "microsoftsharepoint",
        color: "#0078D4",
        description:
          "Corporate intranet portals, document management, workflow automation, and enterprise collaboration platforms.",
      },
    ],
    services: [
      "Business Applications",
      "ERP Integrations",
      "Enterprise Portals",
      "REST APIs & Microservices",
      "Cloud Solutions",
      "Workflow Automation",
    ],
  },
  {
    id: "open-source",
    tabLabel: "Open Source",
    accent: "#F7931E",
    eyebrow: "Open Source Technologies",
    headline: "Flexible, Scalable & Cost-Effective Open Source Development",
    intro:
      "Open-source technologies offer flexibility, innovation, and lower ownership costs. Our developers build modern web applications, CMS platforms, eCommerce solutions, APIs, and enterprise software using leading open-source technologies. Our solutions are secure, SEO-friendly, scalable, and cloud-ready.",
    items: [
      { name: "PHP", slug: "php", color: "#777BB4" },
      { name: "Laravel", slug: "laravel", color: "#FF2D20" },
      { name: "Magento", slug: "magento", color: "#EE672F" },
      { name: "WordPress", slug: "wordpress", color: "#21759B" },
      { name: "Drupal", slug: "drupal", color: "#0678BE" },
      { name: "Zend Framework", slug: "zend", color: "#68B604" },
      { name: "MySQL", slug: "mysql", color: "#4479A1" },
      { name: "PostgreSQL", slug: "postgresql", color: "#336791" },
      { name: "Node.js", slug: "nodedotjs", color: "#339933" },
    ],
    services: [
      "Modern Web Applications",
      "CMS Platforms",
      "eCommerce Solutions",
      "REST APIs",
      "Enterprise Software",
      "SEO-Friendly Sites",
      "Cloud-Ready Deployments",
    ],
    tagline:
      "Our solutions are secure, SEO-friendly, scalable, and cloud-ready.",
  },
  {
    id: "mobile",
    tabLabel: "Mobile",
    accent: "#3DDC84",
    eyebrow: "Mobile Technologies",
    headline: "Native & Cross-Platform Mobile App Development",
    intro:
      "Deliver seamless mobile experiences across Android and iOS using modern mobile development frameworks. Whether you need a native high-performance app or a cross-platform solution with a single codebase, our mobile team brings the right expertise and tools to every project.",
    items: [
      {
        name: "Android",
        slug: "android",
        color: "#3DDC84",
        description:
          "High-performance native Android applications using Kotlin and Java for optimal device integration and user experience.",
      },
      {
        name: "iOS",
        slug: "apple",
        color: "#000000",
        description:
          "Elegant iPhone and iPad applications built with Swift, following Apple's Human Interface Guidelines.",
      },
      {
        name: "Flutter",
        slug: "flutter",
        color: "#02569B",
        description:
          "Single codebase for Android, iOS, Web, and Desktop applications with near-native performance and beautiful UIs.",
      },
      {
        name: "Ionic",
        slug: "ionic",
        color: "#3880FF",
        description:
          "Hybrid mobile applications with rapid development cycles and lower long-term maintenance costs.",
      },
      {
        name: "React Native",
        slug: "react",
        color: "#61DAFB",
        description:
          "Cross-platform applications that combine native performance with JavaScript's rapid development ecosystem.",
      },
    ],
    services: [
      "Consumer Mobile Apps",
      "Enterprise Mobility Solutions",
      "Offline-First Applications",
      "Push Notification Systems",
      "App Store Deployment",
      "Mobile API Integration",
    ],
  },
  {
    id: "frontend",
    tabLabel: "Front-End",
    accent: "#E34F26",
    eyebrow: "Front-End Technologies",
    headline: "Modern User Interfaces for Exceptional Digital Experiences",
    intro:
      "Create responsive, interactive, and engaging web applications using the latest front-end technologies. Our UI/UX experts focus on performance, accessibility, responsiveness, and SEO optimization to deliver interfaces that users love and search engines reward.",
    items: [
      { name: "HTML5", slug: "html5", color: "#E34F26" },
      { name: "CSS3", slug: "css3", color: "#1572B6" },
      { name: "JavaScript", slug: "javascript", color: "#F7DF1E" },
      { name: "TypeScript", slug: "typescript", color: "#3178C6" },
      { name: "Angular", slug: "angular", color: "#DD0031" },
      { name: "React", slug: "react", color: "#61DAFB" },
      { name: "Vue.js", slug: "vuedotjs", color: "#4FC08D" },
      { name: "Svelte", slug: "svelte", color: "#FF3E00" },
    ],
    services: [
      "SPA Development",
      "Progressive Web Apps",
      "Component Libraries",
      "Performance Optimization",
      "Accessibility (WCAG)",
      "SEO-Optimized UIs",
      "Design System Implementation",
    ],
    tagline:
      "Our UI/UX experts focus on performance, accessibility, responsiveness, and SEO optimization.",
  },
  {
    id: "big-data",
    tabLabel: "Big Data",
    accent: "#E25A1C",
    eyebrow: "Big Data Technologies",
    headline: "Transform Big Data into Business Intelligence",
    intro:
      "Organizations generate massive amounts of data every day. Our Big Data solutions help businesses collect, process, analyze, and visualize data for informed decision-making. We combine the right tools and architectures to deliver data pipelines and analytics platforms that scale with your business.",
    items: [
      { name: "MongoDB", slug: "mongodb", color: "#47A248" },
      { name: "Hadoop", slug: "apachehadoop", color: "#FFD700" },
      { name: "Apache Spark", slug: "apachespark", color: "#E25A1C" },
      { name: "Cassandra", slug: "apachecassandra", color: "#1287B1" },
      { name: "HBase", slug: "apache", color: "#D22128" },
      { name: "CouchDB", slug: "apachecouchdb", color: "#E42528" },
      { name: "Apache Flink", slug: "apacheflink", color: "#E6526F" },
    ],
    services: [
      "Data Engineering",
      "Analytics & Reporting",
      "ETL Pipelines",
      "Real-Time Processing",
      "Enterprise Reporting",
      "Data Warehousing",
      "Business Intelligence Dashboards",
    ],
  },
  {
    id: "java",
    tabLabel: "Java",
    accent: "#5382A1",
    eyebrow: "Java Technologies",
    headline: "Enterprise Java Development for Business-Critical Applications",
    intro:
      "Build secure, scalable, and high-performance enterprise applications using industry-leading Java technologies. Our Java engineers bring deep expertise in enterprise architecture, RESTful service design, and database integration to deliver reliable systems that power your most critical business operations.",
    items: [
      {
        name: "Spring Framework",
        slug: "spring",
        color: "#6DB33F",
        description:
          "Comprehensive framework for enterprise Java development with dependency injection, AOP, and rich ecosystem support.",
      },
      {
        name: "Spring Boot",
        slug: "springboot",
        color: "#6DB33F",
        description:
          "Rapid development of production-ready Spring applications with auto-configuration, embedded servers, and opinionated defaults.",
      },
      {
        name: "Hibernate",
        slug: "hibernate",
        color: "#59666C",
        description:
          "Object-relational mapping for Java with powerful querying, caching, and database-agnostic persistence.",
      },
      {
        name: "Apache Struts",
        slug: "apache",
        color: "#D22128",
        description:
          "MVC framework for building maintainable Java web applications with a clean separation of concerns.",
      },
      {
        name: "Maven",
        slug: "apachemaven",
        color: "#C71A36",
        description:
          "Project management and build automation with dependency management, standardized project structure, and plugin ecosystem.",
      },
    ],
    services: [
      "Enterprise Applications",
      "REST API Development",
      "Banking & Finance Systems",
      "ERP Integrations",
      "Cloud-Native Java Services",
      "Legacy Java Modernisation",
      "Microservices Architecture",
    ],
  },
  {
    id: "ai-ml-data-science",
    tabLabel: "AI & ML",
    accent: "#FF6F00",
    eyebrow: "AI, Machine Learning & Data Science",
    headline: "Intelligent Solutions Powered by Artificial Intelligence",
    intro:
      "We develop next-generation AI applications that automate business processes, improve decision-making, and generate predictive insights. Our data science team combines deep learning, computer vision, NLP, and generative AI to create intelligent systems that give your business a competitive edge.",
    items: [
      { name: "TensorFlow", slug: "tensorflow", color: "#FF6F00" },
      { name: "Keras", slug: "keras", color: "#D00000" },
      { name: "OpenCV", slug: "opencv", color: "#5C3EE8" },
      { name: "ML Kit", slug: "google", color: "#4285F4" },
      { name: "RAG Pipelines", slug: "openai", color: "#10a37f" },
      { name: "Large Language Models", slug: "openai", color: "#10a37f" },
      { name: "Generative AI", slug: "openai", color: "#10a37f" },
      { name: "NLP", slug: "huggingface", color: "#FFD21E" },
    ],
    services: [
      "AI Chatbots & Virtual Assistants",
      "OCR & Document Intelligence",
      "Demand Forecasting",
      "Predictive Analytics",
      "Recommendation Engines",
      "Computer Vision",
      "Generative AI Applications",
      "Business Process Automation",
    ],
  },
  {
    id: "async-messaging",
    tabLabel: "Async Messaging",
    accent: "#FF6600",
    eyebrow: "Asynchronous Messaging & Data Streaming",
    headline: "Build High-Performance Distributed Systems",
    intro:
      "Enable scalable, event-driven applications with real-time messaging and distributed processing. Our engineers design and implement robust messaging architectures that decouple services, ensure data consistency, and handle millions of events per second — ideal for enterprise-grade systems that never sleep.",
    items: [
      { name: "Apache Kafka", slug: "apachekafka", color: "#231F20" },
      { name: "RabbitMQ", slug: "rabbitmq", color: "#FF6600" },
      { name: "Apache Airflow", slug: "apacheairflow", color: "#017CEE" },
      { name: "Celery", slug: "celery", color: "#37814A" },
      { name: "Redis", slug: "redis", color: "#DC382D" },
      { name: "Apache Storm", slug: "apache", color: "#D22128" },
    ],
    services: [
      "ERP Integrations",
      "Microservices Event Bus",
      "IoT Data Platforms",
      "Financial Transaction Systems",
      "Logistics & Supply Chain",
      "Real-Time Analytics",
      "Workflow Orchestration",
    ],
  },
  {
    id: "erp-solutions",
    tabLabel: "ERP Solutions",
    accent: "#0FAAFF",
    eyebrow: "ERP Technologies",
    headline: "Enterprise ERP Platforms for Digital Transformation",
    intro:
      "We help organizations implement, customize, integrate, and support leading ERP platforms that streamline operations and improve business performance. As Certified SAP Professionals with deep Odoo expertise, we ensure successful deployments that deliver measurable ROI from day one.",
    items: [
      {
        name: "SAP Business One",
        slug: "sap",
        color: "#0FAAFF",
        description:
          "Complete ERP solution for SMEs covering Finance, Inventory, Sales, Purchasing, CRM, Production, and Reporting.",
      },
      {
        name: "SAP Business One HANA",
        slug: "sap",
        color: "#0066CC",
        description:
          "In-memory ERP delivering real-time analytics, lightning-fast reporting, and enhanced business intelligence on the HANA platform.",
      },
      {
        name: "SAP S/4HANA",
        slug: "sap",
        color: "#003B6F",
        description:
          "SAP's next-generation intelligent ERP platform for enterprises with AI, automation, embedded analytics, and full digital transformation capabilities.",
      },
      {
        name: "Odoo ERP",
        slug: "odoo",
        color: "#714B67",
        description:
          "Flexible open-source ERP for CRM, Accounting, Manufacturing, Inventory, HR, Sales, Purchase, and eCommerce with extensive customisation options.",
      },
    ],
    services: [
      "ERP Implementation",
      "System Customisation",
      "Data Migration",
      "Third-Party Integrations",
      "User Training",
      "Post-Go-Live Support",
      "ERP Health Checks",
    ],
  },
];

const WHY_ITEMS = [
  "Experienced Full-Stack Development Team",
  "Cloud-Native & Microservices Architecture",
  "API-First Development",
  "AI & Automation Integration",
  "DevOps & CI/CD Best Practices",
  "Enterprise Security Standards",
  "Performance Optimization",
  "Agile Development Methodology",
  "Long-Term Support & Maintenance",
  "End-to-End Digital Transformation Expertise",
];

function TechLogoCard({ tech }: { tech: TechItem }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="flex flex-col items-center gap-3 p-5 bg-white rounded-2xl border border-gray-100 hover:border-gray-200 hover:shadow-lg transition-all group cursor-default"
    >
      <div
        className="w-16 h-16 rounded-2xl flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform duration-300"
        style={{ backgroundColor: `${tech.color}15` }}
      >
        <TechIcon slug={tech.slug} color={tech.color} name={tech.name} size={36} />
      </div>
      <span className="text-sm font-semibold text-gray-700 text-center leading-tight">
        {tech.name}
      </span>
    </motion.div>
  );
}

function TechFeatureCard({ tech, i }: { tech: TechItem; i: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: i * 0.07 }}
      className="group flex gap-5 p-6 bg-white rounded-2xl border border-gray-100 hover:border-gray-200 hover:shadow-lg transition-all"
    >
      <div
        className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform duration-300"
        style={{ backgroundColor: `${tech.color}15` }}
      >
        <TechIcon slug={tech.slug} color={tech.color} name={tech.name} size={32} />
      </div>
      <div>
        <h3 className="font-bold text-gray-900 mb-1.5">{tech.name}</h3>
        {tech.description && (
          <p className="text-sm text-gray-500 leading-relaxed">{tech.description}</p>
        )}
      </div>
    </motion.div>
  );
}

type Props = { params?: { category?: string } };

export default function TechnologiesPage({ params }: Props) {
  const [, navigate] = useLocation();
  const { primaryColor } = useSiteConfig();

  const categoryId = params?.category ?? "microsoft";
  const current = CATEGORIES.find((c) => c.id === categoryId) ?? CATEGORIES[0];

  const hasDescriptions = current.items.some((it) => it.description);

  useEffect(() => {
    if (!CATEGORIES.find((c) => c.id === categoryId)) {
      navigate("/technologies/microsoft");
    }
  }, [categoryId, navigate]);

  return (
    <PublicLayout>
      <SEO
        title={`${current.tabLabel} Technologies`}
        description={current.intro.substring(0, 160)}
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: `${current.tabLabel} Technologies — CtrlA Tech Solutions`,
          description: current.intro.substring(0, 160),
          url: window.location.href,
          publisher: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
          hasPart: current.items.map(item => ({
            "@type": "SoftwareApplication",
            name: item.name,
            description: item.description,
          })),
        }}
      />

      <PageHero
        eyebrow="Technologies"
        title={
          <>
            Our <span style={{ color: "#E84821" }}>Technology</span> Stack
          </>
        }
        subtitle="We leverage best-in-class technologies to deliver scalable, future-ready solutions for your business."
      />

      <section className="py-12 bg-gray-50 min-h-[60vh]">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">

          {/* ── Tab Navigation ── */}
          <div className="overflow-x-auto pb-2 mb-10">
            <div className="flex gap-1 min-w-max bg-white rounded-2xl border border-gray-100 shadow-sm p-1.5">
              {CATEGORIES.map((cat) => {
                const isActive = cat.id === current.id;
                return (
                  <Link key={cat.id} href={`/technologies/${cat.id}`}>
                    <button
                      className={`px-4 py-2.5 rounded-xl text-sm font-semibold whitespace-nowrap transition-all ${
                        isActive
                          ? "text-white shadow-sm"
                          : "text-gray-600 hover:text-gray-900 hover:bg-gray-50"
                      }`}
                      style={isActive ? { backgroundColor: cat.accent } : {}}
                    >
                      {cat.tabLabel}
                    </button>
                  </Link>
                );
              })}
            </div>
          </div>

          {/* ── Category Content ── */}
          <motion.div
            key={current.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            {/* Header */}
            <div className="mb-10">
              <div
                className="inline-block text-xs font-bold uppercase tracking-widest mb-3 px-3 py-1 rounded-full"
                style={{ backgroundColor: `${current.accent}15`, color: current.accent }}
              >
                {current.eyebrow}
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4 max-w-3xl leading-tight">
                {current.headline}
              </h2>
              <div className="flex items-center gap-1.5 mb-5">
                <div className="h-1 w-12 rounded-full bg-[#E84821]" />
                <div className="h-1 w-6 rounded-full" style={{ backgroundColor: current.accent }} />
                <div className="h-1 w-3 rounded-full bg-[#3D4FA0]" />
              </div>
              <p className="text-gray-600 max-w-3xl leading-relaxed">{current.intro}</p>
            </div>

            {/* Eyebrow label above grid */}
            <div className="flex items-center gap-3 mb-6">
              <div className="w-1 h-6 rounded-full" style={{ backgroundColor: current.accent }} />
              <span className="text-sm font-bold text-gray-700 uppercase tracking-wider">
                {hasDescriptions ? "Our Expertise" : "Technologies"}
              </span>
            </div>

            {/* Items: Feature cards (with desc) OR logo grid */}
            {hasDescriptions ? (
              <div className="grid sm:grid-cols-2 gap-4 mb-10">
                {current.items.map((tech, i) => (
                  <TechFeatureCard key={tech.name} tech={tech} i={i} />
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 mb-10">
                {current.items.map((tech, i) => (
                  <motion.div
                    key={tech.name}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: i * 0.05 }}
                  >
                    <TechLogoCard tech={tech} />
                  </motion.div>
                ))}
              </div>
            )}

            {/* Tagline (for some categories) */}
            {current.tagline && (
              <p className="text-sm font-medium text-gray-500 italic mb-10 flex items-center gap-2">
                <span
                  className="w-2 h-2 rounded-full flex-shrink-0"
                  style={{ backgroundColor: current.accent }}
                />
                {current.tagline}
              </p>
            )}

            {/* Services / Use Cases */}
            {current.services && current.services.length > 0 && (
              <div className="mb-12 p-6 bg-white rounded-2xl border border-gray-100">
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-1 h-5 rounded-full" style={{ backgroundColor: current.accent }} />
                  <h3 className="text-sm font-bold uppercase tracking-wider text-gray-700">
                    Our Services Include
                  </h3>
                </div>
                <div className="flex flex-wrap gap-2.5">
                  {current.services.map((svc) => (
                    <span
                      key={svc}
                      className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-sm font-medium border transition-all"
                      style={{
                        backgroundColor: `${current.accent}10`,
                        borderColor: `${current.accent}25`,
                        color: current.accent,
                      }}
                    >
                      <CheckCircle2 size={13} />
                      {svc}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Why Choose CtrlA */}
            <div
              className="rounded-2xl p-8 mb-10"
              style={{
                background:
                  "linear-gradient(140deg, #0d1225 0%, #1A1F36 55%, #2D3561 100%)",
              }}
            >
              <div className="mb-6">
                <div className="text-xs font-bold uppercase tracking-widest text-[#E84821] mb-2">
                  Why Choose CtrlA Tech Solutions?
                </div>
                <h3 className="text-xl font-bold text-white">
                  Across every technology stack, we follow modern engineering practices to deliver reliable, scalable, and future-ready solutions.
                </h3>
              </div>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {WHY_ITEMS.map((item, i) => (
                  <motion.div
                    key={item}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: i * 0.04 }}
                    className="flex items-start gap-2.5 text-sm text-white/80"
                  >
                    <CheckCircle2
                      size={16}
                      className="flex-shrink-0 mt-0.5"
                      style={{ color: current.accent }}
                    />
                    {item}
                  </motion.div>
                ))}
              </div>
              <div className="mt-8">
                <Link
                  href="/contact"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-lg font-bold text-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5"
                  style={{ backgroundColor: current.accent }}
                >
                  Discuss Your Project <ArrowRight size={16} />
                </Link>
              </div>
            </div>

            {/* All categories strip */}
            <div className="pt-10 border-t border-gray-200">
              <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-5">
                All Technology Categories
              </h3>
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-9 gap-3">
                {CATEGORIES.map((cat) => (
                  <Link key={cat.id} href={`/technologies/${cat.id}`}>
                    <div
                      className={`group flex flex-col items-center gap-2 p-3 rounded-xl border transition-all cursor-pointer ${
                        cat.id === current.id
                          ? "shadow-md"
                          : "border-gray-100 hover:border-gray-200 hover:shadow-sm bg-white"
                      }`}
                      style={
                        cat.id === current.id
                          ? {
                              backgroundColor: `${cat.accent}12`,
                              borderColor: `${cat.accent}30`,
                            }
                          : {}
                      }
                    >
                      <div
                        className="w-8 h-8 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: `${cat.accent}18` }}
                      >
                        <span
                          className="text-[10px] font-black"
                          style={{ color: cat.accent }}
                        >
                          {cat.tabLabel.substring(0, 2).toUpperCase()}
                        </span>
                      </div>
                      <span className="text-[10px] font-semibold text-center text-gray-600 leading-tight group-hover:text-gray-900 transition-colors">
                        {cat.tabLabel}
                      </span>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </PublicLayout>
  );
}
