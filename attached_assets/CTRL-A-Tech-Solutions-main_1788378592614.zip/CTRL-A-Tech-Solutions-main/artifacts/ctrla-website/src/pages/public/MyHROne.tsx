import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  ArrowRight, CheckCircle2, Users, DollarSign, Clock, MapPin,
  Smartphone, BarChart3, Brain, Zap, Shield, Globe2,
  UserCheck, Calendar, CreditCard, Truck, MessageSquare,
  Target, TrendingUp, ChevronRight, Sparkles, Activity,
  Fingerprint, Navigation, ClipboardList, Star,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";
import myhrLogo from "@assets/MyHR_One_1783693883544.png";

/* ── HIGHLIGHTS ─────────────────────────────────────────────────── */
const HIGHLIGHTS = [
  { icon: Users,        label: "Complete Employee Lifecycle Management" },
  { icon: DollarSign,   label: "Automated Payroll & Compliance" },
  { icon: Fingerprint,  label: "AI Face Recognition Attendance" },
  { icon: Navigation,   label: "GPS Field Workforce Tracking" },
  { icon: Smartphone,   label: "Mobile-First Employee Self Service" },
  { icon: Target,       label: "Performance Management & KPIs" },
  { icon: Brain,        label: "AI Business Insights & Analytics" },
  { icon: Globe2,       label: "ERP & Biometric Integration" },
  { icon: MessageSquare,label: "Company-Wide Communication" },
  { icon: Shield,       label: "Enterprise Security & Role-Based Access" },
];

/* ── MODULES ────────────────────────────────────────────────────── */
const MODULES = [
  { icon: Users,        title: "HRMS",                   desc: "Complete Human Resource Management",          color: "#E84821", bg: "#FFF4F1" },
  { icon: DollarSign,   title: "Payroll",                desc: "Automated Payroll Processing",                color: "#D4920C", bg: "#FFFBEB" },
  { icon: Clock,        title: "Attendance",             desc: "AI Face Recognition & Biometric Attendance",  color: "#3D4FA0", bg: "#F0F3FF" },
  { icon: Navigation,   title: "Field Workforce",        desc: "GPS Tracking & Geo-Fencing",                  color: "#059669", bg: "#ECFDF5" },
  { icon: ClipboardList,title: "Task Management",        desc: "Digital Task Assignment & Monitoring",         color: "#7C3AED", bg: "#F5F3FF" },
  { icon: Target,       title: "Performance",            desc: "KPIs, Goals & Appraisals",                   color: "#E84821", bg: "#FFF4F1" },
  { icon: MessageSquare,title: "Communication",          desc: "Company-wide Collaboration",                  color: "#0891B2", bg: "#ECFEFF" },
  { icon: Star,         title: "Employee Engagement",    desc: "Building Connected Workplaces",               color: "#D4920C", bg: "#FFFBEB" },
  { icon: Activity,     title: "CRM Integration",        desc: "Connect HR with Sales & Field Operations",    color: "#3D4FA0", bg: "#F0F3FF" },
];

/* ── HRMS SUB-FEATURES ──────────────────────────────────────────── */
const HRMS_FEATURES = [
  {
    icon: Fingerprint,
    title: "AI Face Recognition Attendance",
    desc: "Fast, contactless attendance using AI-powered facial recognition with offline capability.",
    tags: ["AI Face Detection", "Biometric Integration", "Mobile Attendance", "Offline Mode", "Shift-Based Attendance"],
  },
  {
    icon: DollarSign,
    title: "Payroll Management",
    desc: "Run payroll accurately and efficiently every month with full statutory compliance.",
    tags: ["PF & ESI", "Professional Tax", "Income Tax", "Loan & Advance", "Incentives & Bonus", "Bank Transfer Reports"],
  },
  {
    icon: Calendar,
    title: "Leave Management",
    desc: "Digitize leave applications and approval workflows with complete policy management.",
    tags: ["Leave Policies", "Holiday Calendar", "Multi-Level Approval", "Comp-Off", "Leave Reports"],
  },
  {
    icon: Clock,
    title: "Shift & Roster Management",
    desc: "Create flexible work schedules with automated shift planning and rotational shifts.",
    tags: ["Shift Planning", "Weekly Off", "Rotational Shifts", "Night Shift Support", "Overtime Management"],
  },
  {
    icon: CreditCard,
    title: "Expense Management",
    desc: "Track employee expenses digitally with seamless approval and reimbursement workflows.",
    tags: ["Travel Claims", "Fuel Expenses", "Bills Upload", "Approval Workflow", "Reimbursement Reports"],
  },
];

/* ── AI INSIGHTS ─────────────────────────────────────────────────── */
const AI_INSIGHTS = [
  { icon: TrendingUp,   label: "Attendance Trends",         desc: "Track daily, weekly, monthly patterns across teams and departments." },
  { icon: DollarSign,   label: "Payroll Cost Analysis",     desc: "Understand payroll spend breakdown, trends and budget utilization." },
  { icon: Zap,          label: "Employee Productivity",     desc: "Measure output per employee with goal completion and task metrics." },
  { icon: BarChart3,    label: "Department Performance",    desc: "Benchmark teams on KPIs, tasks, and appraisal scores." },
  { icon: Activity,     label: "Attrition Analysis",        desc: "Identify early warning signs of employee churn before they leave." },
  { icon: Calendar,     label: "Leave Trends",              desc: "Spot patterns in absences, leaves, and overtime utilization." },
  { icon: Users,        label: "Recruitment Analytics",     desc: "Track time-to-hire, source efficiency, and funnel conversion rates." },
  { icon: Brain,        label: "AI Performance Insights",   desc: "Machine-learning predictions on team risks, top performers, and gaps." },
];

/* ── FIELD WORKFORCE ─────────────────────────────────────────────── */
const FIELD_FEATURES = [
  { icon: MapPin,       title: "Geo-Fencing Attendance",    desc: "Attendance is marked only within authorized work locations." },
  { icon: Navigation,   title: "Live GPS Tracking",         desc: "Monitor employee movement and route history in real time." },
  { icon: Truck,        title: "Route Optimization",        desc: "Reduce travel time and improve field productivity." },
  { icon: ClipboardList,title: "Visit Management",          desc: "Track customer visits, meeting status, and visit reports." },
  { icon: CreditCard,   title: "Expense Validation",        desc: "Match travel expenses with GPS routes for transparent reimbursement." },
];

/* ── INTEGRATIONS ────────────────────────────────────────────────── */
const INTEGRATIONS = [
  "SAP Business One", "SAP S/4HANA", "TallyPrime", "Microsoft Dynamics 365",
  "Oracle ERP", "QuickBooks", "Zoho", "Biometric Devices",
  "ZKTeco Devices", "ESSL Biometric", "WhatsApp", "Google Workspace",
  "Microsoft 365", "Custom ERP Solutions",
];

const SERVICES_LIST = [
  "HRMS Implementation", "Data Migration", "Biometric Integration",
  "Mobile App Deployment", "User Training", "Custom Configuration",
  "Cloud Hosting", "Annual Maintenance & Support", "API Integration",
];

/* ── COMPONENT ───────────────────────────────────────────────────── */
export default function MyHROnePage() {
  const { primaryColor } = useSiteConfig();

  return (
    <PublicLayout>
      <SEO
        title="MyHROne — AI-Powered HRMS Platform | CtrlA Tech Solutions"
        description="MyHROne is an intelligent HRMS platform with AI Face Recognition, GPS Field Workforce, Payroll Automation, Performance Management, and AI Business Insights for modern businesses."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "Product",
          name: "MyHROne",
          description: "AI-Powered HR Management System with Payroll, Attendance, Field Workforce, and Business Insights.",
          brand: { "@type": "Brand", name: "CtrlA Tech Solutions" },
        }}
      />

      {/* ━━━ HERO ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="relative overflow-hidden min-h-[88vh] flex flex-col justify-center"
        style={{ background: "linear-gradient(140deg, #080C1F 0%, #111627 45%, #1a1f38 100%)" }}>

        {/* SVG decorations */}
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 1200 700" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="950" cy="160" r="320" stroke="#E84821" strokeWidth="0.6" strokeDasharray="8 6"/>
          <circle cx="950" cy="160" r="190" stroke="#3D4FA0" strokeWidth="0.4" strokeDasharray="4 8"/>
          <circle cx="950" cy="160" r="90"  stroke="white"   strokeWidth="0.3" strokeDasharray="3 5"/>
          <path d="M0 380 Q200 340 400 360 Q600 380 800 340 Q1000 300 1200 320" stroke="white" strokeWidth="0.4" fill="none" strokeDasharray="5 5"/>
          {[[60,80],[180,220],[340,60],[120,400],[480,300],[260,480],[700,120]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-7 L2.5-2.5 L7-2.5 L3.5 2 L5 7 L0 4 L-5 7 L-3.5 2 L-7-2.5 L-2.5-2.5Z" fill="white" opacity="0.4"/>
            </g>
          ))}
        </svg>

        <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-20 flex-1 flex items-center">
          <div className="grid lg:grid-cols-2 gap-14 items-center w-full">
            {/* LEFT */}
            <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.65 }}>
              <div className="inline-flex items-center gap-2 mb-5 px-4 py-2 rounded-full border border-[#E84821]/40 bg-[#E84821]/10">
                <Sparkles size={13} className="text-[#E84821]"/>
                <span className="text-xs font-black uppercase tracking-widest text-[#E84821]">CtrlA HR Platform</span>
              </div>

              <img src={myhrLogo} alt="MyHROne Logo" className="h-14 mb-5 brightness-0 invert" />

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black leading-tight tracking-tight mb-4 text-white">
                Empowering Your Workforce.<br/>
                <span style={{ color: "#E84821" }}>Accelerating</span> Business Growth.
              </h1>
              <p className="text-gray-400 text-base leading-relaxed mb-6 max-w-xl">
                One Intelligent Platform for HR, Payroll, Attendance, Field Workforce & Employee Engagement. Built for modern businesses to automate HR operations and make faster, data-driven decisions.
              </p>

              <div className="flex gap-2 mb-8">
                <span className="h-1 w-14 rounded-full bg-[#E84821]"/>
                <span className="h-1 w-8 rounded-full bg-[#D4920C]"/>
                <span className="h-1 w-4 rounded-full bg-[#3D4FA0]"/>
              </div>

              <div className="flex flex-wrap gap-2 mb-8">
                {["Automate", "Empower", "Grow"].map(tag => (
                  <span key={tag} className="px-4 py-1.5 rounded-full text-sm font-bold border border-white/20 text-white/80">
                    {tag}
                  </span>
                ))}
              </div>

              <div className="flex flex-wrap gap-3">
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl font-bold text-white text-sm transition-all hover:-translate-y-0.5 hover:shadow-xl"
                  style={{ backgroundColor: "#E84821", boxShadow: "0 4px 20px rgba(232,72,33,0.35)" }}>
                  Get Free Demo <ArrowRight size={16} />
                </Link>
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl font-bold text-white text-sm border border-white/20 hover:border-white/40 hover:bg-white/5 transition-all">
                  Talk to Sales <ChevronRight size={16} />
                </Link>
              </div>
            </motion.div>

            {/* RIGHT — hero image */}
            <motion.div initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.7, delay: 0.15 }}
              className="relative hidden lg:block">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl" style={{ border: "1px solid rgba(255,255,255,0.08)" }}>
                <img
                  src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=800&q=80"
                  alt="HR team collaboration and workforce management"
                  className="w-full h-[440px] object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-tl from-[#080C1F]/60 via-transparent to-transparent"/>
              </div>
              {/* floating badge */}
              <div className="absolute -bottom-4 -left-4 bg-white rounded-2xl p-4 shadow-xl border border-gray-100 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#E84821]/10 flex items-center justify-center">
                  <Brain size={20} style={{ color: "#E84821" }} />
                </div>
                <div>
                  <p className="text-xs font-bold text-gray-900">AI-Powered Insights</p>
                  <p className="text-[10px] text-gray-400">Real-time HR intelligence</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ━━━ HIGHLIGHTS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="py-10 border-b border-gray-100 bg-white">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-3">
            {HIGHLIGHTS.map(({ icon: Icon, label }, i) => (
              <motion.div key={label} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }} transition={{ delay: i * 0.04 }}
                className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-gray-50 border border-gray-100 text-sm font-medium text-gray-700 hover:border-[#E84821]/30 hover:bg-orange-50 transition-colors">
                <Icon size={14} style={{ color: "#E84821" }} />
                {label}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ━━━ ONE PLATFORM ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="py-20">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div className="text-center mb-14" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <span className="inline-block px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest text-white mb-3" style={{ backgroundColor: "#E84821" }}>
              One Platform. Complete Workforce Management.
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-[#1A1F36] mb-4">
              Powerful Modules — Designed for Every Aspect of Workforce Management
            </h2>
            <p className="text-gray-500 max-w-2xl mx-auto text-base">
              Digitize every stage of your employee journey with intelligent automation, real-time data, and seamless integrations.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {MODULES.map(({ icon: Icon, title, desc, color, bg }, i) => (
              <motion.div key={title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }} transition={{ delay: i * 0.06 }}
                className="group p-6 rounded-2xl border border-gray-100 hover:border-gray-200 hover:shadow-lg transition-all bg-white">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4" style={{ backgroundColor: bg }}>
                  <Icon size={22} style={{ color }} />
                </div>
                <h3 className="text-base font-bold text-gray-900 mb-1 group-hover:text-[#E84821] transition-colors">{title}</h3>
                <p className="text-sm text-gray-500">{desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ━━━ HRMS DEEP-DIVE ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-14 items-start">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821] mb-2 block">HRMS</span>
              <h2 className="text-3xl sm:text-4xl font-black text-[#1A1F36] mb-4">
                Simplify Every Employee Journey
              </h2>
              <p className="text-gray-500 mb-8 text-base leading-relaxed">
                Manage every stage of the employee lifecycle — from recruitment to retirement — through one intelligent HR platform with powerful automation.
              </p>
              <div className="space-y-6">
                {HRMS_FEATURES.map(({ icon: Icon, title, desc, tags }, i) => (
                  <motion.div key={title} initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }} transition={{ delay: i * 0.08 }}
                    className="bg-white rounded-xl p-5 border border-gray-100 hover:border-[#E84821]/30 hover:shadow-sm transition-all">
                    <div className="flex items-start gap-3 mb-3">
                      <div className="p-2 rounded-lg bg-[#E84821]/8 flex-shrink-0">
                        <Icon size={16} style={{ color: "#E84821" }} />
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900 text-sm">{title}</h4>
                        <p className="text-xs text-gray-500 mt-0.5">{desc}</p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-1.5 pl-9">
                      {tags.map(tag => (
                        <span key={tag} className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-gray-50 border border-gray-200 text-gray-600">{tag}</span>
                      ))}
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}
              className="sticky top-24">
              <div className="rounded-2xl overflow-hidden shadow-xl mb-6">
                <img
                  src="https://images.unsplash.com/photo-1553484771-371a605b060b?auto=format&fit=crop&w=700&q=80"
                  alt="AI face recognition attendance system"
                  className="w-full h-56 object-cover"
                />
              </div>
              <div className="rounded-2xl overflow-hidden shadow-xl">
                <img
                  src="https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&w=700&q=80"
                  alt="HR team in modern office"
                  className="w-full h-56 object-cover"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ━━━ AI POWERED INSIGHTS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="py-24 relative overflow-hidden"
        style={{ background: "linear-gradient(135deg, #080C1F 0%, #0f1528 50%, #151c35 100%)" }}>
        {/* Background glow */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full"
            style={{ background: "radial-gradient(circle, rgba(232,72,33,0.06) 0%, transparent 70%)" }} />
        </div>

        <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* LEFT */}
            <motion.div initial={{ opacity: 0, x: -24 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#E84821]/30 bg-[#E84821]/10 mb-6">
                <Brain size={13} className="text-[#E84821]" />
                <span className="text-xs font-black uppercase tracking-widest text-[#E84821]">AI Powered Insights</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-black text-white mb-4 leading-tight">
                Turn HR Data into<br/>
                <span style={{ color: "#E84821" }}>Actionable Intelligence</span>
              </h2>
              <p className="text-gray-400 text-base leading-relaxed mb-8">
                Managers and business owners can instantly view real-time analytics, predictive reports, and AI-driven insights — all from a single intelligent dashboard. No data science team required.
              </p>

              <div className="space-y-3">
                {AI_INSIGHTS.map(({ icon: Icon, label, desc }, i) => (
                  <motion.div key={label}
                    initial={{ opacity: 0, x: -16 }} whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }} transition={{ delay: i * 0.07 }}
                    className="flex items-start gap-3 p-3.5 rounded-xl border border-white/6 hover:border-[#E84821]/30 hover:bg-white/3 transition-all"
                    style={{ backgroundColor: "rgba(255,255,255,0.03)" }}>
                    <div className="p-2 rounded-lg flex-shrink-0"
                      style={{ backgroundColor: "rgba(232,72,33,0.15)", border: "1px solid rgba(232,72,33,0.2)" }}>
                      <Icon size={15} style={{ color: "#E84821" }} />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-white leading-tight">{label}</p>
                      <p className="text-xs text-gray-500 mt-0.5">{desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* RIGHT — analytics image */}
            <motion.div initial={{ opacity: 0, x: 24 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}
              className="relative">
              <div className="rounded-2xl overflow-hidden shadow-2xl" style={{ border: "1px solid rgba(232,72,33,0.2)" }}>
                <img
                  src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=700&q=80"
                  alt="HR analytics and AI insights dashboard"
                  className="w-full h-[420px] object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#080C1F]/50 to-transparent" />
              </div>

              {/* Floating metric cards */}
              <div className="absolute -top-4 -right-4 bg-white rounded-xl p-3.5 shadow-xl border border-gray-100">
                <div className="flex items-center gap-2 mb-1">
                  <TrendingUp size={14} style={{ color: "#059669" }} />
                  <span className="text-xs font-bold text-gray-700">Productivity</span>
                </div>
                <p className="text-xl font-black" style={{ color: "#059669" }}>+34%</p>
                <p className="text-[10px] text-gray-400">vs last quarter</p>
              </div>
              <div className="absolute -bottom-4 -left-4 bg-white rounded-xl p-3.5 shadow-xl border border-gray-100">
                <div className="flex items-center gap-2 mb-1">
                  <Activity size={14} style={{ color: "#E84821" }} />
                  <span className="text-xs font-bold text-gray-700">Attrition Risk</span>
                </div>
                <p className="text-xl font-black" style={{ color: "#E84821" }}>↓ 18%</p>
                <p className="text-[10px] text-gray-400">AI prediction score</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ━━━ FIELD WORKFORCE ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="py-20 bg-white">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="rounded-2xl overflow-hidden shadow-xl">
                <img
                  src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?auto=format&fit=crop&w=700&q=80"
                  alt="Field workforce GPS tracking and management"
                  className="w-full h-[380px] object-cover"
                />
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <span className="text-xs font-bold uppercase tracking-widest text-[#059669] mb-2 block">Field Workforce Management</span>
              <h2 className="text-3xl sm:text-4xl font-black text-[#1A1F36] mb-4">
                Manage Your Workforce<br/>Anytime, Anywhere
              </h2>
              <p className="text-gray-500 mb-8 text-base leading-relaxed">
                Improve visibility and productivity of sales teams, service engineers, delivery executives, and field employees through GPS-enabled workforce management.
              </p>
              <div className="space-y-4">
                {FIELD_FEATURES.map(({ icon: Icon, title, desc }, i) => (
                  <motion.div key={title} initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }} transition={{ delay: i * 0.08 }}
                    className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 bg-green-50">
                      <Icon size={18} style={{ color: "#059669" }} />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 text-sm mb-0.5">{title}</h4>
                      <p className="text-sm text-gray-500">{desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ━━━ MOBILE ESS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-14 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0] mb-2 block">Employee Self Service</span>
              <h2 className="text-3xl font-black text-[#1A1F36] mb-4">Mobile-First HR Experience</h2>
              <p className="text-gray-500 mb-6 text-base leading-relaxed">
                Empower your employees with a mobile app that puts every HR service at their fingertips — from payslips and leave requests to attendance marking and performance reviews.
              </p>
              <div className="grid grid-cols-2 gap-3">
                {["Mark Attendance via Mobile","View Payslips","Apply for Leave","Download Tax Documents",
                  "Raise Expense Claims","View Performance Goals","Chat with HR","Company Announcements"].map(f => (
                  <div key={f} className="flex items-center gap-2 text-sm text-gray-700">
                    <CheckCircle2 size={14} style={{ color: "#3D4FA0" }} />
                    {f}
                  </div>
                ))}
              </div>
              <Link href="/contact" className="inline-flex items-center gap-2 mt-8 px-6 py-3.5 rounded-xl font-bold text-white text-sm transition-all hover:-translate-y-0.5"
                style={{ backgroundColor: "#3D4FA0", boxShadow: "0 4px 16px rgba(61,79,160,0.3)" }}>
                Request a Demo <ArrowRight size={16} />
              </Link>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="rounded-2xl overflow-hidden shadow-xl">
                <img
                  src="https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?auto=format&fit=crop&w=700&q=80"
                  alt="Mobile HR self service app for employees"
                  className="w-full h-[380px] object-cover"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ━━━ INTEGRATIONS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="py-20 bg-white">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div className="text-center mb-12" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2 className="text-3xl font-black text-[#1A1F36] mb-3">Seamless Integrations</h2>
            <p className="text-gray-500">Connect MyHROne with your ERP, biometric devices, and business tools.</p>
          </motion.div>
          <div className="flex flex-wrap justify-center gap-3 mb-16">
            {INTEGRATIONS.map((name, i) => (
              <motion.span key={name} initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }} transition={{ delay: i * 0.03 }}
                className="px-4 py-2 rounded-xl bg-gray-50 border border-gray-200 text-sm font-semibold text-gray-700 hover:border-[#E84821]/40 hover:bg-orange-50 transition-colors">
                {name}
              </motion.span>
            ))}
          </div>

          {/* Implementation Services */}
          <div className="bg-gray-50 rounded-2xl p-8 border border-gray-100">
            <h3 className="text-xl font-bold text-[#1A1F36] mb-6 text-center">Our Implementation Services</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {SERVICES_LIST.map(s => (
                <div key={s} className="flex items-center gap-2 text-sm text-gray-700 bg-white rounded-lg px-4 py-2.5 border border-gray-100">
                  <CheckCircle2 size={14} style={{ color: "#E84821" }} />
                  {s}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ━━━ CTA ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <section className="py-24 relative overflow-hidden"
        style={{ background: "linear-gradient(135deg, #E84821 0%, #c73d1a 50%, #a33015 100%)" }}>
        <div className="absolute inset-0 pointer-events-none opacity-10">
          <svg viewBox="0 0 1200 400" className="w-full h-full" preserveAspectRatio="xMidYMid slice">
            <circle cx="200" cy="200" r="300" stroke="white" strokeWidth="0.5" fill="none"/>
            <circle cx="1000" cy="200" r="200" stroke="white" strokeWidth="0.5" fill="none"/>
          </svg>
        </div>
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <img src={myhrLogo} alt="MyHROne" className="h-10 mx-auto mb-6 brightness-0 invert" />
            <h2 className="text-3xl sm:text-4xl font-black text-white mb-4">
              Ready to Transform Your HR Operations?
            </h2>
            <p className="text-white/80 text-base mb-8 max-w-2xl mx-auto">
              Join hundreds of businesses using MyHROne to streamline HR, automate payroll, and unlock workforce intelligence.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link href="/contact" className="inline-flex items-center gap-2 px-8 py-4 rounded-xl font-bold text-[#E84821] bg-white hover:bg-gray-50 transition-all hover:-translate-y-0.5 shadow-xl text-sm">
                Get Free Demo <ArrowRight size={16} />
              </Link>
              <Link href="/become-a-partner" className="inline-flex items-center gap-2 px-8 py-4 rounded-xl font-bold text-white border-2 border-white/40 hover:border-white hover:bg-white/10 transition-all text-sm">
                Become a Partner <UserCheck size={16} />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </PublicLayout>
  );
}
