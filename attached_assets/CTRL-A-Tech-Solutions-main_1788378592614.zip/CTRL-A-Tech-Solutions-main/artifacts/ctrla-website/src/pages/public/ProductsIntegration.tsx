import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, Plug, CheckCircle2 } from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";
import ProductItemModal from "@/components/public/ProductItemModal";
import { getIcon } from "@/lib/iconMap";
import type { ProductItem } from "@/types/productItem";

const benefits = [
  "Pre-built connectors — faster time to value",
  "Real-time & batch data synchronisation",
  "Error handling with automatic retry logic",
  "Full audit trail for every transaction",
  "Low-code configuration, no custom dev needed",
  "Supports REST, SOAP, EDI, and flat-file formats",
];

export default function ProductsIntegrationPage() {
  const config = useSiteConfig();
  const primary = config.primaryColor;
  const accent = config.accentColor;
  const [selected, setSelected] = useState<ProductItem | null>(null);

  const { data: items = [], isLoading } = useQuery<ProductItem[]>({
    queryKey: ["product-items", "integration-suite"],
    queryFn: () => fetch("/api/public/product-items?category=integration-suite").then(r => r.json()),
  });

  return (
    <PublicLayout>
      <SEO
        title="Integration Suite — SAP, Marketplace, Payment & Logistics APIs | CtrlA Tech Solutions"
        description="13 integration products connecting SAP with marketplaces, ecommerce, logistics, payment gateways, WhatsApp, banking, e-invoicing, and GST from CtrlA Tech Solutions."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "Integration Suite — CtrlA Tech Solutions",
          description: "13 integration products connecting SAP with marketplaces, ecommerce, logistics, payment gateways, WhatsApp, banking, e-invoicing, and GST from CtrlA Tech Solutions.",
          url: window.location.href,
          publisher: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
        }}
      />

      <section className="relative overflow-hidden py-16 md:py-24 bg-gradient-to-br from-[#1A1F36] to-[#0d1225]">
        <div className="pointer-events-none absolute inset-0 opacity-10" style={{ backgroundImage: `radial-gradient(circle at 15% 50%, ${primary} 0%, transparent 45%), radial-gradient(circle at 85% 20%, #E84821 0%, transparent 45%)` }} />
        <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -24 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6 }} className="flex-1">
              <Link href="/products" className="inline-flex items-center gap-1.5 text-white/50 text-sm mb-6 hover:text-white/80 transition-colors">← Products</Link>
              <div className="inline-flex items-center gap-2 mb-4 px-3 py-1 rounded-full bg-[#D4920C]/20 text-[#D4920C]">
                <Plug size={14} />
                <span className="text-xs font-bold uppercase tracking-widest">13 Products</span>
              </div>
              <h1 className="text-4xl sm:text-5xl font-bold text-white leading-tight mb-5">
                Integration Suite<br /><span style={{ color: primary }}>Connect Everything</span>
              </h1>
              <p className="text-white/70 text-lg leading-relaxed mb-8 max-w-xl">
                Pre-built, production-ready connectors linking SAP with marketplaces, logistics, payments, government portals, and communication channels.
              </p>
              <div className="grid sm:grid-cols-2 gap-2 mb-8">
                {benefits.map(b => (
                  <div key={b} className="flex items-center gap-2 text-sm text-white/70">
                    <CheckCircle2 size={15} style={{ color: primary }} className="flex-shrink-0" />
                    {b}
                  </div>
                ))}
              </div>
              <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-lg font-bold text-white shadow-lg transition-all hover:-translate-y-0.5" style={{ backgroundColor: primary }}>
                See Integration Demo <ArrowRight size={16} />
              </Link>
            </motion.div>
            <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.1 }} className="flex-shrink-0 w-full lg:w-[340px]">
              <div className="rounded-2xl overflow-hidden shadow-2xl border border-white/10">
                <img src="https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=700&q=80" alt="Integration Suite" className="w-full h-[260px] object-cover" />
                <div className="bg-white/5 p-5">
                  <div className="text-white font-bold mb-1">50+ Pre-Built Connectors</div>
                  <div className="text-white/50 text-sm">Marketplaces, logistics, payments, and more</div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1 flex">
          <div className="flex-[3] bg-[#E84821]" /><div className="flex-[2]" style={{ backgroundColor: primary }} /><div className="flex-1 bg-[#3D4FA0]" />
        </div>
      </section>

      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-12 text-center">
            <div className="text-xs font-bold uppercase tracking-widest mb-3" style={{ color: primary }}>Full Product Range</div>
            <h2 className="text-3xl sm:text-4xl font-bold" style={{ color: accent }}>All 13 Integration Products</h2>
            <p className="text-gray-400 text-sm mt-2">Click any product to learn more</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {isLoading
              ? Array.from({ length: 6 }).map((_, i) => <div key={i} className="rounded-2xl border border-gray-100 bg-gray-50 animate-pulse h-36" />)
              : items.map((p, i) => {
                  const Icon = getIcon(p.iconName);
                  return (
                    <motion.div key={p.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-40px" }} transition={{ duration: 0.4, delay: i * 0.04 }}>
                      <button
                        onClick={() => setSelected(p)}
                        className="group flex flex-col h-full w-full text-left rounded-2xl border border-gray-100 p-6 hover:border-transparent hover:shadow-xl transition-all hover:-translate-y-0.5 bg-white cursor-pointer"
                      >
                        <div className="flex items-center gap-3 mb-3">
                          <div className="p-2 rounded-lg flex-shrink-0" style={{ backgroundColor: `${p.accentColor}15` }}>
                            <Icon size={18} style={{ color: p.accentColor }} />
                          </div>
                          <h3 className="font-bold text-gray-900 text-sm group-hover:text-[#D4920C] transition-colors leading-tight">{p.name}</h3>
                        </div>
                        <p className="text-gray-500 text-xs leading-relaxed flex-1">{p.shortDesc}</p>
                        <div className="mt-3 flex items-center gap-1 text-xs font-semibold" style={{ color: p.accentColor }}>
                          Learn more <ArrowRight size={12} className="group-hover:translate-x-0.5 transition-transform" />
                        </div>
                      </button>
                    </motion.div>
                  );
                })
            }
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50 border-t border-gray-100">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4" style={{ color: accent }}>Break Down Your Data Silos</h2>
          <p className="text-gray-500 mb-8">Let our integration architects map your systems and build a connected enterprise in weeks, not months.</p>
          <Link href="/contact" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-lg font-bold text-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5" style={{ backgroundColor: primary }}>
            Talk to Integration Expert <ArrowRight size={18} />
          </Link>
        </div>
      </section>

      {selected && <ProductItemModal open product={selected} onClose={() => setSelected(null)} />}
    </PublicLayout>
  );
}
