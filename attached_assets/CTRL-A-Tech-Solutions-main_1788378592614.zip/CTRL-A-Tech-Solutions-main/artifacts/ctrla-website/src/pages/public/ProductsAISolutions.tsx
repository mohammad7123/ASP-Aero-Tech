import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  ArrowRight, Brain, CheckCircle2, BarChart3, MessageSquare,
  TrendingUp, Package, FileText, Globe2, ShoppingCart,
  DollarSign, Truck, HeadphonesIcon, Zap, ChevronRight,
  Layers, Database, Eye, Cpu, Users, RefreshCw,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

/* ─── Why Choose AI ────────────────────────────────────────────── */
const WHY_AI = [
  "Automate repetitive business processes",
  "Reduce operational costs",
  "Improve productivity",
  "Make faster business decisions",
  "Predict future demand",
  "Improve inventory planning",
  "Enhance customer experience",
  "Generate business insights instantly",
  "Reduce manual errors",
  "Increase profitability",
];

/* ─── AI Expertise ─────────────────────────────────────────────── */
const AI_EXPERTISE = [
  "Generative AI",
  "Large Language Models (LLMs)",
  "Machine Learning",
  "Predictive Analytics",
  "Computer Vision",
  "OCR & Intelligent Document Processing",
  "AI Chatbots",
  "Business Intelligence",
  "Natural Language Processing (NLP)",
  "AI Integration with ERP & Business Applications",
];

/* ─── Enterprise integrations ──────────────────────────────────── */
const INTEGRATIONS = [
  "SAP Business One", "SAP S/4HANA", "WMS360", "OMS360",
  "TallyPrime", "Microsoft Dynamics", "Oracle ERP", "ERPNext",
  "Salesforce", "Zoho CRM", "Microsoft Power BI", "Custom ERP Solutions",
];

/* ─── All 11 AI products ────────────────────────────────────────── */
const AI_PRODUCTS = [
  {
    icon: BarChart3,
    title: "AI Analytics Assistant",
    subtitle: "Ask Questions. Get Instant Business Insights.",
    color: "#E84821",
    bg: "#FFF4F1",
    desc: "Transform your business data into meaningful insights using natural language. Ask \"What were my top-selling products this month?\" and get instant interactive charts, dashboards, and recommendations — no SQL needed.",
    examples: ["What were my top-selling products this month?", "Show inventory below reorder level.", "Which customers generated the highest revenue?", "Compare warehouse performance.", "Show pending purchase orders."],
    features: ["Natural Language Queries", "Interactive Dashboards", "AI Generated Charts", "KPI Monitoring", "Trend Analysis", "Executive Reporting", "Forecasting Insights", "Anomaly Detection"],
    tag: "Featured",
  },
  {
    icon: MessageSquare,
    title: "AI ERP Chatbot",
    subtitle: "Talk to Your ERP Like You Talk to Your Team",
    color: "#3D4FA0",
    bg: "#F0F3FF",
    desc: "Instead of navigating multiple ERP screens, employees simply ask questions or give commands. Check stock, create purchase orders, approve documents — all through natural conversation.",
    examples: ["Check Item Stock", "Create Purchase Order", "Show Sales Report", "Approve Documents", "Check Customer Balance", "Find Pending Deliveries"],
    features: ["SAP Business One", "SAP S/4HANA", "WMS360", "OMS360", "Custom ERP Solutions"],
    tag: "Featured",
  },
  {
    icon: TrendingUp,
    title: "AI Demand Forecasting",
    subtitle: "Predict Tomorrow's Demand Today",
    color: "#059669",
    bg: "#ECFDF5",
    desc: "AI analyzes historical sales, seasonality, purchasing patterns, promotions, and market trends to accurately predict future product demand — reducing stock shortages and excess inventory.",
    examples: [],
    features: ["Product Demand", "Sales Forecast", "Seasonal Trends", "Inventory Requirements", "Procurement Planning", "Production Planning"],
    tag: "Featured",
  },
  {
    icon: Package,
    title: "AI Warehouse Optimization",
    subtitle: "Build a Smarter Warehouse",
    color: "#D4920C",
    bg: "#FFFBEB",
    desc: "AI continuously analyzes inventory movement, order patterns, storage utilization, and workforce productivity to recommend operational improvements and maximize warehouse efficiency.",
    examples: [],
    features: ["Smart Bin Allocation", "Pick Path Optimization", "Labour Planning", "Warehouse Heat Maps", "Slotting Optimization", "Space Utilization", "Warehouse Performance Analytics"],
    tag: null,
  },
  {
    icon: FileText,
    title: "AI Invoice Processing",
    subtitle: "Zero-Touch Invoice Processing",
    color: "#7C3AED",
    bg: "#F5F3FF",
    desc: "Automate invoice processing using OCR and AI. The solution extracts invoice data, validates against purchase orders, identifies discrepancies, and automatically prepares transactions for ERP posting.",
    examples: [],
    features: ["OCR Extraction", "Invoice Matching", "Vendor Validation", "PO Matching", "Tax Validation", "Duplicate Invoice Detection", "ERP Integration"],
    tag: null,
  },
  {
    icon: Eye,
    title: "AI Document Intelligence",
    subtitle: "Convert Documents into Structured Business Data",
    color: "#0F766E",
    bg: "#F0FDFA",
    desc: "Extract valuable information from business documents without manual data entry. Supports purchase orders, sales orders, delivery challans, bills of lading, contracts, invoices, and compliance documents.",
    examples: [],
    features: ["OCR", "Intelligent Data Extraction", "Classification", "Document Search", "Auto Indexing", "Validation Rules"],
    tag: "Featured",
  },
  {
    icon: ShoppingCart,
    title: "AI Marketplace Analytics",
    subtitle: "Turn Marketplace Data into Business Intelligence",
    color: "#B45309",
    bg: "#FFF7ED",
    desc: "Monitor Amazon, Flipkart, Blinkit, Zepto, Shopify, WooCommerce, and Magento to gain insights into pricing, competition, customer behavior, and product performance.",
    examples: [],
    features: ["Competitor Pricing", "Product Performance", "Market Trends", "Revenue Analysis", "Customer Insights", "Sales Ranking"],
    tag: null,
  },
  {
    icon: DollarSign,
    title: "AI Sales Prediction",
    subtitle: "Predict Sales Before They Happen",
    color: "#DC2626",
    bg: "#FFF1F1",
    desc: "Use AI models to identify future sales opportunities, customer buying patterns, and revenue forecasts — enabling proactive sales strategy and target setting.",
    examples: [],
    features: ["Revenue Forecasting", "Customer Churn Prediction", "Cross-Selling Opportunities", "Upselling Opportunities", "Territory Performance", "Sales Target Prediction"],
    tag: null,
  },
  {
    icon: Truck,
    title: "AI Procurement Intelligence",
    subtitle: "Make Smarter Purchasing Decisions",
    color: "#0284C7",
    bg: "#F0F9FF",
    desc: "Optimize procurement using AI-powered analytics — evaluating vendor performance, risk, pricing benchmarks, and contract intelligence to improve purchasing decisions.",
    examples: [],
    features: ["Vendor Performance", "Supplier Risk Analysis", "Price Benchmarking", "Spend Analytics", "Purchase Recommendation", "Contract Intelligence"],
    tag: null,
  },
  {
    icon: Layers,
    title: "AI Inventory Optimization",
    subtitle: "The Right Inventory at the Right Time",
    color: "#7C3AED",
    bg: "#F5F3FF",
    desc: "Balance inventory investment while maintaining optimal stock availability. AI recommends safety stock levels, reorder points, and identifies dead stock, slow movers, and overstock situations.",
    examples: [],
    features: ["Safety Stock", "Reorder Point", "EOQ Calculation", "Dead Stock Detection", "Slow Moving Analysis", "Overstock Alerts", "Stock Optimization"],
    tag: null,
  },
  {
    icon: HeadphonesIcon,
    title: "AI Customer Support Assistant",
    subtitle: "24×7 Intelligent Customer Support",
    color: "#059669",
    bg: "#ECFDF5",
    desc: "Deliver faster customer service using AI-powered virtual assistants integrated with your business systems — on Website Chat, WhatsApp, Microsoft Teams, Email, and Mobile Apps.",
    examples: [],
    features: ["Order Tracking", "Delivery Status", "Return Requests", "Invoice Requests", "Product Information", "Complaint Registration", "FAQ Automation"],
    tag: null,
  },
];

const FEATURED = AI_PRODUCTS.filter(p => p.tag === "Featured");
const ALL = AI_PRODUCTS;

export default function ProductsAISolutionsPage() {
  const { primaryColor, accentColor } = useSiteConfig();
  const [expanded, setExpanded] = useState<string | null>(null);

  return (
    <PublicLayout>
      <SEO
        title="AI Solutions — 11 Enterprise AI Products | CtrlA Tech Solutions"
        description="11 AI-powered products: AI Analytics Assistant, ERP Chatbot, Demand Forecasting, Warehouse Optimization, Invoice Processing, Document Intelligence and more — integrated with SAP, WMS & ERP."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "AI Solutions — CtrlA Tech Solutions",
          description: "11 AI-powered products: AI Analytics Assistant, ERP Chatbot, Demand Forecasting, Warehouse Optimization, Invoice Processing, Document Intelligence and more — integrated with SAP, WMS & ERP.",
          url: window.location.href,
          publisher: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
        }}
      />

      {/* ── HERO ─────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden" style={{ background: "linear-gradient(140deg, #0d1225 0%, #1A1F36 55%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 1200 520" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="970" cy="260" r="340" stroke="#3D4FA0" strokeWidth="0.8" strokeDasharray="12 8"/>
          <circle cx="970" cy="260" r="200" stroke={primaryColor} strokeWidth="0.5" strokeDasharray="6 10"/>
          <rect x="810" y="60" width="160" height="160" rx="22" stroke="#7C3AED" strokeWidth="0.6" strokeDasharray="8 6"/>
          <path d="M0 380 Q300 330 600 360 Q900 390 1200 350" stroke="white" strokeWidth="0.5" fill="none" strokeDasharray="7 7"/>
          {[[60,55],[190,290],[320,85],[220,195],[510,330],[640,110],[770,265],[400,200],[550,80]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-7 L2-2.5 L7-2.5 L3.5 2 L5 7 L0 4 L-5 7 L-3.5 2 L-7-2.5 L-2-2.5Z" fill="white" opacity="0.45"/>
            </g>
          ))}
        </svg>

        <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-22">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <Link href="/products" className="inline-flex items-center gap-1.5 text-white/40 text-xs mb-5 hover:text-white/70 transition-colors">← Products</Link>
              <div className="inline-flex items-center gap-2 mb-4 px-3 py-1.5 rounded-full border border-[#7C3AED]/40 bg-[#7C3AED]/12">
                <Brain size={13} className="text-[#7C3AED]"/>
                <span className="text-xs font-black uppercase tracking-widest text-[#7C3AED]">11 AI Products</span>
              </div>
              <h1 className="text-4xl sm:text-5xl font-black leading-[1.06] text-white mb-3">
                Transform Your Business<br/>
                <span style={{ color: primaryColor }}>with Intelligent</span><br/>
                <span className="text-white/80 text-3xl sm:text-4xl font-bold">AI Solutions</span>
              </h1>
              <div className="flex gap-2 my-5">
                <span className="h-1 w-12 rounded-full bg-[#E84821]"/>
                <span className="h-1 w-7 rounded-full" style={{ backgroundColor: primaryColor }}/>
                <span className="h-1 w-4 rounded-full bg-[#3D4FA0]"/>
              </div>
              <p className="text-gray-300 text-sm leading-relaxed mb-3 max-w-lg">
                Artificial Intelligence is reshaping the way businesses operate. We develop enterprise-grade AI solutions that automate repetitive tasks, improve decision-making, optimize business processes, and unlock valuable insights from your data.
              </p>
              <p className="text-gray-400 text-sm leading-relaxed mb-8 max-w-lg">
                Our AI-powered solutions seamlessly integrate with <strong className="text-white">SAP, WMS, OMS, CRM, and ERP platforms</strong> to create a truly intelligent enterprise.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 shadow-lg transition-all text-sm">
                  Schedule an AI Consultation <ArrowRight size={15}/>
                </Link>
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
                  Request a Live Demo <ChevronRight size={14}/>
                </Link>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.12 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10">
                <img
                  src="https://images.unsplash.com/photo-1677442135703-1787eea5ce01?auto=format&fit=crop&w=800&q=80"
                  alt="AI Solutions"
                  className="w-full h-64 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/80 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-2 h-2 rounded-full bg-violet-400 animate-pulse flex-shrink-0"/>
                    <span className="text-white text-xs font-semibold">Generative AI · LLMs · Machine Learning · Computer Vision</span>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3 mt-4">
                {[{ n: "11", label: "AI Products" }, { n: "SAP", label: "Native Integration" }, { n: "24×7", label: "AI Assistance" }].map(s => (
                  <div key={s.label} className="bg-white/5 border border-white/10 rounded-xl p-3 text-center">
                    <div className="text-xl font-black text-white">{s.n}</div>
                    <div className="text-white/50 text-xs mt-0.5">{s.label}</div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
        <div className="h-1 flex">
          <div className="flex-[3] bg-[#E84821]"/><div className="flex-[2]" style={{ backgroundColor: primaryColor }}/><div className="flex-1 bg-[#3D4FA0]"/>
        </div>
      </section>

      {/* ── WHY AI ───────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #F5F3FF 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 400" preserveAspectRatio="xMidYMid slice">
          {Array.from({length:12}).map((_,r)=>Array.from({length:26}).map((_,c)=>(
            <circle key={`${r}-${c}`} cx={c*35+17} cy={r*35+17} r="1.6" fill="#7C3AED"/>
          )))}
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-4">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why Choose AI Solutions?</span>
              </div>
              <h2 className="text-3xl font-bold mb-3" style={{ color: accentColor }}>
                AI is no longer a luxury —<br/>
                <span style={{ color: "#7C3AED" }}>it's a competitive advantage</span>
              </h2>
              <p className="text-gray-500 text-sm leading-relaxed mb-4">Our AI platform helps organizations work smarter, faster, and more efficiently — integrating seamlessly with the business systems you already use.</p>
              <Link href="/contact" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-white text-sm shadow-lg hover:-translate-y-0.5 transition-all" style={{ backgroundColor: primaryColor }}>
                Request a Personalized AI Demo <ArrowRight size={14}/>
              </Link>
            </motion.div>
            <motion.div initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="grid grid-cols-2 gap-2">
                {WHY_AI.map((w, i) => (
                  <motion.div key={w} initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                    className="flex items-center gap-2 p-2.5 rounded-xl bg-white border border-gray-100 hover:border-[#7C3AED]/30 hover:bg-[#7C3AED]/3 transition-all">
                    <CheckCircle2 size={13} className="text-[#7C3AED] flex-shrink-0"/>
                    <span className="text-xs font-semibold text-gray-700">{w}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── FEATURED 4 ───────────────────────────────────────────────── */}
      <section className="py-16 md:py-20 bg-white border-t border-gray-100">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">AI Product Portfolio</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold" style={{ color: accentColor }}>
              AI Analytics Assistant · AI ERP Chatbot · AI Demand Forecasting · AI Document Intelligence
            </h2>
            <p className="text-gray-400 text-sm mt-2">View all 11 products below ↓</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {FEATURED.map((p, i) => {
              const Icon = p.icon;
              return (
                <motion.div key={p.title} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.09 }}
                  className="bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                  <div className="h-1.5 w-full" style={{ backgroundColor: p.color }}/>
                  <div className="p-5 flex flex-col h-full">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: p.bg }}>
                        <Icon size={18} style={{ color: p.color }}/>
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-900 text-sm leading-tight">{p.title}</h3>
                        <p className="text-[10px] font-semibold mt-0.5" style={{ color: p.color }}>{p.subtitle}</p>
                      </div>
                    </div>
                    <p className="text-gray-500 text-xs leading-relaxed mb-4 flex-1">{p.desc}</p>
                    {p.examples.length > 0 && (
                      <div className="mb-3 p-3 rounded-xl bg-gray-50 border border-gray-100 space-y-1">
                        <div className="text-[9px] font-bold uppercase tracking-wider text-gray-400 mb-1">Example queries</div>
                        {p.examples.slice(0, 3).map(ex => (
                          <div key={ex} className="flex items-start gap-1.5 text-[10px] text-gray-600 italic">
                            <span className="text-gray-300 font-bold mt-0.5 flex-shrink-0">"</span>{ex}"
                          </div>
                        ))}
                      </div>
                    )}
                    <div className="grid grid-cols-2 gap-1">
                      {p.features.slice(0, 6).map(f => (
                        <div key={f} className="flex items-center gap-1 text-[10px] text-gray-600">
                          <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: p.color }}/>
                          {f}
                        </div>
                      ))}
                    </div>
                    <Link href="/contact" className="mt-4 inline-flex items-center gap-1 text-xs font-semibold hover:gap-2 transition-all" style={{ color: p.color }}>
                      Request Demo <ArrowRight size={12}/>
                    </Link>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── ALL 11 PRODUCTS ──────────────────────────────────────────── */}
      <section className="py-16 md:py-20 border-t border-gray-100 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #EFF2FF 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 700" preserveAspectRatio="xMidYMid slice">
          {Array.from({length:20}).map((_,r)=>Array.from({length:26}).map((_,c)=>(
            <circle key={`${r}-${c}`} cx={c*35+17} cy={r*35+17} r="1.6" fill="#3D4FA0"/>
          )))}
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Full Product Portfolio</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold" style={{ color: accentColor }}>All 11 AI Solutions</h2>
            <p className="text-gray-400 text-sm mt-2">Click any card to expand details · Request a live demo for any product</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {ALL.map((p, i) => {
              const Icon = p.icon;
              const isOpen = expanded === p.title;
              return (
                <motion.div key={p.title} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: (i % 6) * 0.07 }}>
                  <div
                    className="bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl transition-all duration-300 cursor-pointer"
                    onClick={() => setExpanded(isOpen ? null : p.title)}
                  >
                    <div className="h-1.5 w-full" style={{ backgroundColor: p.color }}/>
                    <div className="p-5">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: p.bg }}>
                          <Icon size={18} style={{ color: p.color }}/>
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h3 className="font-bold text-gray-900 text-sm leading-tight">{p.title}</h3>
                            {p.tag && <span className="text-[9px] font-black uppercase px-1.5 py-0.5 rounded-full" style={{ backgroundColor: `${p.color}15`, color: p.color }}>{p.tag}</span>}
                          </div>
                          <p className="text-[10px] font-semibold mt-0.5" style={{ color: p.color }}>{p.subtitle}</p>
                        </div>
                        <ChevronRight size={14} className={`text-gray-300 flex-shrink-0 transition-transform duration-300 ${isOpen ? "rotate-90" : ""}`}/>
                      </div>
                      <p className="text-gray-500 text-xs leading-relaxed">{p.desc}</p>

                      {isOpen && (
                        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} className="mt-4 space-y-3 overflow-hidden">
                          {p.examples.length > 0 && (
                            <div className="p-3 rounded-xl bg-gray-50 border border-gray-100">
                              <div className="text-[9px] font-bold uppercase tracking-wider text-gray-400 mb-2">Example commands / queries</div>
                              <div className="space-y-1">
                                {p.examples.map(ex => (
                                  <div key={ex} className="text-[10px] text-gray-600 italic flex items-start gap-1">
                                    <span className="text-gray-300 font-bold flex-shrink-0">"</span>{ex}"
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                          <div>
                            <div className="text-[9px] font-bold uppercase tracking-wider text-gray-400 mb-2">
                              {p.title === "AI ERP Chatbot" ? "Supports" : "Capabilities & Features"}
                            </div>
                            <div className="grid grid-cols-2 gap-1.5">
                              {p.features.map(f => (
                                <div key={f} className="flex items-center gap-1.5 text-xs text-gray-600">
                                  <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: p.color }}/>
                                  {f}
                                </div>
                              ))}
                            </div>
                          </div>
                          <Link href="/contact"
                            onClick={e => e.stopPropagation()}
                            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg font-bold text-white text-xs shadow-md hover:-translate-y-0.5 transition-all"
                            style={{ backgroundColor: p.color }}>
                            Request Demo for {p.title} <ArrowRight size={12}/>
                          </Link>
                        </motion.div>
                      )}

                      {!isOpen && (
                        <div className="mt-3 flex items-center gap-1 text-xs font-semibold" style={{ color: p.color }}>
                          View details <ChevronRight size={12}/>
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── ENTERPRISE PLATFORM + AI EXPERTISE ──────────────────────── */}
      <section className="py-16 bg-white border-t border-gray-100">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-14">
            {/* Enterprise integrations */}
            <motion.div initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Enterprise AI Platform</span>
              </div>
              <h2 className="text-2xl font-bold mb-2" style={{ color: accentColor }}>Seamless integration with your existing systems</h2>
              <p className="text-gray-500 text-sm leading-relaxed mb-5">All AI products are designed to work independently or together as a unified intelligent business platform — integrating natively with:</p>
              <div className="grid grid-cols-3 gap-2">
                {INTEGRATIONS.map((int, i) => (
                  <motion.div key={int} initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}
                    className="flex items-center gap-2 p-2.5 rounded-xl bg-gray-50 border border-gray-100 hover:border-[#3D4FA0]/30 hover:bg-[#3D4FA0]/3 transition-all">
                    <Database size={11} className="text-[#3D4FA0] flex-shrink-0"/>
                    <span className="text-[10px] font-semibold text-gray-700">{int}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* AI expertise */}
            <motion.div initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Our AI Expertise</span>
              </div>
              <h2 className="text-2xl font-bold mb-2" style={{ color: accentColor }}>Enterprise software meets cutting-edge AI</h2>
              <p className="text-gray-500 text-sm leading-relaxed mb-5">We combine deep ERP & domain expertise with the latest AI technologies to build solutions that deliver measurable business value.</p>
              <div className="space-y-2.5">
                {AI_EXPERTISE.map((e, i) => (
                  <motion.div key={e} initial={{ opacity: 0, x: 12 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.06 }}
                    className="flex items-center gap-3 p-3 rounded-xl bg-gray-50 border border-gray-100 hover:border-[#E84821]/30 hover:bg-[#E84821]/3 transition-all">
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-[#E84821]/10 flex-shrink-0">
                      <Cpu size={13} className="text-[#E84821]"/>
                    </div>
                    <span className="text-sm font-semibold text-gray-700">{e}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 900 280" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="820" cy="140" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          {[[80,50],[200,210],[370,60],[520,190]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-5 L2-2 L5-2 L3 2 L4 5 L0 3 L-4 5 L-3 2 L-5-2 L-2-2Z" fill="white" opacity="0.5"/>
            </g>
          ))}
        </svg>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <h2 className="text-3xl font-bold text-white mb-3">Ready to Build an Intelligent Enterprise?</h2>
          <p className="text-gray-400 text-sm mb-8 max-w-2xl mx-auto leading-relaxed">
            Whether you're looking to automate ERP processes, optimize inventory, improve customer service, or unlock powerful business insights — CtrlA Tech Solutions provides AI solutions that deliver measurable business value.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 transition-all text-sm shadow-xl">
              Request a Personalized AI Demo <ArrowRight size={15}/>
            </Link>
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
              Talk to Our AI Experts <ChevronRight size={14}/>
            </Link>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1 flex">
          <div className="flex-[3] bg-[#E84821]"/>
          <div className="flex-[2]" style={{ backgroundColor: primaryColor }}/>
          <div className="flex-1 bg-[#3D4FA0]"/>
        </div>
      </section>
    </PublicLayout>
  );
}
