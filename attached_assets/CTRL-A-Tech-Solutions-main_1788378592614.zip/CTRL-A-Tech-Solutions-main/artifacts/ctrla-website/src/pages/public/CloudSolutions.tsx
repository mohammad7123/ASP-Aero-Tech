import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  ArrowRight, Cloud, CheckCircle2, Server, Shield, Database,
  RefreshCw, BarChart3, Globe2, Zap, Lock, Settings,
  ChevronRight, ArrowUpRight, Layers, Wifi, HardDrive,
} from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

const CLOUD_SERVICES = [
  {
    icon: BarChart3,
    title: "Cloud Consulting & Strategy",
    color: "#E84821",
    bg: "#FFF4F1",
    desc: "Develop a cloud adoption roadmap aligned with your business goals, infrastructure, and future growth plans.",
    features: ["Cloud Readiness Assessment", "Technology Roadmap", "Cost-Benefit Analysis", "Migration Planning", "Architecture Design", "Governance Framework"],
  },
  {
    icon: RefreshCw,
    title: "Cloud Migration",
    color: "#3D4FA0",
    bg: "#F0F3FF",
    desc: "Seamlessly migrate applications, databases, ERP systems, and workloads from on-premise infrastructure to the cloud with minimal downtime.",
    features: ["Application Migration", "Database Migration", "ERP Cloud Migration", "Workload Assessment", "Cutover Planning", "Post-Migration Support"],
  },
  {
    icon: Server,
    title: "Cloud Infrastructure Design",
    color: "#D4920C",
    bg: "#FFFBEB",
    desc: "Design secure, highly available, and scalable cloud environments optimized for performance, reliability, and cost efficiency.",
    features: ["High Availability Architecture", "Network & VPC Design", "Load Balancing", "Auto-Scaling Setup", "Multi-Region Deployment", "Cost Optimisation"],
  },
  {
    icon: Settings,
    title: "Managed Cloud Services",
    color: "#059669",
    bg: "#ECFDF5",
    desc: "Our certified cloud engineers proactively monitor, maintain, optimize, and secure your cloud infrastructure 24×7.",
    features: ["24×7 NOC Monitoring", "Patch Management", "Performance Optimisation", "Capacity Planning", "Incident Response", "Monthly Reporting"],
  },
  {
    icon: HardDrive,
    title: "Backup & Disaster Recovery",
    color: "#7C3AED",
    bg: "#F5F3FF",
    desc: "Protect critical business data with automated backups, disaster recovery planning, and business continuity solutions.",
    features: ["Automated Daily Backups", "Geo-Redundant Storage", "Disaster Recovery Planning", "RTO/RPO Definition", "DR Drills & Testing", "Business Continuity"],
  },
  {
    icon: Shield,
    title: "Cloud Security",
    color: "#DC2626",
    bg: "#FFF1F1",
    desc: "Secure your cloud environment with identity management, encryption, firewall configuration, threat monitoring, and compliance best practices.",
    features: ["Identity & Access Management", "Data Encryption", "Firewall Configuration", "Threat Monitoring", "Compliance (ISO/SOC 2)", "Security Audits"],
  },
];

const AWS_SERVICES = ["EC2", "S3 Storage", "RDS", "Load Balancers", "Auto Scaling", "Virtual Private Cloud (VPC)", "Cloud Backup", "Disaster Recovery"];
const AZURE_SERVICES = ["Azure Virtual Machines", "Azure SQL", "Azure Storage", "Azure Active Directory", "Azure Backup", "Azure Kubernetes Service", "Azure Networking"];
const GCP_SERVICES = ["Compute Engine", "Cloud SQL", "Kubernetes Engine", "Cloud Storage", "BigQuery", "Cloud Functions", "AI & Machine Learning Services"];

const B1PLUS_BENEFITS = [
  "SAP Business One SQL & SAP HANA Hosting",
  "High Availability Infrastructure",
  "Automatic Backups",
  "Disaster Recovery",
  "Enterprise Security",
  "Performance Monitoring",
  "Secure Remote Access",
  "Affordable Monthly Subscription",
  "Managed Updates & Maintenance",
  "24×7 Technical Support",
];

const WHY_CLOUD = [
  "Reduce IT Infrastructure Costs",
  "Eliminate Server Maintenance",
  "Improve Business Continuity",
  "Access Systems from Anywhere",
  "Scale Resources On Demand",
  "Enhance Performance & Reliability",
  "Improve Disaster Recovery",
  "Strengthen Security & Compliance",
  "Pay Only for What You Use",
];

const WHY_CTRLA = [
  "Cloud Strategy & Architecture Consulting",
  "AWS, Azure & Google Cloud Expertise",
  "SAP Business One Cloud Specialists",
  "Cloud Migration & Modernization",
  "Infrastructure Monitoring",
  "Backup & Disaster Recovery",
  "Performance Optimization",
  "Managed Cloud Services",
  "24×7 Technical Support",
  "Secure & Cost-Effective Cloud Solutions",
];

export default function CloudSolutionsPage() {
  const { primaryColor, accentColor } = useSiteConfig();

  return (
    <PublicLayout>
      <SEO
        title="Cloud Solutions — AWS, Azure, GCP & SAP Cloud | CtrlA Tech Solutions"
        description="Secure, scalable cloud solutions: cloud migration, managed AWS/Azure/GCP infrastructure, backup & disaster recovery, cloud security, and B1Plus Cloud for SAP Business One."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: "Cloud Solutions",
          description: "Secure, scalable cloud solutions: cloud migration, managed AWS/Azure/GCP infrastructure, backup & disaster recovery, cloud security, and B1Plus Cloud for SAP Business One.",
          provider: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
          areaServed: ["IN", "GB"],
          serviceType: ["Cloud Migration", "Managed Cloud Services", "Cloud Security", "Backup & Disaster Recovery"],
          url: window.location.href,
        }}
      />

      {/* ── HERO ─────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden" style={{ background: "linear-gradient(140deg, #0d1225 0%, #1A1F36 55%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 1200 520" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="970" cy="260" r="340" stroke="#3D4FA0" strokeWidth="0.8" strokeDasharray="12 8"/>
          <circle cx="970" cy="260" r="200" stroke={primaryColor} strokeWidth="0.5" strokeDasharray="6 10"/>
          <rect x="810" y="60" width="160" height="160" rx="22" stroke="#059669" strokeWidth="0.6" strokeDasharray="8 6"/>
          <path d="M0 380 Q300 330 600 360 Q900 390 1200 350" stroke="white" strokeWidth="0.5" fill="none" strokeDasharray="7 7"/>
          {[[60,55],[190,290],[320,85],[220,195],[510,330],[640,110],[770,265]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-7 L2-2.5 L7-2.5 L3.5 2 L5 7 L0 4 L-5 7 L-3.5 2 L-7-2.5 L-2-2.5Z" fill="white" opacity="0.45"/>
            </g>
          ))}
        </svg>

        <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-22">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <Link href="/services" className="inline-flex items-center gap-1.5 text-white/40 text-xs mb-5 hover:text-white/70 transition-colors">← IT Services</Link>
              <div className="inline-flex items-center gap-2 mb-4 px-3 py-1.5 rounded-full border border-[#059669]/40 bg-[#059669]/12">
                <Cloud size={13} className="text-[#059669]"/>
                <span className="text-xs font-black uppercase tracking-widest text-[#059669]">Cloud Solutions</span>
              </div>
              <h1 className="text-4xl sm:text-5xl font-black leading-[1.06] text-white mb-3">
                Secure, Scalable &<br/>
                <span style={{ color: primaryColor }}>Future-Ready</span><br/>
                <span className="text-white/80 text-3xl sm:text-4xl font-bold">Cloud Infrastructure</span>
              </h1>
              <div className="flex gap-2 my-5">
                <span className="h-1 w-12 rounded-full bg-[#E84821]"/>
                <span className="h-1 w-7 rounded-full" style={{ backgroundColor: primaryColor }}/>
                <span className="h-1 w-4 rounded-full bg-[#3D4FA0]"/>
              </div>
              <p className="text-gray-300 text-sm leading-relaxed mb-3 max-w-lg">
                Transform your IT infrastructure with enterprise-grade cloud solutions designed for performance, security, and business continuity.
              </p>
              <p className="text-gray-400 text-sm leading-relaxed mb-8 max-w-lg">
                From cloud consulting and architecture design to migration, managed services, disaster recovery, and cloud security — we deliver <strong className="text-white">end-to-end cloud solutions</strong> tailored to your business objectives.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 shadow-lg transition-all text-sm">
                  Schedule a Cloud Assessment <ArrowRight size={15}/>
                </Link>
                <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
                  Talk to Our Cloud Experts <ChevronRight size={14}/>
                </Link>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.12 }}>
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10">
                <img
                  src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80"
                  alt="Cloud infrastructure"
                  className="w-full h-64 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/80 to-transparent"/>
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse flex-shrink-0"/>
                    <span className="text-white text-xs font-semibold">AWS · Azure · GCP · B1Plus Cloud</span>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3 mt-4">
                {[{ n: "100+", label: "Migrations" }, { n: "99.9%", label: "Uptime SLA" }, { n: "24×7", label: "NOC Support" }].map(s => (
                  <div key={s.label} className="bg-white/5 border border-white/10 rounded-xl p-3 text-center">
                    <div className="text-xl font-black text-white">{s.n}</div>
                    <div className="text-white/50 text-xs mt-0.5">{s.label}</div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
        <div className="h-1 flex">
          <div className="flex-[3] bg-[#E84821]"/><div className="flex-[2]" style={{ backgroundColor: primaryColor }}/><div className="flex-1 bg-[#3D4FA0]"/>
        </div>
      </section>

      {/* ── OUR CLOUD SERVICES ───────────────────────────────────────── */}
      <section className="py-16 md:py-20 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #ECFDF5 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 700" preserveAspectRatio="xMidYMid slice">
          {Array.from({length:20}).map((_,r)=>Array.from({length:26}).map((_,c)=>(
            <circle key={`${r}-${c}`} cx={c*35+17} cy={r*35+17} r="1.6" fill="#059669"/>
          )))}
        </svg>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Our Cloud Services</span>
              <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>End-to-end cloud services for every business need</h2>
            <p className="text-gray-500 text-sm mt-2 max-w-xl mx-auto">From strategy and migration to ongoing managed services and security — we handle your cloud from day one.</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {CLOUD_SERVICES.map((s, i) => {
              const Icon = s.icon;
              return (
                <motion.div key={s.title} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }}
                  className="bg-white rounded-2xl border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 overflow-hidden">
                  <div className="h-1.5 w-full" style={{ backgroundColor: s.color }}/>
                  <div className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: s.bg }}>
                        <Icon size={20} style={{ color: s.color }}/>
                      </div>
                      <h3 className="font-bold text-gray-900 text-sm leading-tight">{s.title}</h3>
                    </div>
                    <p className="text-gray-500 text-xs leading-relaxed mb-4">{s.desc}</p>
                    <div className="grid grid-cols-2 gap-1.5">
                      {s.features.map(f => (
                        <div key={f} className="flex items-center gap-1.5 text-xs text-gray-600">
                          <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: s.color }}/>
                          {f}
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── CLOUD PLATFORMS ──────────────────────────────────────────── */}
      <section className="py-16 md:py-20 bg-white border-t border-gray-100">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
              <span className="text-xs font-bold uppercase tracking-widest text-[#3D4FA0]">Cloud Platforms We Support</span>
              <span className="w-6 h-0.5 rounded bg-[#3D4FA0]"/>
            </div>
            <h2 className="text-3xl font-bold" style={{ color: accentColor }}>AWS, Azure, GCP & B1Plus Cloud</h2>
            <p className="text-gray-500 text-sm mt-2 max-w-xl mx-auto">We work across all major cloud platforms and our own purpose-built SAP cloud — B1Plus Cloud.</p>
          </div>

          <div className="grid lg:grid-cols-4 gap-5">
            {/* AWS */}
            <motion.div initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
              className="bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all">
              <div className="h-1.5 bg-[#FF9900]"/>
              <div className="p-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-[#FF9900]/10 flex-shrink-0">
                    <Cloud size={18} className="text-[#FF9900]"/>
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 text-sm">Amazon Web Services</h3>
                    <span className="text-xs text-[#FF9900] font-semibold">AWS</span>
                  </div>
                </div>
                <p className="text-gray-500 text-xs leading-relaxed mb-4">Build scalable and resilient cloud infrastructure using the world's leading cloud platform.</p>
                <div className="space-y-1.5">
                  {AWS_SERVICES.map(s => (
                    <div key={s} className="flex items-center gap-1.5 text-xs text-gray-600">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#FF9900] flex-shrink-0"/>
                      {s}
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Azure */}
            <motion.div initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.08 }}
              className="bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all">
              <div className="h-1.5 bg-[#0078D4]"/>
              <div className="p-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-[#0078D4]/10 flex-shrink-0">
                    <Cloud size={18} className="text-[#0078D4]"/>
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 text-sm">Microsoft Azure</h3>
                    <span className="text-xs text-[#0078D4] font-semibold">Azure</span>
                  </div>
                </div>
                <p className="text-gray-500 text-xs leading-relaxed mb-4">Leverage Microsoft's enterprise cloud ecosystem for business applications, hybrid infrastructure, and enterprise security.</p>
                <div className="space-y-1.5">
                  {AZURE_SERVICES.map(s => (
                    <div key={s} className="flex items-center gap-1.5 text-xs text-gray-600">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#0078D4] flex-shrink-0"/>
                      {s}
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* GCP */}
            <motion.div initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.12 }}
              className="bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all">
              <div className="h-1.5 bg-[#4285F4]"/>
              <div className="p-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-[#4285F4]/10 flex-shrink-0">
                    <Globe2 size={18} className="text-[#4285F4]"/>
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 text-sm">Google Cloud Platform</h3>
                    <span className="text-xs text-[#4285F4] font-semibold">GCP</span>
                  </div>
                </div>
                <p className="text-gray-500 text-xs leading-relaxed mb-4">Deploy modern applications with Google's high-performance cloud infrastructure, AI capabilities, and data analytics platform.</p>
                <div className="space-y-1.5">
                  {GCP_SERVICES.map(s => (
                    <div key={s} className="flex items-center gap-1.5 text-xs text-gray-600">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#4285F4] flex-shrink-0"/>
                      {s}
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* B1Plus Cloud — featured */}
            <motion.div initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.16 }}>
              <Link href="/b1plus-cloud"
                className="group flex flex-col h-full bg-gradient-to-br from-[#1A1F36] to-[#2D3561] rounded-2xl overflow-hidden hover:shadow-2xl hover:-translate-y-1 transition-all">
                <div className="h-1.5 bg-[#D4920C]"/>
                <div className="p-5 flex flex-col flex-1">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-[#D4920C]/20 flex-shrink-0">
                      <Server size={18} className="text-[#D4920C]"/>
                    </div>
                    <div>
                      <h3 className="font-bold text-white text-sm">B1Plus Cloud</h3>
                      <span className="text-xs text-[#D4920C] font-semibold">SAP-Ready Cloud</span>
                    </div>
                  </div>
                  <p className="text-white/70 text-xs leading-relaxed mb-4">Purpose-built cloud hosting for SAP Business One, delivering enterprise-grade performance, security, and reliability without managing physical servers.</p>
                  <div className="space-y-1.5 flex-1">
                    {B1PLUS_BENEFITS.slice(0, 6).map(s => (
                      <div key={s} className="flex items-center gap-1.5 text-xs text-white/70">
                        <CheckCircle2 size={11} className="text-[#D4920C] flex-shrink-0"/>
                        {s}
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 flex items-center gap-1.5 text-xs font-bold text-[#D4920C] group-hover:gap-2.5 transition-all">
                    Explore B1Plus Cloud <ArrowUpRight size={13}/>
                  </div>
                </div>
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── WHY MOVE TO CLOUD + WHY CTRLA ───────────────────────────── */}
      <section className="py-16 border-t border-gray-100 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #EFF2FF 100%)" }}>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-14">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-6 h-0.5 rounded bg-[#059669]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#059669]">Why Move to the Cloud?</span>
              </div>
              <h2 className="text-2xl font-bold mb-5" style={{ color: accentColor }}>Business benefits that matter</h2>
              <div className="grid sm:grid-cols-2 gap-2">
                {WHY_CLOUD.map((w, i) => (
                  <motion.div key={w} initial={{ opacity: 0, x: -10 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                    className="flex items-center gap-2 p-3 rounded-xl bg-white border border-gray-100 text-sm text-gray-700">
                    <CheckCircle2 size={13} className="text-[#059669] flex-shrink-0"/>
                    {w}
                  </motion.div>
                ))}
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <div className="inline-flex items-center gap-2 mb-5">
                <span className="w-6 h-0.5 rounded bg-[#E84821]"/>
                <span className="text-xs font-bold uppercase tracking-widest text-[#E84821]">Why CtrlA Tech Solutions?</span>
              </div>
              <h2 className="text-2xl font-bold mb-5" style={{ color: accentColor }}>Your trusted cloud partner</h2>
              <div className="space-y-2.5">
                {WHY_CTRLA.map((w, i) => (
                  <motion.div key={w} initial={{ opacity: 0, x: 12 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.06 }}
                    className="flex items-center gap-3 p-3 rounded-xl bg-white border border-gray-100 hover:border-[#E84821]/30 hover:bg-[#E84821]/3 transition-all">
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-[#E84821]/10 flex-shrink-0">
                      <CheckCircle2 size={14} className="text-[#E84821]"/>
                    </div>
                    <span className="text-sm font-semibold text-gray-700">{w}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────── */}
      <section className="py-14 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        <svg className="absolute inset-0 w-full h-full opacity-[0.07]" viewBox="0 0 900 280" fill="none" preserveAspectRatio="xMidYMid slice">
          <circle cx="820" cy="140" r="200" stroke="white" strokeWidth="0.5" strokeDasharray="6 6"/>
          {[[80,50],[200,210],[370,60],[520,190]].map(([cx,cy],i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-5 L2-2 L5-2 L3 2 L4 5 L0 3 L-4 5 L-3 2 L-5-2 L-2-2Z" fill="white" opacity="0.5"/>
            </g>
          ))}
        </svg>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <h2 className="text-3xl font-bold text-white mb-3">Empower Your Business with the Cloud</h2>
          <p className="text-gray-400 text-sm mb-8 max-w-2xl mx-auto leading-relaxed">
            Whether you're planning your first cloud migration, hosting SAP Business One, modernizing applications, or building a cloud-native infrastructure — CtrlA Tech Solutions provides the expertise and managed services to help your business innovate with confidence.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/contact" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold text-white bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 transition-all text-sm shadow-xl">
              Request a Free Cloud Consultation <ArrowRight size={15}/>
            </Link>
            <Link href="/b1plus-cloud" className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold border border-white/20 text-white hover:bg-white/8 transition-all text-sm">
              Explore B1Plus Cloud <ChevronRight size={14}/>
            </Link>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1 flex">
          <div className="flex-[3] bg-[#E84821]"/>
          <div className="flex-[2]" style={{ backgroundColor: primaryColor }}/>
          <div className="flex-1 bg-[#3D4FA0]"/>
        </div>
      </section>
    </PublicLayout>
  );
}
