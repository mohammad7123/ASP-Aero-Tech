import { useRoute } from "wouter";
import PublicLayout from "@/components/public/PublicLayout";
import { useGetPublicPage } from "@/lib/apiClient";
import { SEO } from "@/components/SEO";

export default function DynamicPage() {
  const [, params] = useRoute("/:slug");
  const slug = params?.slug ?? "";
  const { data: page, isLoading, isError } = useGetPublicPage(slug);

  if (slug === "admin" || slug === "api") return null;

  return (
    <PublicLayout>
      {page && (
        <SEO
          title={page.metaTitle ?? page.title}
          description={page.metaDescription ?? undefined}
          jsonLd={{
            "@context": "https://schema.org",
            "@type": "WebPage",
            name: page.title,
            description: page.metaDescription ?? undefined,
            url: window.location.href,
            dateModified: page.updatedAt ?? undefined,
            publisher: {
              "@type": "Organization",
              name: "CtrlA Tech Solutions",
            },
          }}
        />
      )}
      {isLoading && (
        <div className="max-w-4xl mx-auto px-4 py-24 space-y-4 animate-pulse">
          <div className="h-12 bg-gray-200 rounded w-1/2" />
          <div className="h-4 bg-gray-100 rounded" />
          <div className="h-4 bg-gray-100 rounded w-5/6" />
        </div>
      )}
      {isError && (
        <>
          <SEO title="Page Not Found" noindex={true} />
          <div className="text-center py-24 text-gray-400">
            <p className="text-xl">Page not found.</p>
          </div>
        </>
      )}
      {page && (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <h1 className="text-4xl font-bold text-[#1C1917] mb-8">{page.title}</h1>
          <div
            className="prose prose-lg max-w-none prose-headings:text-[#1C1917] prose-a:text-[#E84821]"
            dangerouslySetInnerHTML={{ __html: page.content }}
          />
        </div>
      )}
    </PublicLayout>
  );
}
