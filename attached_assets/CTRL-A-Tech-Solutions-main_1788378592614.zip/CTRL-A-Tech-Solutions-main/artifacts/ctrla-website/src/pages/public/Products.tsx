import { motion } from "framer-motion";
import { Link } from "wouter";
import { ArrowRight, Database, Briefcase, Brain, Cloud, Plug, CheckCircle2 } from "lucide-react";
import PublicLayout from "@/components/public/PublicLayout";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

const categories = [
  {
    icon: Database,
    title: "ERP Products",
    subtitle: "19 Products",
    desc: "Complete SAP Business One, S/4 HANA, and a rich ecosystem of SAP add-ons, mobility, dashboards, and industry-specific modules.",
    href: "/products/erp",
    accent: "#E84821",
    highlights: ["SAP Business One", "SAP S/4 HANA", "SAP Mobility Solutions", "SAP GST Solutions", "SAP Warehouse Automation"],
  },
  {
    icon: Briefcase,
    title: "Business Applications",
    subtitle: "14 Products",
    desc: "Purpose-built applications for ecommerce, WMS, OMS, HRMS, POS, fleet management, dealer portals and beyond.",
    href: "/products/business-apps",
    accent: "#D4920C",
    highlights: ["Ecommerce Platform", "WMS 360", "Order Management System", "HRMS", "Loyalty & Rewards Platform"],
  },
  {
    icon: Brain,
    title: "AI Solutions",
    subtitle: "11 Products",
    desc: "Next-generation AI tools for analytics, demand forecasting, invoice processing, warehouse optimisation, and intelligent customer support.",
    href: "/products/ai-solutions",
    accent: "#3D4FA0",
    highlights: ["AI Analytics Assistant", "AI ERP Chatbot", "AI Demand Forecasting", "AI Document Intelligence", "AI Sales Prediction"],
  },
  {
    icon: Cloud,
    title: "Cloud Platforms",
    subtitle: "8 Products",
    desc: "Managed cloud hosting on AWS and Azure, high availability infrastructure, backup & disaster recovery, and seamless cloud migration.",
    href: "/products/cloud-platforms",
    accent: "#E84821",
    highlights: ["B1PlusCloud", "Managed AWS Hosting", "Managed Azure Hosting", "High Availability Infrastructure", "Cloud Migration Services"],
  },
  {
    icon: Plug,
    title: "Integration Suite",
    subtitle: "13 Products",
    desc: "Pre-built connectors and APIs for marketplaces, ecommerce, logistics, payment gateways, WhatsApp, banking, e-invoicing, and GST.",
    href: "/products/integration-suite",
    accent: "#D4920C",
    highlights: ["SAP Integration Hub", "Marketplace Integration", "Payment Gateway Integration", "WhatsApp Integration", "GST Integration"],
  },
];

export default function ProductsPage() {
  const config = useSiteConfig();
  const primary = config.primaryColor;
  const accent = config.accentColor;

  return (
    <PublicLayout>
      <SEO
        title="Products"
        description="Explore CtrlA Tech Solutions' complete product portfolio — SAP ERP, Business Applications, AI Solutions, Cloud Platforms, and Integration Suite."
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "Products — CtrlA Tech Solutions",
          description: "Explore CtrlA Tech Solutions' complete product portfolio — SAP ERP, Business Applications, AI Solutions, Cloud Platforms, and Integration Suite.",
          url: window.location.href,
          publisher: { "@type": "Organization", name: "CtrlA Tech Solutions", url: window.location.origin },
          hasPart: categories.map(c => ({
            "@type": "Product",
            name: c.title,
            description: c.desc,
            url: `${window.location.origin}${c.href}`,
          })),
        }}
      />

      {/* Hero */}
      <section className="relative overflow-hidden py-20 md:py-28" style={{ backgroundColor: accent }}>
        <div className="pointer-events-none absolute inset-0 opacity-10" style={{ backgroundImage: `radial-gradient(circle at 20% 50%, ${primary} 0%, transparent 50%), radial-gradient(circle at 80% 20%, #E84821 0%, transparent 40%)` }} />
        <div className="relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="inline-flex items-center gap-2 mb-6 px-4 py-1.5 rounded-full bg-white/10 border border-white/20">
              <span className="flex gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#E84821]" />
                <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: primary }} />
                <span className="w-1.5 h-1.5 rounded-full bg-[#3D4FA0]" />
              </span>
              <span className="text-xs font-bold text-white/80 tracking-widest uppercase">Our Products</span>
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
              65+ Products Across<br /><span style={{ color: primary }}>5 Categories</span>
            </h1>
            <p className="text-white/70 text-lg max-w-2xl mx-auto leading-relaxed mb-8">
              From SAP ERP to AI-powered tools, cloud infrastructure to seamless integrations — everything your enterprise needs to grow.
            </p>
            <div className="flex flex-wrap gap-3 justify-center">
              <Link href="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-lg font-bold text-white shadow-lg transition-all hover:-translate-y-0.5" style={{ backgroundColor: primary }}>
                Talk to a Specialist <ArrowRight size={16} />
              </Link>
              <Link href="/services" className="inline-flex items-center gap-2 px-6 py-3 rounded-lg font-semibold border-2 border-white/20 text-white hover:border-white/50 transition-all">
                Our Services
              </Link>
            </div>
          </motion.div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1 flex">
          <div className="flex-[3] bg-[#E84821]" />
          <div className="flex-[2]" style={{ backgroundColor: primary }} />
          <div className="flex-1 bg-[#3D4FA0]" />
        </div>
      </section>

      {/* Category cards */}
      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <div className="text-xs font-bold uppercase tracking-widest mb-3" style={{ color: primary }}>Product Portfolio</div>
            <h2 className="text-3xl sm:text-4xl font-bold" style={{ color: accent }}>Choose Your Solution</h2>
            <div className="mt-4 flex justify-center gap-1.5">
              <div className="h-1 w-12 rounded-full bg-[#E84821]" />
              <div className="h-1 w-6 rounded-full" style={{ backgroundColor: primary }} />
              <div className="h-1 w-3 rounded-full bg-[#3D4FA0]" />
            </div>
          </div>

          <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
            {categories.map((cat, i) => {
              const Icon = cat.icon;
              return (
                <motion.div
                  key={cat.title}
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.45, delay: i * 0.07 }}
                >
                  <Link href={cat.href} className="group flex flex-col h-full rounded-2xl border border-gray-100 p-7 hover:border-transparent hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 bg-white">
                    <div className="flex items-start gap-4 mb-5">
                      <div className="p-3 rounded-xl flex-shrink-0" style={{ backgroundColor: `${cat.accent}15` }}>
                        <Icon size={24} style={{ color: cat.accent }} />
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-gray-900 group-hover:text-[#D4920C] transition-colors">{cat.title}</h3>
                        <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full" style={{ backgroundColor: `${cat.accent}15`, color: cat.accent }}>{cat.subtitle}</span>
                      </div>
                    </div>
                    <p className="text-gray-500 text-sm leading-relaxed mb-5 flex-1">{cat.desc}</p>
                    <ul className="space-y-1.5 mb-5">
                      {cat.highlights.map(h => (
                        <li key={h} className="flex items-center gap-2 text-sm text-gray-600">
                          <CheckCircle2 size={14} style={{ color: cat.accent }} className="flex-shrink-0" />
                          {h}
                        </li>
                      ))}
                    </ul>
                    <div className="flex items-center gap-1.5 text-sm font-bold transition-colors" style={{ color: cat.accent }}>
                      View All Products <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gray-50 border-t border-gray-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4" style={{ color: accent }}>Not Sure Which Product Fits?</h2>
          <p className="text-gray-500 mb-8">Our consultants will assess your needs and recommend the right combination of tools for your business.</p>
          <Link href="/contact" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-lg font-bold text-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5" style={{ backgroundColor: primary }}>
            Get Free Consultation <ArrowRight size={18} />
          </Link>
        </div>
      </section>
    </PublicLayout>
  );
}
