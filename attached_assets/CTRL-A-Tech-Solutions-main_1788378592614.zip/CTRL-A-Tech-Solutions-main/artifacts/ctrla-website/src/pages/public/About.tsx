import { useTranslation } from "react-i18next";
import PublicLayout from "@/components/public/PublicLayout";
import PageHero from "@/components/public/PageHero";
import { SEO } from "@/components/SEO";
import { useSiteConfig } from "@/contexts/SiteConfigContext";
import { useGetPublicPage } from "@/lib/apiClient";
import { usePageContent } from "@/lib/usePageContent";
import { Link } from "wouter";
import pratibhaImg from "@assets/bfb6413c-db9c-4198-aa82-ab4a321eaa5e_1779815465847.png";
import puneetImg from "@assets/2c55100f-63ab-407e-bd94-9546ec2b974b_1779815506837.png";
import placideImg from "@assets/ChatGPT_Image_May_28,_2026,_03_49_26_PM_1779965106070.png";

/* ─── Data ──────────────────────────────────────────────────────────────── */

type Member = {
  name: string;
  role: string;
  location?: string;
  bio?: string;
  bullets?: string[];
  accent: string;
  bg: string;
  avatarUrl?: string;
};

const LEADERS: Member[] = [
  {
    name: "Pratibha Kaushik",
    role: "Director & Founder",
    accent: "#E84821",
    bg: "#FFF4F1",
    avatarUrl: pratibhaImg,
    bullets: [
      "Visionary leadership with strategic business insight",
      "Expertise in Market Gap Analysis and business opportunity identification",
      "Human Resource Management and team coordination specialist",
      "Strong leadership in Marketing and Brand Development",
      "Digital Marketing Expert with experience in online campaigns and customer engagement",
      "Skilled in business coordination, administration, and process improvement",
    ],
  },
  {
    name: "Puneet M Kaushik",
    role: "CEO & Co-Founder",
    accent: "#3D4FA0",
    bg: "#F0F3FF",
    avatarUrl: puneetImg,
    bullets: [
      "SAP Certified Professional with extensive ERP consulting expertise",
      "20+ years of business consulting and technology leadership",
      "Successful delivery of enterprise projects with customer-centric approach",
      "Expertise in IT infrastructure, cloud solutions, AI-enabled systems, and automation",
      "Strong relationship management and stakeholder engagement skills",
      "Engineering background with Bachelor's and Master's qualifications",
      "Passionate about innovation, AI adoption, and emerging technologies",
    ],
  },
  {
    name: "Placide Ludiwa",
    role: "Director & CEO (UK)",
    location: "Based in UK",
    accent: "#0F766E",
    bg: "#F0FDFA",
    avatarUrl: placideImg,
    bullets: [
      "IT and Telecommunications Consulting",
      "Strategic Procurement and Supply Chain Advisory",
      "International Business Development and Market Expansion",
      "Enterprise Technology Solutions and Digital Transformation",
      "Client Relationship Management and Stakeholder Engagement",
      "Cross-border Project Management and Strategic Partnerships",
      "Technology-driven Business Growth and Operational Excellence",
    ],
  },
];

const TECHNICAL_PILLARS: Member[] = [
  {
    name: "Md Arslaan",
    role: "Head of Engineering and AI",
    bio: "Arslaan combines strong technical expertise with strategic problem-solving abilities to transform business requirements into scalable and future-ready technology solutions. His passion for Artificial Intelligence, automation, and modern software engineering enables organizations to accelerate innovation and maintain a competitive technological edge.",
    accent: "#D4920C",
    bg: "#FFFBEB",
  },
  {
    name: "Rajneesh Raja",
    role: "Infrastructure Head",
    bio: "Rajneesh plays a key role in ensuring that technology environments are future-ready, secure, and capable of supporting complex business operations. His strong technical acumen and solution-oriented mindset help organizations achieve operational efficiency, business continuity, and seamless system integration.",
    accent: "#059669",
    bg: "#F0FDF6",
  },
];

const STATS = [
  { value: "22+", label: "Years Combined Experience", color: "#E84821" },
  { value: "200+", label: "Clients Served", color: "#3D4FA0" },
  { value: "90%", label: "Customer Retention Rate", color: "#059669" },
  { value: "50+", label: "Expert Professionals", color: "#D4920C" },
];

const EXPERTISE = [
  {
    title: "SAP & ERP Solutions",
    desc: "End-to-end SAP consulting, implementation, and support for enterprise-grade business operations.",
    color: "#E84821",
    bg: "#FFF4F1",
    icon: (
      <svg viewBox="0 0 48 48" fill="none" className="w-10 h-10">
        <rect x="6" y="10" width="36" height="28" rx="5" stroke="#E84821" strokeWidth="2.5" strokeDasharray="4 2"/>
        <path d="M14 20h20M14 27h12" stroke="#E84821" strokeWidth="2.5" strokeLinecap="round"/>
        <circle cx="36" cy="27" r="3" fill="#E84821"/>
        <path d="M24 10V6M24 42v-4" stroke="#E84821" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    ),
  },
  {
    title: "AI & Automation",
    desc: "Intelligent automation, ML models, and AI-driven solutions to streamline operations and decisions.",
    color: "#3D4FA0",
    bg: "#F0F3FF",
    icon: (
      <svg viewBox="0 0 48 48" fill="none" className="w-10 h-10">
        <circle cx="24" cy="24" r="8" stroke="#3D4FA0" strokeWidth="2.5"/>
        <path d="M24 8v4M24 36v4M8 24h4M36 24h4" stroke="#3D4FA0" strokeWidth="2.5" strokeLinecap="round"/>
        <path d="M13.5 13.5l2.8 2.8M31.7 31.7l2.8 2.8M13.5 34.5l2.8-2.8M31.7 16.3l2.8-2.8" stroke="#3D4FA0" strokeWidth="2" strokeLinecap="round"/>
        <circle cx="24" cy="24" r="3" fill="#3D4FA0"/>
      </svg>
    ),
  },
  {
    title: "Cloud Computing",
    desc: "Cloud migration, architecture, and managed services for scalable and secure infrastructure.",
    color: "#0F766E",
    bg: "#F0FDFA",
    icon: (
      <svg viewBox="0 0 48 48" fill="none" className="w-10 h-10">
        <path d="M34 30a8 8 0 10-1-16 10 10 0 10-18 4 7 7 0 001 12h18z" stroke="#0F766E" strokeWidth="2.5" strokeLinejoin="round"/>
        <path d="M20 34v6M28 34v6M24 34v8" stroke="#0F766E" strokeWidth="2" strokeLinecap="round" strokeDasharray="2 2"/>
      </svg>
    ),
  },
  {
    title: "Digital Marketing",
    desc: "SEO, SEM, social media, and performance marketing to grow your brand and generate qualified leads.",
    color: "#D4920C",
    bg: "#FFFBEB",
    icon: (
      <svg viewBox="0 0 48 48" fill="none" className="w-10 h-10">
        <path d="M8 36l10-12 8 6 8-14 6 8" stroke="#D4920C" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
        <circle cx="40" cy="12" r="4" stroke="#D4920C" strokeWidth="2.5"/>
        <path d="M8 40h32" stroke="#D4920C" strokeWidth="2" strokeLinecap="round" strokeDasharray="3 3"/>
      </svg>
    ),
  },
  {
    title: "API & Integrations",
    desc: "Seamless system integrations, API development, and middleware to connect your technology ecosystem.",
    color: "#7C3AED",
    bg: "#F5F3FF",
    icon: (
      <svg viewBox="0 0 48 48" fill="none" className="w-10 h-10">
        <rect x="6" y="18" width="12" height="12" rx="3" stroke="#7C3AED" strokeWidth="2.5"/>
        <rect x="30" y="18" width="12" height="12" rx="3" stroke="#7C3AED" strokeWidth="2.5"/>
        <path d="M18 24h12" stroke="#7C3AED" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="3 2"/>
        <path d="M24 12v6M24 30v6" stroke="#7C3AED" strokeWidth="2" strokeLinecap="round"/>
        <circle cx="24" cy="10" r="3" fill="#7C3AED"/>
        <circle cx="24" cy="38" r="3" fill="#7C3AED"/>
      </svg>
    ),
  },
  {
    title: "Data & Analytics",
    desc: "Business intelligence, data analytics, and reporting dashboards to power informed decision-making.",
    color: "#059669",
    bg: "#F0FDF6",
    icon: (
      <svg viewBox="0 0 48 48" fill="none" className="w-10 h-10">
        <rect x="8" y="28" width="8" height="12" rx="2" fill="#059669" fillOpacity=".2" stroke="#059669" strokeWidth="2"/>
        <rect x="20" y="20" width="8" height="20" rx="2" fill="#059669" fillOpacity=".2" stroke="#059669" strokeWidth="2"/>
        <rect x="32" y="10" width="8" height="30" rx="2" fill="#059669" fillOpacity=".2" stroke="#059669" strokeWidth="2"/>
        <path d="M8 8h32" stroke="#059669" strokeWidth="2" strokeLinecap="round" strokeDasharray="3 3"/>
      </svg>
    ),
  },
];

const WHY_CHOOSE = [
  "22+ years of combined technology and consulting experience",
  "Customer-centric approach focused on delivering measurable business outcomes",
  "Expertise in digital transformation, enterprise applications, cloud technologies, and AI-driven automation",
  "Customized solutions designed around your business goals and operational needs",
  "Skilled team of experienced consultants, architects, developers, and digital marketing professionals",
  "End-to-end project execution — from consulting and implementation to support and continuous improvement",
  "Proven track record of delivering secure, scalable, and future-ready solutions",
  "90% customer retention driven by trust, quality, and long-term partnerships",
];

/* ─── Sub-components ─────────────────────────────────────────────────────── */

function TeamPhoto({ avatarUrl, name, accent }: { avatarUrl?: string; name: string; accent: string }) {
  if (!avatarUrl) {
    return (
      <div
        className="relative w-28 h-28 mx-auto rounded-full flex items-center justify-center border-4 shadow-md text-5xl font-black select-none"
        style={{ borderColor: accent, backgroundColor: accent + "18", color: accent }}
      >
        {name.charAt(0)}
      </div>
    );
  }
  return (
    <div
      className="relative w-28 h-28 mx-auto rounded-full overflow-hidden border-4 shadow-md"
      style={{ borderColor: accent }}
    >
      <img
        src={avatarUrl}
        alt={name}
        className="w-full h-full object-cover object-top"
        onError={(e) => {
          e.currentTarget.style.display = "none";
          const parent = e.currentTarget.parentElement;
          if (parent) {
            parent.style.background = accent + "22";
            parent.innerHTML = `<span style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:48px;font-weight:900;color:${accent}">${name.charAt(0)}</span>`;
          }
        }}
      />
    </div>
  );
}

function MemberCard({ member }: { member: Member }) {
  return (
    <div
      className="group relative rounded-3xl p-6 flex flex-col items-center text-center border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
      style={{ backgroundColor: member.bg }}
    >
      <div className="absolute top-0 left-0 right-0 h-1 rounded-t-3xl" style={{ backgroundColor: member.accent }} />
      <div className="mt-3 mb-4">
        <TeamPhoto avatarUrl={member.avatarUrl} name={member.name} accent={member.accent} />
      </div>
      <span
        className="inline-block px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider mb-1"
        style={{ backgroundColor: member.accent + "18", color: member.accent }}
      >
        {member.role}
      </span>
      {member.location && (
        <span className="text-[10px] text-gray-400 font-medium mb-2">{member.location}</span>
      )}
      <h3 className="text-lg font-bold text-gray-900 leading-tight mb-2">{member.name}</h3>
      {member.bio && <p className="text-xs text-gray-500 leading-relaxed mb-2">{member.bio}</p>}
      {member.bullets && member.bullets.length > 0 && (
        <ul className="text-left mt-1 space-y-1 w-full">
          {member.bullets.map((b, i) => (
            <li key={i} className="flex items-start gap-1.5 text-xs text-gray-500 leading-relaxed">
              <span className="mt-1 flex-shrink-0 w-1.5 h-1.5 rounded-full" style={{ backgroundColor: member.accent }} />
              {b}
            </li>
          ))}
        </ul>
      )}
      <svg className="absolute bottom-4 right-4 opacity-20" width="32" height="32" viewBox="0 0 32 32" fill="none">
        <circle cx="16" cy="16" r="14" stroke={member.accent} strokeWidth="2" strokeDasharray="3 3" />
        <circle cx="16" cy="16" r="6" fill={member.accent} />
      </svg>
    </div>
  );
}

function SectionLabel({ color, children }: { color: string; children: string }) {
  return (
    <div className="inline-flex items-center gap-2 mb-3">
      <span className="w-6 h-0.5 rounded" style={{ backgroundColor: color }} />
      <span className="text-xs font-bold uppercase tracking-widest" style={{ color }}>{children}</span>
      <span className="w-6 h-0.5 rounded" style={{ backgroundColor: color }} />
    </div>
  );
}

/* ─── Page ───────────────────────────────────────────────────────────────── */

export default function AboutPage() {
  const { t } = useTranslation();
  const config = useSiteConfig();
  const { data: cmsPage } = useGetPublicPage("about");
  const { field, blocks } = usePageContent("about");

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "AboutPage",
    name: `About ${config.siteName}`,
    url: typeof window !== "undefined" ? window.location.href : "",
    description: `Learn about ${config.siteName}, India's premier technology partner.`,
  };

  return (
    <PublicLayout>
      <SEO
        title={cmsPage?.metaTitle ?? "About Us"}
        description={cmsPage?.metaDescription ?? `Learn about ${config.siteName} — India's premier technology partner delivering innovative IT solutions.`}
        jsonLd={jsonLd}
      />

      <PageHero
        eyebrow={field("hero_eyebrow", t("about.eyebrow"))}
        title={<>About <span style={{ color: "#E84821" }}>{config.siteName}</span></>}
        subtitle={field("hero_subtitle", t("about.subtitle"))}
        heroImage={field("hero_image", "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1200&q=80")}
        heroImageAlt="IT professionals collaborating around laptops"
      />

      {/* ── Who We Are ──────────────────────────────────────────────────── */}
      <section className="py-12 bg-white relative overflow-hidden">
        {/* Background doodle: circuit lines */}
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 900 500" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">
          <path d="M0 120h200l40-40h120l40 40h200" stroke="#3D4FA0" strokeWidth="2"/>
          <circle cx="200" cy="120" r="6" fill="#3D4FA0"/>
          <circle cx="560" cy="120" r="6" fill="#3D4FA0"/>
          <path d="M0 300h100l30 30h140l30-30h200l40 40h160" stroke="#E84821" strokeWidth="2"/>
          <circle cx="100" cy="300" r="6" fill="#E84821"/>
          <circle cx="600" cy="340" r="6" fill="#E84821"/>
          <path d="M700 0v120l40 40v100" stroke="#059669" strokeWidth="2"/>
          <circle cx="700" cy="260" r="6" fill="#059669"/>
          <rect x="800" y="200" width="20" height="20" stroke="#D4920C" strokeWidth="2"/>
          <rect x="820" y="380" width="16" height="16" stroke="#D4920C" strokeWidth="2"/>
        </svg>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left — text */}
            <div>
              <SectionLabel color="#E84821">{t("about.whoWeAre")}</SectionLabel>
              <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6 leading-tight">
                {field("who_title", t("about.whoWeAreTitle"))}
              </h2>
              {blocks.who_para1 ? (
                <p className="text-gray-600 leading-relaxed mb-4">{blocks.who_para1}</p>
              ) : (
                <p className="text-gray-600 leading-relaxed mb-4">
                  <strong>CtrlA Tech Solutions Pvt. Ltd.</strong> is a leading Digital Transformation and Information Technology company dedicated to helping businesses innovate, automate, and grow through intelligent technology solutions. We combine business expertise with cutting-edge technologies to deliver solutions that improve operational efficiency, enhance customer experiences, and drive sustainable business growth.
                </p>
              )}
              {blocks.who_para2 ? (
                <p className="text-gray-600 leading-relaxed mb-4">{blocks.who_para2}</p>
              ) : (
                <p className="text-gray-600 leading-relaxed mb-4">
                  With over <strong>22 years of combined industry experience</strong>, our team has successfully delivered enterprise solutions for organizations ranging from emerging businesses to large enterprises — ensuring every project delivers measurable value.
                </p>
              )}
              {blocks.who_para3 ? (
                <p className="text-gray-600 leading-relaxed">{blocks.who_para3}</p>
              ) : (
                <p className="text-gray-600 leading-relaxed">
                  Innovation is at the heart of everything we do. We leverage modern technologies such as <strong>AI, Cloud Computing, Enterprise Mobility, Business Process Automation, API Integrations, and Data Analytics</strong> to help organizations streamline operations and make informed business decisions.
                </p>
              )}
            </div>

            {/* Right — stats grid */}
            <div className="grid grid-cols-2 gap-5">
              {STATS.map((s) => (
                <div key={s.label} className="relative rounded-2xl p-6 text-center shadow-sm border border-gray-100 overflow-hidden group hover:-translate-y-1 transition-transform duration-300">
                  {/* Doodle bg circle */}
                  <div className="absolute -top-6 -right-6 w-20 h-20 rounded-full opacity-10 transition-all group-hover:opacity-20" style={{ backgroundColor: s.color }} />
                  <div className="text-4xl font-black mb-1" style={{ color: s.color }}>{s.value}</div>
                  <div className="text-xs text-gray-500 font-medium leading-snug">{s.label}</div>
                  {/* tiny doodle underline */}
                  <svg className="mx-auto mt-2" width="30" height="6" viewBox="0 0 30 6">
                    <path d="M0 3 Q7 0 15 3 Q23 6 30 3" stroke={s.color} strokeWidth="1.5" fill="none"/>
                  </svg>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Expertise Areas ─────────────────────────────────────────────── */}
      <section className="py-12 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #1A1F36 0%, #2D3561 100%)" }}>
        {/* Doodle stars scattered in background */}
        <svg className="absolute top-0 left-0 w-full h-full opacity-10" viewBox="0 0 900 500" fill="none" preserveAspectRatio="xMidYMid slice">
          {[
            [60,60],[200,120],[400,40],[700,80],[850,30],[100,300],[300,380],[550,320],[750,420],[880,350],
            [150,450],[450,200],[650,160],[820,250],[30,220],[480,450]
          ].map(([cx, cy], i) => (
            <g key={i} transform={`translate(${cx},${cy})`}>
              <path d="M0-8 L2-2 L8-2 L3 2 L5 8 L0 4 L-5 8 L-3 2 L-8-2 L-2-2Z" fill="white" opacity={0.5 + (i % 3) * 0.2}/>
            </g>
          ))}
          <circle cx="450" cy="250" r="180" stroke="white" strokeWidth="0.5" strokeDasharray="6 6" opacity="0.15"/>
          <circle cx="450" cy="250" r="280" stroke="white" strokeWidth="0.5" strokeDasharray="4 8" opacity="0.1"/>
        </svg>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <SectionLabel color="#D4920C">{t("services.eyebrow")}</SectionLabel>
            <h2 className="text-3xl sm:text-4xl font-bold text-white">{field("expertise_title", t("about.expertiseTitle"))}</h2>
            <p className="mt-3 text-gray-300 max-w-xl mx-auto">{field("expertise_subtitle", "Full-spectrum technology services designed to drive your business forward in the digital era.")}</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {EXPERTISE.map((item) => (
              <div
                key={item.title}
                className="group rounded-2xl p-6 border border-white/10 hover:border-white/30 transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl"
                style={{ backgroundColor: "rgba(255,255,255,0.06)", backdropFilter: "blur(6px)" }}
              >
                <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300" style={{ backgroundColor: item.bg }}>
                  {item.icon}
                </div>
                <h3 className="text-white font-bold text-lg mb-2">{item.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{item.desc}</p>
                {/* doodle underline */}
                <svg className="mt-4" width="40" height="6" viewBox="0 0 40 6">
                  <path d="M0 3 Q10 0 20 3 Q30 6 40 3" stroke={item.color} strokeWidth="2" fill="none"/>
                </svg>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Why Choose Us ───────────────────────────────────────────────── */}
      <section className="py-12 bg-white relative overflow-hidden">
        {/* Doodle: dotted grid pattern */}
        <svg className="absolute inset-0 w-full h-full opacity-[0.04]" viewBox="0 0 900 500" preserveAspectRatio="xMidYMid slice">
          {Array.from({ length: 18 }).map((_, row) =>
            Array.from({ length: 30 }).map((_, col) => (
              <circle key={`${row}-${col}`} cx={col * 30 + 15} cy={row * 30 + 15} r="2" fill="#3D4FA0"/>
            ))
          )}
        </svg>
        {/* large doodle shape top-right */}
        <svg className="absolute -top-10 -right-10 opacity-[0.06] w-80 h-80" viewBox="0 0 200 200" fill="none">
          <path d="M100 20 C140 20 180 60 180 100 C180 140 140 180 100 180 C60 180 20 140 20 100 C20 60 60 20 100 20Z" stroke="#E84821" strokeWidth="3" strokeDasharray="8 5"/>
          <path d="M100 50 C125 50 150 75 150 100 C150 125 125 150 100 150 C75 150 50 125 50 100 C50 75 75 50 100 50Z" stroke="#3D4FA0" strokeWidth="2" strokeDasharray="4 6"/>
        </svg>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <SectionLabel color="#3D4FA0">Our Advantage</SectionLabel>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">{field("why_title", "Why Choose CtrlA?")}</h2>
            <p className="mt-3 text-gray-500 max-w-xl mx-auto">{field("why_subtitle", "Eight reasons why businesses across India and beyond trust us as their long-term technology partner.")}</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {WHY_CHOOSE.map((point, i) => (
              <div
                key={i}
                className="group flex items-start gap-4 p-5 rounded-2xl border border-gray-100 hover:border-[#E84821]/20 hover:shadow-md transition-all duration-300 bg-white"
              >
                <div
                  className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold shadow-sm"
                  style={{ backgroundColor: ["#E84821","#3D4FA0","#0F766E","#D4920C","#7C3AED","#059669","#E84821","#3D4FA0"][i] }}
                >
                  {i + 1}
                </div>
                <p className="text-gray-700 text-sm leading-relaxed pt-0.5">{point}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Vision & Mission ────────────────────────────────────────────── */}
      <section className="py-12 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #F8F9FF 0%, #FFF4F1 100%)" }}>
        {/* Doodle: hand-drawn arrows and shapes */}
        <svg className="absolute bottom-0 left-0 opacity-[0.07] w-96 h-96" viewBox="0 0 200 200" fill="none">
          <path d="M20 180 Q60 140 100 160 Q140 180 160 140 Q180 100 160 60" stroke="#3D4FA0" strokeWidth="3" strokeLinecap="round"/>
          <path d="M155 55 L165 70 M155 55 L170 58" stroke="#3D4FA0" strokeWidth="2.5" strokeLinecap="round"/>
          <circle cx="50" cy="60" r="12" stroke="#E84821" strokeWidth="2" strokeDasharray="4 3"/>
          <circle cx="160" cy="170" r="8" stroke="#D4920C" strokeWidth="2"/>
        </svg>
        <svg className="absolute top-0 right-0 opacity-[0.07] w-72 h-72" viewBox="0 0 200 200" fill="none">
          <path d="M40 40 L80 20 L160 60 L180 140 L120 180 L40 160 L20 80 Z" stroke="#059669" strokeWidth="2.5" strokeDasharray="6 4"/>
          <path d="M100 80 L120 100 L100 120 L80 100 Z" fill="#059669" fillOpacity="0.15" stroke="#059669" strokeWidth="1.5"/>
        </svg>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <SectionLabel color="#059669">Our Direction</SectionLabel>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">Vision & Mission</h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Vision */}
            <div className="relative rounded-3xl p-10 overflow-hidden shadow-lg border border-white" style={{ background: "linear-gradient(135deg, #1A1F36, #2D3561)" }}>
              <svg className="absolute top-4 right-4 opacity-20 w-24 h-24" viewBox="0 0 100 100" fill="none">
                <circle cx="50" cy="50" r="45" stroke="white" strokeWidth="2" strokeDasharray="8 5"/>
                <path d="M50 20 L55 42 L78 42 L60 56 L66 78 L50 64 L34 78 L40 56 L22 42 L45 42Z" fill="white"/>
              </svg>
              <div className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center mb-6">
                <svg viewBox="0 0 32 32" fill="none" className="w-8 h-8">
                  <circle cx="16" cy="16" r="6" stroke="white" strokeWidth="2"/>
                  <path d="M16 4v4M16 24v4M4 16h4M24 16h4" stroke="white" strokeWidth="2" strokeLinecap="round"/>
                  <circle cx="16" cy="16" r="2" fill="white"/>
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">{field("vision_title", "Our Vision")}</h3>
              {blocks.vision_text ? (
                <p className="text-gray-300 leading-relaxed">{blocks.vision_text}</p>
              ) : (
                <p className="text-gray-300 leading-relaxed">
                  To become a globally trusted technology partner that empowers businesses through innovation, digital transformation, and intelligent solutions — enabling them to achieve <strong className="text-white">sustainable growth and long-term success</strong>.
                </p>
              )}
              <div className="mt-6 h-1 w-16 rounded-full bg-gradient-to-r from-[#E84821] to-[#D4920C]" />
            </div>

            {/* Mission */}
            <div className="relative rounded-3xl p-10 overflow-hidden shadow-lg border border-[#E84821]/10 bg-white">
              <svg className="absolute top-4 right-4 opacity-10 w-24 h-24" viewBox="0 0 100 100" fill="none">
                <path d="M50 10 L90 30 L90 70 L50 90 L10 70 L10 30Z" stroke="#E84821" strokeWidth="3" strokeDasharray="6 4"/>
                <circle cx="50" cy="50" r="20" stroke="#3D4FA0" strokeWidth="2"/>
              </svg>
              <div className="w-14 h-14 rounded-2xl bg-[#E84821]/10 flex items-center justify-center mb-6">
                <svg viewBox="0 0 32 32" fill="none" className="w-8 h-8">
                  <path d="M16 4L28 10v8c0 6.6-5.1 12.8-12 14C9.1 30.8 4 24.6 4 18v-8L16 4z" stroke="#E84821" strokeWidth="2" strokeLinejoin="round"/>
                  <path d="M11 16l3 3 7-7" stroke="#E84821" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">{field("mission_title", "Our Mission")}</h3>
              {blocks.mission_text ? (
                <p className="text-gray-600 leading-relaxed">{blocks.mission_text}</p>
              ) : (
                <p className="text-gray-600 leading-relaxed">
                  To deliver innovative technology and digital solutions that <strong>simplify business operations, accelerate growth, enhance customer experiences</strong>, and create lasting value through excellence, integrity, and continuous innovation.
                </p>
              )}
              <div className="mt-6 h-1 w-16 rounded-full bg-gradient-to-r from-[#E84821] to-[#3D4FA0]" />
            </div>
          </div>

          {/* Bottom tagline */}
          <div className="text-center mt-8 p-8 rounded-2xl border border-gray-200 bg-white/60 backdrop-blur-sm">
            {blocks.vm_tagline ? (
              <p className="text-gray-700 text-lg italic leading-relaxed max-w-3xl mx-auto">{blocks.vm_tagline}</p>
            ) : (
              <p className="text-gray-700 text-lg italic leading-relaxed max-w-3xl mx-auto">
                "At CtrlA Tech Solutions, we are committed to building lasting partnerships and delivering technology that enables businesses to <strong>adapt, innovate, and succeed</strong> in the digital era."
              </p>
            )}
          </div>
        </div>
      </section>

      {/* ── Leadership Team ─────────────────────────────────────────────── */}
      <section className="py-12 bg-white relative overflow-hidden">
        <svg className="absolute top-0 right-0 opacity-[0.04] w-96 h-96" viewBox="0 0 200 200" fill="none">
          <circle cx="100" cy="100" r="90" stroke="#E84821" strokeWidth="3" strokeDasharray="8 6"/>
          <circle cx="100" cy="100" r="60" stroke="#3D4FA0" strokeWidth="2" strokeDasharray="4 8"/>
          <circle cx="100" cy="100" r="30" stroke="#D4920C" strokeWidth="2"/>
        </svg>
        <svg className="absolute bottom-0 left-0 opacity-[0.04] w-72 h-72" viewBox="0 0 200 200" fill="none">
          <rect x="20" y="20" width="160" height="160" rx="40" stroke="#059669" strokeWidth="3" strokeDasharray="6 6"/>
          <rect x="50" y="50" width="100" height="100" rx="25" stroke="#E84821" strokeWidth="2" strokeDasharray="4 8"/>
        </svg>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-10">
            <SectionLabel color="#E84821">{t("about.leadersBadge")}</SectionLabel>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">{field("leaders_title", t("about.leadersTitle"))}</h2>
            <p className="mt-3 text-gray-500 max-w-xl mx-auto">{field("leaders_subtitle", "The visionary leaders behind CtrlA — combining global experience, strategic thinking, and deep industry expertise to drive world-class technology partnerships.")}</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {LEADERS.map((member) => (
              <MemberCard key={member.name} member={member} />
            ))}
          </div>

          {/* Technical Pillars */}
          <div className="mt-10">
            <div className="text-center mb-10">
              <SectionLabel color="#3D4FA0">Technical Excellence</SectionLabel>
              <h3 className="text-2xl sm:text-3xl font-bold text-gray-900">Technical Pillars</h3>
              <p className="mt-3 text-gray-500 max-w-lg mx-auto">The engineering and infrastructure leaders who keep CtrlA's technology edge sharp and our solutions scalable.</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 max-w-2xl mx-auto">
              {TECHNICAL_PILLARS.map((member) => (
                <MemberCard key={member.name} member={member} />
              ))}
            </div>
          </div>

          <div className="text-center mt-8">
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl text-sm font-bold text-white shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all"
              style={{ backgroundColor: "#E84821" }}
            >
              Connect with Our Team
            </Link>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
