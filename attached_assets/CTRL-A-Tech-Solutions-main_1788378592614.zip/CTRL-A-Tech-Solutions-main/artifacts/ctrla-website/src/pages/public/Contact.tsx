import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { Mail, Phone, MapPin, MessageSquare, Send, Handshake, Building2, Users } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "react-i18next";
import PublicLayout from "@/components/public/PublicLayout";
import PageHero from "@/components/public/PageHero";
import { useSiteConfig } from "@/contexts/SiteConfigContext";
import { usePageContent } from "@/lib/usePageContent";
import { SEO } from "@/components/SEO";
import CaptchaWidget from "@/components/public/CaptchaWidget";
import SuccessModal from "@/components/public/SuccessModal";

function isValidPhone(phone: string): boolean {
  if (!phone.trim()) return true;
  const digits = phone.replace(/[^0-9]/g, "");
  return /^[+]?[0-9\s\-().]{7,20}$/.test(phone.trim()) && digits.length >= 7;
}

const EMPLOYEE_OPTIONS = [
  "1-10 employees",
  "11-50 employees",
  "51-200 employees",
  "201-500 employees",
  "501-1,000 employees",
  ">1,000 employees",
];

const OFFICES = [
  {
    label: "India Office",
    lines: [
      "First Floor, Unit No. 1244,",
      "Landmark Cyber Park, Plus Offices,",
      "Sector 67, Gurugram, Haryana – 122102",
      "India",
    ],
  },
  {
    label: "UK Office",
    lines: [
      "PO Box 4385,",
      "15252213 – Companies House Default Address,",
      "Cardiff, CF14 8LH",
      "United Kingdom",
    ],
  },
];

const _BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";
type CmsPage = { metaTitle?: string | null; metaDescription?: string | null };
async function _fetchCmsPage(slug: string): Promise<CmsPage> {
  const res = await fetch(`${_BASE}/api/pages/${slug}`);
  if (!res.ok) return {};
  return res.json();
}

export default function ContactPage() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const config = useSiteConfig();
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
    companyName: "",
    employees: "",
  });
  const [loading, setLoading] = useState(false);
  const [captchaToken, setCaptchaToken] = useState("");
  const [captchaAnswer, setCaptchaAnswer] = useState("");
  const [captchaKey, setCaptchaKey] = useState(0);
  const [phoneError, setPhoneError] = useState("");
  const [employeesError, setEmployeesError] = useState("");
  const [captchaError, setCaptchaError] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);
  const { data: cmsPage } = useQuery<CmsPage>({ queryKey: ["pages", "contact"], queryFn: () => _fetchCmsPage("contact"), staleTime: 60_000 });
  const { field } = usePageContent("contact");

  const base = import.meta.env.BASE_URL.replace(/\/$/, "");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (form.phone && !isValidPhone(form.phone)) {
      setPhoneError("Please enter a valid phone number (digits, +, -, spaces; min 7 digits).");
      return;
    }
    if (form.companyName.trim() && !form.employees) {
      setEmployeesError("Please select the number of employees.");
      return;
    }
    setLoading(true);
    setCaptchaError("");
    setEmployeesError("");
    try {
      const res = await fetch(`${base}/api/public/contacts`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, captchaToken, captchaAnswer }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        const msg: string = body.error ?? "";
        if (msg.toLowerCase().includes("security check") || msg.toLowerCase().includes("captcha")) {
          setCaptchaError("Wrong answer — a new question has been loaded. Please try again.");
          setCaptchaToken("");
          setCaptchaAnswer("");
          setCaptchaKey(k => k + 1);
        } else {
          toast({ title: t("contact.errorTitle"), description: msg || t("contact.errorDesc"), variant: "destructive" });
        }
        return;
      }
      setForm({ name: "", email: "", phone: "", subject: "", message: "", companyName: "", employees: "" });
      setPhoneError("");
      setEmployeesError("");
      setCaptchaError("");
      setCaptchaToken("");
      setCaptchaAnswer("");
      setCaptchaKey(k => k + 1);
      setShowSuccess(true);
    } catch {
      toast({ title: t("contact.errorTitle"), description: t("contact.errorDesc"), variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }

  const contactItems = [
    ...(config.contactEmail  ? [{ icon: Mail,           label: "Email",     value: config.contactEmail,               href: `mailto:${config.contactEmail}` }]              : []),
    ...(config.contactPhone  ? [{ icon: Phone,          label: "India",     value: config.contactPhone,               href: `tel:${config.contactPhone}` }]                  : []),
    ...(config.contactPhone2 ? [{ icon: Phone,          label: "UK",        value: config.contactPhone2,              href: `tel:${config.contactPhone2}` }]                 : []),
    ...(config.whatsappNumber? [{ icon: MessageSquare,  label: "WhatsApp",  value: `+${config.whatsappNumber}`,       href: `https://wa.me/${config.whatsappNumber}` }]      : []),
  ];

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "ContactPage",
    name: "Contact CtrlA Tech Solutions",
    url: window.location.href,
    mainEntity: {
      "@type": "Organization",
      name: config.siteName,
      email: config.contactEmail,
      telephone: config.contactPhone,
    },
  };

  return (
    <PublicLayout>
      <SuccessModal
        open={showSuccess}
        onClose={() => setShowSuccess(false)}
        title="Thank You!"
        message="Thank you for contacting us! We have received your message and our team will get back to you as soon as possible."
      />
      <SEO
        title={cmsPage?.metaTitle ?? t("contact.eyebrow")}
        description={cmsPage?.metaDescription ?? "Get in touch with CtrlA Tech Solutions. We're ready to help with your technology needs across India and the UK."}
        jsonLd={jsonLd}
      />
      <PageHero
        eyebrow={field("hero_eyebrow", t("contact.eyebrow"))}
        title={<>{t("contact.titlePart1")}<span style={{ color: "#E84821" }}>{t("contact.titleHighlight")}</span></>}
        subtitle={field("hero_subtitle", t("contact.subtitle"))}
        heroImage={field("hero_image", "https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=1200&q=80")}
        heroImageAlt="Professional team ready to support your project"
      />

      {/* Become a Partner CTA banner */}
      <section className="py-5 border-b border-gray-100" style={{ background: "linear-gradient(90deg, #FFF4F1 0%, #FFF8EC 100%)" }}>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <p className="font-bold text-[#1A1F36] text-sm">Looking to resell our products?</p>
            <p className="text-gray-500 text-xs mt-0.5">Join our partner programme and unlock new revenue streams with WMS 360, OMS 360, SyncAI & more.</p>
          </div>
          <Link
            href="/become-a-partner"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-white text-sm bg-[#E84821] hover:opacity-90 hover:-translate-y-0.5 transition-all shadow-md flex-shrink-0"
          >
            <Handshake size={15} /> Become a Partner
          </Link>
        </div>
      </section>

      <section id="contact-form" className="py-16">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">

            {/* ── Left column: contact details + office addresses ── */}
            <div className="lg:col-span-1 space-y-5">

              {/* Dynamic contact items (email, phone, WhatsApp) */}
              {contactItems.map(({ icon: Icon, label, value, href }) => (
                <motion.div
                  key={label}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  className="flex items-start gap-4 p-5 bg-gray-50 rounded-xl"
                >
                  <div className="bg-[#E84821]/10 p-3 rounded-lg flex-shrink-0">
                    <Icon className="text-[#E84821]" size={20} />
                  </div>
                  <div>
                    <p className="font-semibold text-[#1A1F36] text-sm">{label}</p>
                    {href ? (
                      <a href={href} className="text-gray-600 text-sm mt-0.5 hover:text-[#D4920C] transition-colors">
                        {value}
                      </a>
                    ) : (
                      <p className="text-gray-600 text-sm mt-0.5">{value}</p>
                    )}
                  </div>
                </motion.div>
              ))}

              {/* Office addresses */}
              {OFFICES.map((office, i) => (
                <motion.div
                  key={office.label}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.08 }}
                  className="flex items-start gap-4 p-5 bg-gray-50 rounded-xl"
                >
                  <div className="bg-[#E84821]/10 p-3 rounded-lg flex-shrink-0">
                    <MapPin className="text-[#E84821]" size={20} />
                  </div>
                  <div>
                    <p className="font-semibold text-[#1A1F36] text-sm mb-1">{office.label}</p>
                    {office.lines.map((line, j) => (
                      <p key={j} className="text-gray-600 text-sm leading-relaxed">{line}</p>
                    ))}
                  </div>
                </motion.div>
              ))}

              {contactItems.length === 0 && (
                <p className="text-gray-400 text-sm">{t("contact.noContactInfo")}</p>
              )}
            </div>

            {/* ── Right column: Send Us a Message form ── */}
            <motion.div
              className="lg:col-span-2 bg-white border border-gray-100 rounded-2xl p-8 shadow-sm"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-2xl font-bold text-[#1A1F36] mb-6">{field("form_title", t("contact.formTitle"))}</h2>
              <form onSubmit={handleSubmit} className="space-y-5">

                {/* Name + Email */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">{t("contact.name")} *</label>
                    <input
                      required
                      value={form.name}
                      onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                      className="w-full border border-gray-200 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50 focus:border-[#E84821]"
                      placeholder={t("contact.namePlaceholder")}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">{t("contact.email")} *</label>
                    <input
                      required
                      type="email"
                      value={form.email}
                      onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
                      className="w-full border border-gray-200 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50 focus:border-[#E84821]"
                      placeholder={t("contact.emailPlaceholder")}
                    />
                  </div>
                </div>

                {/* Phone + Subject */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">{t("contact.phone")}</label>
                    <input
                      value={form.phone}
                      onChange={e => {
                        const val = e.target.value;
                        setForm(p => ({ ...p, phone: val }));
                        setPhoneError(val && !isValidPhone(val) ? "Enter a valid phone number (7–15 digits, may include +, -, spaces)." : "");
                      }}
                      className={`w-full border rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50 focus:border-[#E84821] ${phoneError ? "border-red-400" : "border-gray-200"}`}
                      placeholder={t("contact.phonePlaceholder")}
                    />
                    {phoneError && <p className="text-xs text-red-500 mt-1">{phoneError}</p>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">{t("contact.subject")}</label>
                    <input
                      value={form.subject}
                      onChange={e => setForm(p => ({ ...p, subject: e.target.value }))}
                      className="w-full border border-gray-200 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50 focus:border-[#E84821]"
                      placeholder={t("contact.subjectPlaceholder")}
                    />
                  </div>
                </div>

                {/* Company Name + Number of Employees */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      <span className="inline-flex items-center gap-1.5">
                        <Building2 size={14} className="text-gray-400" />
                        Company Name
                        <span className="text-gray-400 font-normal text-xs">(optional)</span>
                      </span>
                    </label>
                    <input
                      value={form.companyName}
                      onChange={e => {
                        const val = e.target.value;
                        setForm(p => ({ ...p, companyName: val }));
                        if (!val.trim()) {
                          setForm(p => ({ ...p, companyName: val, employees: "" }));
                          setEmployeesError("");
                        }
                      }}
                      className="w-full border border-gray-200 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50 focus:border-[#E84821]"
                      placeholder="Your company name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      <span className="inline-flex items-center gap-1.5">
                        <Users size={14} className="text-gray-400" />
                        Number of Employees
                        {form.companyName.trim() && <span className="text-[#E84821] text-xs font-semibold">*</span>}
                      </span>
                    </label>
                    <select
                      value={form.employees}
                      onChange={e => {
                        setForm(p => ({ ...p, employees: e.target.value }));
                        setEmployeesError("");
                      }}
                      className={`w-full border rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50 focus:border-[#E84821] bg-white ${
                        employeesError ? "border-red-400" : "border-gray-200"
                      } ${!form.employees ? "text-gray-400" : "text-gray-800"}`}
                    >
                      <option value="" disabled>Select company size</option>
                      {EMPLOYEE_OPTIONS.map(opt => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                    </select>
                    {employeesError && <p className="text-xs text-red-500 mt-1">{employeesError}</p>}
                  </div>
                </div>

                {/* Message */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t("contact.message")} *</label>
                  <textarea
                    required
                    rows={5}
                    value={form.message}
                    onChange={e => setForm(p => ({ ...p, message: e.target.value }))}
                    className="w-full border border-gray-200 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50 focus:border-[#E84821] resize-none"
                    placeholder={t("contact.messagePlaceholder")}
                  />
                </div>

                <CaptchaWidget
                  key={captchaKey}
                  onVerify={(tok, ans) => { setCaptchaToken(tok); setCaptchaAnswer(ans); setCaptchaError(""); }}
                  onExpire={() => { setCaptchaToken(""); setCaptchaAnswer(""); }}
                />
                {captchaError && (
                  <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                    {captchaError}
                  </p>
                )}
                <button
                  type="submit"
                  disabled={loading || !captchaAnswer}
                  className="w-full text-white py-4 rounded-xl font-bold hover:opacity-90 transition-all flex items-center justify-center gap-2 disabled:opacity-60 shadow-lg"
                  style={{ backgroundColor: config.primaryColor }}
                >
                  {loading ? t("contact.sending") : <><Send size={18} /> {t("contact.send")}</>}
                </button>
              </form>
            </motion.div>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
