import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Sparkles, Mail, Phone, MessageCircle, Activity, CheckCircle2, XCircle, Clock } from "lucide-react";
import { getToken } from "@/lib/auth";

async function api(path: string) {
  const res = await fetch(path, { headers: { Authorization: `Bearer ${getToken()}` } });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

type ChannelBucket = {
  channel: string;
  total: number;
  success: number;
  failed: number;
  providers: Record<string, { success: number; failed: number }>;
};

type UsageSummary = { days: number; since: string; channels: ChannelBucket[] };
type UsageEvent = {
  id: number; channel: string; provider: string; action: string;
  status: "success" | "failed"; units: number;
  meta: Record<string, unknown> | null; createdAt: string;
};

const CHANNEL_META: Record<string, { label: string; icon: React.ElementType; color: string }> = {
  ai:       { label: "AI Hits",       icon: Sparkles,      color: "#7c3aed" },
  email:    { label: "Emails",        icon: Mail,          color: "#E84821" },
  sms:      { label: "SMS",           icon: Phone,         color: "#16a34a" },
  whatsapp: { label: "WhatsApp",      icon: MessageCircle, color: "#25D366" },
};

export default function AdminUsage() {
  const [days, setDays] = useState(30);
  const [activeChannel, setActiveChannel] = useState<string>("ai");

  const { data: summary, isLoading } = useQuery<UsageSummary>({
    queryKey: ["admin-usage-summary", days],
    queryFn: () => api(`/api/admin/usage/summary?days=${days}`),
    refetchInterval: 30_000,
  });

  const { data: recent = [] } = useQuery<UsageEvent[]>({
    queryKey: ["admin-usage-recent", activeChannel],
    queryFn: () => api(`/api/admin/usage/recent?channel=${activeChannel}&limit=50`),
    refetchInterval: 30_000,
  });

  const channels = summary?.channels ?? [];

  return (
    <div>
      <div className="mb-6 flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-[#1C1917]">Usage & Analytics</h1>
          <p className="text-gray-500 text-sm mt-1">Track AI generations, emails, SMS and WhatsApp messages sent across the platform.</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-500">Range:</span>
          {[1, 7, 30, 90].map(d => (
            <button
              key={d}
              onClick={() => setDays(d)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                days === d ? "bg-[#1C1917] text-white border-[#1C1917]" : "bg-white text-gray-600 border-gray-200 hover:border-gray-300"
              }`}
            >
              {d === 1 ? "24h" : `${d}d`}
            </button>
          ))}
        </div>
      </div>

      {isLoading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-28 rounded-2xl bg-gray-100 animate-pulse" />)}
        </div>
      )}

      {!isLoading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {Object.keys(CHANNEL_META).map(key => {
            const meta = CHANNEL_META[key];
            const Icon = meta.icon;
            const bucket = channels.find(c => c.channel === key) ?? { channel: key, total: 0, success: 0, failed: 0, providers: {} };
            return (
              <button
                key={key}
                onClick={() => setActiveChannel(key)}
                className={`text-left bg-white rounded-2xl border p-5 transition-all hover:shadow-sm ${
                  activeChannel === key ? "border-[#1C1917] shadow-sm" : "border-gray-100"
                }`}
              >
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: meta.color + "1A", color: meta.color }}>
                    <Icon size={18} />
                  </div>
                  <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{meta.label}</div>
                </div>
                <div className="text-3xl font-bold text-[#1C1917] mb-1">{bucket.total.toLocaleString()}</div>
                <div className="flex items-center gap-3 text-xs">
                  <span className="text-emerald-600 flex items-center gap-1"><CheckCircle2 size={12} /> {bucket.success}</span>
                  <span className="text-red-500 flex items-center gap-1"><XCircle size={12} /> {bucket.failed}</span>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {/* Per-provider breakdown for selected channel */}
      <div className="bg-white rounded-2xl border border-gray-100 p-5 mb-6">
        <div className="flex items-center gap-2 mb-4">
          <Activity size={16} className="text-gray-500" />
          <h2 className="font-bold text-[#1C1917] text-sm uppercase tracking-wider">{CHANNEL_META[activeChannel]?.label} — by provider</h2>
        </div>
        {(() => {
          const bucket = channels.find(c => c.channel === activeChannel);
          const providers = bucket ? Object.entries(bucket.providers) : [];
          if (providers.length === 0) return <p className="text-sm text-gray-400">No usage recorded yet for this channel.</p>;
          return (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {providers.map(([prov, stats]) => {
                const total = stats.success + stats.failed;
                const pct = total > 0 ? Math.round((stats.success / total) * 100) : 100;
                return (
                  <div key={prov} className="border border-gray-100 rounded-xl p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-semibold text-[#1C1917] capitalize">{prov}</span>
                      <span className="text-xs text-gray-400">{total} total</span>
                    </div>
                    <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-500" style={{ width: `${pct}%` }} />
                    </div>
                    <div className="flex justify-between text-xs mt-2">
                      <span className="text-emerald-600">{stats.success} ok</span>
                      <span className="text-red-500">{stats.failed} failed</span>
                    </div>
                  </div>
                );
              })}
            </div>
          );
        })()}
      </div>

      {/* Recent events */}
      <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100 flex items-center gap-2">
          <Clock size={16} className="text-gray-500" />
          <h2 className="font-bold text-[#1C1917] text-sm uppercase tracking-wider">Recent {CHANNEL_META[activeChannel]?.label}</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-xs text-gray-500 uppercase">
              <tr>
                <th className="text-left px-5 py-2.5 font-semibold">When</th>
                <th className="text-left px-5 py-2.5 font-semibold">Provider</th>
                <th className="text-left px-5 py-2.5 font-semibold">Action</th>
                <th className="text-left px-5 py-2.5 font-semibold">Status</th>
                <th className="text-left px-5 py-2.5 font-semibold">Detail</th>
              </tr>
            </thead>
            <tbody>
              {recent.length === 0 && (
                <tr><td colSpan={5} className="px-5 py-6 text-center text-gray-400 text-sm">No events recorded.</td></tr>
              )}
              {recent.map(ev => (
                <tr key={ev.id} className="border-t border-gray-100">
                  <td className="px-5 py-2.5 text-gray-600 whitespace-nowrap">{new Date(ev.createdAt).toLocaleString()}</td>
                  <td className="px-5 py-2.5 text-gray-700 capitalize">{ev.provider || "—"}</td>
                  <td className="px-5 py-2.5 text-gray-700">{ev.action || "—"}</td>
                  <td className="px-5 py-2.5">
                    {ev.status === "success" ? (
                      <span className="inline-flex items-center gap-1 text-emerald-600 text-xs font-semibold"><CheckCircle2 size={12} /> success</span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-red-500 text-xs font-semibold"><XCircle size={12} /> failed</span>
                    )}
                  </td>
                  <td className="px-5 py-2.5 text-gray-500 text-xs font-mono max-w-md truncate">
                    {ev.meta && Object.keys(ev.meta).length > 0 ? JSON.stringify(ev.meta) : "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
