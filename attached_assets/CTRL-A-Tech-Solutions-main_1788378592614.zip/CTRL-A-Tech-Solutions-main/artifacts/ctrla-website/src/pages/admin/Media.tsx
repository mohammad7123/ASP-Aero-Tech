import { useState } from "react";
import { Plus, Trash2, Image, Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useListMedia, useCreateMedia, useDeleteMedia } from "@/lib/apiClient";
import { useQueryClient } from "@tanstack/react-query";

const base = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";

export default function AdminMedia() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const { data: media, isLoading } = useListMedia();
  const createMedia = useCreateMedia();
  const deleteMedia = useDeleteMedia();

  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ filename: "", objectPath: "", mimeType: "", altText: "" });
  const [uploading, setUploading] = useState(false);
  const [copied, setCopied] = useState<number | null>(null);

  async function handleUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const urlRes = await fetch(`${base}/api/storage/uploads/request-url`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${localStorage.getItem("ctrla_admin_token")}` },
        body: JSON.stringify({ name: file.name, size: file.size, contentType: file.type }),
      });
      if (!urlRes.ok) throw new Error("Failed to get upload URL");
      const { uploadURL, objectPath } = await urlRes.json();
      await fetch(uploadURL, { method: "PUT", body: file, headers: { "Content-Type": file.type } });
      await createMedia.mutateAsync({ data: { filename: file.name, objectPath, mimeType: file.type, size: file.size, altText: file.name } });
      qc.invalidateQueries();
      toast({ title: "File uploaded successfully" });
    } catch (err) {
      toast({ title: "Upload failed", variant: "destructive" });
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  }

  async function handleAddUrl(e: React.FormEvent) {
    e.preventDefault();
    await createMedia.mutateAsync({ data: { ...form, size: null, mimeType: form.mimeType || null, altText: form.altText || null } }, {
      onSuccess: () => { toast({ title: "Media added" }); qc.invalidateQueries(); setShowForm(false); setForm({ filename: "", objectPath: "", mimeType: "", altText: "" }); },
      onError: () => toast({ title: "Error", variant: "destructive" }),
    });
  }

  function buildMediaUrl(objectPath: string) {
    return objectPath.startsWith("/objects/")
      ? `${base}/api/storage/objects/${objectPath.replace(/^\/objects\//, "")}`
      : objectPath;
  }

  function copyPath(id: number, path: string) {
    navigator.clipboard.writeText(buildMediaUrl(path));
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this media?")) return;
    await deleteMedia.mutateAsync({ id }, { onSuccess: () => { toast({ title: "Deleted" }); qc.invalidateQueries(); } });
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-[#1C1917]">Media Library</h1>
          <p className="text-gray-500 text-sm mt-1">Manage images and files</p>
        </div>
        <div className="flex gap-3">
          <label className={`flex items-center gap-2 bg-[#E84821] text-[#1C1917] px-4 py-2.5 rounded-xl text-sm font-semibold cursor-pointer hover:bg-[#c73d1a] transition-all ${uploading ? "opacity-60 cursor-not-allowed" : ""}`}>
            <Plus size={16} /> {uploading ? "Uploading..." : "Upload File"}
            <input type="file" className="hidden" onChange={handleUpload} disabled={uploading} accept="image/*,video/*,application/pdf" />
          </label>
          <button onClick={() => setShowForm(true)} className="border border-gray-200 text-gray-600 px-4 py-2.5 rounded-xl text-sm font-semibold hover:bg-gray-50 transition-all">Add URL</button>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md">
            <div className="p-6 border-b"><h2 className="font-bold text-[#1C1917]">Add Media URL</h2></div>
            <form onSubmit={handleAddUrl} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Filename *</label>
                <input required value={form.filename} onChange={e => setForm(p => ({ ...p, filename: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">URL / Path *</label>
                <input required value={form.objectPath} onChange={e => setForm(p => ({ ...p, objectPath: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50" placeholder="https://..." />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Alt Text</label>
                <input value={form.altText} onChange={e => setForm(p => ({ ...p, altText: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50" />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="submit" className="bg-[#1C1917] text-white px-6 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#E84821] hover:text-[#1C1917] transition-all">Add</button>
                <button type="button" onClick={() => setShowForm(false)} className="border border-gray-200 text-gray-600 px-6 py-2.5 rounded-xl text-sm font-semibold hover:bg-gray-50 transition-all">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">{Array.from({ length: 8 }).map((_, i) => <div key={i} className="h-40 bg-gray-100 rounded-xl animate-pulse" />)}</div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {media?.map(m => (
            <div key={m.id} className="group relative bg-white border border-gray-100 rounded-xl overflow-hidden hover:shadow-md transition-all">
              <div className="aspect-square bg-gray-50 flex items-center justify-center">
                {m.mimeType?.startsWith("image/") ? (
                  <img
                    src={m.objectPath.startsWith("/objects/")
                      ? `${base}/api/storage/objects/${m.objectPath.replace(/^\/objects\//, "")}`
                      : m.objectPath}
                    alt={m.altText ?? m.filename}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <Image size={32} className="text-gray-300" />
                )}
              </div>
              <div className="p-2">
                <p className="text-xs text-gray-600 truncate font-medium">{m.filename}</p>
                <p className="text-xs text-gray-400">{m.size ? `${Math.round(m.size / 1024)} KB` : ""}</p>
              </div>
              <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onClick={() => copyPath(m.id, m.objectPath)} className="p-1.5 bg-white rounded-lg shadow-sm text-gray-500 hover:text-[#E84821]">
                  {copied === m.id ? <Check size={12} /> : <Copy size={12} />}
                </button>
                <button onClick={() => handleDelete(m.id)} className="p-1.5 bg-white rounded-lg shadow-sm text-gray-500 hover:text-red-500">
                  <Trash2 size={12} />
                </button>
              </div>
            </div>
          ))}
          {!media?.length && (
            <div className="col-span-full text-center py-16 text-gray-400">
              <Image size={32} className="mx-auto mb-3 opacity-30" />
              <p>No media files yet.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
