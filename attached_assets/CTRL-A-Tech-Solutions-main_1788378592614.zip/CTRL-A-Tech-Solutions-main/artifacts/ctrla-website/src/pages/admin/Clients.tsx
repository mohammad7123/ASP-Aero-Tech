import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Pencil, Trash2, Search, X, Upload, ExternalLink, Star, Building2, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { getToken } from "@/lib/auth";

type Client = {
  id: number;
  name: string;
  logoUrl: string | null;
  websiteUrl: string | null;
  industry: string | null;
  testimonial: string | null;
  testimonialPerson: string | null;
  testimonialRole: string | null;
  sortOrder: number;
  isActive: boolean;
};

const empty = {
  name: "", logoUrl: "", websiteUrl: "", industry: "",
  testimonial: "", testimonialPerson: "", testimonialRole: "",
  sortOrder: 0, isActive: true,
};

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

async function api(path: string, opts?: RequestInit) {
  const token = getToken();
  const res = await fetch(`${BASE}${path}`, {
    ...opts,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}`, ...(opts?.headers ?? {}) },
  });
  if (!res.ok) throw new Error(await res.text());
  if (res.status === 204) return null;
  return res.json();
}

export default function AdminClients() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [editItem, setEditItem] = useState<Client | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ ...empty });
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const { data: items = [], isLoading } = useQuery<Client[]>({
    queryKey: ["admin-clients"],
    queryFn: () => api("/api/admin/clients"),
  });

  const filtered = items.filter(it => !search || it.name.toLowerCase().includes(search.toLowerCase()));

  const saveMutation = useMutation({
    mutationFn: (data: typeof empty & { id?: number }) => {
      const { id, ...body } = data;
      const payload = { ...body, logoUrl: body.logoUrl || null, websiteUrl: body.websiteUrl || null };
      return id
        ? api(`/api/admin/clients/${id}`, { method: "PATCH", body: JSON.stringify(payload) })
        : api("/api/admin/clients", { method: "POST", body: JSON.stringify(payload) });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-clients"] });
      qc.invalidateQueries({ queryKey: ["public-clients"] });
      toast({ title: editItem ? "Client updated" : "Client added" });
      closeForm();
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => api(`/api/admin/clients/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-clients"] });
      toast({ title: "Client deleted" });
      setDeleteId(null);
    },
  });

  function openCreate() {
    setEditItem(null);
    setForm({ ...empty });
    setShowForm(true);
  }

  function openEdit(item: Client) {
    setEditItem(item);
    setForm({
      name: item.name, logoUrl: item.logoUrl ?? "", websiteUrl: item.websiteUrl ?? "",
      industry: item.industry ?? "", testimonial: item.testimonial ?? "",
      testimonialPerson: item.testimonialPerson ?? "", testimonialRole: item.testimonialRole ?? "",
      sortOrder: item.sortOrder, isActive: item.isActive,
    });
    setShowForm(true);
  }

  function closeForm() {
    setShowForm(false);
    setEditItem(null);
    setForm({ ...empty });
  }

  async function handleLogoUpload(file: File) {
    setUploading(true);
    try {
      const urlRes = await fetch(`${BASE}/api/storage/uploads/request-url`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken()}` },
        body: JSON.stringify({ name: file.name, size: file.size, contentType: file.type }),
      });
      if (!urlRes.ok) throw new Error("Failed to get upload URL");
      const { uploadURL, objectPath } = await urlRes.json();
      const putRes = await fetch(uploadURL, { method: "PUT", body: file, headers: { "Content-Type": file.type } });
      if (!putRes.ok) throw new Error("Upload failed");
      const logoUrl = `${BASE}/api/storage/objects/${objectPath.replace(/^\/objects\//, "")}`;
      setForm(f => ({ ...f, logoUrl }));
      toast({ title: "Logo uploaded successfully" });
    } catch (e: unknown) {
      toast({ title: "Upload failed", description: e instanceof Error ? e.message : "Unknown error", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  }

  const set = (k: string, v: unknown) => setForm(f => ({ ...f, [k]: v }));

  return (
    <div className="max-w-6xl">
      <div className="mb-6 flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Clients</h1>
          <p className="text-sm text-gray-500 mt-1">Manage client logos and testimonials shown on the public Clients page</p>
        </div>
        <button onClick={openCreate} className="flex items-center gap-2 px-4 py-2 bg-[#E84821] text-white rounded-lg text-sm font-semibold hover:bg-[#c73d1a] transition-colors">
          <Plus size={15} /> Add Client
        </button>
      </div>

      <div className="mb-4 relative">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input
          value={search} onChange={e => setSearch(e.target.value)}
          placeholder="Search clients…"
          className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/30"
        />
      </div>

      {isLoading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-40 bg-white rounded-xl border border-gray-100 animate-pulse" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-xl border border-gray-100 p-12 text-center">
          <Building2 size={40} className="mx-auto text-gray-300 mb-3" />
          <p className="text-gray-400">{search ? "No clients match your search" : "No clients yet. Add your first client logo and testimonial."}</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(client => (
            <div key={client.id} className="bg-white rounded-xl border border-gray-100 p-5 hover:shadow-md transition-shadow">
              <div className="flex items-start gap-3 mb-3">
                {client.logoUrl ? (
                  <img src={client.logoUrl} alt={client.name} className="w-14 h-14 rounded-lg object-contain border border-gray-100 bg-gray-50 flex-shrink-0" />
                ) : (
                  <div className="w-14 h-14 rounded-lg bg-[#3D4FA0]/10 flex items-center justify-center text-[#3D4FA0] font-bold text-xl flex-shrink-0">
                    {client.name[0]}
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <div className="font-bold text-gray-900 truncate">{client.name}</div>
                  {client.industry && <div className="text-xs text-[#D4920C] font-semibold mt-0.5">{client.industry}</div>}
                  {client.websiteUrl && (
                    <a href={client.websiteUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-gray-400 hover:text-[#3D4FA0] flex items-center gap-1 mt-0.5 truncate">
                      <ExternalLink size={10} /> {client.websiteUrl.replace(/^https?:\/\//, "")}
                    </a>
                  )}
                </div>
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full flex-shrink-0 ${client.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                  {client.isActive ? "Active" : "Hidden"}
                </span>
              </div>
              {client.testimonial && (
                <div className="bg-gray-50 rounded-lg p-3 mb-3">
                  <div className="flex gap-0.5 mb-1.5">
                    {Array.from({ length: 5 }).map((_, j) => <Star key={j} size={10} className="fill-current text-amber-400" />)}
                  </div>
                  <p className="text-xs text-gray-600 italic leading-relaxed line-clamp-2">"{client.testimonial}"</p>
                  {client.testimonialPerson && (
                    <div className="text-xs font-semibold text-gray-700 mt-1.5">— {client.testimonialPerson}{client.testimonialRole ? `, ${client.testimonialRole}` : ""}</div>
                  )}
                </div>
              )}
              <div className="flex gap-2 pt-2 border-t border-gray-50">
                <button onClick={() => openEdit(client)} className="flex-1 flex items-center justify-center gap-1.5 py-1.5 text-xs font-semibold text-gray-600 hover:text-[#D4920C] hover:bg-amber-50 rounded-lg transition-colors">
                  <Pencil size={12} /> Edit
                </button>
                <button onClick={() => setDeleteId(client.id)} className="flex-1 flex items-center justify-center gap-1.5 py-1.5 text-xs font-semibold text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                  <Trash2 size={12} /> Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="font-bold text-gray-900">{editItem ? "Edit Client" : "Add Client"}</h2>
              <button onClick={closeForm} className="p-1.5 hover:bg-gray-100 rounded-lg"><X size={16} /></button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">Company Name *</label>
                <input value={form.name} onChange={e => set("name", e.target.value)} placeholder="Acme Pvt Ltd" className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/30" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">Logo</label>
                <div className="flex gap-2">
                  <input value={form.logoUrl} onChange={e => set("logoUrl", e.target.value)} placeholder="https://... or upload below" className="flex-1 border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/30" />
                  <button
                    type="button"
                    onClick={() => fileRef.current?.click()}
                    disabled={uploading}
                    className="flex items-center gap-1.5 px-3 py-2 border border-gray-200 rounded-lg text-xs font-semibold text-gray-600 hover:bg-gray-50 disabled:opacity-50"
                  >
                    {uploading ? <div className="w-3 h-3 border-2 border-gray-400 border-t-transparent rounded-full animate-spin" /> : <Upload size={13} />}
                    Upload
                  </button>
                </div>
                <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={e => e.target.files?.[0] && handleLogoUpload(e.target.files[0])} />
                {form.logoUrl && (
                  <div className="mt-2 flex items-center gap-2">
                    <img src={form.logoUrl} alt="preview" className="w-12 h-12 rounded-lg object-contain border border-gray-100 bg-gray-50" />
                    <CheckCircle size={14} className="text-green-500" />
                    <span className="text-xs text-green-600 font-semibold">Logo ready</span>
                  </div>
                )}
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">Website URL</label>
                <input value={form.websiteUrl} onChange={e => set("websiteUrl", e.target.value)} placeholder="https://www.client.com" className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/30" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">Industry</label>
                <input value={form.industry} onChange={e => set("industry", e.target.value)} placeholder="Manufacturing, Retail, Healthcare…" className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/30" />
              </div>
              <div className="border-t border-gray-100 pt-4">
                <div className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">Testimonial (optional)</div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Quote</label>
                  <textarea value={form.testimonial} onChange={e => set("testimonial", e.target.value)} rows={3} placeholder="What did this client say about us?" className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/30 resize-none" />
                </div>
                <div className="grid grid-cols-2 gap-3 mt-3">
                  <div>
                    <label className="block text-xs font-semibold text-gray-600 mb-1">Person Name</label>
                    <input value={form.testimonialPerson} onChange={e => set("testimonialPerson", e.target.value)} placeholder="Rajesh Sharma" className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/30" />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-600 mb-1">Role / Title</label>
                    <input value={form.testimonialRole} onChange={e => set("testimonialRole", e.target.value)} placeholder="CEO, Acme Pvt Ltd" className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/30" />
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 border-t border-gray-100 pt-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Sort Order</label>
                  <input type="number" value={form.sortOrder} onChange={e => set("sortOrder", Number(e.target.value))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/30" />
                </div>
                <div className="flex items-end pb-1">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <div
                      onClick={() => set("isActive", !form.isActive)}
                      className={`relative w-10 h-5 rounded-full transition-colors ${form.isActive ? "bg-green-500" : "bg-gray-300"}`}
                    >
                      <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${form.isActive ? "translate-x-5" : "translate-x-0.5"}`} />
                    </div>
                    <span className="text-xs font-semibold text-gray-600">Active</span>
                  </label>
                </div>
              </div>
            </div>
            <div className="flex gap-3 px-6 py-4 border-t border-gray-100">
              <button onClick={closeForm} className="flex-1 py-2 border border-gray-200 rounded-lg text-sm font-semibold text-gray-600 hover:bg-gray-50">Cancel</button>
              <button
                onClick={() => saveMutation.mutate(editItem ? { ...form, id: editItem.id } : form)}
                disabled={saveMutation.isPending || !form.name}
                className="flex-1 py-2 bg-[#E84821] text-white rounded-lg text-sm font-semibold hover:bg-[#c73d1a] disabled:opacity-50"
              >
                {saveMutation.isPending ? "Saving…" : editItem ? "Save Changes" : "Add Client"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirm */}
      {deleteId !== null && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl p-6 max-w-sm w-full">
            <h3 className="font-bold text-gray-900 mb-2">Delete Client?</h3>
            <p className="text-sm text-gray-500 mb-6">This will remove the client and their testimonial from the public page.</p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteId(null)} className="flex-1 py-2 border border-gray-200 rounded-lg text-sm font-semibold text-gray-600">Cancel</button>
              <button onClick={() => deleteMutation.mutate(deleteId!)} disabled={deleteMutation.isPending} className="flex-1 py-2 bg-red-600 text-white rounded-lg text-sm font-semibold hover:bg-red-700 disabled:opacity-50">
                {deleteMutation.isPending ? "Deleting…" : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
