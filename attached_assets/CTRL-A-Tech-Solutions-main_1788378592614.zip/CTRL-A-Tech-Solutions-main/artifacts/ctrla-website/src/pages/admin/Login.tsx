import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Eye, EyeOff, Lock, User } from "lucide-react";
import { setToken, isAuthenticated } from "@/lib/auth";
import { useAdminLogin } from "@/lib/apiClient";
import CaptchaWidget from "@/components/public/CaptchaWidget";

export default function AdminLogin() {
  const [, setLocation] = useLocation();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState("");
  const [captchaToken, setCaptchaToken] = useState("");
  const [captchaAnswer, setCaptchaAnswer] = useState("");

  useEffect(() => {
    if (isAuthenticated()) setLocation("/admin");
  }, []);

  const login = useAdminLogin({
    mutation: {
      onSuccess: (data) => {
        setToken(data.token);
        setLocation("/admin");
      },
      onError: () => {
        setError("Invalid username or password");
      },
    },
  });

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    login.mutate({ data: { username, password, captchaToken, captchaAnswer } as any });
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1C1917] via-[#0d1533] to-[#1C1917] flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-1 mb-2">
            <span className="text-4xl font-bold text-[#E84821]">Ctrl</span>
            <span className="text-4xl font-bold text-white">A</span>
          </div>
          <p className="text-gray-400 text-sm">Admin Panel</p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-8 space-y-5"
        >
          <h1 className="text-white text-xl font-bold text-center mb-6">Sign In</h1>

          {error && (
            <div className="bg-red-500/10 border border-red-500/20 text-red-400 rounded-lg px-4 py-3 text-sm">
              {error}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1.5">Username</label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
              <input
                type="text"
                required
                value={username}
                onChange={e => setUsername(e.target.value)}
                className="w-full bg-white/5 border border-white/10 text-white rounded-xl pl-10 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50 focus:border-[#E84821] placeholder:text-gray-600"
                placeholder="admin"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1.5">Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
              <input
                type={showPass ? "text" : "password"}
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full bg-white/5 border border-white/10 text-white rounded-xl pl-10 pr-12 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50 focus:border-[#E84821] placeholder:text-gray-600"
                placeholder="••••••••"
              />
              <button
                type="button"
                onClick={() => setShowPass(!showPass)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
              >
                {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          <CaptchaWidget
            onVerify={(tok, ans) => { setCaptchaToken(tok); setCaptchaAnswer(ans); }}
            onExpire={() => { setCaptchaToken(""); setCaptchaAnswer(""); }}
            theme="dark"
          />

          <button
            type="submit"
            disabled={login.isPending || !captchaAnswer}
            className="w-full bg-[#E84821] text-[#1C1917] py-3 rounded-xl font-bold hover:bg-[#c73d1a] transition-all disabled:opacity-60"
          >
            {login.isPending ? "Signing in..." : "Sign In"}
          </button>

        </form>
      </div>
    </div>
  );
}
