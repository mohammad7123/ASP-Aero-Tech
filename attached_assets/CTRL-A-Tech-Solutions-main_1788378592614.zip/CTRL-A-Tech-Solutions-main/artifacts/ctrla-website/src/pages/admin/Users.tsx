import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Pencil, Trash2, Shield, User, X, Eye, EyeOff, Key } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { getToken, isAdmin } from "@/lib/auth";
import { useLocation } from "wouter";

type AdminUser = {
  id: number;
  username: string;
  email: string | null;
  role: string;
  createdAt: string;
};

type FormData = {
  username: string;
  email: string;
  password: string;
  role: "admin" | "user";
};

const emptyForm: FormData = { username: "", email: "", password: "", role: "user" };

async function apiFetch(path: string, opts?: RequestInit) {
  const token = getToken();
  const res = await fetch(path, {
    ...opts,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      ...(opts?.headers ?? {}),
    },
  });
  if (!res.ok) throw new Error(await res.text());
  if (res.status === 204) return null;
  return res.json();
}

export default function AdminUsers() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [showForm, setShowForm] = useState(false);
  const [editUser, setEditUser] = useState<AdminUser | null>(null);
  const [form, setForm] = useState<FormData>(emptyForm);
  const [showPass, setShowPass] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  if (!isAdmin()) {
    navigate("/admin");
    return null;
  }

  const { data: users = [], isLoading } = useQuery<AdminUser[]>({
    queryKey: ["admin-users"],
    queryFn: () => apiFetch("/api/admin/users"),
  });

  const saveMutation = useMutation({
    mutationFn: (data: FormData & { id?: number }) => {
      const { id, ...body } = data;
      const payload = { ...body, email: body.email || null };
      if (!payload.password && id) delete (payload as { password?: string }).password;
      return id
        ? apiFetch(`/api/admin/users/${id}`, { method: "PATCH", body: JSON.stringify(payload) })
        : apiFetch("/api/admin/users", { method: "POST", body: JSON.stringify(payload) });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-users"] });
      toast({ title: editUser ? "User updated" : "User created successfully" });
      closeForm();
    },
    onError: (e: Error) => {
      let msg = e.message;
      try { msg = JSON.parse(e.message).error ?? msg; } catch { /* */ }
      toast({ title: "Error", description: msg, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiFetch(`/api/admin/users/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-users"] });
      toast({ title: "User deleted" });
      setDeleteId(null);
    },
    onError: (e: Error) => {
      let msg = e.message;
      try { msg = JSON.parse(e.message).error ?? msg; } catch { /* */ }
      toast({ title: "Error", description: msg, variant: "destructive" });
    },
  });

  function openCreate() {
    setEditUser(null);
    setForm(emptyForm);
    setShowPass(false);
    setShowForm(true);
  }

  function openEdit(u: AdminUser) {
    setEditUser(u);
    setForm({ username: u.username, email: u.email ?? "", password: "", role: u.role as "admin" | "user" });
    setShowPass(false);
    setShowForm(true);
  }

  function closeForm() {
    setShowForm(false);
    setEditUser(null);
    setForm(emptyForm);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!editUser && !form.password) {
      toast({ title: "Password required for new users", variant: "destructive" });
      return;
    }
    saveMutation.mutate(editUser ? { ...form, id: editUser.id } : form);
  }

  return (
    <div className="max-w-4xl">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">User Management</h1>
          <p className="text-sm text-gray-500 mt-1">Create and manage admin panel users. Only Admins can access this section.</p>
        </div>
        <button
          onClick={openCreate}
          className="flex items-center gap-2 px-4 py-2 bg-[#D4920C] text-white rounded-lg font-semibold text-sm hover:bg-[#b87a09] transition-colors"
        >
          <Plus size={16} /> Add User
        </button>
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6 flex items-start gap-3">
        <Shield size={18} className="text-amber-600 flex-shrink-0 mt-0.5" />
        <div>
          <p className="text-amber-800 font-semibold text-sm">Role Permissions</p>
          <p className="text-amber-700 text-xs mt-0.5">
            <strong>Admin</strong> — Full access: create/edit/delete all content, manage users, view all sections.<br />
            <strong>User</strong> — Read & write access to content (pages, blog, products, media). Cannot manage users or delete critical data.
          </p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-gray-400">Loading users…</div>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left px-5 py-3 font-semibold text-gray-600">User</th>
                <th className="text-left px-5 py-3 font-semibold text-gray-600 hidden sm:table-cell">Email</th>
                <th className="text-left px-5 py-3 font-semibold text-gray-600">Role</th>
                <th className="text-left px-5 py-3 font-semibold text-gray-600 hidden md:table-cell">Created</th>
                <th className="text-right px-5 py-3 font-semibold text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors last:border-0">
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold ${u.role === "admin" ? "bg-[#E84821]" : "bg-[#3D4FA0]"}`}>
                        {u.username[0].toUpperCase()}
                      </div>
                      <span className="font-medium text-gray-900">{u.username}</span>
                    </div>
                  </td>
                  <td className="px-5 py-3 hidden sm:table-cell text-gray-500">{u.email ?? "—"}</td>
                  <td className="px-5 py-3">
                    {u.role === "admin" ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-[#E84821]/10 text-[#E84821]">
                        <Shield size={11} /> Admin
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-[#3D4FA0]/10 text-[#3D4FA0]">
                        <User size={11} /> User
                      </span>
                    )}
                  </td>
                  <td className="px-5 py-3 hidden md:table-cell text-gray-400 text-xs">
                    {new Date(u.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                  </td>
                  <td className="px-5 py-3 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button onClick={() => openEdit(u)} className="p-1.5 rounded-lg text-gray-400 hover:text-blue-600 hover:bg-blue-50 transition-colors" title="Edit">
                        <Pencil size={14} />
                      </button>
                      <button onClick={() => setDeleteId(u.id)} className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors" title="Delete">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="flex items-center justify-between p-6 border-b border-gray-100">
              <h2 className="text-lg font-bold text-gray-900">{editUser ? "Edit User" : "Create New User"}</h2>
              <button onClick={closeForm} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors">
                <X size={18} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">Username *</label>
                <input
                  required
                  value={form.username}
                  onChange={e => setForm(f => ({ ...f, username: e.target.value }))}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C]"
                  placeholder="e.g. john_doe"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">Email</label>
                <input
                  type="email"
                  value={form.email}
                  onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C]"
                  placeholder="user@company.com"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">
                  {editUser ? "New Password (leave blank to keep current)" : "Password *"}
                  <span className="ml-1 text-gray-400 font-normal">min 6 chars</span>
                </label>
                <div className="relative">
                  <Key size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    type={showPass ? "text" : "password"}
                    required={!editUser}
                    minLength={editUser ? undefined : 6}
                    value={form.password}
                    onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                    className="w-full border border-gray-200 rounded-lg pl-9 pr-10 py-2 text-sm outline-none focus:border-[#D4920C]"
                    placeholder={editUser ? "Leave blank to keep unchanged" : "Min 6 characters"}
                  />
                  <button type="button" onClick={() => setShowPass(p => !p)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                    {showPass ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-2">Role *</label>
                <div className="grid grid-cols-2 gap-3">
                  {(["admin", "user"] as const).map(r => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setForm(f => ({ ...f, role: r }))}
                      className={`flex items-center gap-2 p-3 rounded-xl border-2 transition-all text-sm font-semibold ${form.role === r ? r === "admin" ? "border-[#E84821] bg-[#E84821]/5 text-[#E84821]" : "border-[#3D4FA0] bg-[#3D4FA0]/5 text-[#3D4FA0]" : "border-gray-200 text-gray-500 hover:border-gray-300"}`}
                    >
                      {r === "admin" ? <Shield size={16} /> : <User size={16} />}
                      {r === "admin" ? "Admin" : "User"}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-gray-400 mt-1.5">
                  {form.role === "admin" ? "Full access including user management" : "Content read & write access, no user management"}
                </p>
              </div>
              <div className="flex justify-end gap-3 pt-2 border-t border-gray-100">
                <button type="button" onClick={closeForm} className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900 transition-colors">Cancel</button>
                <button
                  type="submit"
                  disabled={saveMutation.isPending}
                  className="px-5 py-2 bg-[#D4920C] text-white rounded-lg text-sm font-semibold hover:bg-[#b87a09] disabled:opacity-50 transition-colors"
                >
                  {saveMutation.isPending ? "Saving…" : editUser ? "Save Changes" : "Create User"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {deleteId !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-2">Delete User?</h3>
            <p className="text-sm text-gray-500 mb-6">This will permanently remove the user's admin panel access. This cannot be undone.</p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setDeleteId(null)} className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900 transition-colors">Cancel</button>
              <button
                onClick={() => deleteMutation.mutate(deleteId!)}
                disabled={deleteMutation.isPending}
                className="px-4 py-2 bg-red-500 text-white rounded-lg text-sm font-semibold hover:bg-red-600 disabled:opacity-50 transition-colors"
              >
                {deleteMutation.isPending ? "Deleting…" : "Delete User"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
