import React from "react";
import { FileText, BookOpen, MessageSquare, Image, Users, TrendingUp, Briefcase } from "lucide-react";
import { Link } from "wouter";
import { useGetDashboardStats } from "@/lib/apiClient";

function StatCard({ label, value, icon: Icon, href, color }: {
  label: string;
  value: number;
  icon: React.ElementType;
  href: string;
  color: string;
}) {
  return (
    <Link href={href} className="block bg-white rounded-2xl p-6 border border-gray-100 hover:shadow-md transition-all hover:border-[#E84821]/30">
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 rounded-xl ${color}`}>
          <Icon size={20} className="text-[#1C1917]" />
        </div>
        <TrendingUp size={16} className="text-green-400" />
      </div>
      <div className="text-3xl font-bold text-[#1C1917] mb-1">{value}</div>
      <div className="text-gray-500 text-sm">{label}</div>
    </Link>
  );
}

export default function AdminDashboard() {
  const { data: stats, isLoading } = useGetDashboardStats();

  const cards: Array<{ label: string; value: number; icon: React.ElementType; href: string; color: string }> = [
    { label: "Total Pages", value: stats?.totalPages ?? 0, icon: FileText, href: "/admin/pages", color: "bg-[#E84821]/20" },
    { label: "Blog Posts", value: stats?.totalBlogPosts ?? 0, icon: BookOpen, href: "/admin/blog", color: "bg-blue-100" },
    { label: "Total Contacts", value: stats?.totalContacts ?? 0, icon: Users, href: "/admin/contacts", color: "bg-purple-100" },
    { label: "Unread Messages", value: stats?.unreadContacts ?? 0, icon: MessageSquare, href: "/admin/contacts", color: "bg-orange-100" },
    { label: "Media Files", value: stats?.totalMedia ?? 0, icon: Image, href: "/admin/media", color: "bg-pink-100" },
    { label: "Portfolio Items", value: stats?.totalPortfolio ?? 0, icon: Briefcase, href: "/admin/portfolio", color: "bg-teal-100" },
  ];

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-[#1C1917]">Dashboard</h1>
        <p className="text-gray-500 text-sm mt-1">Welcome back to CtrlA CMS</p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="bg-white rounded-2xl h-36 animate-pulse border border-gray-100" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {cards.map(card => (
            <StatCard key={card.label} {...card} />
          ))}
        </div>
      )}
    </div>
  );
}
