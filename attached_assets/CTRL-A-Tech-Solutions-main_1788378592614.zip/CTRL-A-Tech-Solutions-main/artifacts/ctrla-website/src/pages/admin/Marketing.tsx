import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import {
  Mail, Send, Users, TrendingUp, Eye, MousePointerClick,
  BarChart3, Megaphone, FileText, Globe, Search, CheckCircle2, Clock,
  Sparkles, Wand2, Copy, Loader2, MessageCircle, Phone, Plus, Trash2, Eye as EyeIcon, X, Download
} from "lucide-react";
import { getToken } from "@/lib/auth";
import { exportToExcel } from "@/lib/exportToExcel";

async function api(path: string, opts?: RequestInit) {
  const token = getToken();
  const res = await fetch(path, {
    ...opts,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}`, ...(opts?.headers ?? {}) },
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    let msg = txt;
    try { msg = JSON.parse(txt).error ?? txt; } catch { /* keep raw */ }
    throw new Error(msg || `HTTP ${res.status}`);
  }
  if (res.status === 204) return null;
  return res.json();
}

type ContactInquiry = {
  id: number; name: string; email: string; phone?: string; subject?: string; message: string; createdAt: string;
};

const QUICK_STATS = [
  { label: "Total Leads", icon: Users, color: "#E84821", key: "contacts" },
  { label: "Blog Posts", icon: FileText, color: "#D4920C", key: "blog" },
  { label: "Portfolio Items", icon: Globe, color: "#3D4FA0", key: "portfolio" },
  { label: "Products Listed", icon: TrendingUp, color: "#16a34a", key: "products" },
];

const SEO_CHECKLIST = [
  { item: "Meta titles set for all pages", done: true },
  { item: "Meta descriptions configured", done: true },
  { item: "OG images for social sharing", done: false },
  { item: "Sitemap.xml auto-generated", done: true },
  { item: "Robots.txt configured", done: true },
  { item: "Schema markup (JSON-LD)", done: false },
  { item: "Page speed optimised", done: true },
  { item: "Mobile-responsive design", done: true },
];

const MARKETING_CHANNELS = [
  { label: "Website SEO", icon: Search, desc: "Organic search traffic via optimised pages and blog content", color: "#3D4FA0" },
  { label: "Email Marketing", icon: Mail, desc: "Nurture leads captured via contact forms with targeted campaigns", color: "#E84821" },
  { label: "SMS Campaigns", icon: Phone, desc: "Reach leads instantly with personalised SMS messages via Twilio", color: "#16a34a" },
  { label: "WhatsApp Outreach", icon: MessageCircle, desc: "Generate click-through wa.me links for personal one-on-one outreach", color: "#25D366" },
  { label: "Content Marketing", icon: FileText, desc: "Blog posts and case studies that build authority and generate leads", color: "#D4920C" },
  { label: "Lead Generation", icon: Users, desc: "Contact form submissions automatically captured and tracked", color: "#7c3aed" },
];

export default function AdminMarketing() {
  const [activeTab, setActiveTab] = useState<"overview" | "leads" | "seo" | "ai" | "campaigns" | "reports">("overview");

  const { data: stats } = useQuery({
    queryKey: ["admin-dashboard-stats"],
    queryFn: () => api("/api/admin/dashboard/stats"),
  });

  const { data: contacts = [] } = useQuery<ContactInquiry[]>({
    queryKey: ["admin-contacts-marketing"],
    queryFn: () => api("/api/admin/contacts"),
    enabled: activeTab === "leads",
  });

  const TABS = [
    { id: "overview", label: "Overview", icon: Megaphone },
    { id: "ai", label: "AI Studio", icon: Sparkles },
    { id: "campaigns", label: "Campaigns", icon: Send },
    { id: "reports", label: "Reports", icon: BarChart3 },
    { id: "leads", label: "Leads", icon: Users },
    { id: "seo", label: "SEO", icon: Search },
  ] as const;

  return (
    <div className="max-w-6xl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Marketing Hub</h1>
        <p className="text-sm text-gray-500 mt-1">Manage digital marketing — leads, SEO, AI content, and bulk Email/SMS/WhatsApp campaigns</p>
      </div>

      <div className="flex gap-1 mb-6 bg-gray-100 rounded-xl p-1 w-fit overflow-x-auto max-w-full">
        {TABS.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${activeTab === tab.id ? "bg-white text-[#1A1F36] shadow-sm" : "text-gray-500 hover:text-gray-700"}`}
          >
            <tab.icon size={14} /> {tab.label}
          </button>
        ))}
      </div>

      {activeTab === "overview" && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {QUICK_STATS.map(s => (
              <div key={s.label} className="bg-white rounded-xl border border-gray-100 p-5">
                <div className="flex items-center gap-2 mb-3">
                  <div className="p-2 rounded-lg" style={{ backgroundColor: `${s.color}15` }}>
                    <s.icon size={16} style={{ color: s.color }} />
                  </div>
                </div>
                <div className="text-2xl font-bold text-gray-900 mb-0.5">
                  {stats ? (stats[s.key] ?? "—") : "…"}
                </div>
                <div className="text-xs text-gray-400 font-medium">{s.label}</div>
              </div>
            ))}
          </div>

          <div>
            <h2 className="text-base font-bold text-gray-900 mb-3">Marketing Channels</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {MARKETING_CHANNELS.map(ch => (
                <div key={ch.label} className="bg-white rounded-xl border border-gray-100 p-5 hover:shadow-md transition-shadow">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="p-2 rounded-lg" style={{ backgroundColor: `${ch.color}15` }}>
                      <ch.icon size={16} style={{ color: ch.color }} />
                    </div>
                    <span className="font-semibold text-sm text-gray-900">{ch.label}</span>
                  </div>
                  <p className="text-xs text-gray-500 leading-relaxed">{ch.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === "ai" && <AiStudio />}
      {activeTab === "campaigns" && <CampaignsPanel />}
      {activeTab === "reports" && <CampaignReportsPanel />}

      {activeTab === "leads" && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold text-gray-900">All Lead Inquiries ({contacts.length})</h2>
            {contacts.length > 0 && (
              <button
                onClick={() =>
                  exportToExcel(
                    contacts.map(c => ({
                      ID: c.id,
                      Name: c.name,
                      Email: c.email,
                      Phone: c.phone ?? "",
                      Subject: c.subject ?? "",
                      Message: c.message,
                      "Date Received": new Date(c.createdAt).toLocaleString("en-IN"),
                    })),
                    `leads-${new Date().toISOString().slice(0, 10)}`,
                    "Leads"
                  )
                }
                className="flex items-center gap-2 px-3 py-1.5 text-sm font-semibold text-white rounded-lg transition-colors"
                style={{ backgroundColor: "#16a34a" }}
              >
                <Download size={14} /> Export to Excel
              </button>
            )}
          </div>
          <div className="space-y-3">
            {contacts.length === 0 ? (
              <div className="bg-white rounded-xl border border-gray-100 p-8 text-center text-gray-400">No leads yet. They will appear here when visitors submit the contact form.</div>
            ) : contacts.map(c => (
              <div key={c.id} className="bg-white rounded-xl border border-gray-100 p-5">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-full bg-[#E84821]/10 flex items-center justify-center text-[#E84821] font-bold text-sm flex-shrink-0">
                      {c.name[0].toUpperCase()}
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900 text-sm">{c.name}</div>
                      <div className="text-xs text-gray-400 flex flex-wrap gap-3 mt-0.5">
                        <a href={`mailto:${c.email}`} className="hover:text-[#D4920C] transition-colors">{c.email}</a>
                        {c.phone && <span>{c.phone}</span>}
                        {c.subject && <span className="text-[#3D4FA0] font-medium">{c.subject}</span>}
                      </div>
                    </div>
                  </div>
                  <div className="text-xs text-gray-400 flex items-center gap-1 flex-shrink-0">
                    <Clock size={11} />
                    {new Date(c.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                  </div>
                </div>
                {c.message && (
                  <p className="text-sm text-gray-600 mt-3 pl-12 leading-relaxed border-t border-gray-50 pt-3">{c.message}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === "seo" && (
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <h2 className="font-bold text-gray-900 mb-1">SEO Health Checklist</h2>
            <p className="text-sm text-gray-400 mb-5">Technical and on-page SEO status for your website</p>
            <div className="space-y-3">
              {SEO_CHECKLIST.map(s => (
                <div key={s.item} className="flex items-center gap-3">
                  <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${s.done ? "bg-green-500" : "bg-gray-200"}`}>
                    {s.done ? <CheckCircle2 size={12} className="text-white" /> : <Clock size={11} className="text-gray-400" />}
                  </div>
                  <span className={`text-sm ${s.done ? "text-gray-700" : "text-gray-400"}`}>{s.item}</span>
                  {!s.done && <span className="text-xs text-orange-500 font-medium ml-auto">Pending</span>}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-100 p-6">
            <h2 className="font-bold text-gray-900 mb-1">Content SEO Tips</h2>
            <div className="space-y-3 mt-3">
              {[
                { tip: "Publish 2–4 blog posts per month targeting SAP and ERP keywords", icon: FileText },
                { tip: "Each blog post should be 800–1500 words with structured headings (H2, H3)", icon: Eye },
                { tip: "Use product page descriptions with local India keywords (city + SAP ERP)", icon: Search },
                { tip: "Add client testimonials and case studies to boost trust signals", icon: Globe },
                { tip: "Share blog posts on LinkedIn and Twitter immediately after publishing", icon: MousePointerClick },
              ].map(t => (
                <div key={t.tip} className="flex items-start gap-3 text-sm text-gray-600">
                  <t.icon size={15} className="text-[#D4920C] flex-shrink-0 mt-0.5" />
                  {t.tip}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ───────────────────────── AI STUDIO ─────────────────────────

const AI_PRESETS = [
  { key: "marketing-email", label: "Marketing Email", desc: "Persuasive B2B email body", icon: Mail },
  { key: "email-subject", label: "Email Subject Lines", desc: "5 high-open subjects", icon: Mail },
  { key: "blog-post", label: "Blog Post (HTML)", desc: "Full SEO-optimized post", icon: FileText },
  { key: "blog-outline", label: "Blog Outline", desc: "Structured outline + keywords", icon: FileText },
  { key: "seo-meta", label: "SEO Meta Tags", desc: "Title, description, keywords", icon: Search },
  { key: "social-post", label: "LinkedIn Post", desc: "Engaging social copy", icon: Megaphone },
  { key: "ad-copy", label: "Ad Copy", desc: "Google/Meta ad variants", icon: TrendingUp },
  { key: "product-description", label: "Product Description", desc: "Compelling B2B product copy", icon: Globe },
  { key: "lead-reply", label: "Lead Reply Email", desc: "Personalized sales follow-up", icon: Send },
  { key: "sms-copy", label: "SMS Copy", desc: "3 short SMS variants", icon: Phone },
  { key: "whatsapp-copy", label: "WhatsApp Copy", desc: "Friendly WA message", icon: MessageCircle },
  { key: "freeform", label: "Freeform", desc: "Anything marketing-related", icon: Sparkles },
];

type ProviderInfo = { key: string; label: string; configured: boolean; defaultModel: string; longModel: string };

function AiStudio() {
  const { toast } = useToast();
  const [preset, setPreset] = useState("marketing-email");
  const [provider, setProvider] = useState("openai");
  const [model, setModel] = useState("");
  const [prompt, setPrompt] = useState("");
  const [context, setContext] = useState("");
  const [output, setOutput] = useState("");
  const [loading, setLoading] = useState(false);

  const { data: providersData } = useQuery<{ providers: ProviderInfo[] }>({
    queryKey: ["ai-providers"],
    queryFn: () => api("/api/admin/ai/providers"),
  });

  const providers = providersData?.providers ?? [];
  const currentProvider = providers.find(p => p.key === provider);
  const current = AI_PRESETS.find(p => p.key === preset)!;

  async function handleGenerate() {
    if (!prompt.trim()) {
      toast({ title: "Enter a brief", description: "Describe what you want to generate", variant: "destructive" });
      return;
    }
    if (currentProvider && !currentProvider.configured) {
      toast({ title: "Provider not configured", description: `Add the ${currentProvider.label} integration first`, variant: "destructive" });
      return;
    }
    setLoading(true);
    setOutput("");
    try {
      const data = await api("/api/admin/ai/generate", {
        method: "POST",
        body: JSON.stringify({
          preset, prompt,
          context: context || undefined,
          provider,
          model: model || undefined,
        }),
      });
      setOutput(data.content || "");
    } catch (e: unknown) {
      const message = e instanceof Error ? e.message : "Generation failed";
      toast({ title: "Error", description: message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }

  function handleCopy() {
    navigator.clipboard.writeText(output);
    toast({ title: "Copied", description: "Generated content copied to clipboard" });
  }

  return (
    <div className="space-y-5">
      <div className="bg-gradient-to-r from-[#E84821] via-[#D4920C] to-[#3D4FA0] rounded-2xl p-5 text-white">
        <div className="flex items-start gap-3">
          <div className="p-2.5 bg-white/15 rounded-xl flex-shrink-0">
            <Sparkles size={20} />
          </div>
          <div>
            <h3 className="font-bold text-lg leading-tight">AI Marketing Studio</h3>
            <p className="text-white/80 text-xs mt-1 leading-relaxed">
              Generate emails, blog posts, ad copy, SEO meta, social and SMS/WhatsApp messages —
              powered by OpenAI, Anthropic, Gemini, or OpenRouter via Replit AI Integrations.
            </p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-4 grid sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-semibold text-gray-600 mb-1">AI Provider</label>
          <select value={provider} onChange={e => { setProvider(e.target.value); setModel(""); }} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C]">
            {providers.map(p => (
              <option key={p.key} value={p.key} disabled={!p.configured}>
                {p.label} {!p.configured ? "(not configured)" : ""}
              </option>
            ))}
          </select>
          {currentProvider && !currentProvider.configured && (
            <p className="text-xs text-orange-600 mt-1">⚠ Provider not configured. Add the integration in Replit.</p>
          )}
        </div>
        <div>
          <label className="block text-xs font-semibold text-gray-600 mb-1">Model {currentProvider && <span className="text-gray-400 font-normal">(default: {currentProvider.defaultModel})</span>}</label>
          <input value={model} onChange={e => setModel(e.target.value)} placeholder={currentProvider?.defaultModel ?? ""} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C]" />
        </div>
      </div>

      <div>
        <label className="block text-xs font-semibold text-gray-600 mb-2">Choose Content Type</label>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
          {AI_PRESETS.map(p => {
            const Icon = p.icon;
            const active = p.key === preset;
            return (
              <button
                key={p.key}
                onClick={() => setPreset(p.key)}
                className={`text-left p-3 rounded-xl border transition-all ${active ? "border-[#D4920C] bg-amber-50 shadow-sm" : "border-gray-200 bg-white hover:border-gray-300 hover:bg-gray-50"}`}
              >
                <Icon size={16} className={active ? "text-[#D4920C]" : "text-gray-400"} />
                <div className={`text-xs font-bold mt-1.5 ${active ? "text-[#1A1F36]" : "text-gray-700"}`}>{p.label}</div>
                <div className="text-[10px] text-gray-400 mt-0.5 leading-tight">{p.desc}</div>
              </button>
            );
          })}
        </div>
      </div>

      <div>
        <label className="block text-xs font-semibold text-gray-600 mb-1">Describe What You Need</label>
        <textarea value={prompt} onChange={e => setPrompt(e.target.value)} rows={3} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C] resize-y" placeholder="Briefly describe what you want to generate..." />
      </div>

      <div>
        <label className="block text-xs font-semibold text-gray-600 mb-1">Extra Context <span className="text-gray-400 font-normal">(optional)</span></label>
        <textarea value={context} onChange={e => setContext(e.target.value)} rows={2} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C] resize-y" placeholder="Paste in any reference data — lead info, product specs, prior conversation, etc." />
      </div>

      <button onClick={handleGenerate} disabled={loading || !prompt.trim()} className="flex items-center gap-2 px-5 py-2.5 bg-[#E84821] text-white rounded-lg text-sm font-bold hover:bg-[#c73d1a] disabled:opacity-40 disabled:cursor-not-allowed">
        {loading ? <Loader2 size={15} className="animate-spin" /> : <Wand2 size={15} />}
        {loading ? "Generating..." : `Generate ${current.label}`}
      </button>

      {output && (
        <div className="border border-gray-200 rounded-xl bg-white">
          <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-gradient-to-r from-[#E84821] to-[#D4920C] flex items-center justify-center">
                <Sparkles size={11} className="text-white" />
              </div>
              <span className="text-xs font-bold text-gray-700">Generated {current.label}</span>
            </div>
            <button onClick={handleCopy} className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-100 hover:bg-gray-200 rounded-lg text-xs font-semibold text-gray-700">
              <Copy size={11} /> Copy
            </button>
          </div>
          <pre className="p-4 text-sm text-gray-800 whitespace-pre-wrap font-sans leading-relaxed max-h-[600px] overflow-y-auto">{output}</pre>
        </div>
      )}
    </div>
  );
}

// ───────────────────────── CAMPAIGN REPORTS ─────────────────────────

function CampaignReportsPanel() {
  const { data: campaigns = [], isLoading } = useQuery<Campaign[]>({
    queryKey: ["admin-campaigns"],
    queryFn: () => api("/api/admin/campaigns"),
  });

  const sentCampaigns = campaigns.filter(c => c.status === "sent" || c.status === "ready" || (c.stats && (c.stats.total ?? 0) > 0));

  const totalSent = sentCampaigns.reduce((acc, c) => acc + (c.stats?.sent ?? 0), 0);
  const totalFailed = sentCampaigns.reduce((acc, c) => acc + (c.stats?.failed ?? 0), 0);
  const totalRecipients = sentCampaigns.reduce((acc, c) => acc + (c.stats?.total ?? 0), 0);
  const deliveryRate = totalRecipients > 0 ? Math.round((totalSent / totalRecipients) * 100) : 0;

  const byType = { email: { sent: 0, failed: 0, total: 0 }, sms: { sent: 0, failed: 0, total: 0 }, whatsapp: { sent: 0, failed: 0, total: 0 } };
  sentCampaigns.forEach(c => {
    if (c.type in byType) {
      byType[c.type].sent += c.stats?.sent ?? 0;
      byType[c.type].failed += c.stats?.failed ?? 0;
      byType[c.type].total += c.stats?.total ?? 0;
    }
  });

  if (isLoading) return <div className="p-8 text-center text-gray-400">Loading…</div>;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total Campaigns", value: campaigns.length, color: "#3D4FA0" },
          { label: "Total Recipients", value: totalRecipients, color: "#D4920C" },
          { label: "Successfully Sent", value: totalSent, color: "#16a34a" },
          { label: "Delivery Rate", value: `${deliveryRate}%`, color: "#E84821" },
        ].map(s => (
          <div key={s.label} className="bg-white rounded-xl border border-gray-100 p-5">
            <div className="text-2xl font-bold mb-1" style={{ color: s.color }}>{s.value}</div>
            <div className="text-xs text-gray-500 font-medium">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        {(["email", "sms", "whatsapp"] as const).map(type => {
          const d = byType[type];
          const rate = d.total > 0 ? Math.round((d.sent / d.total) * 100) : 0;
          const typeColor = type === "email" ? "#E84821" : type === "sms" ? "#3D4FA0" : "#25D366";
          return (
            <div key={type} className="bg-white rounded-xl border border-gray-100 p-5">
              <div className="flex items-center gap-2 mb-4">
                <div className="p-2 rounded-lg" style={{ backgroundColor: `${typeColor}15` }}>
                  {type === "email" ? <Mail size={16} style={{ color: typeColor }} /> :
                   type === "sms" ? <Phone size={16} style={{ color: typeColor }} /> :
                   <MessageCircle size={16} style={{ color: typeColor }} />}
                </div>
                <span className="font-bold text-gray-900 capitalize">{type}</span>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-gray-500">Campaigns</span><span className="font-semibold">{campaigns.filter(c => c.type === type).length}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Recipients</span><span className="font-semibold">{d.total}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Delivered</span><span className="font-semibold text-green-600">{d.sent}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Failed</span><span className="font-semibold text-red-500">{d.failed}</span></div>
                {d.total > 0 && (
                  <div className="mt-3">
                    <div className="flex justify-between text-xs mb-1"><span className="text-gray-500">Delivery Rate</span><span className="font-bold" style={{ color: typeColor }}>{rate}%</span></div>
                    <div className="w-full bg-gray-100 rounded-full h-2">
                      <div className="h-2 rounded-full" style={{ width: `${rate}%`, backgroundColor: typeColor }} />
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
          <h3 className="font-bold text-gray-900">All Campaigns</h3>
          <div className="flex items-center gap-3">
            <span className="text-xs text-gray-400">{campaigns.length} total</span>
            {campaigns.length > 0 && (
              <button
                onClick={() =>
                  exportToExcel(
                    campaigns.map(c => ({
                      ID: c.id,
                      Name: c.name,
                      Type: c.type,
                      Subject: c.subject ?? "",
                      Status: c.status,
                      "Total Recipients": c.stats?.total ?? 0,
                      Delivered: c.stats?.sent ?? 0,
                      Failed: c.stats?.failed ?? 0,
                      "Delivery Rate (%)":
                        (c.stats?.total ?? 0) > 0
                          ? Math.round(((c.stats?.sent ?? 0) / (c.stats?.total ?? 1)) * 100)
                          : 0,
                      "Sent At": c.sentAt ? new Date(c.sentAt).toLocaleString("en-IN") : "",
                      "Created At": new Date(c.createdAt).toLocaleString("en-IN"),
                    })),
                    `campaigns-report-${new Date().toISOString().slice(0, 10)}`,
                    "Campaigns"
                  )
                }
                className="flex items-center gap-2 px-3 py-1.5 text-sm font-semibold text-white rounded-lg transition-colors"
                style={{ backgroundColor: "#16a34a" }}
              >
                <Download size={14} /> Export to Excel
              </button>
            )}
          </div>
        </div>
        {campaigns.length === 0 ? (
          <div className="p-8 text-center text-gray-400">No campaigns yet</div>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                <th className="text-left px-5 py-3 font-semibold text-gray-600">Campaign</th>
                <th className="text-left px-5 py-3 font-semibold text-gray-600">Type</th>
                <th className="text-left px-5 py-3 font-semibold text-gray-600">Status</th>
                <th className="text-left px-5 py-3 font-semibold text-gray-600">Sent</th>
                <th className="text-left px-5 py-3 font-semibold text-gray-600">Failed</th>
                <th className="text-left px-5 py-3 font-semibold text-gray-600 hidden md:table-cell">Date</th>
              </tr>
            </thead>
            <tbody>
              {campaigns.map(c => (
                <tr key={c.id} className="border-b border-gray-50 hover:bg-gray-50">
                  <td className="px-5 py-3 font-medium text-gray-900">{c.name}</td>
                  <td className="px-5 py-3">
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${c.type === "email" ? "bg-orange-100 text-orange-700" : c.type === "sms" ? "bg-blue-100 text-blue-700" : "bg-green-100 text-green-700"}`}>{c.type}</span>
                  </td>
                  <td className="px-5 py-3">
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${c.status === "draft" ? "bg-gray-100 text-gray-700" : c.status === "sending" ? "bg-yellow-100 text-yellow-700" : c.status === "sent" || c.status === "ready" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>{c.status}</span>
                  </td>
                  <td className="px-5 py-3 text-green-600 font-semibold">{c.stats?.sent ?? "—"}</td>
                  <td className="px-5 py-3 text-red-500 font-semibold">{c.stats?.failed ?? "—"}</td>
                  <td className="px-5 py-3 hidden md:table-cell text-xs text-gray-400">
                    {c.sentAt ? new Date(c.sentAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : new Date(c.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ───────────────────────── CAMPAIGNS ─────────────────────────

type Campaign = {
  id: number; name: string; type: "email" | "sms" | "whatsapp";
  subject: string | null; body: string; status: string;
  audienceFilter: { source?: string; ids?: number[] } | null;
  stats: { total?: number; sent?: number; failed?: number } | null;
  createdAt: string; sentAt: string | null;
};

type CampaignDetail = Campaign & {
  recipients: Array<{ id: number; name: string; email: string; phone: string; status: string; link: string | null; errorMsg: string | null }>;
};

function CampaignsPanel() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [showForm, setShowForm] = useState(false);
  const [viewId, setViewId] = useState<number | null>(null);

  const { data: campaigns = [], isLoading } = useQuery<Campaign[]>({
    queryKey: ["admin-campaigns"],
    queryFn: () => api("/api/admin/campaigns"),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => api(`/api/admin/campaigns/${id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin-campaigns"] }); toast({ title: "Campaign deleted" }); },
  });

  return (
    <div className="space-y-5">
      <div className="bg-gradient-to-r from-[#16a34a] via-[#3D4FA0] to-[#E84821] rounded-2xl p-5 text-white">
        <div className="flex items-start gap-3">
          <div className="p-2.5 bg-white/15 rounded-xl flex-shrink-0"><Send size={20} /></div>
          <div className="flex-1">
            <h3 className="font-bold text-lg leading-tight">Bulk Campaigns — Email · SMS · WhatsApp</h3>
            <p className="text-white/80 text-xs mt-1 leading-relaxed">
              Create personalised bulk campaigns to your contact-form leads. Use <code className="bg-white/15 px-1 rounded">{"{name}"}</code> for personalisation.
              Email needs SMTP credentials; SMS uses Twilio; WhatsApp generates click-through wa.me links (no API needed).
            </p>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <h2 className="text-base font-bold text-gray-900">Your Campaigns ({campaigns.length})</h2>
        <button onClick={() => setShowForm(true)} className="flex items-center gap-2 px-4 py-2 bg-[#E84821] text-white rounded-lg font-semibold text-sm hover:bg-[#c73d1a]">
          <Plus size={16} /> New Campaign
        </button>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-gray-400">Loading…</div>
        ) : campaigns.length === 0 ? (
          <div className="p-8 text-center text-gray-400">No campaigns yet. Click "New Campaign" to create one.</div>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left px-4 py-3 font-semibold text-gray-600">Name</th>
                <th className="text-left px-4 py-3 font-semibold text-gray-600">Type</th>
                <th className="text-left px-4 py-3 font-semibold text-gray-600">Status</th>
                <th className="text-left px-4 py-3 font-semibold text-gray-600 hidden md:table-cell">Stats</th>
                <th className="text-left px-4 py-3 font-semibold text-gray-600 hidden md:table-cell">Created</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody>
              {campaigns.map(c => (
                <tr key={c.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="px-4 py-3 font-medium text-gray-900">{c.name}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                      c.type === "email" ? "bg-orange-100 text-orange-700" :
                      c.type === "sms" ? "bg-blue-100 text-blue-700" :
                      "bg-green-100 text-green-700"
                    }`}>{c.type}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                      c.status === "draft" ? "bg-gray-100 text-gray-700" :
                      c.status === "sending" ? "bg-yellow-100 text-yellow-700" :
                      c.status === "sent" || c.status === "ready" ? "bg-green-100 text-green-700" :
                      "bg-red-100 text-red-700"
                    }`}>{c.status}</span>
                  </td>
                  <td className="px-4 py-3 hidden md:table-cell text-xs text-gray-600">
                    {c.stats && c.stats.total ? `${c.stats.sent ?? 0}/${c.stats.total} sent${c.stats.failed ? `, ${c.stats.failed} failed` : ""}` : "—"}
                  </td>
                  <td className="px-4 py-3 hidden md:table-cell text-xs text-gray-400">
                    {new Date(c.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button onClick={() => setViewId(c.id)} className="p-1.5 rounded-lg text-gray-400 hover:text-blue-600 hover:bg-blue-50" title="View / Send"><EyeIcon size={14} /></button>
                      <button onClick={() => { if (confirm("Delete this campaign?")) deleteMutation.mutate(c.id); }} className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50"><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showForm && <CampaignForm onClose={() => setShowForm(false)} onCreated={(id) => { setShowForm(false); setViewId(id); }} />}
      {viewId !== null && <CampaignDetailModal id={viewId} onClose={() => setViewId(null)} />}
    </div>
  );
}

function CampaignForm({ onClose, onCreated }: { onClose: () => void; onCreated: (id: number) => void }) {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const [type, setType] = useState<"email" | "sms" | "whatsapp">("email");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");

  const createMutation = useMutation({
    mutationFn: () => api("/api/admin/campaigns", {
      method: "POST",
      body: JSON.stringify({ name, type, subject, body, audienceFilter: { source: "all-leads" } }),
    }),
    onSuccess: (data: Campaign) => {
      qc.invalidateQueries({ queryKey: ["admin-campaigns"] });
      toast({ title: "Campaign created" });
      onCreated(data.id);
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const placeholders = {
    email: `Hi {name},\n\nWe'd love to show you what SAP Business One can do for your business...\n\nBest regards,\nCtrlA Tech Solutions`,
    sms: `Hi {name}! Free SAP B1 demo available this week. Reply YES to book. — CtrlA`,
    whatsapp: `Hi {name}! 👋 Quick question — would you be open to a free 30-min SAP demo this week?`,
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <h2 className="text-lg font-bold text-gray-900">New Campaign</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100"><X size={18} /></button>
        </div>
        <form onSubmit={(e) => { e.preventDefault(); createMutation.mutate(); }} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Campaign Name *</label>
            <input required value={name} onChange={e => setName(e.target.value)} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C]" placeholder="e.g. May Demo Outreach" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Channel</label>
            <div className="grid grid-cols-3 gap-2">
              {(["email", "sms", "whatsapp"] as const).map(t => (
                <button key={t} type="button" onClick={() => setType(t)} className={`p-3 rounded-lg border-2 text-sm font-semibold capitalize transition-all ${type === t ? "border-[#D4920C] bg-amber-50 text-[#1A1F36]" : "border-gray-200 text-gray-500 hover:border-gray-300"}`}>
                  {t === "email" && <Mail size={14} className="inline mr-1.5" />}
                  {t === "sms" && <Phone size={14} className="inline mr-1.5" />}
                  {t === "whatsapp" && <MessageCircle size={14} className="inline mr-1.5" />}
                  {t}
                </button>
              ))}
            </div>
          </div>
          {type === "email" && (
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Subject Line</label>
              <input value={subject} onChange={e => setSubject(e.target.value)} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C]" placeholder="e.g. Free SAP B1 demo for {name}" />
            </div>
          )}
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Message Body * <span className="text-gray-400 font-normal">(use {"{name}"} for personalisation)</span></label>
            <textarea required value={body} onChange={e => setBody(e.target.value)} rows={type === "email" ? 10 : 5} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C] font-mono resize-y" placeholder={placeholders[type]} />
          </div>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-xs text-blue-700">
            <strong>Audience:</strong> All leads from contact form ({type === "email" ? "with email" : "with phone"}). You can fine-tune later.
          </div>
          <div className="flex justify-end gap-3 pt-2 border-t border-gray-100">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900">Cancel</button>
            <button type="submit" disabled={createMutation.isPending} className="px-5 py-2 bg-[#E84821] text-white rounded-lg text-sm font-semibold hover:bg-[#c73d1a] disabled:opacity-50">
              {createMutation.isPending ? "Creating…" : "Create Draft"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function CampaignDetailModal({ id, onClose }: { id: number; onClose: () => void }) {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [previewing, setPreviewing] = useState(false);
  const [preview, setPreview] = useState<{ totalRecipients: number; samples: Array<{ to: string; name: string; subject?: string; body: string }> } | null>(null);
  const [sending, setSending] = useState(false);

  const { data: campaign, refetch } = useQuery<CampaignDetail>({
    queryKey: ["admin-campaign-detail", id],
    queryFn: () => api(`/api/admin/campaigns/${id}`),
  });

  async function handlePreview() {
    setPreviewing(true);
    try {
      const data = await api(`/api/admin/campaigns/${id}/preview`, { method: "POST" });
      setPreview(data);
    } catch (e) {
      toast({ title: "Preview failed", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setPreviewing(false);
    }
  }

  async function handleSend() {
    if (!confirm(`Send this ${campaign?.type} campaign to all matching leads?`)) return;
    setSending(true);
    try {
      const data = await api(`/api/admin/campaigns/${id}/send`, { method: "POST" });
      toast({
        title: campaign?.type === "whatsapp" ? "Links generated" : "Send complete",
        description: `${data.sent} succeeded, ${data.failed} failed (out of ${data.total})`,
      });
      qc.invalidateQueries({ queryKey: ["admin-campaigns"] });
      refetch();
    } catch (e) {
      toast({ title: "Send failed", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSending(false);
    }
  }

  if (!campaign) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
        <div className="bg-white rounded-2xl p-8 text-gray-400">Loading…</div>
      </div>
    );
  }

  const sentRecipients = campaign.recipients?.filter(r => r.status === "sent" || r.status === "ready") ?? [];
  const failedRecipients = campaign.recipients?.filter(r => r.status === "failed") ?? [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-100 sticky top-0 bg-white z-10">
          <div>
            <h2 className="text-lg font-bold text-gray-900">{campaign.name}</h2>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xs font-semibold capitalize text-gray-500">{campaign.type}</span>
              <span className="text-xs">•</span>
              <span className="text-xs font-semibold text-gray-500">{campaign.status}</span>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100"><X size={18} /></button>
        </div>

        <div className="p-6 space-y-5">
          {campaign.subject && (
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Subject</label>
              <div className="bg-gray-50 rounded-lg p-3 text-sm">{campaign.subject}</div>
            </div>
          )}
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Body</label>
            <pre className="bg-gray-50 rounded-lg p-3 text-sm whitespace-pre-wrap font-sans">{campaign.body}</pre>
          </div>

          <div className="flex flex-wrap gap-3">
            <button onClick={handlePreview} disabled={previewing} className="flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-700 rounded-lg text-sm font-semibold hover:bg-blue-100 disabled:opacity-50">
              {previewing ? <Loader2 size={14} className="animate-spin" /> : <EyeIcon size={14} />} Preview Audience
            </button>
            {campaign.status !== "sending" && (
              <button onClick={handleSend} disabled={sending} className="flex items-center gap-2 px-5 py-2 bg-[#E84821] text-white rounded-lg text-sm font-semibold hover:bg-[#c73d1a] disabled:opacity-50">
                {sending ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
                {campaign.type === "whatsapp" ? "Generate WhatsApp Links" : `Send ${campaign.type.toUpperCase()}`}
              </button>
            )}
          </div>

          {preview && (
            <div className="border border-gray-200 rounded-xl">
              <div className="px-4 py-3 border-b border-gray-100 font-semibold text-sm">
                Audience: {preview.totalRecipients} recipient{preview.totalRecipients !== 1 ? "s" : ""}
              </div>
              <div className="divide-y divide-gray-100">
                {preview.samples.map((s, i) => (
                  <div key={i} className="p-3 text-xs">
                    <div className="font-semibold text-gray-700 mb-1">→ {s.name} ({s.to})</div>
                    {s.subject && <div className="text-gray-500 mb-1"><strong>Subject:</strong> {s.subject}</div>}
                    <pre className="whitespace-pre-wrap font-sans text-gray-600">{s.body}</pre>
                  </div>
                ))}
                {preview.totalRecipients > preview.samples.length && (
                  <div className="p-3 text-xs text-gray-400">…and {preview.totalRecipients - preview.samples.length} more</div>
                )}
              </div>
            </div>
          )}

          {campaign.recipients && campaign.recipients.length > 0 && (
            <div>
              <h3 className="font-semibold text-sm text-gray-900 mb-2">
                Send Results: {sentRecipients.length} {campaign.type === "whatsapp" ? "ready" : "sent"}, {failedRecipients.length} failed
              </h3>
              <div className="border border-gray-200 rounded-xl divide-y divide-gray-100 max-h-80 overflow-y-auto">
                {campaign.recipients.map(r => (
                  <div key={r.id} className="p-3 flex items-center justify-between gap-3 text-xs">
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-gray-700">{r.name || "—"}</div>
                      <div className="text-gray-400 truncate">{r.email || r.phone}</div>
                      {r.errorMsg && <div className="text-red-500 mt-0.5 truncate">⚠ {r.errorMsg}</div>}
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                        r.status === "sent" || r.status === "ready" ? "bg-green-100 text-green-700" :
                        r.status === "failed" ? "bg-red-100 text-red-700" : "bg-gray-100 text-gray-700"
                      }`}>{r.status}</span>
                      {r.link && (
                        <a href={r.link} target="_blank" rel="noopener noreferrer" className="px-2 py-1 bg-green-50 text-green-700 rounded text-xs font-semibold hover:bg-green-100 flex items-center gap-1">
                          <MessageCircle size={11} /> Open
                        </a>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
