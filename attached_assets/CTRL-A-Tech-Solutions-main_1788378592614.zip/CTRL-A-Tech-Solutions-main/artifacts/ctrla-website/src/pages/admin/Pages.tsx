import { useState } from "react";
import { Plus, Edit2, Trash2, Eye, EyeOff, FolderOpen, LayoutTemplate } from "lucide-react";
import RichTextEditor from "@/components/RichTextEditor";
import { MediaPickerModal } from "@/components/admin/MediaPickerModal";
import { PageContentEditor } from "@/components/admin/PageContentEditor";
import { hasContentSchema } from "@/lib/pageContentSchema";
import { useToast } from "@/hooks/use-toast";
import {
  useListPages, useCreatePage, useUpdatePage, useDeletePage,
} from "@/lib/apiClient";
import { useQueryClient } from "@tanstack/react-query";

type Page = { id: number; title: string; slug: string; content: string; heroImage?: string | null; metaTitle?: string | null; metaDescription?: string | null; isPublished: boolean; sortOrder: number };

const emptyForm = { title: "", slug: "", content: "", heroImage: "", metaTitle: "", metaDescription: "", isPublished: false, sortOrder: 0 };

export default function AdminPages() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const { data: pages, isLoading } = useListPages();
  const createPage = useCreatePage();
  const updatePage = useUpdatePage();
  const deletePage = useDeletePage();

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Page | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [showMediaPicker, setShowMediaPicker] = useState(false);
  const [contentEditor, setContentEditor] = useState<{ slug: string; title: string } | null>(null);

  function openCreate() { setEditing(null); setForm(emptyForm); setShowForm(true); }
  function openEdit(page: Page) {
    setEditing(page);
    setForm({ title: page.title, slug: page.slug, content: page.content, heroImage: page.heroImage ?? "", metaTitle: page.metaTitle ?? "", metaDescription: page.metaDescription ?? "", isPublished: page.isPublished, sortOrder: page.sortOrder });
    setShowForm(true);
  }

  function generateSlug(title: string) {
    return title.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const data = { ...form, heroImage: form.heroImage || null, metaTitle: form.metaTitle || null, metaDescription: form.metaDescription || null };
    if (editing) {
      await updatePage.mutateAsync({ id: editing.id, data }, {
        onSuccess: () => { toast({ title: "Page updated" }); qc.invalidateQueries(); setShowForm(false); },
        onError: () => toast({ title: "Error", variant: "destructive" }),
      });
    } else {
      await createPage.mutateAsync({ data }, {
        onSuccess: () => { toast({ title: "Page created" }); qc.invalidateQueries(); setShowForm(false); },
        onError: () => toast({ title: "Error", variant: "destructive" }),
      });
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this page?")) return;
    await deletePage.mutateAsync({ id }, {
      onSuccess: () => { toast({ title: "Page deleted" }); qc.invalidateQueries(); },
    });
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-[#1C1917]">Pages</h1>
          <p className="text-gray-500 text-sm mt-1">Manage website pages</p>
        </div>
        <button onClick={openCreate} className="flex items-center gap-2 bg-[#1C1917] text-white px-4 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#E84821] hover:text-[#1C1917] transition-all">
          <Plus size={16} /> New Page
        </button>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b">
              <h2 className="font-bold text-[#1C1917]">{editing ? "Edit Page" : "New Page"}</h2>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Title *</label>
                  <input required value={form.title} onChange={e => { setForm(p => ({ ...p, title: e.target.value, slug: p.slug || generateSlug(e.target.value) })); }} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Slug *</label>
                  <input required value={form.slug} onChange={e => setForm(p => ({ ...p, slug: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Hero Image</label>
                <div className="flex gap-2">
                  <input value={form.heroImage} onChange={e => setForm(p => ({ ...p, heroImage: e.target.value }))} placeholder="https://... or browse media library" className="flex-1 border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50" />
                  <button type="button" onClick={() => setShowMediaPicker(true)} className="flex items-center gap-1.5 px-3 py-2 text-sm border border-gray-200 rounded-lg text-gray-600 hover:bg-gray-50 hover:border-[#E84821] transition-all whitespace-nowrap">
                    <FolderOpen size={15} /> Browse
                  </button>
                </div>
                {form.heroImage && (
                  <img src={form.heroImage} alt="Hero preview" className="mt-2 h-24 w-full object-cover rounded-lg border border-gray-200" onError={e => { (e.target as HTMLImageElement).style.display = "none"; }} />
                )}
              </div>
              {showMediaPicker && (
                <MediaPickerModal onSelect={url => setForm(p => ({ ...p, heroImage: url }))} onClose={() => setShowMediaPicker(false)} />
              )}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Content</label>
                <RichTextEditor value={form.content} onChange={html => setForm(p => ({ ...p, content: html }))} placeholder="Page content…" minHeight="220px" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Meta Title</label>
                  <input value={form.metaTitle} onChange={e => setForm(p => ({ ...p, metaTitle: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Sort Order</label>
                  <input type="number" value={form.sortOrder} onChange={e => setForm(p => ({ ...p, sortOrder: Number(e.target.value) }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Meta Description</label>
                <textarea rows={2} value={form.metaDescription} onChange={e => setForm(p => ({ ...p, metaDescription: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50" />
              </div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={form.isPublished} onChange={e => setForm(p => ({ ...p, isPublished: e.target.checked }))} className="rounded" />
                <span className="text-sm text-gray-700">Published</span>
              </label>
              <div className="flex gap-3 pt-2">
                <button type="submit" className="bg-[#1C1917] text-white px-6 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#E84821] hover:text-[#1C1917] transition-all">Save Page</button>
                <button type="button" onClick={() => setShowForm(false)} className="border border-gray-200 text-gray-600 px-6 py-2.5 rounded-xl text-sm font-semibold hover:bg-gray-50 transition-all">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-16 bg-gray-100 rounded-xl animate-pulse" />)}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                <th className="text-left px-6 py-4 font-medium text-gray-500">Title</th>
                <th className="text-left px-6 py-4 font-medium text-gray-500">Slug</th>
                <th className="text-left px-6 py-4 font-medium text-gray-500">Status</th>
                <th className="text-right px-6 py-4 font-medium text-gray-500">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {pages?.map(page => (
                <tr key={page.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 font-medium text-[#1C1917]">{page.title}</td>
                  <td className="px-6 py-4 text-gray-500 font-mono text-xs">/{page.slug}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${page.isPublished ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                      {page.isPublished ? <Eye size={10} /> : <EyeOff size={10} />}
                      {page.isPublished ? "Published" : "Draft"}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center gap-2 justify-end">
                      {hasContentSchema(page.slug) && (
                        <button onClick={() => setContentEditor({ slug: page.slug, title: page.title })} title="Edit page text & images" className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-[#E84821]/10 text-[#E84821] hover:bg-[#E84821] hover:text-white transition-colors">
                          <LayoutTemplate size={13} /> Content
                        </button>
                      )}
                      <button onClick={() => openEdit(page as Page)} title="Edit settings (SEO, slug, status)" className="p-2 hover:bg-[#E84821]/10 rounded-lg text-gray-400 hover:text-[#E84821] transition-colors"><Edit2 size={14} /></button>
                      <button onClick={() => handleDelete(page.id)} className="p-2 hover:bg-red-50 rounded-lg text-gray-400 hover:text-red-500 transition-colors"><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))}
              {!pages?.length && (
                <tr><td colSpan={4} className="px-6 py-12 text-center text-gray-400">No pages yet. Create your first page.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {contentEditor && (
        <PageContentEditor
          slug={contentEditor.slug}
          title={contentEditor.title}
          onClose={() => setContentEditor(null)}
        />
      )}
    </div>
  );
}
