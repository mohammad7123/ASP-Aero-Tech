import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Pencil, Trash2, Package, Search, X, Image, ArrowUp, ArrowDown } from "lucide-react";
import AdminLayout from "@/components/admin/AdminLayout";
import { useToast } from "@/hooks/use-toast";
import { getIcon } from "@/lib/iconMap";
import { getToken } from "@/lib/auth";
import type { ProductItem } from "@/types/productItem";

const CATEGORIES = [
  { value: "", label: "All Categories" },
  { value: "erp", label: "ERP Solutions" },
  { value: "business-apps", label: "Business Applications" },
  { value: "ai-solutions", label: "AI Solutions" },
  { value: "cloud-platforms", label: "Cloud Platforms" },
  { value: "integration-suite", label: "Integration Suite" },
];

const ICON_OPTIONS = [
  "Package","Database","LayoutGrid","Zap","Rocket","Network","Smartphone","CheckCircle2",
  "BarChart3","Printer","Receipt","ShieldCheck","ShoppingCart","Factory","Headphones",
  "Wrench","Server","Cloud","Briefcase","ShoppingBag","Store","ClipboardList","Truck",
  "CreditCard","Users","Building2","MapPin","Shield","Star","Brain","MessageSquare",
  "TrendingDown","FileText","Search","TrendingUp","Cpu","RefreshCw","HardDrive",
  "Globe","Mail","Building","Plug","Activity","Bell",
];

const ACCENT_OPTIONS = [
  { label: "Orange", value: "#E84821" },
  { label: "Gold", value: "#D4920C" },
  { label: "Navy", value: "#3D4FA0" },
  { label: "Green", value: "#16a34a" },
  { label: "Purple", value: "#7c3aed" },
];

type FormData = {
  name: string;
  category: string;
  shortDesc: string;
  description: string;
  imageUrl: string;
  iconName: string;
  accentColor: string;
  sortOrder: number;
  isActive: boolean;
};

const emptyForm: FormData = {
  name: "",
  category: "erp",
  shortDesc: "",
  description: "",
  imageUrl: "",
  iconName: "Package",
  accentColor: "#D4920C",
  sortOrder: 0,
  isActive: true,
};

async function apiFetch(path: string, opts?: RequestInit) {
  const token = getToken();
  const res = await fetch(path, {
    ...opts,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}`, ...(opts?.headers ?? {}) },
  });
  if (!res.ok) throw new Error(await res.text());
  if (res.status === 204) return null;
  return res.json();
}

export default function AdminProductItems() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [category, setCategory] = useState("");
  const [search, setSearch] = useState("");
  const [editItem, setEditItem] = useState<ProductItem | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<FormData>(emptyForm);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const url = category ? `/api/admin/product-items?category=${category}` : "/api/admin/product-items";
  const { data: items = [], isLoading } = useQuery<ProductItem[]>({
    queryKey: ["admin-product-items", category],
    queryFn: () => apiFetch(url),
  });

  const filtered = items.filter(it =>
    !search || it.name.toLowerCase().includes(search.toLowerCase()) || it.category.includes(search.toLowerCase())
  );

  const saveMutation = useMutation({
    mutationFn: (data: FormData & { id?: number }) => {
      const { id, ...body } = data;
      const payload = { ...body, imageUrl: body.imageUrl || null };
      return id
        ? apiFetch(`/api/admin/product-items/${id}`, { method: "PATCH", body: JSON.stringify(payload) })
        : apiFetch("/api/admin/product-items", { method: "POST", body: JSON.stringify(payload) });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-product-items"] });
      qc.invalidateQueries({ queryKey: ["product-items"] });
      toast({ title: editItem ? "Product updated" : "Product created" });
      closeForm();
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiFetch(`/api/admin/product-items/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-product-items"] });
      qc.invalidateQueries({ queryKey: ["product-items"] });
      toast({ title: "Product deleted" });
      setDeleteId(null);
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const toggleActive = useMutation({
    mutationFn: ({ id, isActive }: { id: number; isActive: boolean }) =>
      apiFetch(`/api/admin/product-items/${id}`, { method: "PATCH", body: JSON.stringify({ isActive }) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-product-items"] }),
  });

  const moveMutation = useMutation({
    mutationFn: ({ id, direction }: { id: number; direction: "up" | "down" }) =>
      apiFetch(`/api/admin/product-items/${id}/move`, { method: "POST", body: JSON.stringify({ direction }) }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-product-items"] });
      qc.invalidateQueries({ queryKey: ["product-items"] });
    },
  });

  function openCreate() {
    setEditItem(null);
    setForm({ ...emptyForm, category: category || "erp" });
    setShowForm(true);
  }

  function openEdit(item: ProductItem) {
    setEditItem(item);
    setForm({
      name: item.name,
      category: item.category,
      shortDesc: item.shortDesc,
      description: item.description ?? "",
      imageUrl: item.imageUrl ?? "",
      iconName: item.iconName,
      accentColor: item.accentColor,
      sortOrder: item.sortOrder,
      isActive: item.isActive,
    });
    setShowForm(true);
  }

  function closeForm() {
    setShowForm(false);
    setEditItem(null);
    setForm(emptyForm);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    saveMutation.mutate(editItem ? { ...form, id: editItem.id } : form);
  }

  const CATEGORY_MAP: Record<string, string> = {
    erp: "ERP",
    "business-apps": "Business Apps",
    "ai-solutions": "AI Solutions",
    "cloud-platforms": "Cloud",
    "integration-suite": "Integration",
  };

  return (
    <AdminLayout>
      <div className="max-w-6xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Product Items</h1>
            <p className="text-sm text-gray-500 mt-1">Manage modal content (description + image) for all product cards</p>
          </div>
          <button
            onClick={openCreate}
            className="flex items-center gap-2 px-4 py-2 bg-[#D4920C] text-white rounded-lg font-semibold text-sm hover:bg-[#b87a09] transition-colors"
          >
            <Plus size={16} /> Add Product
          </button>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 mb-6 p-4 flex flex-wrap gap-3">
          <div className="flex items-center gap-2 flex-1 min-w-[200px]">
            <Search size={16} className="text-gray-400" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search products…"
              className="flex-1 text-sm outline-none"
            />
            {search && <button onClick={() => setSearch("")}><X size={14} className="text-gray-400" /></button>}
          </div>
          <select
            value={category}
            onChange={e => setCategory(e.target.value)}
            className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 outline-none"
          >
            {CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
          </select>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          {isLoading ? (
            <div className="p-8 text-center text-gray-400">Loading…</div>
          ) : filtered.length === 0 ? (
            <div className="p-8 text-center text-gray-400">No products found</div>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="text-left px-4 py-3 font-semibold text-gray-600 w-20">Order</th>
                  <th className="text-left px-4 py-3 font-semibold text-gray-600">Product</th>
                  <th className="text-left px-4 py-3 font-semibold text-gray-600 hidden md:table-cell">Category</th>
                  <th className="text-left px-4 py-3 font-semibold text-gray-600 hidden lg:table-cell">Image</th>
                  <th className="text-left px-4 py-3 font-semibold text-gray-600 hidden lg:table-cell">Description</th>
                  <th className="text-center px-4 py-3 font-semibold text-gray-600">Active</th>
                  <th className="text-right px-4 py-3 font-semibold text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((item, i) => {
                  const Icon = getIcon(item.iconName);
                  const sameCategoryItems = filtered.filter(x => x.category === item.category);
                  const idxInCat = sameCategoryItems.findIndex(x => x.id === item.id);
                  return (
                    <tr key={item.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1">
                          <button onClick={() => moveMutation.mutate({ id: item.id, direction: "up" })} disabled={idxInCat === 0} className="p-1 rounded hover:bg-blue-50 text-gray-400 hover:text-blue-600 disabled:opacity-30 disabled:cursor-not-allowed" title="Move up in category"><ArrowUp size={14} /></button>
                          <button onClick={() => moveMutation.mutate({ id: item.id, direction: "down" })} disabled={idxInCat === sameCategoryItems.length - 1} className="p-1 rounded hover:bg-blue-50 text-gray-400 hover:text-blue-600 disabled:opacity-30 disabled:cursor-not-allowed" title="Move down in category"><ArrowDown size={14} /></button>
                          <span className="text-xs text-gray-400 ml-1">{item.sortOrder}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="p-1.5 rounded-lg" style={{ backgroundColor: `${item.accentColor}18` }}>
                            <Icon size={14} style={{ color: item.accentColor }} />
                          </div>
                          <span className="font-medium text-gray-900">{item.name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 hidden md:table-cell">
                        <span className="px-2 py-0.5 rounded-full text-xs font-medium text-white" style={{ backgroundColor: item.accentColor }}>
                          {CATEGORY_MAP[item.category] ?? item.category}
                        </span>
                      </td>
                      <td className="px-4 py-3 hidden lg:table-cell">
                        {item.imageUrl ? (
                          <span className="inline-flex items-center gap-1 text-green-600 text-xs font-medium">
                            <Image size={12} /> Set
                          </span>
                        ) : (
                          <span className="text-gray-300 text-xs">—</span>
                        )}
                      </td>
                      <td className="px-4 py-3 hidden lg:table-cell max-w-[200px]">
                        <p className="text-gray-400 text-xs truncate">{item.description || item.shortDesc}</p>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <button
                          onClick={() => toggleActive.mutate({ id: item.id, isActive: !item.isActive })}
                          className={`w-9 h-5 rounded-full transition-colors ${item.isActive ? "bg-green-500" : "bg-gray-200"}`}
                        >
                          <span className={`block w-3.5 h-3.5 rounded-full bg-white shadow mx-0.5 transition-transform ${item.isActive ? "translate-x-4" : "translate-x-0"}`} />
                        </button>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button onClick={() => openEdit(item)} className="p-1.5 rounded-lg text-gray-400 hover:text-blue-600 hover:bg-blue-50 transition-colors">
                            <Pencil size={14} />
                          </button>
                          <button onClick={() => setDeleteId(item.id)} className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors">
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-gray-100">
              <h2 className="text-lg font-bold text-gray-900">{editItem ? "Edit Product" : "Add Product"}</h2>
              <button onClick={closeForm} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors">
                <X size={18} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Name *</label>
                  <input
                    required
                    value={form.name}
                    onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C]"
                    placeholder="Product name"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Category *</label>
                  <select
                    value={form.category}
                    onChange={e => setForm(f => ({ ...f, category: e.target.value }))}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C]"
                  >
                    {CATEGORIES.filter(c => c.value).map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">Short Description (shown on card)</label>
                <textarea
                  value={form.shortDesc}
                  onChange={e => setForm(f => ({ ...f, shortDesc: e.target.value }))}
                  rows={2}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C] resize-none"
                  placeholder="Brief description shown on the product card"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">
                  Modal Description (1–2 paragraphs shown when user clicks the card)
                </label>
                <textarea
                  value={form.description}
                  onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                  rows={5}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C] resize-y"
                  placeholder="Detailed description for the modal popup. Separate paragraphs with a blank line."
                />
                <p className="text-xs text-gray-400 mt-1">Separate paragraphs with a blank line (double Enter)</p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">
                  Modal Image URL
                </label>
                <div className="flex gap-2">
                  <input
                    value={form.imageUrl}
                    onChange={e => setForm(f => ({ ...f, imageUrl: e.target.value }))}
                    className="flex-1 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C]"
                    placeholder="https://… (leave blank for no image)"
                  />
                  {form.imageUrl && (
                    <img src={form.imageUrl} alt="" className="h-10 w-16 object-cover rounded-lg border border-gray-200" onError={e => { (e.target as HTMLImageElement).style.display = "none"; }} />
                  )}
                </div>
                <p className="text-xs text-gray-400 mt-1">Paste any image URL or use a media library URL from the Media section</p>
              </div>

              <div className="grid sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Icon</label>
                  <select
                    value={form.iconName}
                    onChange={e => setForm(f => ({ ...f, iconName: e.target.value }))}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C]"
                  >
                    {ICON_OPTIONS.map(i => <option key={i} value={i}>{i}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Accent Color</label>
                  <div className="flex gap-1">
                    {ACCENT_OPTIONS.map(opt => (
                      <button
                        key={opt.value}
                        type="button"
                        onClick={() => setForm(f => ({ ...f, accentColor: opt.value }))}
                        className={`w-7 h-7 rounded-full border-2 transition-all ${form.accentColor === opt.value ? "border-gray-900 scale-110" : "border-transparent"}`}
                        style={{ backgroundColor: opt.value }}
                        title={opt.label}
                      />
                    ))}
                    <input
                      type="color"
                      value={form.accentColor}
                      onChange={e => setForm(f => ({ ...f, accentColor: e.target.value }))}
                      className="w-7 h-7 rounded-full border border-gray-200 cursor-pointer"
                      title="Custom color"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Sort Order</label>
                  <input
                    type="number"
                    value={form.sortOrder}
                    onChange={e => setForm(f => ({ ...f, sortOrder: Number(e.target.value) }))}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C]"
                    min={0}
                  />
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setForm(f => ({ ...f, isActive: !f.isActive }))}
                  className={`w-10 h-5 rounded-full transition-colors ${form.isActive ? "bg-green-500" : "bg-gray-200"}`}
                >
                  <span className={`block w-4 h-4 rounded-full bg-white shadow mx-0.5 transition-transform ${form.isActive ? "translate-x-5" : "translate-x-0"}`} />
                </button>
                <span className="text-sm text-gray-600">Active (visible on website)</span>
              </div>

              <div className="flex justify-end gap-3 pt-2 border-t border-gray-100">
                <button type="button" onClick={closeForm} className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900 transition-colors">
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saveMutation.isPending}
                  className="px-5 py-2 bg-[#D4920C] text-white rounded-lg text-sm font-semibold hover:bg-[#b87a09] disabled:opacity-50 transition-colors"
                >
                  {saveMutation.isPending ? "Saving…" : editItem ? "Save Changes" : "Add Product"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {deleteId !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-2">Delete Product?</h3>
            <p className="text-sm text-gray-500 mb-6">This will permanently remove the product and its modal content.</p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setDeleteId(null)} className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900 transition-colors">Cancel</button>
              <button
                onClick={() => deleteMutation.mutate(deleteId!)}
                disabled={deleteMutation.isPending}
                className="px-4 py-2 bg-red-500 text-white rounded-lg text-sm font-semibold hover:bg-red-600 disabled:opacity-50 transition-colors"
              >
                {deleteMutation.isPending ? "Deleting…" : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
