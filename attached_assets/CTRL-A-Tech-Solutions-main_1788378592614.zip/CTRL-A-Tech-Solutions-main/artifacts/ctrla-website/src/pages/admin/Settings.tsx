import React, { useState, useEffect, useRef } from "react";
import { Save, Palette, Globe, MessageSquare, Mail, BarChart3, Bot, Smartphone, Sparkles, Share2, Upload, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useGetSettings, useUpdateSettings } from "@/lib/apiClient";
import { getToken } from "@/lib/auth";
import { useQueryClient } from "@tanstack/react-query";
import type { SiteSettings } from "@workspace/api-client-react";

type Tab = "general" | "colors" | "contact" | "social" | "smtp" | "sms" | "whatsapp" | "ai" | "analytics" | "chatbot";

const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
  { id: "general", label: "General", icon: Globe },
  { id: "colors", label: "Colors & Fonts", icon: Palette },
  { id: "contact", label: "Contact Info", icon: MessageSquare },
  { id: "social", label: "Social Media", icon: Share2 },
  { id: "smtp", label: "SMTP", icon: Mail },
  { id: "sms", label: "SMS", icon: Smartphone },
  { id: "whatsapp", label: "WhatsApp", icon: MessageSquare },
  { id: "ai", label: "AI Providers", icon: Sparkles },
  { id: "analytics", label: "Analytics", icon: BarChart3 },
  { id: "chatbot", label: "Chatbot", icon: Bot },
];

type SettingsForm = Record<string, string | number | boolean | null | undefined>;

export default function AdminSettings() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const { data: settings, isLoading } = useGetSettings();
  const updateSettings = useUpdateSettings();
  const [tab, setTab] = useState<Tab>("general");
  const [form, setForm] = useState<SettingsForm>({});
  const [logoUploading, setLogoUploading] = useState(false);
  const [faviconUploading, setFaviconUploading] = useState(false);
  const logoFileRef = useRef<HTMLInputElement>(null);
  const faviconFileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (settings) setForm(settings as unknown as SettingsForm);
  }, [settings]);

  function field(key: string, type = "text", placeholder = "") {
    return (
      <input
        type={type}
        value={String(form[key] ?? "")}
        onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))}
        className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50"
        placeholder={placeholder}
      />
    );
  }

  function checkbox(key: string, label: string) {
    return (
      <label className="flex items-center gap-2 cursor-pointer">
        <input
          type="checkbox"
          checked={!!form[key]}
          onChange={e => setForm(p => ({ ...p, [key]: e.target.checked }))}
          className="rounded w-4 h-4 accent-[#E84821]"
        />
        <span className="text-sm text-gray-700">{label}</span>
      </label>
    );
  }

  function colorField(key: string, label: string) {
    return (
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
        <div className="flex gap-2 items-center">
          <input
            type="color"
            value={String(form[key] ?? "#000000")}
            onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))}
            className="w-12 h-10 rounded border border-gray-200 cursor-pointer p-1"
          />
          <input
            type="text"
            value={String(form[key] ?? "")}
            onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))}
            className="flex-1 border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50 font-mono"
            placeholder="#000000"
          />
        </div>
      </div>
    );
  }

  async function uploadImageFile(file: File): Promise<string> {
    const urlRes = await fetch("/api/storage/uploads/request-url", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken() ?? ""}` },
      body: JSON.stringify({ name: file.name, size: file.size, contentType: file.type }),
    });
    if (!urlRes.ok) throw new Error("Failed to get upload URL");
    const { uploadURL, objectPath } = await urlRes.json();
    const uploadRes = await fetch(uploadURL, { method: "PUT", body: file, headers: { "Content-Type": file.type } });
    if (!uploadRes.ok) throw new Error("Upload failed");
    return `/api/storage/objects/${objectPath.replace(/^\/objects\//, "")}`;
  }

  async function handleLogoUpload(file: File) {
    setLogoUploading(true);
    try {
      const logoUrl = await uploadImageFile(file);
      setForm(p => ({ ...p, logoUrl }));
      toast({ title: "Logo uploaded", description: "Click Save Settings to apply." });
    } catch (err) {
      toast({ title: "Upload failed", description: err instanceof Error ? err.message : "", variant: "destructive" });
    } finally {
      setLogoUploading(false);
    }
  }

  async function handleFaviconUpload(file: File) {
    setFaviconUploading(true);
    try {
      const faviconUrl = await uploadImageFile(file);
      setForm(p => ({ ...p, faviconUrl }));
      toast({ title: "Favicon uploaded", description: "Click Save Settings to apply." });
    } catch (err) {
      toast({ title: "Upload failed", description: err instanceof Error ? err.message : "", variant: "destructive" });
    } finally {
      setFaviconUploading(false);
    }
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    const cleanForm = Object.fromEntries(
      Object.entries(form)
        .filter(([k]) => k !== "updatedAt")
        .map(([k, v]) => [k, v === "" ? null : v])
    );
    // Bypass typed mutation: we send extended fields (WhatsApp Business / AI provider keys)
    // that aren't yet in the generated zod schema. The API merges them safely.
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken() ?? ""}` },
        body: JSON.stringify(cleanForm),
      });
      if (!res.ok) throw new Error(await res.text());
      toast({ title: "Settings saved" });
      qc.invalidateQueries();
    } catch (err) {
      console.error(err);
      toast({ title: "Error saving settings", variant: "destructive" });
    }
  }

  if (isLoading) return (
    <div className="animate-pulse space-y-4">
      {Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-12 bg-gray-100 rounded-xl" />)}
    </div>
  );

  const primary = String(form.primaryColor ?? "#E84821");
  const accent = String(form.accentColor ?? "#1C1917");
  const bg = String(form.backgroundColor ?? "#ffffff");
  const font = String(form.fontFamily ?? "Inter");

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-[#1C1917]">Settings</h1>
        <p className="text-gray-500 text-sm mt-1">Configure your website settings</p>
      </div>

      <div className="flex gap-8">
        <div className="w-48 flex-shrink-0">
          <nav className="space-y-1">
            {tabs.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setTab(id)}
                className={`w-full flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${tab === id ? "bg-[#1C1917] text-white" : "text-gray-500 hover:bg-gray-100"}`}
              >
                <Icon size={16} />{label}
              </button>
            ))}
          </nav>
        </div>

        <div className="flex-1">
          <form onSubmit={handleSave}>
            <div className="bg-white rounded-2xl border border-gray-100 p-6 space-y-5">
              {tab === "general" && (
                <>
                  <h2 className="font-bold text-[#1C1917] text-sm uppercase tracking-wider">General Settings</h2>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Site Name</label>{field("siteName", "text", "CtrlA Tech Solutions")}</div>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Tagline</label>{field("tagline", "text", "Innovating the Future")}</div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Logo</label>
                    <div className="flex flex-col gap-2">
                      {form.logoUrl && (
                        <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg border border-gray-200">
                          <img src={String(form.logoUrl)} alt="Current logo" className="h-10 object-contain rounded" onError={e => (e.currentTarget.style.display = "none")} />
                          <span className="text-xs text-gray-500 truncate flex-1">{String(form.logoUrl)}</span>
                          <CheckCircle size={16} className="text-green-500 flex-shrink-0" />
                        </div>
                      )}
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={String(form.logoUrl ?? "")}
                          onChange={e => setForm(p => ({ ...p, logoUrl: e.target.value }))}
                          className="flex-1 border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50"
                          placeholder="https://... or /logo.png or upload →"
                        />
                        <button
                          type="button"
                          onClick={() => logoFileRef.current?.click()}
                          disabled={logoUploading}
                          className="flex items-center gap-2 px-3 py-2 bg-[#1C1917] text-white rounded-lg text-sm font-semibold hover:bg-[#E84821] transition-colors disabled:opacity-50 whitespace-nowrap"
                        >
                          {logoUploading ? "Uploading…" : <><Upload size={14} /> Upload</>}
                        </button>
                        <input ref={logoFileRef} type="file" className="hidden"
                          accept="image/*"
                          onChange={e => { const f = e.target.files?.[0]; if (f) handleLogoUpload(f); }} />
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Favicon</label>
                    <div className="flex flex-col gap-2">
                      {form.faviconUrl && (
                        <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg border border-gray-200">
                          <img src={String(form.faviconUrl)} alt="Current favicon" className="h-8 w-8 object-contain rounded" onError={e => (e.currentTarget.style.display = "none")} />
                          <span className="text-xs text-gray-500 truncate flex-1">{String(form.faviconUrl)}</span>
                          <CheckCircle size={16} className="text-green-500 flex-shrink-0" />
                        </div>
                      )}
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={String(form.faviconUrl ?? "")}
                          onChange={e => setForm(p => ({ ...p, faviconUrl: e.target.value }))}
                          className="flex-1 border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50"
                          placeholder="https://... or /favicon.ico or upload →"
                        />
                        <button
                          type="button"
                          onClick={() => faviconFileRef.current?.click()}
                          disabled={faviconUploading}
                          className="flex items-center gap-2 px-3 py-2 bg-[#1C1917] text-white rounded-lg text-sm font-semibold hover:bg-[#E84821] transition-colors disabled:opacity-50 whitespace-nowrap"
                        >
                          {faviconUploading ? "Uploading…" : <><Upload size={14} /> Upload</>}
                        </button>
                        <input ref={faviconFileRef} type="file" className="hidden"
                          accept="image/*"
                          onChange={e => { const f = e.target.files?.[0]; if (f) handleFaviconUpload(f); }} />
                      </div>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Support Login URL</label>
                    <p className="text-xs text-gray-400 mb-1">Shown as a "Support Login" button in the navigation bar. Leave blank to hide.</p>
                    {field("supportLoginUrl", "url", "https://support.yourcompany.com/login")}
                  </div>
                </>
              )}
              {tab === "colors" && (
                <>
                  <h2 className="font-bold text-[#1C1917] text-sm uppercase tracking-wider">Colors & Typography</h2>
                  {colorField("primaryColor", "Primary Color (Teal)")}
                  {colorField("accentColor", "Accent Color (Navy)")}
                  {colorField("backgroundColor", "Background Color")}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Font Family</label>
                    <select
                      value={String(form.fontFamily ?? "Inter")}
                      onChange={e => setForm(p => ({ ...p, fontFamily: e.target.value }))}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50"
                    >
                      {["Inter", "Poppins", "Roboto", "Open Sans", "Lato", "Montserrat", "Nunito"].map(f => <option key={f} value={f}>{f}</option>)}
                    </select>
                  </div>

                  <div className="mt-4 rounded-2xl border border-gray-200 overflow-hidden">
                    <div className="px-4 py-2 bg-gray-50 border-b border-gray-200 text-xs font-medium text-gray-500 uppercase tracking-wider">Live Preview</div>
                    <div style={{ backgroundColor: bg, fontFamily: font }} className="p-6">
                      <div style={{ backgroundColor: accent }} className="rounded-xl p-4 mb-4">
                        <p style={{ color: primary }} className="text-xs font-semibold uppercase tracking-wider mb-1">India's Premier Tech Partner</p>
                        <h3 className="text-white text-lg font-bold mb-2">Innovating the Future</h3>
                        <button style={{ backgroundColor: primary, color: accent }} className="px-4 py-2 rounded-lg text-sm font-bold">Get Started</button>
                      </div>
                      <div style={{ borderColor: primary + "40" }} className="border rounded-xl p-4">
                        <div style={{ backgroundColor: primary + "20", color: primary }} className="text-xs font-semibold px-2 py-0.5 rounded w-fit mb-2">Service</div>
                        <p style={{ color: accent }} className="font-bold text-sm mb-1">Web Development</p>
                        <p className="text-gray-500 text-xs">Custom solutions built with modern tech.</p>
                      </div>
                    </div>
                  </div>
                </>
              )}
              {tab === "contact" && (
                <>
                  <h2 className="font-bold text-[#1C1917] text-sm uppercase tracking-wider">Contact Information</h2>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Contact Email</label>{field("contactEmail", "email", "info@company.com")}</div>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Contact Phone (India)</label>{field("contactPhone", "tel", "+91-9310775007")}</div>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Contact Phone 2 (UK / Secondary)</label>{field("contactPhone2", "tel", "+44-7557035271")}</div>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Address</label>{field("address", "text", "India & United Kingdom")}</div>
                </>
              )}
              {tab === "social" && (
                <>
                  <h2 className="font-bold text-[#1C1917] text-sm uppercase tracking-wider">Social Media Links</h2>
                  <p className="text-xs text-gray-500">These links appear in the website footer. Leave blank to hide.</p>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-[#0077B5] rounded-lg flex items-center justify-center flex-shrink-0">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="white"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>
                      </div>
                      <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-700 mb-1">LinkedIn</label>
                        {field("linkedinUrl", "url", "https://linkedin.com/company/ctrla")}
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-black rounded-lg flex items-center justify-center flex-shrink-0">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="white"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                      </div>
                      <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-700 mb-1">X (Twitter)</label>
                        {field("twitterUrl", "url", "https://x.com/ctrlatech")}
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-[#1877F2] rounded-lg flex items-center justify-center flex-shrink-0">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="white"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
                      </div>
                      <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-700 mb-1">Facebook</label>
                        {field("facebookUrl", "url", "https://facebook.com/ctrlatech")}
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: "linear-gradient(135deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%)" }}>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="white"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" fill="none" stroke="white" strokeWidth="1.5"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5" stroke="white" strokeWidth="1.5"/></svg>
                      </div>
                      <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-700 mb-1">Instagram</label>
                        {field("instagramUrl", "url", "https://instagram.com/ctrlatech")}
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-[#FF0000] rounded-lg flex items-center justify-center flex-shrink-0">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="white"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46a2.78 2.78 0 0 0-1.95 1.96A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.41 19.1C5.12 19.56 12 19.56 12 19.56s6.88 0 8.59-.46a2.78 2.78 0 0 0 1.95-1.95 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z"/><polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02" fill="#FF0000"/></svg>
                      </div>
                      <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-700 mb-1">YouTube</label>
                        {field("youtubeUrl", "url", "https://youtube.com/@ctrlatech")}
                      </div>
                    </div>
                  </div>
                </>
              )}
              {tab === "smtp" && (
                <>
                  <h2 className="font-bold text-[#1C1917] text-sm uppercase tracking-wider">SMTP Email Configuration</h2>
                  <p className="text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">SMTP password is encrypted before storage. The masked value (••••••••) is shown when a password is set.</p>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">SMTP Host</label>{field("smtpHost", "text", "smtp.gmail.com")}</div>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">SMTP Port</label>{field("smtpPort", "number", "587")}</div>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">SMTP Username</label>{field("smtpUser", "text", "user@gmail.com")}</div>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">SMTP Password</label>{field("smtpPassword", "password", "••••••••")}</div>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">From Address</label>{field("smtpFrom", "email", "noreply@company.com")}</div>
                </>
              )}
              {tab === "sms" && (
                <>
                  <h2 className="font-bold text-[#1C1917] text-sm uppercase tracking-wider">SMS Configuration</h2>
                  <p className="text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">SMS API key is encrypted before storage. The masked value (••••••••) is shown when a key is set.</p>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">SMS Provider</label>
                    <select
                      value={String(form.smsProvider ?? "")}
                      onChange={e => setForm(p => ({ ...p, smsProvider: e.target.value }))}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50"
                    >
                      <option value="">— Select provider —</option>
                      <option value="twilio">Twilio</option>
                      <option value="msg91">MSG91</option>
                      <option value="textlocal">Textlocal</option>
                      <option value="fast2sms">Fast2SMS</option>
                    </select>
                  </div>
                  {String(form.smsProvider ?? "") === "twilio" && (
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">Twilio Account SID</label>{field("smsAccountSid", "text", "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")}</div>
                  )}
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">API Key / Auth Token</label>{field("smsApiKey", "password", "••••••••")}</div>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Sender ID / From Number</label>{field("smsSenderId", "text", "CTRLA or +91XXXXXXXXXX")}</div>
                  <p className="text-xs text-gray-400">Used by bulk SMS campaigns and transactional alerts. Twilio also requires the Account SID.</p>
                </>
              )}
              {tab === "whatsapp" && (
                <>
                  <h2 className="font-bold text-[#1C1917] text-sm uppercase tracking-wider">WhatsApp — Floating Widget</h2>
                  <p className="text-xs text-gray-500">Public widget that opens a wa.me link with your greeting.</p>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">WhatsApp Number (with country code, no +)</label>{field("whatsappNumber", "text", "919876543210")}</div>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Greeting Message</label>{field("whatsappGreeting", "text", "Hello! How can we help?")}</div>

                  <hr className="my-4 border-gray-200" />
                  <h2 className="font-bold text-[#1C1917] text-sm uppercase tracking-wider">WhatsApp — Bulk Sending</h2>
                  <p className="text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
                    Choose a provider for outbound campaigns. Tokens are encrypted before storage.
                    Leave provider as <b>Click-through link (wa.me)</b> to skip API integration — campaigns will produce one wa.me link per recipient.
                  </p>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Provider</label>
                    <select
                      value={String(form.whatsappProvider ?? "")}
                      onChange={e => setForm(p => ({ ...p, whatsappProvider: e.target.value }))}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50"
                    >
                      <option value="">Click-through link (wa.me) — no API needed</option>
                      <option value="twilio">Twilio WhatsApp</option>
                      <option value="meta">Meta WhatsApp Business Cloud API</option>
                    </select>
                  </div>

                  {String(form.whatsappProvider ?? "") === "twilio" && (
                    <>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Twilio Account SID</label>{field("whatsappAccountSid", "text", "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")}</div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Twilio Auth Token</label>{field("whatsappAuthToken", "password", "••••••••")}</div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Twilio WhatsApp From Number</label>{field("whatsappFromNumber", "text", "+14155238886 (or whatsapp:+14155238886)")}</div>
                    </>
                  )}
                  {String(form.whatsappProvider ?? "") === "meta" && (
                    <>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Meta Phone Number ID</label>{field("whatsappPhoneNumberId", "text", "1234567890")}</div>
                      <div><label className="block text-sm font-medium text-gray-700 mb-1">Meta Permanent Access Token</label>{field("whatsappAccessToken", "password", "••••••••")}</div>
                    </>
                  )}
                </>
              )}
              {tab === "ai" && (
                <>
                  <h2 className="font-bold text-[#1C1917] text-sm uppercase tracking-wider">AI Providers</h2>
                  <p className="text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
                    Add your own API keys for each AI provider. Keys are encrypted at rest. Leave a key blank to disable that provider.
                    Usage is tracked in <b>Usage & Analytics</b>.
                  </p>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Default Provider</label>
                    <select
                      value={String(form.defaultAiProvider ?? "openai")}
                      onChange={e => setForm(p => ({ ...p, defaultAiProvider: e.target.value }))}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50"
                    >
                      <option value="openai">OpenAI</option>
                      <option value="anthropic">Anthropic (Claude)</option>
                      <option value="gemini">Google Gemini</option>
                      <option value="openrouter">OpenRouter</option>
                    </select>
                  </div>

                  <div className="rounded-xl border border-gray-200 p-4 space-y-3">
                    <h3 className="font-semibold text-[#1C1917] text-sm flex items-center gap-2"><Sparkles size={14} className="text-emerald-600" /> OpenAI</h3>
                    <div><label className="block text-xs font-medium text-gray-600 mb-1">API Key</label>{field("openaiApiKey", "password", "sk-...")}</div>
                    <div className="grid grid-cols-2 gap-3">
                      <div><label className="block text-xs font-medium text-gray-600 mb-1">Default Model</label>{field("openaiModel", "text", "gpt-4o-mini")}</div>
                      <div><label className="block text-xs font-medium text-gray-600 mb-1">Base URL (optional)</label>{field("openaiBaseUrl", "url", "https://api.openai.com/v1")}</div>
                    </div>
                  </div>

                  <div className="rounded-xl border border-gray-200 p-4 space-y-3">
                    <h3 className="font-semibold text-[#1C1917] text-sm flex items-center gap-2"><Sparkles size={14} className="text-purple-600" /> Anthropic (Claude)</h3>
                    <div><label className="block text-xs font-medium text-gray-600 mb-1">API Key</label>{field("anthropicApiKey", "password", "sk-ant-...")}</div>
                    <div className="grid grid-cols-2 gap-3">
                      <div><label className="block text-xs font-medium text-gray-600 mb-1">Default Model</label>{field("anthropicModel", "text", "claude-3-5-haiku-latest")}</div>
                      <div><label className="block text-xs font-medium text-gray-600 mb-1">Base URL (optional)</label>{field("anthropicBaseUrl", "url", "https://api.anthropic.com/v1")}</div>
                    </div>
                  </div>

                  <div className="rounded-xl border border-gray-200 p-4 space-y-3">
                    <h3 className="font-semibold text-[#1C1917] text-sm flex items-center gap-2"><Sparkles size={14} className="text-blue-600" /> Google Gemini</h3>
                    <div><label className="block text-xs font-medium text-gray-600 mb-1">API Key</label>{field("geminiApiKey", "password", "AIza...")}</div>
                    <div className="grid grid-cols-2 gap-3">
                      <div><label className="block text-xs font-medium text-gray-600 mb-1">Default Model</label>{field("geminiModel", "text", "gemini-1.5-flash")}</div>
                      <div><label className="block text-xs font-medium text-gray-600 mb-1">Base URL (optional)</label>{field("geminiBaseUrl", "url", "https://generativelanguage.googleapis.com/v1beta")}</div>
                    </div>
                  </div>

                  <div className="rounded-xl border border-gray-200 p-4 space-y-3">
                    <h3 className="font-semibold text-[#1C1917] text-sm flex items-center gap-2"><Sparkles size={14} className="text-orange-600" /> OpenRouter</h3>
                    <div><label className="block text-xs font-medium text-gray-600 mb-1">API Key</label>{field("openrouterApiKey", "password", "sk-or-...")}</div>
                    <div className="grid grid-cols-2 gap-3">
                      <div><label className="block text-xs font-medium text-gray-600 mb-1">Default Model</label>{field("openrouterModel", "text", "openai/gpt-4o-mini")}</div>
                      <div><label className="block text-xs font-medium text-gray-600 mb-1">Base URL (optional)</label>{field("openrouterBaseUrl", "url", "https://openrouter.ai/api/v1")}</div>
                    </div>
                  </div>
                </>
              )}
              {tab === "analytics" && (
                <>
                  <h2 className="font-bold text-[#1C1917] text-sm uppercase tracking-wider">Analytics</h2>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Google Analytics ID (GA4)</label>{field("gaId", "text", "G-XXXXXXXXXX")}</div>
                  <p className="text-xs text-gray-400">Enter your GA4 Measurement ID to enable Google Analytics tracking on the website.</p>
                </>
              )}
              {tab === "chatbot" && (
                <>
                  <h2 className="font-bold text-[#1C1917] text-sm uppercase tracking-wider">AI Chatbot</h2>
                  <p className="text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">The chatbot API key is encrypted before storage.</p>
                  {checkbox("chatbotEnabled", "Enable Chatbot")}
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Bot Name</label>{field("chatbotName", "text", "CtrlA Bot")}</div>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">Greeting Message</label>{field("chatbotGreeting", "text", "Hi! How can I assist you?")}</div>
                  <div><label className="block text-sm font-medium text-gray-700 mb-1">AI API Key (OpenAI / Gemini / etc.)</label>{field("chatbotApiKey", "password", "••••••••")}</div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">AI Model</label>
                    {field("chatbotModel", "text", "e.g. gpt-4o-mini, gemini-1.5-flash")}
                    <p className="text-xs text-gray-400 mt-1">Leave blank to use the default model for your provider (gpt-4o-mini for OpenAI, gemini-1.5-flash for Gemini).</p>
                  </div>
                  <p className="text-xs text-gray-400">Provide an AI provider API key to enable intelligent responses. Leave blank to use FAQ-based responses.</p>
                </>
              )}
            </div>

            <div className="mt-4 flex justify-end">
              <button type="submit" disabled={updateSettings.isPending} className="flex items-center gap-2 bg-[#1C1917] text-white px-6 py-3 rounded-xl font-semibold hover:bg-[#E84821] hover:text-[#1C1917] transition-all disabled:opacity-60">
                <Save size={16} /> {updateSettings.isPending ? "Saving..." : "Save Settings"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
