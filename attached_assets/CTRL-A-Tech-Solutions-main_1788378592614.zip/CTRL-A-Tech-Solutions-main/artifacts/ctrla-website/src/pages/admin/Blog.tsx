import { useState, useRef } from "react";
import { Plus, Edit2, Trash2, Eye, EyeOff, FolderOpen, Upload, Loader2 } from "lucide-react";
import RichTextEditor from "@/components/RichTextEditor";
import { MediaPickerModal } from "@/components/admin/MediaPickerModal";
import { useToast } from "@/hooks/use-toast";
import { useListBlogPosts, useCreateBlogPost, useUpdateBlogPost, useDeleteBlogPost, useListBlogCategories, useCreateBlogCategory, useCreateMedia } from "@/lib/apiClient";
import { useQueryClient } from "@tanstack/react-query";
import { getToken } from "@/lib/auth";

const base = (import.meta.env.BASE_URL ?? "/").replace(/\/$/, "");

type Post = { id: number; title: string; slug: string; content: string; excerpt?: string | null; featuredImage?: string | null; categoryId?: number | null; isPublished: boolean; metaTitle?: string | null; metaDescription?: string | null };
const emptyForm = { title: "", slug: "", content: "", excerpt: "", featuredImage: "", categoryId: null as number | null, isPublished: false, metaTitle: "", metaDescription: "" };

function generateSlug(title: string) {
  return title.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
}

export default function AdminBlog() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const { data: posts, isLoading } = useListBlogPosts();
  const { data: categories } = useListBlogCategories();
  const createPost = useCreateBlogPost();
  const updatePost = useUpdateBlogPost();
  const deletePost = useDeleteBlogPost();
  const createCat = useCreateBlogCategory();
  const createMedia = useCreateMedia();

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Post | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [showMediaPicker, setShowMediaPicker] = useState(false);
  const [newCat, setNewCat] = useState("");
  const [imgUploading, setImgUploading] = useState(false);
  const imgInputRef = useRef<HTMLInputElement>(null);

  async function handleDirectImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = "";
    setImgUploading(true);
    try {
      const urlRes = await fetch(`${base}/api/storage/uploads/request-url`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken()}` },
        body: JSON.stringify({ name: file.name, size: file.size, contentType: file.type }),
      });
      if (!urlRes.ok) throw new Error("Failed to get upload URL");
      const { uploadURL, objectPath } = await urlRes.json();
      const putRes = await fetch(uploadURL, { method: "PUT", body: file, headers: { "Content-Type": file.type } });
      if (!putRes.ok) throw new Error("Upload failed");
      await createMedia.mutateAsync({ data: { filename: file.name, objectPath, mimeType: file.type, size: file.size, altText: file.name } });
      await qc.invalidateQueries();
      const imageUrl = `${base}/api/storage/objects/${(objectPath as string).replace(/^\/objects\//, "")}`;
      setForm(p => ({ ...p, featuredImage: imageUrl }));
      toast({ title: "Image uploaded successfully" });
    } catch {
      toast({ title: "Upload failed", variant: "destructive" });
    } finally {
      setImgUploading(false);
    }
  }

  function openCreate() { setEditing(null); setForm(emptyForm); setShowForm(true); }
  function openEdit(post: Post) {
    setEditing(post);
    setForm({ title: post.title, slug: post.slug, content: post.content, excerpt: post.excerpt ?? "", featuredImage: post.featuredImage ?? "", categoryId: post.categoryId ?? null, isPublished: post.isPublished, metaTitle: post.metaTitle ?? "", metaDescription: post.metaDescription ?? "" });
    setShowForm(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const data = { ...form, excerpt: form.excerpt || null, featuredImage: form.featuredImage || null, metaTitle: form.metaTitle || null, metaDescription: form.metaDescription || null };
    if (editing) {
      await updatePost.mutateAsync({ id: editing.id, data }, { onSuccess: () => { toast({ title: "Post updated" }); qc.invalidateQueries(); setShowForm(false); }, onError: () => toast({ title: "Error", variant: "destructive" }) });
    } else {
      await createPost.mutateAsync({ data }, { onSuccess: () => { toast({ title: "Post created" }); qc.invalidateQueries(); setShowForm(false); }, onError: () => toast({ title: "Error", variant: "destructive" }) });
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this post?")) return;
    await deletePost.mutateAsync({ id }, { onSuccess: () => { toast({ title: "Post deleted" }); qc.invalidateQueries(); } });
  }

  async function handleAddCategory(e: React.FormEvent) {
    e.preventDefault();
    if (!newCat) return;
    await createCat.mutateAsync({ data: { name: newCat, slug: generateSlug(newCat) } }, { onSuccess: () => { toast({ title: "Category added" }); qc.invalidateQueries(); setNewCat(""); } });
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-[#1C1917]">Blog</h1>
          <p className="text-gray-500 text-sm mt-1">Manage blog posts and categories</p>
        </div>
        <button onClick={openCreate} className="flex items-center gap-2 bg-[#1C1917] text-white px-4 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#E84821] hover:text-[#1C1917] transition-all">
          <Plus size={16} /> New Post
        </button>
      </div>

      <div className="mb-6 p-4 bg-white rounded-xl border border-gray-100">
        <h3 className="font-medium text-sm text-gray-700 mb-3">Categories</h3>
        <div className="flex flex-wrap gap-2 mb-3">
          {categories?.map(cat => (
            <span key={cat.id} className="bg-[#E84821]/10 text-[#E84821] text-xs px-3 py-1 rounded-full font-medium">{cat.name}</span>
          ))}
        </div>
        <form onSubmit={handleAddCategory} className="flex gap-2">
          <input value={newCat} onChange={e => setNewCat(e.target.value)} placeholder="New category name" className="border border-gray-200 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50 flex-1" />
          <button type="submit" className="bg-[#1C1917] text-white px-4 py-1.5 rounded-lg text-sm font-medium hover:bg-[#E84821] hover:text-[#1C1917] transition-all">Add</button>
        </form>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b"><h2 className="font-bold text-[#1C1917]">{editing ? "Edit Post" : "New Post"}</h2></div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Title *</label>
                  <input required value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value, slug: p.slug || generateSlug(e.target.value) }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Slug *</label>
                  <input required value={form.slug} onChange={e => setForm(p => ({ ...p, slug: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Excerpt</label>
                <textarea rows={2} value={form.excerpt} onChange={e => setForm(p => ({ ...p, excerpt: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Content</label>
                <RichTextEditor value={form.content} onChange={html => setForm(p => ({ ...p, content: html }))} placeholder="Post content…" minHeight="220px" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Featured Image</label>
                  <div className="flex gap-2">
                    <input value={form.featuredImage} onChange={e => setForm(p => ({ ...p, featuredImage: e.target.value }))} className="flex-1 border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50" placeholder="Paste URL or use buttons →" />
                    <input ref={imgInputRef} type="file" accept="image/*" className="hidden" onChange={handleDirectImageUpload} />
                    <button type="button" onClick={() => imgInputRef.current?.click()} disabled={imgUploading} className="flex items-center gap-1.5 px-3 py-2 text-sm font-semibold text-white rounded-lg disabled:opacity-60 whitespace-nowrap" style={{ backgroundColor: "#E84821" }}>
                      {imgUploading ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />}
                      {imgUploading ? "Uploading…" : "Upload"}
                    </button>
                    <button type="button" onClick={() => setShowMediaPicker(true)} className="flex items-center gap-1.5 px-3 py-2 text-sm border border-gray-200 rounded-lg text-gray-600 hover:bg-gray-50 hover:border-[#E84821] transition-all whitespace-nowrap">
                      <FolderOpen size={15} /> Library
                    </button>
                  </div>
                  {form.featuredImage && (
                    <img src={form.featuredImage} alt="Featured" className="mt-2 h-20 rounded-lg object-cover border border-gray-200" onError={e => { (e.target as HTMLImageElement).style.display = "none"; }} />
                  )}
                  {showMediaPicker && (
                    <MediaPickerModal onSelect={url => setForm(p => ({ ...p, featuredImage: url }))} onClose={() => setShowMediaPicker(false)} />
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                  <select value={form.categoryId ?? ""} onChange={e => setForm(p => ({ ...p, categoryId: e.target.value ? Number(e.target.value) : null }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50">
                    <option value="">No category</option>
                    {categories?.map(cat => <option key={cat.id} value={cat.id}>{cat.name}</option>)}
                  </select>
                </div>
              </div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={form.isPublished} onChange={e => setForm(p => ({ ...p, isPublished: e.target.checked }))} className="rounded" />
                <span className="text-sm text-gray-700">Published</span>
              </label>
              <div className="flex gap-3 pt-2">
                <button type="submit" className="bg-[#1C1917] text-white px-6 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#E84821] hover:text-[#1C1917] transition-all">Save Post</button>
                <button type="button" onClick={() => setShowForm(false)} className="border border-gray-200 text-gray-600 px-6 py-2.5 rounded-xl text-sm font-semibold hover:bg-gray-50 transition-all">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isLoading ? (
        <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-16 bg-gray-100 rounded-xl animate-pulse" />)}</div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                <th className="text-left px-6 py-4 font-medium text-gray-500">Title</th>
                <th className="text-left px-6 py-4 font-medium text-gray-500">Slug</th>
                <th className="text-left px-6 py-4 font-medium text-gray-500">Status</th>
                <th className="text-right px-6 py-4 font-medium text-gray-500">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {posts?.map(post => (
                <tr key={post.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 font-medium text-[#1C1917]">{post.title}</td>
                  <td className="px-6 py-4 text-gray-500 font-mono text-xs">{post.slug}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${post.isPublished ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                      {post.isPublished ? <Eye size={10} /> : <EyeOff size={10} />}
                      {post.isPublished ? "Published" : "Draft"}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center gap-2 justify-end">
                      <button onClick={() => openEdit(post as Post)} className="p-2 hover:bg-[#E84821]/10 rounded-lg text-gray-400 hover:text-[#E84821] transition-colors"><Edit2 size={14} /></button>
                      <button onClick={() => handleDelete(post.id)} className="p-2 hover:bg-red-50 rounded-lg text-gray-400 hover:text-red-500 transition-colors"><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))}
              {!posts?.length && <tr><td colSpan={4} className="px-6 py-12 text-center text-gray-400">No posts yet.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
