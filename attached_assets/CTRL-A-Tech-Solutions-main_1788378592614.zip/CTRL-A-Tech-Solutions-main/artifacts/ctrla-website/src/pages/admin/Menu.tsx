import { useState } from "react";
import { Plus, Edit2, Trash2, GripVertical, ExternalLink, Eye, EyeOff } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useListMenuItems, useCreateMenuItem, useUpdateMenuItem, useDeleteMenuItem } from "@/lib/apiClient";
import { useQueryClient } from "@tanstack/react-query";
import {
  DndContext, closestCenter, KeyboardSensor, PointerSensor,
  useSensor, useSensors, type DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext, sortableKeyboardCoordinates, useSortable,
  verticalListSortingStrategy, arrayMove,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

type Item = { id: number; label: string; url: string; sortOrder: number; openInNewTab: boolean; isVisible: boolean; pageId?: number | null };
const emptyForm = { label: "", url: "", openInNewTab: false };

const base = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";

function SortableRow({ item, onEdit, onDelete, onToggleVisibility }: { item: Item; onEdit: () => void; onDelete: () => void; onToggleVisibility: () => void }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: item.id });
  const style = { transform: CSS.Transform.toString(transform), transition, opacity: isDragging ? 0.5 : 1 };

  return (
    <tr ref={setNodeRef} style={style} className="hover:bg-gray-50 transition-colors">
      <td className="px-4 py-4 w-10 text-gray-300">
        <button {...attributes} {...listeners} className="cursor-grab active:cursor-grabbing touch-none p-1" title="Drag to reorder">
          <GripVertical size={16} />
        </button>
      </td>
      <td className="px-4 py-4 font-medium text-[#1C1917]">{item.label}</td>
      <td className="px-4 py-4 text-gray-500 font-mono text-xs">{item.url}</td>
      <td className="px-4 py-4">{item.openInNewTab && <ExternalLink size={14} className="text-[#D4920C]" />}</td>
      <td className="px-4 py-4">
        <button
          onClick={onToggleVisibility}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold transition-all ${
            item.isVisible ? "bg-emerald-50 text-emerald-600 hover:bg-emerald-100" : "bg-gray-100 text-gray-400 hover:bg-gray-200"
          }`}
          title={item.isVisible ? "Click to hide" : "Click to show"}
        >
          {item.isVisible ? <Eye size={12} /> : <EyeOff size={12} />}
          {item.isVisible ? "Visible" : "Hidden"}
        </button>
      </td>
      <td className="px-4 py-4 text-right">
        <div className="flex items-center gap-2 justify-end">
          <button onClick={onEdit} className="p-2 hover:bg-[#D4920C]/10 rounded-lg text-gray-400 hover:text-[#D4920C] transition-colors"><Edit2 size={14} /></button>
          <button onClick={onDelete} className="p-2 hover:bg-red-50 rounded-lg text-gray-400 hover:text-red-500 transition-colors"><Trash2 size={14} /></button>
        </div>
      </td>
    </tr>
  );
}

export default function AdminMenu() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const { data: items, isLoading } = useListMenuItems();
  const createItem = useCreateMenuItem();
  const updateItem = useUpdateMenuItem();
  const deleteItem = useDeleteMenuItem();

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Item | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [localItems, setLocalItems] = useState<Item[] | null>(null);

  const displayItems: Item[] = (localItems ?? items ?? []) as Item[];

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  function openCreate() { setEditing(null); setForm(emptyForm); setShowForm(true); }
  function openEdit(item: Item) {
    setEditing(item);
    setForm({ label: item.label, url: item.url, openInNewTab: item.openInNewTab });
    setShowForm(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const sortOrder = editing ? editing.sortOrder : displayItems.length;
    if (editing) {
      await updateItem.mutateAsync({ id: editing.id, data: { ...form, sortOrder: editing.sortOrder } }, {
        onSuccess: () => { toast({ title: "Item updated" }); qc.invalidateQueries(); setLocalItems(null); setShowForm(false); },
        onError: () => toast({ title: "Error", variant: "destructive" }),
      });
    } else {
      await createItem.mutateAsync({ data: { ...form, sortOrder } }, {
        onSuccess: () => { toast({ title: "Item created" }); qc.invalidateQueries(); setLocalItems(null); setShowForm(false); },
        onError: () => toast({ title: "Error", variant: "destructive" }),
      });
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this menu item?")) return;
    await deleteItem.mutateAsync({ id }, {
      onSuccess: () => { toast({ title: "Deleted" }); qc.invalidateQueries(); setLocalItems(null); },
    });
  }

  async function handleToggleVisibility(item: Item) {
    try {
      const token = localStorage.getItem("ctrla_admin_token");
      const res = await fetch(`${base}/api/admin/menu/${item.id}/visibility`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token ?? ""}` },
        body: JSON.stringify({ isVisible: !item.isVisible }),
      });
      if (!res.ok) throw new Error("Failed");
      toast({ title: item.isVisible ? "Menu item hidden" : "Menu item visible" });
      qc.invalidateQueries();
      setLocalItems(null);
    } catch {
      toast({ title: "Failed to update visibility", variant: "destructive" });
    }
  }

  async function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const oldIndex = displayItems.findIndex(i => i.id === active.id);
    const newIndex = displayItems.findIndex(i => i.id === over.id);
    const reordered = arrayMove(displayItems, oldIndex, newIndex);
    setLocalItems(reordered);
    try {
      const token = localStorage.getItem("ctrla_admin_token");
      const res = await fetch(`${base}/api/admin/menu/reorder`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token ?? ""}` },
        body: JSON.stringify({ ids: reordered.map(i => i.id) }),
      });
      if (!res.ok) throw new Error("Reorder failed");
      qc.invalidateQueries();
    } catch {
      toast({ title: "Failed to save new order", variant: "destructive" });
      setLocalItems(null);
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-[#1C1917]">Menu</h1>
          <p className="text-gray-500 text-sm mt-1">Drag to reorder · Toggle visibility · Edit or delete items.</p>
        </div>
        <button onClick={openCreate} className="flex items-center gap-2 bg-[#1C1917] text-white px-4 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#D4920C] transition-all">
          <Plus size={16} /> Add Item
        </button>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md">
            <div className="p-6 border-b"><h2 className="font-bold text-[#1C1917]">{editing ? "Edit Item" : "New Menu Item"}</h2></div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Label *</label>
                <input required value={form.label} onChange={e => setForm(p => ({ ...p, label: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/50" placeholder="e.g. Home" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">URL *</label>
                <input required value={form.url} onChange={e => setForm(p => ({ ...p, url: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/50" placeholder="/" />
              </div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={form.openInNewTab} onChange={e => setForm(p => ({ ...p, openInNewTab: e.target.checked }))} className="rounded" />
                <span className="text-sm text-gray-700">Open in new tab</span>
              </label>
              <div className="flex gap-3 pt-2">
                <button type="submit" className="bg-[#1C1917] text-white px-6 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#D4920C] transition-all">Save</button>
                <button type="button" onClick={() => setShowForm(false)} className="border border-gray-200 text-gray-600 px-6 py-2.5 rounded-xl text-sm font-semibold hover:bg-gray-50 transition-all">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isLoading ? (
        <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-16 bg-gray-100 rounded-xl animate-pulse" />)}</div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                <th className="px-4 py-4 w-10" />
                <th className="text-left px-4 py-4 font-medium text-gray-500">Label</th>
                <th className="text-left px-4 py-4 font-medium text-gray-500">URL</th>
                <th className="text-left px-4 py-4 font-medium text-gray-500">New Tab</th>
                <th className="text-left px-4 py-4 font-medium text-gray-500">Visibility</th>
                <th className="text-right px-4 py-4 font-medium text-gray-500">Actions</th>
              </tr>
            </thead>
            <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
              <SortableContext items={displayItems.map(i => i.id)} strategy={verticalListSortingStrategy}>
                <tbody className="divide-y divide-gray-50">
                  {displayItems.map(item => (
                    <SortableRow
                      key={item.id}
                      item={item}
                      onEdit={() => openEdit(item)}
                      onDelete={() => handleDelete(item.id)}
                      onToggleVisibility={() => handleToggleVisibility(item)}
                    />
                  ))}
                  {!displayItems.length && (
                    <tr><td colSpan={6} className="px-6 py-12 text-center text-gray-400">No menu items yet. Add one above.</td></tr>
                  )}
                </tbody>
              </SortableContext>
            </DndContext>
          </table>
        </div>
      )}
    </div>
  );
}
