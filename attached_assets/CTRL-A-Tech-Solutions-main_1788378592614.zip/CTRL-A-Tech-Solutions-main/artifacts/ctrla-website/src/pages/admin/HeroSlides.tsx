import { useState, useEffect } from "react";
import { Plus, Edit2, Trash2, GripVertical, Eye, EyeOff, Image, UploadCloud, FolderOpen, X, Settings2, Timer, Maximize2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import {
  DndContext, closestCenter, KeyboardSensor, PointerSensor,
  useSensor, useSensors, type DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext, sortableKeyboardCoordinates, useSortable,
  verticalListSortingStrategy, arrayMove,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { MediaPickerModal } from "@/components/admin/MediaPickerModal";

const base = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";

function BannerSettings() {
  const { toast } = useToast();
  const [height, setHeight] = useState(640);
  const [speed, setSpeed] = useState(5);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch(`${base}/api/public/site-config`)
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (data) {
          setHeight(data.bannerHeight ?? 640);
          setSpeed(Math.round((data.bannerSpeed ?? 5000) / 1000));
        }
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  async function handleSave() {
    setSaving(true);
    try {
      const token = localStorage.getItem("ctrla_admin_token") ?? "";
      const res = await fetch(`${base}/api/admin/settings`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ bannerHeight: height, bannerSpeed: speed * 1000 }),
      });
      if (!res.ok) throw new Error("Failed");
      toast({ title: "Banner settings saved" });
    } catch {
      toast({ title: "Failed to save banner settings", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <div className="h-36 bg-gray-50 rounded-2xl animate-pulse mb-8" />;

  return (
    <div className="bg-white rounded-2xl border border-gray-100 p-6 mb-8">
      <div className="flex items-center gap-2 mb-5">
        <Settings2 size={18} className="text-[#D4920C]" />
        <h2 className="font-bold text-[#1C1917] text-base">Banner Display Settings</h2>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        {/* Height */}
        <div>
          <label className="flex items-center gap-1.5 text-sm font-medium text-gray-700 mb-3">
            <Maximize2 size={14} className="text-gray-400" /> Banner Height
            <span className="ml-auto font-mono text-[#D4920C]">{height}px</span>
          </label>
          <input
            type="range"
            min={400}
            max={900}
            step={10}
            value={height}
            onChange={e => setHeight(Number(e.target.value))}
            className="w-full accent-[#D4920C]"
          />
          <div className="flex justify-between text-xs text-gray-400 mt-1">
            <span>400px</span><span>Compact ← → Tall</span><span>900px</span>
          </div>
        </div>
        {/* Speed */}
        <div>
          <label className="flex items-center gap-1.5 text-sm font-medium text-gray-700 mb-3">
            <Timer size={14} className="text-gray-400" /> Slide Interval
            <span className="ml-auto font-mono text-[#D4920C]">{speed}s</span>
          </label>
          <input
            type="range"
            min={2}
            max={15}
            step={1}
            value={speed}
            onChange={e => setSpeed(Number(e.target.value))}
            className="w-full accent-[#D4920C]"
          />
          <div className="flex justify-between text-xs text-gray-400 mt-1">
            <span>2s (Fast)</span><span>Auto-play delay</span><span>15s (Slow)</span>
          </div>
        </div>
      </div>
      <div className="mt-5 flex justify-end">
        <button
          onClick={handleSave}
          disabled={saving}
          className="bg-[#1C1917] text-white px-5 py-2 rounded-xl text-sm font-semibold hover:bg-[#D4920C] transition-all disabled:opacity-60"
        >
          {saving ? "Saving…" : "Save Settings"}
        </button>
      </div>
    </div>
  );
}

interface Slide {
  id: number;
  eyebrow: string | null;
  title: string;
  subtitle: string | null;
  imageUrl: string;
  ctaText: string | null;
  ctaUrl: string | null;
  stat1: string | null;
  stat2: string | null;
  stat3: string | null;
  badge: string | null;
  sortOrder: number;
  isActive: boolean;
}

const emptyForm = { eyebrow: "", title: "", subtitle: "", imageUrl: "", ctaText: "", ctaUrl: "", stat1: "", stat2: "", stat3: "", badge: "", isActive: true };

function getToken() { return localStorage.getItem("ctrla_admin_token") ?? ""; }

async function apiFetch(path: string, method: string, body?: unknown) {
  const res = await fetch(`${base}${path}`, {
    method,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken()}` },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  if (res.status === 204) return null;
  return res.json();
}

function SortableRow({ slide, onEdit, onDelete, onToggle }: { slide: Slide; onEdit: () => void; onDelete: () => void; onToggle: () => void }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: slide.id });
  const style = { transform: CSS.Transform.toString(transform), transition, opacity: isDragging ? 0.5 : 1 };

  return (
    <tr ref={setNodeRef} style={style} className="hover:bg-gray-50 transition-colors">
      <td className="px-4 py-3 w-10 text-gray-300">
        <button {...attributes} {...listeners} className="cursor-grab active:cursor-grabbing touch-none p-1" title="Drag to reorder">
          <GripVertical size={16} />
        </button>
      </td>
      <td className="px-4 py-3 w-20">
        <div className="w-16 h-10 rounded-lg overflow-hidden bg-gray-100 border border-gray-200">
          <img src={slide.imageUrl} alt={slide.title} className="w-full h-full object-cover" onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
        </div>
      </td>
      <td className="px-4 py-3">
        <div className="font-medium text-[#1C1917] text-sm leading-tight">{slide.title}</div>
        {slide.subtitle && <div className="text-xs text-gray-400 mt-0.5 truncate max-w-xs">{slide.subtitle}</div>}
      </td>
      <td className="px-4 py-3 text-gray-500 font-mono text-xs">{slide.ctaText || "—"}</td>
      <td className="px-4 py-3">
        <button onClick={onToggle} className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold transition-all ${slide.isActive ? "bg-emerald-50 text-emerald-600" : "bg-gray-100 text-gray-400"}`}>
          {slide.isActive ? <Eye size={12} /> : <EyeOff size={12} />}
          {slide.isActive ? "Active" : "Hidden"}
        </button>
      </td>
      <td className="px-4 py-3 text-right">
        <div className="flex items-center gap-2 justify-end">
          <button onClick={onEdit} className="p-2 hover:bg-[#D4920C]/10 rounded-lg text-gray-400 hover:text-[#D4920C] transition-colors"><Edit2 size={14} /></button>
          <button onClick={onDelete} className="p-2 hover:bg-red-50 rounded-lg text-gray-400 hover:text-red-500 transition-colors"><Trash2 size={14} /></button>
        </div>
      </td>
    </tr>
  );
}

export default function AdminHeroSlides() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [slides, setSlides] = useState<Slide[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Slide | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [showMediaPicker, setShowMediaPicker] = useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  async function load() {
    try {
      setLoading(true);
      const data = await apiFetch("/api/admin/slides", "GET");
      setSlides(data ?? []);
    } catch {
      toast({ title: "Failed to load slides", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  function openCreate() { setEditing(null); setForm(emptyForm); setShowForm(true); }
  function openEdit(s: Slide) {
    setEditing(s);
    setForm({ eyebrow: s.eyebrow ?? "", title: s.title, subtitle: s.subtitle ?? "", imageUrl: s.imageUrl, ctaText: s.ctaText ?? "", ctaUrl: s.ctaUrl ?? "", stat1: s.stat1 ?? "", stat2: s.stat2 ?? "", stat3: s.stat3 ?? "", badge: s.badge ?? "", isActive: s.isActive });
    setShowForm(true);
  }

  async function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const urlRes = await fetch(`${base}/api/storage/uploads/request-url`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken()}` },
        body: JSON.stringify({ name: file.name, size: file.size, contentType: file.type }),
      });
      if (!urlRes.ok) throw new Error("Failed to get upload URL");
      const { uploadURL, objectPath } = await urlRes.json();
      const putRes = await fetch(uploadURL, { method: "PUT", body: file, headers: { "Content-Type": file.type } });
      if (!putRes.ok) throw new Error("Upload failed");
      const imageUrl = `${base}/api/storage/objects/${(objectPath as string).replace(/^\/objects\//, "")}`;
      setForm(p => ({ ...p, imageUrl }));
      toast({ title: "Image uploaded" });
    } catch {
      toast({ title: "Upload failed", description: "Could not upload the image. Please try again.", variant: "destructive" });
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const payload = { ...form, eyebrow: form.eyebrow || null, subtitle: form.subtitle || null, ctaText: form.ctaText || null, ctaUrl: form.ctaUrl || null, stat1: form.stat1 || null, stat2: form.stat2 || null, stat3: form.stat3 || null, badge: form.badge || null };
    try {
      if (editing) {
        await apiFetch(`/api/admin/slides/${editing.id}`, "PATCH", payload);
        toast({ title: "Slide updated" });
      } else {
        await apiFetch("/api/admin/slides", "POST", { ...payload, sortOrder: slides.length });
        toast({ title: "Slide created" });
      }
      await load();
      qc.invalidateQueries();
      setShowForm(false);
    } catch {
      toast({ title: "Error saving slide", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this slide?")) return;
    try {
      await apiFetch(`/api/admin/slides/${id}`, "DELETE");
      toast({ title: "Slide deleted" });
      await load();
    } catch {
      toast({ title: "Error deleting slide", variant: "destructive" });
    }
  }

  async function handleToggle(slide: Slide) {
    try {
      await apiFetch(`/api/admin/slides/${slide.id}`, "PATCH", { isActive: !slide.isActive });
      await load();
    } catch {
      toast({ title: "Error updating slide", variant: "destructive" });
    }
  }

  async function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const oldIdx = slides.findIndex(s => s.id === active.id);
    const newIdx = slides.findIndex(s => s.id === over.id);
    const reordered = arrayMove(slides, oldIdx, newIdx);
    setSlides(reordered);
    try {
      await apiFetch("/api/admin/slides/reorder", "PUT", { ids: reordered.map(s => s.id) });
    } catch {
      toast({ title: "Failed to save order", variant: "destructive" });
      await load();
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-[#1C1917]">Hero Slides</h1>
          <p className="text-gray-500 text-sm mt-1">Manage the homepage banner slideshow. Drag to reorder.</p>
        </div>
        <button onClick={openCreate} className="flex items-center gap-2 bg-[#1C1917] text-white px-4 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#D4920C] transition-all">
          <Plus size={16} /> Add Slide
        </button>
      </div>

      <BannerSettings />

      {/* Slide form modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg max-h-[92vh] overflow-y-auto">
            <div className="p-6 border-b flex items-center justify-between">
              <h2 className="font-bold text-[#1C1917]">{editing ? "Edit Slide" : "New Slide"}</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-600 transition-colors">
                <X size={18} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {/* Eyebrow pill — Section 1 */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Eyebrow Label <span className="text-xs text-gray-400 font-normal">(small pill above headline)</span>
                </label>
                <input value={form.eyebrow} onChange={e => setForm(p => ({ ...p, eyebrow: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/50" placeholder="e.g. India & UK Technology Partner" />
              </div>

              {/* Title — Section 2 */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title *</label>
                <input required value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/50" placeholder="Slide headline" />
              </div>

              {/* Subtitle — Section 3 */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Subtitle</label>
                <textarea rows={2} value={form.subtitle} onChange={e => setForm(p => ({ ...p, subtitle: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/50 resize-none" placeholder="Supporting text" />
              </div>

              {/* Image — upload, media picker, or URL */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Banner Image *</label>

                {/* Upload + Media picker buttons */}
                <div className="flex gap-2 mb-3">
                  <label className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold border cursor-pointer transition-all ${uploading ? "opacity-60 cursor-not-allowed border-gray-200 text-gray-400" : "border-[#D4920C]/50 text-[#D4920C] hover:bg-amber-50"}`}>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      disabled={uploading}
                      onChange={handleImageUpload}
                    />
                    <UploadCloud size={13} />
                    {uploading ? "Uploading…" : "Upload Image"}
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowMediaPicker(true)}
                    className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold border border-gray-200 text-gray-600 hover:border-[#D4920C]/50 hover:text-[#D4920C] hover:bg-amber-50 transition-all"
                  >
                    <FolderOpen size={13} /> Media Library
                  </button>
                </div>

                {/* URL input (manual / result of upload) */}
                <input
                  required
                  value={form.imageUrl}
                  onChange={e => setForm(p => ({ ...p, imageUrl: e.target.value }))}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/50"
                  placeholder="https://... or /image.jpg (auto-filled after upload)"
                />

                {/* Live preview */}
                {form.imageUrl && (
                  <div className="mt-2 h-28 rounded-xl overflow-hidden border border-gray-100 relative">
                    <img
                      src={form.imageUrl}
                      alt="Preview"
                      className="w-full h-full object-cover"
                      onError={e => { (e.target as HTMLImageElement).style.opacity = '0.2'; }}
                    />
                    <button
                      type="button"
                      onClick={() => setForm(p => ({ ...p, imageUrl: "" }))}
                      className="absolute top-1.5 right-1.5 bg-black/50 hover:bg-black/70 text-white rounded-full p-0.5 transition-colors"
                      title="Clear image"
                    >
                      <X size={12} />
                    </button>
                  </div>
                )}
              </div>

              {/* CTA */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">CTA Button Text</label>
                  <input value={form.ctaText} onChange={e => setForm(p => ({ ...p, ctaText: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/50" placeholder="Get Started" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">CTA Link</label>
                  <input value={form.ctaUrl} onChange={e => setForm(p => ({ ...p, ctaUrl: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/50" placeholder="/contact" />
                </div>
              </div>

              {/* Stats + Badge — Section 4 */}
              <div className="border border-gray-100 rounded-xl p-4 space-y-3 bg-gray-50/50">
                <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Section 4 — Stats &amp; Badge</p>
                <div className="grid grid-cols-1 gap-3">
                  <input value={form.stat1} onChange={e => setForm(p => ({ ...p, stat1: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/50 bg-white" placeholder="Stat 1 (e.g. 100+ Projects Delivered)" />
                  <input value={form.stat2} onChange={e => setForm(p => ({ ...p, stat2: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/50 bg-white" placeholder="Stat 2 (e.g. 24/7 Support)" />
                  <input value={form.stat3} onChange={e => setForm(p => ({ ...p, stat3: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/50 bg-white" placeholder="Stat 3 (e.g. Trusted by Businesses in India & UK)" />
                  <input value={form.badge} onChange={e => setForm(p => ({ ...p, badge: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4920C]/50 bg-white" placeholder="Badge text (e.g. Real teams. Real results.)" />
                </div>
                <p className="text-xs text-gray-400">Leave blank to show default values.</p>
              </div>

              {/* Active toggle */}
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={form.isActive} onChange={e => setForm(p => ({ ...p, isActive: e.target.checked }))} className="rounded w-4 h-4 accent-[#D4920C]" />
                <span className="text-sm text-gray-700">Active (visible on homepage)</span>
              </label>

              <div className="flex gap-3 pt-2">
                <button type="submit" disabled={saving || uploading} className="bg-[#1C1917] text-white px-6 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#D4920C] transition-all disabled:opacity-60">
                  {saving ? "Saving…" : "Save Slide"}
                </button>
                <button type="button" onClick={() => setShowForm(false)} className="border border-gray-200 text-gray-600 px-6 py-2.5 rounded-xl text-sm font-semibold hover:bg-gray-50 transition-all">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Media picker modal (z-[60] so it appears above slide form) */}
      {showMediaPicker && (
        <MediaPickerModal
          onSelect={(url) => {
            setForm(p => ({ ...p, imageUrl: url }));
            setShowMediaPicker(false);
          }}
          onClose={() => setShowMediaPicker(false)}
        />
      )}

      {loading ? (
        <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-16 bg-gray-100 rounded-xl animate-pulse" />)}</div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                <th className="px-4 py-4 w-10" />
                <th className="text-left px-4 py-4 font-medium text-gray-500">Preview</th>
                <th className="text-left px-4 py-4 font-medium text-gray-500">Title / Subtitle</th>
                <th className="text-left px-4 py-4 font-medium text-gray-500">CTA</th>
                <th className="text-left px-4 py-4 font-medium text-gray-500">Status</th>
                <th className="text-right px-4 py-4 font-medium text-gray-500">Actions</th>
              </tr>
            </thead>
            <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
              <SortableContext items={slides.map(s => s.id)} strategy={verticalListSortingStrategy}>
                <tbody className="divide-y divide-gray-50">
                  {slides.map(slide => (
                    <SortableRow key={slide.id} slide={slide} onEdit={() => openEdit(slide)} onDelete={() => handleDelete(slide.id)} onToggle={() => handleToggle(slide)} />
                  ))}
                  {!slides.length && (
                    <tr>
                      <td colSpan={6} className="px-6 py-16 text-center">
                        <Image size={40} className="mx-auto text-gray-200 mb-3" />
                        <p className="text-gray-400 text-sm">No slides yet. Add one above.</p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </SortableContext>
            </DndContext>
          </table>
        </div>
      )}
    </div>
  );
}
