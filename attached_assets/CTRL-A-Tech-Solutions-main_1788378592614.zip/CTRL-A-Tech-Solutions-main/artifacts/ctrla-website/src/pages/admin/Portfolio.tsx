import { useState } from "react";
import { Plus, Pencil, Trash2, Globe, Eye, EyeOff, FolderOpen } from "lucide-react";
import { MediaPickerModal } from "@/components/admin/MediaPickerModal";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListPortfolioItems,
  useCreatePortfolioItem,
  useUpdatePortfolioItem,
  useDeletePortfolioItem,
  getListPortfolioItemsQueryKey,
} from "@/lib/apiClient";
import type { PortfolioItem, CreatePortfolioBody } from "@workspace/api-client-react";
import RichTextEditor from "@/components/RichTextEditor";

type FormState = {
  title: string;
  slug: string;
  description: string;
  content: string;
  featuredImage: string;
  clientName: string;
  projectUrl: string;
  technologies: string;
  isPublished: boolean;
  sortOrder: number;
};

const emptyForm = (): FormState => ({
  title: "", slug: "", description: "", content: "",
  featuredImage: "",
  clientName: "", projectUrl: "", technologies: "",
  isPublished: false, sortOrder: 0,
});

function toSlug(t: string) {
  return t.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

export default function AdminPortfolio() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const { data: items = [], isLoading } = useListPortfolioItems();
  const createItem = useCreatePortfolioItem();
  const updateItem = useUpdatePortfolioItem();
  const deleteItem = useDeletePortfolioItem();

  const [editing, setEditing] = useState<PortfolioItem | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [form, setForm] = useState<FormState>(emptyForm());
  const [confirmDelete, setConfirmDelete] = useState<number | null>(null);
  const [showMediaPicker, setShowMediaPicker] = useState(false);

  const invalidate = () => qc.invalidateQueries({ queryKey: getListPortfolioItemsQueryKey() });

  function openNew() {
    setIsNew(true); setEditing(null); setForm(emptyForm());
  }

  function openEdit(item: PortfolioItem) {
    setIsNew(false); setEditing(item);
    setForm({
      title: item.title, slug: item.slug,
      description: item.description ?? "",
      content: item.content,
      featuredImage: item.featuredImage ?? "",
      clientName: item.clientName ?? "",
      projectUrl: item.projectUrl ?? "",
      technologies: item.technologies ?? "",
      isPublished: item.isPublished,
      sortOrder: item.sortOrder,
    });
  }

  function closeForm() { setEditing(null); setIsNew(false); }

  function f(key: keyof FormState, type: string = "text") {
    return (
      <input
        type={type}
        value={String(form[key])}
        onChange={e => setForm(p => ({ ...p, [key]: type === "number" ? +e.target.value : e.target.value }))}
        className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50"
      />
    );
  }

  async function handleSave() {
    const data: CreatePortfolioBody = {
      title: form.title,
      slug: form.slug || toSlug(form.title),
      description: form.description || null,
      content: form.content,
      featuredImage: form.featuredImage || null,
      clientName: form.clientName || null,
      projectUrl: form.projectUrl || null,
      technologies: form.technologies || null,
      isPublished: form.isPublished,
      sortOrder: form.sortOrder,
    };
    try {
      if (isNew) {
        await createItem.mutateAsync({ data });
        toast({ title: "Portfolio item created" });
      } else if (editing) {
        await updateItem.mutateAsync({ id: editing.id, data });
        toast({ title: "Portfolio item updated" });
      }
      invalidate(); closeForm();
    } catch {
      toast({ title: "Error saving item", variant: "destructive" });
    }
  }

  async function handleDelete(id: number) {
    try {
      await deleteItem.mutateAsync({ id });
      toast({ title: "Item deleted" });
      invalidate(); setConfirmDelete(null);
    } catch {
      toast({ title: "Error deleting item", variant: "destructive" });
    }
  }

  async function togglePublish(item: PortfolioItem) {
    await updateItem.mutateAsync({ id: item.id, data: { isPublished: !item.isPublished } });
    invalidate();
  }

  if (editing !== null || isNew) {
    return (
      <div>
        <div className="mb-6 flex items-center gap-4">
          <button onClick={closeForm} className="text-sm text-gray-500 hover:text-[#1C1917] flex items-center gap-1">← Back</button>
          <h1 className="text-2xl font-bold text-[#1C1917]">{isNew ? "New Portfolio Item" : "Edit Portfolio Item"}</h1>
        </div>
        <div className="bg-white rounded-2xl border border-gray-100 p-6 space-y-5">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Title *</label>
              <input type="text" value={form.title}
                onChange={e => setForm(p => ({ ...p, title: e.target.value, slug: p.slug || toSlug(e.target.value) }))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Slug *</label>
              {f("slug")}
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Short Description</label>
            {f("description")}
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Client Name</label>
              {f("clientName")}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Project URL</label>
              {f("projectUrl", "url")}
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Technologies (comma-separated)</label>
            {f("technologies")}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Featured Image</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={form.featuredImage}
                onChange={e => setForm(p => ({ ...p, featuredImage: e.target.value }))}
                placeholder="https://... or browse media library"
                className="flex-1 border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50"
              />
              <button type="button" onClick={() => setShowMediaPicker(true)} className="flex items-center gap-1.5 px-3 py-2.5 text-sm border border-gray-200 rounded-lg text-gray-600 hover:bg-gray-50 hover:border-[#E84821] transition-all whitespace-nowrap">
                <FolderOpen size={15} /> Browse
              </button>
            </div>
            {form.featuredImage && (
              <img src={form.featuredImage} alt="Featured preview" className="mt-2 h-20 rounded-lg object-cover border border-gray-200" onError={e => { (e.target as HTMLImageElement).style.display = "none"; }} />
            )}
            {showMediaPicker && (
              <MediaPickerModal onSelect={url => setForm(p => ({ ...p, featuredImage: url }))} onClose={() => setShowMediaPicker(false)} />
            )}
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Sort Order</label>
              {f("sortOrder", "number")}
            </div>
            <div className="flex items-end pb-1">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={form.isPublished} onChange={e => setForm(p => ({ ...p, isPublished: e.target.checked }))} className="rounded w-4 h-4 accent-[#E84821]" />
                <span className="text-sm text-gray-700">Published</span>
              </label>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Content</label>
            <RichTextEditor value={form.content} onChange={v => setForm(p => ({ ...p, content: v }))} />
          </div>
          <div className="flex gap-3 pt-2">
            <button onClick={handleSave} disabled={createItem.isPending || updateItem.isPending}
              className="bg-[#1C1917] text-white px-6 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#E84821] hover:text-[#1C1917] transition-all disabled:opacity-60">
              {createItem.isPending || updateItem.isPending ? "Saving..." : "Save Item"}
            </button>
            <button onClick={closeForm} className="px-6 py-2.5 rounded-xl text-sm font-semibold border border-gray-200 hover:bg-gray-50 transition-all">Cancel</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#1C1917]">Portfolio</h1>
          <p className="text-gray-500 text-sm mt-1">Manage case studies and portfolio items</p>
        </div>
        <button onClick={openNew} className="flex items-center gap-2 bg-[#1C1917] text-white px-5 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#E84821] hover:text-[#1C1917] transition-all">
          <Plus size={16} /> New Item
        </button>
      </div>

      {isLoading ? (
        <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-16 bg-gray-100 rounded-xl animate-pulse" />)}</div>
      ) : items.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-16 text-center">
          <p className="text-gray-400 mb-4">No portfolio items yet</p>
          <button onClick={openNew} className="text-sm text-[#E84821] font-medium hover:underline">Add your first item →</button>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-100">
                <th className="text-left px-6 py-3 text-gray-500 font-medium">Title</th>
                <th className="text-left px-6 py-3 text-gray-500 font-medium">Client</th>
                <th className="text-left px-6 py-3 text-gray-500 font-medium">Status</th>
                <th className="text-right px-6 py-3 text-gray-500 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map(item => (
                <tr key={item.id} className="border-b border-gray-50 last:border-0 hover:bg-gray-50/50">
                  <td className="px-6 py-4">
                    <div className="font-medium text-[#1C1917]">{item.title}</div>
                    <div className="text-gray-400 text-xs">{item.slug}</div>
                  </td>
                  <td className="px-6 py-4 text-gray-600">{item.clientName ?? "—"}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${item.isPublished ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                      {item.isPublished ? "Published" : "Draft"}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 justify-end">
                      {item.isPublished && (
                        <a href={`/portfolio/${item.slug}`} target="_blank" rel="noopener noreferrer" className="p-1.5 rounded-lg text-gray-400 hover:bg-gray-100 hover:text-[#E84821]">
                          <Globe size={15} />
                        </a>
                      )}
                      <button onClick={() => togglePublish(item)} className="p-1.5 rounded-lg text-gray-400 hover:bg-gray-100">
                        {item.isPublished ? <EyeOff size={15} /> : <Eye size={15} />}
                      </button>
                      <button onClick={() => openEdit(item)} className="p-1.5 rounded-lg text-gray-400 hover:bg-gray-100 hover:text-[#1C1917]">
                        <Pencil size={15} />
                      </button>
                      {confirmDelete === item.id ? (
                        <div className="flex gap-1">
                          <button onClick={() => handleDelete(item.id)} className="px-2 py-1 text-xs bg-red-500 text-white rounded-lg">Yes</button>
                          <button onClick={() => setConfirmDelete(null)} className="px-2 py-1 text-xs border border-gray-200 rounded-lg">No</button>
                        </div>
                      ) : (
                        <button onClick={() => setConfirmDelete(item.id)} className="p-1.5 rounded-lg text-gray-400 hover:bg-red-50 hover:text-red-500">
                          <Trash2 size={15} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
