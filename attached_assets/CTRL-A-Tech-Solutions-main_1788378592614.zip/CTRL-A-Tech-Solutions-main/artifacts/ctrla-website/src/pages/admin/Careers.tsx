import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { getToken } from "@/lib/auth";
import { Plus, Trash2, Edit2, Eye, X, Briefcase, MapPin, Clock, DollarSign, Users, CheckCircle, XCircle, ChevronDown, ChevronUp } from "lucide-react";

async function api(path: string, opts?: RequestInit) {
  const token = getToken();
  const res = await fetch(path, {
    ...opts,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}`, ...(opts?.headers ?? {}) },
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    let msg = txt;
    try { msg = JSON.parse(txt).error ?? txt; } catch { /* keep raw */ }
    throw new Error(msg || `HTTP ${res.status}`);
  }
  if (res.status === 204) return null;
  return res.json();
}

type Job = {
  id: number; title: string; department: string; location: string; type: string;
  description: string; requirements: string; salaryRange: string | null;
  isActive: boolean; sortOrder: number; createdAt: string;
};

type Application = {
  id: number; jobId: number; name: string; email: string; phone: string | null;
  coverLetter: string | null; cvObjectPath: string | null; cvFilename: string | null;
  status: string; notes: string | null; createdAt: string;
};

const JOB_TYPES = ["full-time", "part-time", "contract", "internship", "remote"];
const APP_STATUSES = ["new", "reviewing", "shortlisted", "rejected"];
const STATUS_COLORS: Record<string, string> = {
  new: "bg-blue-100 text-blue-700",
  reviewing: "bg-yellow-100 text-yellow-700",
  shortlisted: "bg-green-100 text-green-700",
  rejected: "bg-red-100 text-red-700",
};

export default function AdminCareers() {
  const [activeTab, setActiveTab] = useState<"jobs" | "applications">("jobs");
  const [showForm, setShowForm] = useState(false);
  const [editJob, setEditJob] = useState<Job | null>(null);
  const [viewApplications, setViewApplications] = useState<number | null>(null);

  const { data: jobs = [], isLoading } = useQuery<Job[]>({
    queryKey: ["admin-jobs"],
    queryFn: () => api("/api/admin/jobs"),
  });

  const { data: allApplications = [] } = useQuery<Application[]>({
    queryKey: ["admin-applications"],
    queryFn: () => api("/api/admin/applications"),
    enabled: activeTab === "applications",
  });

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-[#1A1F36] via-[#3D4FA0] to-[#E84821] rounded-2xl p-6 text-white">
        <div className="flex items-start gap-3">
          <div className="p-2.5 bg-white/15 rounded-xl"><Briefcase size={20} /></div>
          <div className="flex-1">
            <h1 className="font-bold text-xl">Careers Management</h1>
            <p className="text-white/75 text-sm mt-1">Create and manage job postings. Candidates can apply with their CV from your public careers page.</p>
          </div>
        </div>
      </div>

      <div className="flex gap-3">
        {(["jobs", "applications"] as const).map(t => (
          <button key={t} onClick={() => setActiveTab(t)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold capitalize transition-all ${activeTab === t ? "bg-[#1A1F36] text-white" : "bg-white text-gray-600 border border-gray-200 hover:border-gray-300"}`}>
            {t === "jobs" ? `Job Postings (${jobs.length})` : `All Applications (${allApplications.length})`}
          </button>
        ))}
        <div className="flex-1" />
        {activeTab === "jobs" && (
          <button onClick={() => { setEditJob(null); setShowForm(true); }}
            className="flex items-center gap-2 px-4 py-2 bg-[#E84821] text-white rounded-lg font-semibold text-sm hover:bg-[#c73d1a]">
            <Plus size={16} /> New Job
          </button>
        )}
      </div>

      {activeTab === "jobs" && (
        <JobsTab jobs={jobs} isLoading={isLoading}
          onEdit={(j) => { setEditJob(j); setShowForm(true); }}
          onViewApps={(id) => setViewApplications(id)} />
      )}
      {activeTab === "applications" && (
        <AllApplicationsTab applications={allApplications} jobs={jobs} />
      )}

      {showForm && (
        <JobForm job={editJob} onClose={() => setShowForm(false)} />
      )}
      {viewApplications !== null && (
        <ApplicationsModal jobId={viewApplications} jobs={jobs} onClose={() => setViewApplications(null)} />
      )}
    </div>
  );
}

function JobsTab({ jobs, isLoading, onEdit, onViewApps }: {
  jobs: Job[]; isLoading: boolean;
  onEdit: (j: Job) => void; onViewApps: (id: number) => void;
}) {
  const qc = useQueryClient();
  const { toast } = useToast();

  const toggleActive = useMutation({
    mutationFn: (j: Job) => api(`/api/admin/jobs/${j.id}`, { method: "PATCH", body: JSON.stringify({ isActive: !j.isActive }) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-jobs"] }),
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => api(`/api/admin/jobs/${id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin-jobs"] }); toast({ title: "Job deleted" }); },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  if (isLoading) return <div className="p-8 text-center text-gray-400">Loading…</div>;
  if (jobs.length === 0) return (
    <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
      <Briefcase size={40} className="mx-auto text-gray-300 mb-3" />
      <p className="text-gray-500 font-medium">No job postings yet</p>
      <p className="text-gray-400 text-sm mt-1">Click "New Job" to create your first posting</p>
    </div>
  );

  return (
    <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-gray-50 border-b border-gray-200">
          <tr>
            <th className="text-left px-4 py-3 font-semibold text-gray-600">Title</th>
            <th className="text-left px-4 py-3 font-semibold text-gray-600 hidden md:table-cell">Department</th>
            <th className="text-left px-4 py-3 font-semibold text-gray-600 hidden md:table-cell">Type</th>
            <th className="text-left px-4 py-3 font-semibold text-gray-600">Status</th>
            <th className="text-right px-4 py-3 font-semibold text-gray-600">Actions</th>
          </tr>
        </thead>
        <tbody>
          {jobs.map(j => (
            <tr key={j.id} className="border-b border-gray-100 hover:bg-gray-50">
              <td className="px-4 py-3">
                <div className="font-medium text-gray-900">{j.title}</div>
                <div className="text-xs text-gray-400 flex items-center gap-1 mt-0.5">
                  <MapPin size={10} /> {j.location || "—"}
                </div>
              </td>
              <td className="px-4 py-3 hidden md:table-cell text-gray-600">{j.department || "—"}</td>
              <td className="px-4 py-3 hidden md:table-cell">
                <span className="text-xs bg-blue-50 text-blue-700 font-semibold px-2 py-0.5 rounded-full capitalize">{j.type}</span>
              </td>
              <td className="px-4 py-3">
                <button onClick={() => toggleActive.mutate(j)}
                  className={`flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full ${j.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                  {j.isActive ? <CheckCircle size={11} /> : <XCircle size={11} />}
                  {j.isActive ? "Active" : "Inactive"}
                </button>
              </td>
              <td className="px-4 py-3 text-right">
                <div className="flex items-center justify-end gap-1">
                  <button onClick={() => onViewApps(j.id)} className="p-1.5 rounded-lg text-gray-400 hover:text-blue-600 hover:bg-blue-50" title="View applications"><Eye size={14} /></button>
                  <button onClick={() => onEdit(j)} className="p-1.5 rounded-lg text-gray-400 hover:text-[#D4920C] hover:bg-amber-50"><Edit2 size={14} /></button>
                  <button onClick={() => { if (confirm("Delete this job?")) deleteMutation.mutate(j.id); }} className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50"><Trash2 size={14} /></button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function AllApplicationsTab({ applications, jobs }: { applications: Application[]; jobs: Job[] }) {
  const qc = useQueryClient();
  const { toast } = useToast();
  const jobMap = Object.fromEntries(jobs.map(j => [j.id, j.title]));

  const updateStatus = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) =>
      api(`/api/admin/applications/${id}`, { method: "PATCH", body: JSON.stringify({ status }) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-applications"] }),
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  if (applications.length === 0) return (
    <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
      <Users size={40} className="mx-auto text-gray-300 mb-3" />
      <p className="text-gray-500 font-medium">No applications yet</p>
    </div>
  );

  return (
    <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-gray-50 border-b border-gray-200">
          <tr>
            <th className="text-left px-4 py-3 font-semibold text-gray-600">Candidate</th>
            <th className="text-left px-4 py-3 font-semibold text-gray-600 hidden md:table-cell">Job</th>
            <th className="text-left px-4 py-3 font-semibold text-gray-600">Status</th>
            <th className="text-left px-4 py-3 font-semibold text-gray-600 hidden md:table-cell">CV</th>
            <th className="text-left px-4 py-3 font-semibold text-gray-600 hidden md:table-cell">Applied</th>
          </tr>
        </thead>
        <tbody>
          {applications.map(a => (
            <tr key={a.id} className="border-b border-gray-100 hover:bg-gray-50">
              <td className="px-4 py-3">
                <div className="font-medium text-gray-900">{a.name}</div>
                <div className="text-xs text-gray-400">{a.email}</div>
              </td>
              <td className="px-4 py-3 hidden md:table-cell text-gray-600 text-xs">{jobMap[a.jobId] ?? `Job #${a.jobId}`}</td>
              <td className="px-4 py-3">
                <select
                  value={a.status}
                  onChange={e => updateStatus.mutate({ id: a.id, status: e.target.value })}
                  className={`text-xs font-semibold px-2 py-1 rounded-full border-0 cursor-pointer ${STATUS_COLORS[a.status] ?? "bg-gray-100 text-gray-600"}`}
                >
                  {APP_STATUSES.map(s => <option key={s} value={s} className="bg-white text-gray-900">{s}</option>)}
                </select>
              </td>
              <td className="px-4 py-3 hidden md:table-cell">
                {a.cvObjectPath ? (
                  <a href={`/api/${a.cvObjectPath}`} target="_blank" rel="noopener noreferrer"
                    className="text-xs text-blue-600 hover:underline font-medium truncate max-w-[120px] block">
                    {a.cvFilename ?? "Download CV"}
                  </a>
                ) : <span className="text-xs text-gray-400">—</span>}
              </td>
              <td className="px-4 py-3 hidden md:table-cell text-xs text-gray-400">
                {new Date(a.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function JobForm({ job, onClose }: { job: Job | null; onClose: () => void }) {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [form, setForm] = useState({
    title: job?.title ?? "",
    department: job?.department ?? "",
    location: job?.location ?? "",
    type: job?.type ?? "full-time",
    salaryRange: job?.salaryRange ?? "",
    description: job?.description ?? "",
    requirements: job?.requirements ?? "",
    isActive: job?.isActive !== false,
  });

  const saveMutation = useMutation({
    mutationFn: () => job
      ? api(`/api/admin/jobs/${job.id}`, { method: "PATCH", body: JSON.stringify(form) })
      : api("/api/admin/jobs", { method: "POST", body: JSON.stringify(form) }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-jobs"] });
      toast({ title: job ? "Job updated" : "Job created" });
      onClose();
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const f = (key: keyof typeof form) => (
    <input
      value={String(form[key])}
      onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))}
      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#E84821]"
    />
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-100 sticky top-0 bg-white z-10">
          <h2 className="text-lg font-bold text-gray-900">{job ? "Edit Job" : "New Job Posting"}</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100"><X size={18} /></button>
        </div>
        <form onSubmit={e => { e.preventDefault(); saveMutation.mutate(); }} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Job Title *</label>
            <input required value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))}
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#E84821]"
              placeholder="e.g. SAP Business One Consultant" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Department</label>
              <input value={form.department} onChange={e => setForm(p => ({ ...p, department: e.target.value }))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#E84821]"
                placeholder="e.g. Consulting" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Location</label>
              <input value={form.location} onChange={e => setForm(p => ({ ...p, location: e.target.value }))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#E84821]"
                placeholder="e.g. Delhi, India" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Job Type</label>
              <select value={form.type} onChange={e => setForm(p => ({ ...p, type: e.target.value }))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#E84821]">
                {JOB_TYPES.map(t => <option key={t} value={t} className="capitalize">{t}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Salary Range (optional)</label>
              {f("salaryRange")}
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Job Description *</label>
            <textarea required value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
              rows={5} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#E84821] resize-y"
              placeholder="Describe the role, responsibilities…" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Requirements</label>
            <textarea value={form.requirements} onChange={e => setForm(p => ({ ...p, requirements: e.target.value }))}
              rows={4} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#E84821] resize-y"
              placeholder="Qualifications, skills, experience…" />
          </div>
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={form.isActive} onChange={e => setForm(p => ({ ...p, isActive: e.target.checked }))} className="rounded accent-[#E84821] w-4 h-4" />
            <span className="text-sm text-gray-700 font-medium">Publish this job (visible on public website)</span>
          </label>
          <div className="flex justify-end gap-3 pt-2 border-t border-gray-100">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900">Cancel</button>
            <button type="submit" disabled={saveMutation.isPending}
              className="px-5 py-2 bg-[#E84821] text-white rounded-lg text-sm font-semibold hover:bg-[#c73d1a] disabled:opacity-50">
              {saveMutation.isPending ? "Saving…" : job ? "Update Job" : "Create Job"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function ApplicationsModal({ jobId, jobs, onClose }: { jobId: number; jobs: Job[]; onClose: () => void }) {
  const qc = useQueryClient();
  const { toast } = useToast();
  const job = jobs.find(j => j.id === jobId);

  const { data: applications = [] } = useQuery<Application[]>({
    queryKey: ["job-applications", jobId],
    queryFn: () => api(`/api/admin/jobs/${jobId}/applications`),
  });

  const updateStatus = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) =>
      api(`/api/admin/applications/${id}`, { method: "PATCH", body: JSON.stringify({ status }) }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["job-applications", jobId] });
      qc.invalidateQueries({ queryKey: ["admin-applications"] });
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const [expanded, setExpanded] = useState<number | null>(null);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-100 sticky top-0 bg-white z-10">
          <div>
            <h2 className="text-lg font-bold text-gray-900">Applications</h2>
            <p className="text-sm text-gray-500">{job?.title}</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100"><X size={18} /></button>
        </div>
        <div className="p-6">
          {applications.length === 0 ? (
            <p className="text-gray-400 text-center py-8">No applications received yet</p>
          ) : (
            <div className="space-y-3">
              {applications.map(a => (
                <div key={a.id} className="border border-gray-200 rounded-xl overflow-hidden">
                  <div className="flex items-center justify-between px-4 py-3 cursor-pointer hover:bg-gray-50"
                    onClick={() => setExpanded(expanded === a.id ? null : a.id)}>
                    <div>
                      <div className="font-semibold text-gray-900">{a.name}</div>
                      <div className="text-xs text-gray-500">{a.email} {a.phone ? `· ${a.phone}` : ""}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <select value={a.status} onClick={e => e.stopPropagation()}
                        onChange={e => updateStatus.mutate({ id: a.id, status: e.target.value })}
                        className={`text-xs font-semibold px-2 py-1 rounded-full border-0 cursor-pointer ${STATUS_COLORS[a.status] ?? "bg-gray-100 text-gray-600"}`}>
                        {APP_STATUSES.map(s => <option key={s} value={s} className="bg-white text-gray-900">{s}</option>)}
                      </select>
                      {expanded === a.id ? <ChevronUp size={14} className="text-gray-400" /> : <ChevronDown size={14} className="text-gray-400" />}
                    </div>
                  </div>
                  {expanded === a.id && (
                    <div className="px-4 pb-4 space-y-2 border-t border-gray-100">
                      {a.coverLetter && (
                        <div>
                          <div className="text-xs font-semibold text-gray-500 mt-3 mb-1">Cover Letter</div>
                          <p className="text-sm text-gray-700 whitespace-pre-line bg-gray-50 rounded-lg p-3">{a.coverLetter}</p>
                        </div>
                      )}
                      {a.cvObjectPath ? (
                        <a href={`/api/storage/objects/${a.cvObjectPath.replace(/^\/objects\//, "")}`}
                          target="_blank" rel="noopener noreferrer"
                          className="inline-flex items-center gap-2 mt-2 px-3 py-1.5 bg-blue-50 text-blue-700 rounded-lg text-xs font-semibold hover:bg-blue-100">
                          Download CV — {a.cvFilename}
                        </a>
                      ) : <p className="text-xs text-gray-400 mt-2">No CV uploaded</p>}
                      <div className="text-xs text-gray-400 mt-1">Applied {new Date(a.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}</div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
