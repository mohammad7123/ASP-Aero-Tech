import { useState } from "react";
import { Mail, Phone, Trash2, CheckCircle, Circle, ChevronDown, ChevronUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useListContacts, useMarkContactRead, useDeleteContact } from "@/lib/apiClient";
import { useQueryClient } from "@tanstack/react-query";

export default function AdminContacts() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const { data: contacts, isLoading } = useListContacts();
  const markRead = useMarkContactRead();
  const deleteContact = useDeleteContact();
  const [expanded, setExpanded] = useState<number | null>(null);

  async function handleMarkRead(id: number) {
    await markRead.mutateAsync({ id }, { onSuccess: () => { toast({ title: "Marked as read" }); qc.invalidateQueries(); } });
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this inquiry?")) return;
    await deleteContact.mutateAsync({ id }, { onSuccess: () => { toast({ title: "Deleted" }); qc.invalidateQueries(); } });
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-[#1C1917]">Contact Inquiries</h1>
        <p className="text-gray-500 text-sm mt-1">
          {contacts ? `${contacts.filter(c => !c.isRead).length} unread of ${contacts.length} total` : "Loading..."}
        </p>
      </div>

      {isLoading ? (
        <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-20 bg-gray-100 rounded-xl animate-pulse" />)}</div>
      ) : (
        <div className="space-y-3">
          {contacts?.map(contact => (
            <div key={contact.id} className={`bg-white rounded-xl border transition-all ${!contact.isRead ? "border-[#E84821]/30 shadow-sm" : "border-gray-100"}`}>
              <div
                className="flex items-center gap-4 p-4 cursor-pointer"
                onClick={() => setExpanded(expanded === contact.id ? null : contact.id)}
              >
                <div className="flex-shrink-0">
                  {contact.isRead
                    ? <CheckCircle size={18} className="text-gray-300" />
                    : <Circle size={18} className="text-[#E84821]" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-[#1C1917] text-sm">{contact.name}</span>
                    {!contact.isRead && <span className="bg-[#E84821] text-[#1C1917] text-xs px-1.5 py-0.5 rounded font-medium">New</span>}
                  </div>
                  <div className="flex items-center gap-4 mt-0.5">
                    <span className="flex items-center gap-1 text-xs text-gray-400"><Mail size={10} /> {contact.email}</span>
                    {contact.phone && <span className="flex items-center gap-1 text-xs text-gray-400"><Phone size={10} /> {contact.phone}</span>}
                  </div>
                  {contact.subject && <p className="text-xs text-gray-500 mt-1 truncate">{contact.subject}</p>}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-400">{new Date(contact.createdAt).toLocaleDateString("en-IN")}</span>
                  {expanded === contact.id ? <ChevronUp size={16} className="text-gray-400" /> : <ChevronDown size={16} className="text-gray-400" />}
                </div>
              </div>

              {expanded === contact.id && (
                <div className="px-4 pb-4 border-t border-gray-50 pt-3">
                  <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap">{contact.message}</p>
                  <div className="flex gap-2 mt-4">
                    {!contact.isRead && (
                      <button onClick={() => handleMarkRead(contact.id)} className="flex items-center gap-1.5 text-xs bg-[#E84821]/10 text-[#E84821] px-3 py-1.5 rounded-lg hover:bg-[#E84821]/20 transition-colors font-medium">
                        <CheckCircle size={12} /> Mark Read
                      </button>
                    )}
                    <a href={`mailto:${contact.email}`} className="flex items-center gap-1.5 text-xs bg-blue-50 text-blue-600 px-3 py-1.5 rounded-lg hover:bg-blue-100 transition-colors font-medium">
                      <Mail size={12} /> Reply
                    </a>
                    <button onClick={() => handleDelete(contact.id)} className="flex items-center gap-1.5 text-xs bg-red-50 text-red-500 px-3 py-1.5 rounded-lg hover:bg-red-100 transition-colors font-medium ml-auto">
                      <Trash2 size={12} /> Delete
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
          {!contacts?.length && (
            <div className="text-center py-16 text-gray-400">
              <Mail size={32} className="mx-auto mb-3 opacity-30" />
              <p>No contact inquiries yet.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
