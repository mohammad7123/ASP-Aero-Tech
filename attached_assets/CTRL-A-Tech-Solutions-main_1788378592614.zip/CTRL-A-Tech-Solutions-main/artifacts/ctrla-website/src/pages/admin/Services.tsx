import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Pencil, Trash2, Search, X, Image as ImageIcon, ArrowUp, ArrowDown } from "lucide-react";
import AdminLayout from "@/components/admin/AdminLayout";
import { useToast } from "@/hooks/use-toast";
import { getIcon } from "@/lib/iconMap";
import { getToken } from "@/lib/auth";

type Service = {
  id: number;
  name: string;
  slug: string;
  category: string;
  shortDesc: string;
  description: string | null;
  imageUrl: string | null;
  iconName: string;
  accentColor: string;
  sortOrder: number;
  isActive: boolean;
};

const ICON_OPTIONS = ["Briefcase","Code2","Cloud","Database","Settings","Shield","Headphones","Wrench","Server","Cpu","Globe","Users","Brain","BarChart3","CheckCircle2","Zap","Network","Smartphone","Layers","RefreshCw"];
const ACCENT_OPTIONS = [
  { label: "Orange", value: "#E84821" },
  { label: "Gold", value: "#D4920C" },
  { label: "Navy", value: "#3D4FA0" },
  { label: "Green", value: "#16a34a" },
  { label: "Purple", value: "#7c3aed" },
];

const empty = {
  name: "", slug: "", category: "general", shortDesc: "", description: "",
  imageUrl: "", iconName: "Briefcase", accentColor: "#D4920C", sortOrder: 0, isActive: true,
};

async function api(path: string, opts?: RequestInit) {
  const token = getToken();
  const res = await fetch(path, {
    ...opts,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}`, ...(opts?.headers ?? {}) },
  });
  if (!res.ok) throw new Error(await res.text());
  if (res.status === 204) return null;
  return res.json();
}

export default function AdminServices() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [editItem, setEditItem] = useState<Service | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ ...empty });
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const { data: items = [], isLoading } = useQuery<Service[]>({
    queryKey: ["admin-services"],
    queryFn: () => api("/api/admin/services"),
  });

  const filtered = items.filter(it => !search || it.name.toLowerCase().includes(search.toLowerCase()));

  const saveMutation = useMutation({
    mutationFn: (data: typeof empty & { id?: number }) => {
      const { id, ...body } = data;
      const payload = { ...body, imageUrl: body.imageUrl || null };
      return id
        ? api(`/api/admin/services/${id}`, { method: "PATCH", body: JSON.stringify(payload) })
        : api("/api/admin/services", { method: "POST", body: JSON.stringify(payload) });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-services"] });
      qc.invalidateQueries({ queryKey: ["public-services"] });
      toast({ title: editItem ? "Service updated" : "Service created" });
      closeForm();
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => api(`/api/admin/services/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-services"] });
      qc.invalidateQueries({ queryKey: ["public-services"] });
      toast({ title: "Service deleted" });
      setDeleteId(null);
    },
  });

  const toggleActive = useMutation({
    mutationFn: ({ id, isActive }: { id: number; isActive: boolean }) =>
      api(`/api/admin/services/${id}`, { method: "PATCH", body: JSON.stringify({ isActive }) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-services"] }),
  });

  const moveMutation = useMutation({
    mutationFn: ({ id, direction }: { id: number; direction: "up" | "down" }) =>
      api(`/api/admin/services/${id}/move`, { method: "POST", body: JSON.stringify({ direction }) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-services"] }),
  });

  function openCreate() { setEditItem(null); setForm({ ...empty, sortOrder: items.length * 10 }); setShowForm(true); }
  function openEdit(it: Service) {
    setEditItem(it);
    setForm({
      name: it.name, slug: it.slug, category: it.category, shortDesc: it.shortDesc,
      description: it.description ?? "", imageUrl: it.imageUrl ?? "",
      iconName: it.iconName, accentColor: it.accentColor, sortOrder: it.sortOrder, isActive: it.isActive,
    });
    setShowForm(true);
  }
  function closeForm() { setShowForm(false); setEditItem(null); setForm({ ...empty }); }
  function handleSubmit(e: React.FormEvent) { e.preventDefault(); saveMutation.mutate(editItem ? { ...form, id: editItem.id } : form); }

  return (
    <AdminLayout>
      <div className="max-w-6xl">
        <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Services</h1>
            <p className="text-sm text-gray-500 mt-1">Manage the services shown on the public Services page</p>
          </div>
          <button onClick={openCreate} className="flex items-center gap-2 px-4 py-2 bg-[#D4920C] text-white rounded-lg font-semibold text-sm hover:bg-[#b87a09] transition-colors">
            <Plus size={16} /> Add Service
          </button>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 mb-6 p-4 flex items-center gap-2">
          <Search size={16} className="text-gray-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search services…" className="flex-1 text-sm outline-none" />
          {search && <button onClick={() => setSearch("")}><X size={14} className="text-gray-400" /></button>}
        </div>

        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          {isLoading ? (
            <div className="p-8 text-center text-gray-400">Loading…</div>
          ) : filtered.length === 0 ? (
            <div className="p-8 text-center text-gray-400">No services yet. Click "Add Service" to create one.</div>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="text-left px-4 py-3 font-semibold text-gray-600 w-20">Order</th>
                  <th className="text-left px-4 py-3 font-semibold text-gray-600">Service</th>
                  <th className="text-left px-4 py-3 font-semibold text-gray-600 hidden lg:table-cell">Description</th>
                  <th className="text-center px-4 py-3 font-semibold text-gray-600">Active</th>
                  <th className="text-right px-4 py-3 font-semibold text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((it, i) => {
                  const Icon = getIcon(it.iconName);
                  return (
                    <tr key={it.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1">
                          <button onClick={() => moveMutation.mutate({ id: it.id, direction: "up" })} disabled={i === 0} className="p-1 rounded hover:bg-blue-50 text-gray-400 hover:text-blue-600 disabled:opacity-30 disabled:cursor-not-allowed" title="Move up">
                            <ArrowUp size={14} />
                          </button>
                          <button onClick={() => moveMutation.mutate({ id: it.id, direction: "down" })} disabled={i === filtered.length - 1} className="p-1 rounded hover:bg-blue-50 text-gray-400 hover:text-blue-600 disabled:opacity-30 disabled:cursor-not-allowed" title="Move down">
                            <ArrowDown size={14} />
                          </button>
                          <span className="text-xs text-gray-400 ml-1">{it.sortOrder}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="p-1.5 rounded-lg" style={{ backgroundColor: `${it.accentColor}18` }}>
                            <Icon size={14} style={{ color: it.accentColor }} />
                          </div>
                          <div>
                            <div className="font-medium text-gray-900">{it.name}</div>
                            <div className="text-xs text-gray-400">{it.slug}</div>
                          </div>
                          {it.imageUrl && <ImageIcon size={11} className="text-green-500" />}
                        </div>
                      </td>
                      <td className="px-4 py-3 hidden lg:table-cell max-w-xs">
                        <p className="text-gray-500 text-xs truncate">{it.shortDesc}</p>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <button onClick={() => toggleActive.mutate({ id: it.id, isActive: !it.isActive })} className={`w-9 h-5 rounded-full ${it.isActive ? "bg-green-500" : "bg-gray-200"}`}>
                          <span className={`block w-3.5 h-3.5 rounded-full bg-white shadow mx-0.5 transition-transform ${it.isActive ? "translate-x-4" : "translate-x-0"}`} />
                        </button>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button onClick={() => openEdit(it)} className="p-1.5 rounded-lg text-gray-400 hover:text-blue-600 hover:bg-blue-50"><Pencil size={14} /></button>
                          <button onClick={() => setDeleteId(it.id)} className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50"><Trash2 size={14} /></button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-gray-100">
              <h2 className="text-lg font-bold text-gray-900">{editItem ? "Edit Service" : "Add Service"}</h2>
              <button onClick={closeForm} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100"><X size={18} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Name *</label>
                  <input required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C]" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Slug</label>
                  <input value={form.slug} onChange={e => setForm(f => ({ ...f, slug: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C]" placeholder="auto-generated" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">Short Description</label>
                <textarea value={form.shortDesc} onChange={e => setForm(f => ({ ...f, shortDesc: e.target.value }))} rows={2} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C] resize-none" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">Full Description</label>
                <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} rows={4} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C] resize-y" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">Image URL</label>
                <input value={form.imageUrl} onChange={e => setForm(f => ({ ...f, imageUrl: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C]" placeholder="https://…" />
              </div>
              <div className="grid sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Icon</label>
                  <select value={form.iconName} onChange={e => setForm(f => ({ ...f, iconName: e.target.value }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C]">
                    {ICON_OPTIONS.map(i => <option key={i} value={i}>{i}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Accent</label>
                  <div className="flex gap-1">
                    {ACCENT_OPTIONS.map(o => (
                      <button key={o.value} type="button" onClick={() => setForm(f => ({ ...f, accentColor: o.value }))} className={`w-7 h-7 rounded-full border-2 ${form.accentColor === o.value ? "border-gray-900 scale-110" : "border-transparent"}`} style={{ backgroundColor: o.value }} title={o.label} />
                    ))}
                    <input type="color" value={form.accentColor} onChange={e => setForm(f => ({ ...f, accentColor: e.target.value }))} className="w-7 h-7 rounded-full border border-gray-200 cursor-pointer" />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">Sort Order</label>
                  <input type="number" value={form.sortOrder} onChange={e => setForm(f => ({ ...f, sortOrder: Number(e.target.value) }))} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#D4920C]" min={0} />
                </div>
              </div>
              <div className="flex items-center gap-3">
                <button type="button" onClick={() => setForm(f => ({ ...f, isActive: !f.isActive }))} className={`w-10 h-5 rounded-full ${form.isActive ? "bg-green-500" : "bg-gray-200"}`}>
                  <span className={`block w-4 h-4 rounded-full bg-white shadow mx-0.5 transition-transform ${form.isActive ? "translate-x-5" : "translate-x-0"}`} />
                </button>
                <span className="text-sm text-gray-600">Active (visible on website)</span>
              </div>
              <div className="flex justify-end gap-3 pt-2 border-t border-gray-100">
                <button type="button" onClick={closeForm} className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900">Cancel</button>
                <button type="submit" disabled={saveMutation.isPending} className="px-5 py-2 bg-[#D4920C] text-white rounded-lg text-sm font-semibold hover:bg-[#b87a09] disabled:opacity-50">
                  {saveMutation.isPending ? "Saving…" : editItem ? "Save Changes" : "Add Service"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {deleteId !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-2">Delete Service?</h3>
            <p className="text-sm text-gray-500 mb-6">This will permanently remove this service.</p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setDeleteId(null)} className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900">Cancel</button>
              <button onClick={() => deleteMutation.mutate(deleteId!)} disabled={deleteMutation.isPending} className="px-4 py-2 bg-red-500 text-white rounded-lg text-sm font-semibold hover:bg-red-600 disabled:opacity-50">
                {deleteMutation.isPending ? "Deleting…" : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
