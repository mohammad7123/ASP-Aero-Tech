import { useEffect } from "react";
import { useEditor, EditorContent, useEditorState } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Link from "@tiptap/extension-link";
import Placeholder from "@tiptap/extension-placeholder";

interface RichTextEditorProps {
  value: string;
  onChange: (html: string) => void;
  placeholder?: string;
  minHeight?: string;
}

interface ToolbarButtonProps {
  onClick: () => void;
  active?: boolean;
  children: React.ReactNode;
  title: string;
}

function ToolbarButton({ onClick, active, children, title }: ToolbarButtonProps) {
  return (
    <button
      type="button"
      title={title}
      onMouseDown={(e) => {
        e.preventDefault();
      }}
      onClick={onClick}
      className={`px-2 py-1 text-xs rounded transition-colors ${
        active
          ? "bg-[#1C1917] text-white"
          : "text-gray-600 hover:bg-gray-200"
      }`}
    >
      {children}
    </button>
  );
}

export default function RichTextEditor({
  value,
  onChange,
  placeholder = "Start typing…",
  minHeight = "200px",
}: RichTextEditorProps) {
  const editor = useEditor({
    immediatelyRender: false,
    extensions: [
      StarterKit,
      Link.configure({ openOnClick: false, HTMLAttributes: { class: "text-[#E84821] underline" } }),
      Placeholder.configure({ placeholder }),
    ],
    content: value,
    onUpdate: ({ editor }) => {
      onChange(editor.getHTML());
    },
  });

  useEffect(() => {
    if (editor && value !== editor.getHTML()) {
      editor.commands.setContent(value || "");
    }
  }, [value]);

  const editorState = useEditorState({
    editor,
    selector: (ctx) => {
      if (!ctx.editor) return null;
      return {
        isBold: ctx.editor.isActive("bold"),
        isItalic: ctx.editor.isActive("italic"),
        isStrike: ctx.editor.isActive("strike"),
        isH1: ctx.editor.isActive("heading", { level: 1 }),
        isH2: ctx.editor.isActive("heading", { level: 2 }),
        isH3: ctx.editor.isActive("heading", { level: 3 }),
        isBulletList: ctx.editor.isActive("bulletList"),
        isOrderedList: ctx.editor.isActive("orderedList"),
        isBlockquote: ctx.editor.isActive("blockquote"),
        isCodeBlock: ctx.editor.isActive("codeBlock"),
        isLink: ctx.editor.isActive("link"),
      };
    },
  });

  if (!editor) return null;

  const addLink = () => {
    const url = window.prompt("Enter URL:");
    if (!url) return;
    editor.chain().focus().extendMarkRange("link").setLink({ href: url }).run();
  };

  return (
    <div className="border border-gray-200 rounded-lg overflow-hidden">
      <div
        className="border-b border-gray-100 p-2 flex gap-1 flex-wrap bg-gray-50"
        onMouseDown={(e) => e.preventDefault()}
      >
        <ToolbarButton title="Bold" onClick={() => editor.chain().focus().toggleBold().run()} active={editorState?.isBold}>
          <strong>B</strong>
        </ToolbarButton>
        <ToolbarButton title="Italic" onClick={() => editor.chain().focus().toggleItalic().run()} active={editorState?.isItalic}>
          <em>I</em>
        </ToolbarButton>
        <ToolbarButton title="Strikethrough" onClick={() => editor.chain().focus().toggleStrike().run()} active={editorState?.isStrike}>
          <s>S</s>
        </ToolbarButton>
        <div className="w-px h-5 bg-gray-300 self-center mx-1" />
        <ToolbarButton title="Heading 1" onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()} active={editorState?.isH1}>
          H1
        </ToolbarButton>
        <ToolbarButton title="Heading 2" onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()} active={editorState?.isH2}>
          H2
        </ToolbarButton>
        <ToolbarButton title="Heading 3" onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()} active={editorState?.isH3}>
          H3
        </ToolbarButton>
        <div className="w-px h-5 bg-gray-300 self-center mx-1" />
        <ToolbarButton title="Bullet list" onClick={() => editor.chain().focus().toggleBulletList().run()} active={editorState?.isBulletList}>
          • List
        </ToolbarButton>
        <ToolbarButton title="Ordered list" onClick={() => editor.chain().focus().toggleOrderedList().run()} active={editorState?.isOrderedList}>
          1. List
        </ToolbarButton>
        <div className="w-px h-5 bg-gray-300 self-center mx-1" />
        <ToolbarButton title="Blockquote" onClick={() => editor.chain().focus().toggleBlockquote().run()} active={editorState?.isBlockquote}>
          ❝
        </ToolbarButton>
        <ToolbarButton title="Code block" onClick={() => editor.chain().focus().toggleCodeBlock().run()} active={editorState?.isCodeBlock}>
          {"</>"}
        </ToolbarButton>
        <ToolbarButton title="Add link" onClick={addLink} active={editorState?.isLink}>
          🔗
        </ToolbarButton>
        <ToolbarButton title="Remove link" onClick={() => editor.chain().focus().unsetLink().run()}>
          ✂️
        </ToolbarButton>
        <div className="w-px h-5 bg-gray-300 self-center mx-1" />
        <ToolbarButton title="Undo" onClick={() => editor.chain().focus().undo().run()}>↩</ToolbarButton>
        <ToolbarButton title="Redo" onClick={() => editor.chain().focus().redo().run()}>↪</ToolbarButton>
      </div>
      <style>{`
        .tiptap-editor .ProseMirror {
          outline: none;
          padding: 0.75rem;
          min-height: ${minHeight};
          font-size: 0.875rem;
          line-height: 1.6;
        }
        .tiptap-editor .ProseMirror h1 { font-size: 1.5rem; font-weight: 700; margin: 0.5rem 0; }
        .tiptap-editor .ProseMirror h2 { font-size: 1.25rem; font-weight: 700; margin: 0.5rem 0; }
        .tiptap-editor .ProseMirror h3 { font-size: 1rem; font-weight: 700; margin: 0.5rem 0; }
        .tiptap-editor .ProseMirror ul { list-style: disc; padding-left: 1.5rem; }
        .tiptap-editor .ProseMirror ol { list-style: decimal; padding-left: 1.5rem; }
        .tiptap-editor .ProseMirror blockquote { border-left: 3px solid #E84821; padding-left: 1rem; color: #666; }
        .tiptap-editor .ProseMirror pre { background: #f4f4f4; padding: 0.75rem; border-radius: 0.375rem; font-size: 0.75rem; overflow-x: auto; }
        .tiptap-editor .ProseMirror a { color: #E84821; text-decoration: underline; }
        .tiptap-editor .ProseMirror p.is-editor-empty:first-child::before { content: attr(data-placeholder); float: left; color: #aaa; pointer-events: none; height: 0; }
      `}</style>
      <div className="tiptap-editor">
        <EditorContent editor={editor} />
      </div>
    </div>
  );
}
