import { useEffect } from "react";
import { INCLUDED_LANGUAGES } from "@/lib/translate";

// Loads the Google Website Translate widget (hidden) so the whole site can be
// translated on demand. The active language is driven by the googtrans cookie
// set in the Navbar language switcher; this widget reads that cookie on load
// and translates the entire document.
export default function GoogleTranslate() {
  useEffect(() => {
    const w = window as unknown as {
      googleTranslateElementInit?: () => void;
      google?: { translate?: { TranslateElement?: new (opts: object, el: string) => void } };
    };

    w.googleTranslateElementInit = () => {
      const TranslateElement = w.google?.translate?.TranslateElement;
      if (!TranslateElement) return;
      new TranslateElement(
        {
          pageLanguage: "en",
          includedLanguages: INCLUDED_LANGUAGES,
          autoDisplay: false,
        },
        "google_translate_element",
      );
    };

    if (!document.getElementById("google-translate-script")) {
      const script = document.createElement("script");
      script.id = "google-translate-script";
      script.src =
        "https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
      document.body.appendChild(script);
    }
  }, []);

  return <div id="google_translate_element" aria-hidden />;
}
