import { MessageCircle } from "lucide-react";
import { motion } from "framer-motion";

interface Props {
  number?: string;
  greeting?: string;
}

export default function WhatsAppButton({ number = "919876543210", greeting = "Hello! How can we help you?" }: Props) {
  const url = `https://wa.me/${number}?text=${encodeURIComponent(greeting)}`;
  return (
    <motion.a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 bg-green-500 text-white p-4 rounded-full shadow-lg hover:bg-green-600 transition-colors"
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      title="Chat on WhatsApp"
    >
      <MessageCircle size={24} fill="white" />
    </motion.a>
  );
}
