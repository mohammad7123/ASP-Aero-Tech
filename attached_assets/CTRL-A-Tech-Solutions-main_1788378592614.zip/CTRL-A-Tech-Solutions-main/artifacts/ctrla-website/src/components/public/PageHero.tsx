import { motion } from "framer-motion";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

interface PageHeroProps {
  eyebrow?: string;
  title: React.ReactNode;
  subtitle?: string;
  heroImage?: string | null;
  heroImageAlt?: string;
  cta?: React.ReactNode;
}

export default function PageHero({ eyebrow, title, subtitle, heroImage, heroImageAlt, cta }: PageHeroProps) {
  const { primaryColor, accentColor } = useSiteConfig();
  const hasImage = !!heroImage;

  return (
    <section className="relative bg-white overflow-hidden border-b border-gray-100">
      {/* Soft decorative blobs */}
      <div className="pointer-events-none absolute -top-24 -right-24 w-96 h-96 rounded-full opacity-[0.06] blur-3xl" style={{ backgroundColor: primaryColor }} />
      <div className="pointer-events-none absolute -bottom-32 -left-24 w-80 h-80 rounded-full opacity-[0.05] blur-3xl bg-[#3D4FA0]" />

      <div className={`relative max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-10 ${hasImage ? "" : "text-center"}`}>
        {hasImage ? (
          <div className="grid lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-7">
              {eyebrow && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-xs font-bold uppercase tracking-widest mb-3"
                  style={{ color: primaryColor }}
                >
                  {eyebrow}
                </motion.div>
              )}
              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="text-4xl sm:text-5xl font-bold tracking-tight"
                style={{ color: accentColor }}
              >
                {title}
              </motion.h1>
              <div className="mt-5 flex items-center gap-1.5">
                <div className="h-1 w-12 rounded-full bg-[#E84821]" />
                <div className="h-1 w-6 rounded-full" style={{ backgroundColor: primaryColor }} />
                <div className="h-1 w-3 rounded-full bg-[#3D4FA0]" />
              </div>
              {subtitle && (
                <p className="text-base sm:text-lg text-gray-600 max-w-2xl mt-6 leading-relaxed">
                  {subtitle}
                </p>
              )}
              {cta}
            </div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="lg:col-span-5"
            >
              <div className="relative">
                <div className="absolute -top-3 -right-3 w-20 h-20 rounded-2xl bg-[#E84821]/10" />
                <div className="absolute -bottom-3 -left-3 w-16 h-16 rounded-2xl" style={{ backgroundColor: `${primaryColor}1a` }} />
                <div className="relative rounded-2xl overflow-hidden shadow-xl border border-gray-100 aspect-[4/3]">
                  <img
                    src={heroImage!}
                    alt={heroImageAlt ?? ""}
                    aria-hidden={heroImageAlt ? undefined : true}
                    className="w-full h-full object-cover"
                    loading="eager"
                  />
                  <div className="absolute inset-0 bg-gradient-to-tr from-[#1A1F36]/35 to-transparent" />
                </div>
              </div>
            </motion.div>
          </div>
        ) : (
          <>
            {eyebrow && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-xs font-bold uppercase tracking-widest mb-3"
                style={{ color: primaryColor }}
              >
                {eyebrow}
              </motion.div>
            )}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-4xl sm:text-5xl font-bold tracking-tight"
              style={{ color: accentColor }}
            >
              {title}
            </motion.h1>
            <div className="mx-auto mt-5 flex justify-center items-center gap-1.5">
              <div className="h-1 w-12 rounded-full bg-[#E84821]" />
              <div className="h-1 w-6 rounded-full" style={{ backgroundColor: primaryColor }} />
              <div className="h-1 w-3 rounded-full bg-[#3D4FA0]" />
            </div>
            {subtitle && (
              <p className="text-base sm:text-lg text-gray-600 max-w-2xl mx-auto mt-6 leading-relaxed">
                {subtitle}
              </p>
            )}
            {cta && <div className="flex justify-center">{cta}</div>}
          </>
        )}
      </div>

      {/* Bottom brand strip */}
      <div className="h-1 flex">
        <div className="flex-[3] bg-[#E84821]" />
        <div className="flex-[2]" style={{ backgroundColor: primaryColor }} />
        <div className="flex-1 bg-[#3D4FA0]" />
      </div>
    </section>
  );
}
