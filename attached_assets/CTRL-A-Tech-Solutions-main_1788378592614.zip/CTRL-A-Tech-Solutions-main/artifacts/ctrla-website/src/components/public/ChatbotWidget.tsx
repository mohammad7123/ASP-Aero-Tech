import { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send, Bot, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface Message {
  role: "bot" | "user";
  text: string;
}

interface Props {
  botName?: string;
  greeting?: string;
  whatsappNumber?: string | null;
}

export default function ChatbotWidget({ botName = "CtrlA Bot", greeting, whatsappNumber }: Props) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  const defaultGreeting = greeting ?? `Hi there! I'm ${botName}. How can I help you today?`;

  useEffect(() => {
    if (open && messages.length === 0) {
      setMessages([{ role: "bot", text: defaultGreeting }]);
    }
  }, [open]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function handleSend() {
    const trimmed = input.trim();
    if (!trimmed || isLoading) return;

    const userMsg: Message = { role: "user", text: trimmed };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setIsLoading(true);

    try {
      const base = import.meta.env.BASE_URL.replace(/\/$/, "");
      const res = await fetch(`${base}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: trimmed,
          history: messages.map(m => ({ role: m.role, content: m.text })),
        }),
      });

      if (res.ok) {
        const data = await res.json() as { reply?: string };
        const replyText = data.reply ?? "Sorry, I couldn't process that. Please try again.";
        const waLink = whatsappNumber ? ` Chat with us on WhatsApp: https://wa.me/${whatsappNumber}` : "";
        setMessages(prev => [...prev, { role: "bot", text: replyText + (replyText.includes("Contact") ? waLink : "") }]);
      } else {
        throw new Error("API error");
      }
    } catch {
      setMessages(prev => [...prev, {
        role: "bot",
        text: `I'm having trouble connecting. Please try our Contact page${whatsappNumber ? ` or WhatsApp: https://wa.me/${whatsappNumber}` : ""}.`,
      }]);
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="fixed bottom-24 right-6 z-50 flex flex-col items-end gap-3">
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="w-80 bg-white rounded-2xl shadow-2xl border border-gray-100 flex flex-col overflow-hidden"
          >
            <div className="bg-[#1C1917] px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bot size={18} className="text-[#E84821]" />
                <span className="text-white text-sm font-semibold">{botName}</span>
                <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              </div>
              <button onClick={() => setOpen(false)} className="text-gray-400 hover:text-white transition-colors">
                <X size={16} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3 max-h-72">
              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[85%] rounded-xl px-3 py-2 text-sm leading-relaxed ${
                      msg.role === "user"
                        ? "bg-[#E84821] text-white font-medium"
                        : "bg-gray-100 text-gray-800"
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-gray-100 rounded-xl px-3 py-2 flex items-center gap-1.5">
                    <Loader2 size={14} className="text-gray-400 animate-spin" />
                    <span className="text-xs text-gray-400">Typing…</span>
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            <div className="border-t border-gray-100 p-3 flex gap-2">
              <input
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === "Enter" && !e.shiftKey && handleSend()}
                placeholder="Type a message…"
                disabled={isLoading}
                className="flex-1 text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#E84821]/40 focus:border-[#E84821] disabled:opacity-60"
              />
              <button
                onClick={handleSend}
                disabled={isLoading || !input.trim()}
                className="bg-[#E84821] text-white p-2 rounded-lg hover:bg-[#c73d1a] transition-colors disabled:opacity-60"
              >
                <Send size={16} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        onClick={() => setOpen(o => !o)}
        className="bg-[#1C1917] text-white p-4 rounded-full shadow-lg hover:bg-[#0d1533] transition-colors border-2 border-[#E84821]"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        title={`Chat with ${botName}`}
      >
        {open ? <X size={22} /> : <Bot size={22} className="text-[#E84821]" />}
      </motion.button>
    </div>
  );
}
