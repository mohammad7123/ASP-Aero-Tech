import { useState, useRef, useEffect } from "react";
import { Link, useLocation } from "wouter";
import {
  Menu, X, ChevronDown, Globe, Smartphone, Cloud, Shield, Lightbulb, Code2, ArrowRight,
  Boxes, LayoutGrid, Zap, HeadphonesIcon, Rocket, Database, TrendingUp,
  Factory, ShoppingBag, HardHat, Utensils, Briefcase, Settings,
  FlaskConical, Package, Pill, Truck, Car, Shirt, Key, Leaf,
  Brain, Plug, Users,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useSiteConfig } from "@/contexts/SiteConfigContext";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { getCurrentLang, setLang, applyDirection } from "@/lib/translate";
import { getTechIconUrl } from "@/lib/techIcon";
import { TechIcon } from "@/components/TechIcon";

type PublicService = { id: number; name: string; slug: string; category: string; shortDesc: string; iconName: string; accentColor: string };
const SERVICE_ICON_MAP: Record<string, React.ElementType> = {
  Globe, Smartphone, Cloud, Shield, Lightbulb, Code2, Briefcase, TrendingUp,
  MessageSquare: HeadphonesIcon, Database, Zap, Boxes, LayoutGrid, Rocket, Brain,
};

const LANGUAGES = [
  { code: "en", label: "English",    flag: "🇬🇧", rtl: false },
  { code: "fi", label: "Suomi",      flag: "🇫🇮", rtl: false },
  { code: "pt", label: "Português",  flag: "🇵🇹", rtl: false },
  { code: "fr", label: "Français",   flag: "🇫🇷", rtl: false },
  { code: "de", label: "Deutsch",    flag: "🇩🇪", rtl: false },
  { code: "es", label: "Español",    flag: "🇪🇸", rtl: false },
  { code: "zh", label: "中文",       flag: "🇨🇳", rtl: false },
  { code: "ja", label: "日本語",     flag: "🇯🇵", rtl: false },
  { code: "ko", label: "한국어",     flag: "🇰🇷", rtl: false },
  { code: "ar", label: "العربية",    flag: "🇸🇦", rtl: true  },
  { code: "hi", label: "हिन्दी",     flag: "🇮🇳", rtl: false },
  { code: "ta", label: "தமிழ்",     flag: "🇮🇳", rtl: false },
];

function LanguageSwitcher() {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const activeLang = getCurrentLang();
  const current = LANGUAGES.find(l => l.code === activeLang) ?? LANGUAGES[0];

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  useEffect(() => {
    applyDirection(activeLang);
  }, [activeLang]);

  return (
    <div ref={ref} className="relative notranslate">
      <button
        onClick={() => setOpen(o => !o)}
        className="flex items-center gap-1.5 text-sm font-semibold text-gray-700 hover:text-[#D4920C] transition-colors py-2 px-2 rounded-lg hover:bg-amber-50"
        aria-label={t("nav.langLabel")}
      >
        <Globe size={15} className="shrink-0" />
        <span className="hidden sm:inline">{current.flag} {current.code.toUpperCase()}</span>
        <ChevronDown size={12} className={`transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 6 }}
            transition={{ duration: 0.12 }}
            className="absolute right-0 top-full mt-2 w-44 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden z-50"
          >
            <div className="p-1">
              {LANGUAGES.map(lang => (
                <button
                  key={lang.code}
                  onClick={() => {
                    setLang(lang.code);
                    setOpen(false);
                  }}
                  className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors text-left ${
                    lang.code === activeLang
                      ? "bg-orange-50 text-[#E84821]"
                      : "text-gray-700 hover:bg-amber-50"
                  }`}
                >
                  <span className="text-base">{lang.flag}</span>
                  <span>{lang.label}</span>
                  {lang.code === activeLang && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-[#E84821]" />}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

const SERVICE_GROUPS = [
  {
    key: "build",
    items: [
      { icon: Globe, labelKey: "webDev", descKey: "webDevD", href: "/services/web-development" },
      { icon: Smartphone, labelKey: "mobileApps", descKey: "mobileAppsD", href: "/services/mobile-apps" },
      { icon: Code2, labelKey: "software", descKey: "softwareD", href: "/services/custom-software" },
    ],
  },
  {
    key: "run",
    items: [
      { icon: Cloud, labelKey: "cloud", descKey: "cloudD", href: "/services/cloud-solutions" },
      { icon: Shield, labelKey: "cyber", descKey: "cyberD", href: "/services/cybersecurity" },
    ],
  },
  {
    key: "grow",
    items: [
      { icon: Lightbulb,   labelKey: "consulting",       descKey: "consultingD",       href: "/services/it-consulting" },
      { icon: TrendingUp,  labelKey: "digitalMarketing", descKey: "digitalMarketingD", href: "/services/digital-marketing" },
    ],
  },
];

const SERVICE_LABELS: Record<string, { label: string; desc: string }> = {
  webDev:     { label: "Web Development",  desc: "Modern websites & web apps" },
  mobileApps: { label: "Mobile Apps",       desc: "iOS, Android & cross-platform" },
  software:   { label: "Custom Software",   desc: "Tailored business solutions" },
  cloud:      { label: "Cloud Solutions",   desc: "AWS, Azure, GCP architecture" },
  cyber:      { label: "Cybersecurity",     desc: "Audits, hardening, monitoring" },
  consulting:       { label: "IT Consulting",      desc: "Digital transformation strategy" },
  digitalMarketing: { label: "Digital Marketing", desc: "SEO, PPC, social & AI marketing" },
};

const ERP_ITEMS = [
  { icon: LayoutGrid, label: "SAP Business One",        desc: "Complete ERP for growing SMEs",          href: "/sap-business-one",      accent: "#E84821" },
  { icon: Zap,        label: "SAP Business One HANA",   desc: "In-memory ERP at lightning speed",       href: "/sap-business-one-hana", accent: "#D4920C" },
  { icon: Rocket,     label: "Rise with SAP HANA",      desc: "Business transformation as a service",   href: "/rise-with-sap",         accent: "#3D4FA0" },
  { icon: Database,   label: "S4 HANA",                 desc: "Intelligent enterprise ERP suite",       href: "/s4-hana",               accent: "#E84821" },
  { icon: Cloud,      label: "SAP B1 On Cloud",         desc: "Managed cloud ERP, no servers",          href: "/sap-b1-on-cloud",       accent: "#D4920C" },
  { icon: HeadphonesIcon, label: "Support Service",     desc: "SLA-backed AMC & helpdesk",              href: "/support-service",       accent: "#3D4FA0" },
];

const INDUSTRY_ITEMS = [
  { icon: Factory,     label: "Manufacturing",              href: "/industries" },
  { icon: ShoppingBag, label: "Retail",                     href: "/industries" },
  { icon: HardHat,     label: "Construction",               href: "/industries" },
  { icon: Utensils,    label: "Food & Beverages",           href: "/industries" },
  { icon: Briefcase,   label: "Professional Services",      href: "/industries" },
  { icon: Settings,    label: "Engineering",                href: "/industries" },
  { icon: FlaskConical,label: "Chemicals & Dyes",           href: "/industries" },
  { icon: Package,     label: "Packaging",                  href: "/industries" },
  { icon: Pill,        label: "Pharma",                     href: "/industries" },
  { icon: Truck,       label: "Wholesale & Distribution",   href: "/industries" },
  { icon: Car,         label: "Automotive",                 href: "/industries" },
  { icon: Shirt,       label: "Textile",                    href: "/industries" },
  { icon: Key,         label: "Rental Services",            href: "/industries" },
  { icon: Leaf,        label: "Agriculture & Horticulture", href: "/industries" },
];

const PRODUCT_CATEGORIES = [
  {
    key: "erp", title: "ERP Products", count: "19", icon: Database, accent: "#E84821",
    href: "/products/erp",
    items: [
      { label: "SAP Business One", href: "/sap-business-one" },
      { label: "SAP Business One HANA", href: "/sap-business-one-hana" },
      { label: "SAP S/4 HANA", href: "/s4-hana" },
      { label: "SAP Cloud Hosting", href: "/sap-b1-on-cloud" },
      { label: "View all 19 products →", href: "/products/erp" },
    ],
  },
  {
    key: "bizApps", title: "Business Applications", count: "14", icon: Briefcase, accent: "#D4920C",
    href: "/products/business-apps",
    items: [
      { label: "Ecommerce Platform", href: "/products/business-apps" },
      { label: "WMS 360", href: "/wms360" },
      { label: "Order Management System", href: "/products/business-apps" },
      { label: "MyHROne (HRMS)", href: "/myhrone" },
      { label: "View all 14 products →", href: "/products/business-apps" },
    ],
  },
  {
    key: "ai", title: "AI Solutions", count: "11", icon: Brain, accent: "#3D4FA0",
    href: "/products/ai-solutions",
    items: [
      { label: "AI Analytics Assistant", href: "/products/ai-solutions" },
      { label: "AI ERP Chatbot", href: "/products/ai-solutions" },
      { label: "AI Demand Forecasting", href: "/products/ai-solutions" },
      { label: "AI Document Intelligence", href: "/products/ai-solutions" },
      { label: "View all 11 products →", href: "/products/ai-solutions" },
    ],
  },
  {
    key: "cloud", title: "Cloud Platforms", count: "8", icon: Cloud, accent: "#E84821",
    href: "/products/cloud-platforms",
    items: [
      { label: "B1Plus Cloud", href: "/b1plus-cloud" },
      { label: "Managed AWS Hosting", href: "/products/cloud-platforms" },
      { label: "Managed Azure Hosting", href: "/products/cloud-platforms" },
      { label: "Backup & Disaster Recovery", href: "/products/cloud-platforms" },
      { label: "View all 8 products →", href: "/products/cloud-platforms" },
    ],
  },
  {
    key: "integration", title: "Integration Suite", count: "13", icon: Plug, accent: "#D4920C",
    href: "/products/integration-suite",
    items: [
      { label: "SAP Integration Hub", href: "/products/integration-suite" },
      { label: "Marketplace Integration", href: "/products/integration-suite" },
      { label: "Payment Gateway", href: "/products/integration-suite" },
      { label: "GST & E-Invoice", href: "/products/integration-suite" },
      { label: "View all 13 products →", href: "/products/integration-suite" },
    ],
  },
];

const TECH_NAV_ITEMS = [
  { label: "Microsoft",               href: "/technologies/microsoft",           accent: "#0078D4" },
  { label: "Open Source",             href: "/technologies/open-source",         accent: "#F7931E" },
  { label: "Mobile",                  href: "/technologies/mobile",              accent: "#3DDC84" },
  { label: "Front-End",               href: "/technologies/frontend",            accent: "#E34F26" },
  { label: "Big Data",                href: "/technologies/big-data",            accent: "#E25A1C" },
  { label: "Java",                    href: "/technologies/java",                accent: "#5382A1" },
  { label: "AI, ML & Data Science",   href: "/technologies/ai-ml-data-science",  accent: "#FF6F00" },
  { label: "Asynchronous Messaging",  href: "/technologies/async-messaging",     accent: "#FF6600" },
  { label: "ERP Solutions",           href: "/technologies/erp-solutions",       accent: "#0FAAFF" },
];

type TechEntry = { name: string; slug: string; color: string };
const TECH_MEGA_CATS: { id: string; title: string; techs: TechEntry[] }[] = [
  {
    id: "microsoft", title: "Microsoft",
    techs: [
      { name: ".NET Framework", slug: "dotnet",              color: "#512BD4" },
      { name: ".NET MVC",       slug: "dotnet",              color: "#512BD4" },
      { name: ".NET Core",      slug: "dotnet",              color: "#7B2FF7" },
      { name: "Azure",          slug: "microsoftazure",      color: "#0078D4" },
      { name: "SQL Server",     slug: "microsoftsqlserver",  color: "#CC2927" },
      { name: "SharePoint",     slug: "microsoftsharepoint", color: "#0078D4" },
    ],
  },
  {
    id: "open-source", title: "Open Source",
    techs: [
      { name: "PHP",            slug: "php",        color: "#777BB4" },
      { name: "Magento",        slug: "magento",    color: "#EE672F" },
      { name: "WordPress",      slug: "wordpress",  color: "#21759B" },
      { name: "Drupal",         slug: "drupal",     color: "#0678BE" },
      { name: "Zend Framework", slug: "zend",       color: "#68B604" },
      { name: "MySQL",          slug: "mysql",      color: "#4479A1" },
      { name: "Node.js",        slug: "nodedotjs",  color: "#339933" },
      { name: "PostgreSQL",     slug: "postgresql", color: "#336791" },
    ],
  },
  {
    id: "mobile", title: "Mobile",
    techs: [
      { name: "iOS",          slug: "apple",    color: "#555555" },
      { name: "Android",      slug: "android",  color: "#3DDC84" },
      { name: "Flutter",      slug: "flutter",  color: "#02569B" },
      { name: "Ionic",        slug: "ionic",    color: "#3880FF" },
      { name: "React Native", slug: "react",    color: "#61DAFB" },
    ],
  },
  {
    id: "frontend", title: "Front-End",
    techs: [
      { name: "HTML5",       slug: "html5",       color: "#E34F26" },
      { name: "Angular JS",  slug: "angular",     color: "#DD0031" },
      { name: "React",       slug: "react",       color: "#61DAFB" },
      { name: "Vue JS",      slug: "vuedotjs",    color: "#4FC08D" },
      { name: "TypeScript",  slug: "typescript",  color: "#3178C6" },
      { name: "Svelte",      slug: "svelte",      color: "#FF3E00" },
    ],
  },
  {
    id: "big-data", title: "Big Data",
    techs: [
      { name: "MongoDB",      slug: "mongodb",           color: "#47A248" },
      { name: "Hadoop",       slug: "apachehadoop",      color: "#CC8400" },
      { name: "CouchDB",      slug: "apachecouchdb",     color: "#E42528" },
      { name: "HBase",        slug: "apache",            color: "#D22128" },
      { name: "Apache Spark", slug: "apachespark",       color: "#E25A1C" },
      { name: "Cassandra",    slug: "apachecassandra",   color: "#1287B1" },
      { name: "Apache Flink", slug: "apacheflink",       color: "#E6526F" },
    ],
  },
  {
    id: "java", title: "Java",
    techs: [
      { name: "Spring",     slug: "spring",      color: "#6DB33F" },
      { name: "Struts",     slug: "apache",      color: "#D22128" },
      { name: "Hibernate",  slug: "hibernate",   color: "#59666C" },
      { name: "Maven",      slug: "apachemaven", color: "#C71A36" },
    ],
  },
  {
    id: "ai-ml-data-science", title: "AI, ML & Data Science",
    techs: [
      { name: "ML Kit",       slug: "google",      color: "#4285F4" },
      { name: "TensorFlow",   slug: "tensorflow",  color: "#FF6F00" },
      { name: "Blockchain",   slug: "ethereum",    color: "#3C3C3D" },
      { name: "Keras",        slug: "keras",       color: "#D00000" },
      { name: "OpenCV",       slug: "opencv",      color: "#5C3EE8" },
      { name: "RAG Pipeline", slug: "langchain",   color: "#1C3C3C" },
    ],
  },
  {
    id: "async-messaging", title: "Asynchronous Messaging",
    techs: [
      { name: "Kafka",         slug: "apachekafka",    color: "#231F20" },
      { name: "RabbitMQ",      slug: "rabbitmq",       color: "#FF6600" },
      { name: "Apache Airflow",slug: "apacheairflow",  color: "#017CEE" },
      { name: "Celery",        slug: "celery",         color: "#37814A" },
      { name: "Redis",         slug: "redis",          color: "#DC382D" },
      { name: "Apache Storm",  slug: "apache",         color: "#D22128" },
    ],
  },
  {
    id: "erp-solutions", title: "ERP Solutions",
    techs: [
      { name: "SAP Business One", slug: "sap",  color: "#0FAAFF" },
      { name: "SAP S/4 HANA",    slug: "sap",  color: "#0FAAFF" },
      { name: "SAP B1 HANA",     slug: "sap",  color: "#0FAAFF" },
      { name: "Odoo",            slug: "odoo", color: "#714B67" },
    ],
  },
];

type MegaKey = "services" | "erp" | "industries" | "products" | "technologies" | null;

export default function Navbar() {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const [megaOpen, setMegaOpen] = useState<MegaKey>(null);
  const [location] = useLocation();
  const config = useSiteConfig();
  const { siteName, logoUrl, menuItems, primaryColor } = config;

  const [translateOffset, setTranslateOffset] = useState(0);
  useEffect(() => {
    const check = () => {
      const translated =
        document.body.classList.contains("translated-ltr") ||
        document.body.classList.contains("translated-rtl");
      setTranslateOffset(translated ? 39 : 0);
    };
    check();
    const observer = new MutationObserver(check);
    observer.observe(document.body, { attributes: true, attributeFilter: ["class"] });
    return () => observer.disconnect();
  }, []);

  const handleEnter = (key: MegaKey) => setMegaOpen(key);
  const handleLeave = () => setMegaOpen(null);

  const groupTitleMap: Record<string, string> = {
    build: t("nav.erpBuild"),
    run:   t("nav.erpRun"),
    grow:  t("nav.erpGrow"),
  };

  // Pull services from DB (admin-managed). Fall back to hardcoded SERVICE_GROUPS
  // if the API returns nothing or fails — keeps the menu populated for first-time users.
  const { data: dbServices } = useQuery<PublicService[]>({
    queryKey: ["public-services"],
    queryFn: async () => {
      const r = await fetch("/api/public/services");
      if (!r.ok) throw new Error("services fetch failed");
      return r.json();
    },
    staleTime: 60_000,
    retry: 1,
  });

  const dynamicGroups = (() => {
    if (!dbServices || dbServices.length === 0) return null;
    // Only include the IT-services categories the static menu used (build/run/grow).
    // SAP/products/support live in their own mega-menu sections.
    const allowed = new Set(["build", "run", "grow"]);
    const buckets: Record<string, PublicService[]> = { build: [], run: [], grow: [] };
    for (const s of dbServices) {
      if (allowed.has(s.category)) buckets[s.category].push(s);
    }
    if (buckets.build.length + buckets.run.length + buckets.grow.length === 0) return null;
    return ["build", "run", "grow"]
      .filter(k => buckets[k].length > 0)
      .map(k => ({ key: k, items: buckets[k] }));
  })();

  return (
    <>
      {/* Brand strip */}
      <div className="fixed left-0 right-0 z-[60] h-1 flex" style={{ top: translateOffset }}>
        <div className="flex-1 bg-[#E84821]" />
        <div className="flex-1" style={{ backgroundColor: primaryColor }} />
        <div className="flex-1 bg-[#3D4FA0]" />
      </div>

      <nav className="fixed left-0 right-0 z-50 bg-white border-b border-gray-100 shadow-sm" style={{ top: translateOffset + 4 }}>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-4">
            <Link href="/" className="flex items-center" data-testid="link-home-logo">
              {logoUrl ? (
                <img src={logoUrl} alt={siteName} className="h-14 w-auto object-contain" />
              ) : (
                <span className="text-xl font-bold text-gray-900">{siteName}</span>
              )}
            </Link>

            {/* Desktop nav */}
            <div className="hidden lg:flex items-center gap-5">
              {menuItems.map(item => {
                const label = item.label.toLowerCase();
                if (label === "contact" || label === "contact us" || label === "get in touch" || label === "blog") return null;
                const isServices   = label.includes("service") || label.includes("what we do");
                const isErp        = label.includes("erp");
                const isIndustries = label.includes("industr");
                const active = location === item.url || location.startsWith(item.url + "/");

                if (isServices) {
                  return (
                    <div key={item.id} className="relative" onMouseEnter={() => handleEnter("services")} onMouseLeave={handleLeave}>
                      <button className="flex items-center gap-1 text-sm font-semibold transition-colors py-2 hover:text-[#D4920C]" style={{ color: active ? "#E84821" : "#1F2937" }}>
                        {item.label} <ChevronDown size={14} className={`transition-transform ${megaOpen === "services" ? "rotate-180" : ""}`} />
                      </button>
                      <AnimatePresence>
                        {megaOpen === "services" && (
                          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }} transition={{ duration: 0.15 }} className="absolute top-full left-1/2 -translate-x-1/2 pt-3 w-[960px]">
                            <div className="bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden">
                              <div className="grid grid-cols-3 divide-x divide-gray-100">

                                {/* Col 1 — IT Services (DB-driven, falls back to static) */}
                                <div className="p-6">
                                  <div className="text-[11px] font-bold uppercase tracking-widest mb-5 text-gray-400">{t("nav.itServices")}</div>
                                  {(dynamicGroups ?? SERVICE_GROUPS).map(g => (
                                    <div key={g.key} className="mb-5 last:mb-0">
                                      <div className="text-[10px] font-bold uppercase tracking-widest mb-3" style={{ color: primaryColor }}>{groupTitleMap[g.key] ?? g.key}</div>
                                      <div className="space-y-2">
                                        {g.items.map((s) => {
                                          const isDb = "slug" in s;
                                          const Icon = isDb
                                            ? (SERVICE_ICON_MAP[(s as PublicService).iconName] ?? Briefcase)
                                            : (s as { icon: React.ElementType }).icon;
                                          const labelKey = isDb ? (s as PublicService).slug : (s as { labelKey: string }).labelKey;
                                          const label = isDb
                                            ? (s as PublicService).name
                                            : t(`home.services.${(s as { labelKey: string }).labelKey}`);
                                          const desc = isDb
                                            ? (s as PublicService).shortDesc
                                            : SERVICE_LABELS[(s as { labelKey: string }).labelKey]?.desc ?? "";
                                          const DB_SERVICE_HREF: Record<string, string> = {
                                            "web-development":    "/services/web-development",
                                            "mobile-apps":        "/services/mobile-apps",
                                            "custom-software":    "/services/custom-software",
                                            "erp-solutions":      "/services/erp-solutions",
                                            "cloud-solutions":    "/services/cloud-solutions",
                                            "cybersecurity":      "/services/cybersecurity",
                                            "it-consulting":      "/services/it-consulting",
                                            "digital-marketing":  "/services/digital-marketing",
                                            "Web Development":    "/services/web-development",
                                            "Mobile Apps":        "/services/mobile-apps",
                                            "Custom Software":    "/services/custom-software",
                                            "Cloud Solutions":    "/services/cloud-solutions",
                                            "Cybersecurity":      "/services/cybersecurity",
                                            "IT Consulting":      "/services/it-consulting",
                                            "Digital Marketing":  "/services/digital-marketing",
                                          };
                                          const href = isDb
                                            ? (DB_SERVICE_HREF[(s as PublicService).slug] ?? DB_SERVICE_HREF[(s as PublicService).name] ?? `/services`)
                                            : (s as { href: string }).href;
                                          return (
                                            <Link key={labelKey} href={href} className="flex items-center gap-2.5 group py-1.5 px-2 rounded-lg hover:bg-amber-50 transition-colors">
                                              <div className="p-1.5 rounded-lg flex-shrink-0 transition-colors group-hover:bg-amber-100" style={{ backgroundColor: `${primaryColor}12` }}>
                                                <Icon size={13} className="transition-colors group-hover:text-[#D4920C]" style={{ color: primaryColor }} />
                                              </div>
                                              <div>
                                                <div className="text-sm font-semibold text-gray-800 group-hover:text-[#D4920C] transition-colors leading-tight">{label}</div>
                                                <div className="text-[11px] text-gray-400 mt-0.5 leading-tight">{desc}</div>
                                              </div>
                                            </Link>
                                          );
                                        })}
                                      </div>
                                    </div>
                                  ))}
                                </div>

                                {/* Col 2 — ERP */}
                                <div className="p-6">
                                  <div className="text-[11px] font-bold uppercase tracking-widest mb-5 text-gray-400">{t("nav.erpSolutions")}</div>
                                  <div className="space-y-2">
                                    {ERP_ITEMS.map(e => {
                                      const Icon = e.icon;
                                      return (
                                        <Link key={e.label} href={e.href} className="flex items-center gap-2.5 group py-1.5 px-2 rounded-lg hover:bg-amber-50 transition-colors">
                                          <div className="p-1.5 rounded-lg flex-shrink-0" style={{ backgroundColor: `${e.accent}15` }}>
                                            <Icon size={13} style={{ color: e.accent }} />
                                          </div>
                                          <div>
                                            <div className="text-sm font-semibold text-gray-800 group-hover:text-[#D4920C] transition-colors leading-tight">{e.label}</div>
                                            <div className="text-[11px] text-gray-400 mt-0.5 leading-tight">{e.desc}</div>
                                          </div>
                                        </Link>
                                      );
                                    })}
                                  </div>
                                </div>

                                {/* Col 3 — Flagship Products */}
                                <div className="p-6 bg-gradient-to-b from-gray-50/60 to-white flex flex-col">
                                  <div className="text-[11px] font-bold uppercase tracking-widest mb-5 text-gray-400">Flagship Products</div>
                                  <Link href="/wms360" className="group flex flex-col rounded-xl border border-gray-100 hover:border-[#D4920C]/40 overflow-hidden hover:shadow-lg transition-all">
                                    <div className="relative h-[120px] overflow-hidden">
                                      <img src="https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=500&q=75" alt="WMS 360 warehouse management" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                                      <div className="absolute inset-0 bg-gradient-to-t from-[#1A1F36]/60 to-transparent" />
                                      <div className="absolute bottom-2 left-3 flex items-center gap-1.5">
                                        <div className="w-5 h-5 rounded flex items-center justify-center bg-[#E84821]">
                                          <Boxes size={11} className="text-white" />
                                        </div>
                                        <span className="text-white text-xs font-bold">WMS 360</span>
                                      </div>
                                    </div>
                                    <div className="p-4 flex flex-col flex-1">
                                      <div className="text-sm font-bold text-gray-900 mb-1.5 group-hover:text-[#D4920C] transition-colors">{t("nav.totalWarehouseIntel")}</div>
                                      <p className="text-[11px] text-gray-500 leading-relaxed flex-1">{t("nav.warehouseDesc")}</p>
                                      <div className="mt-3 flex items-center gap-1 text-xs font-bold text-[#E84821]">
                                        {t("nav.exploreWms")} <ArrowRight size={12} />
                                      </div>
                                    </div>
                                  </Link>
                                  {/* MyHROne */}
                                  <Link href="/myhrone" className="mt-3 group flex items-center gap-3 p-3 rounded-xl border border-gray-100 hover:border-[#D4920C]/40 hover:shadow-md transition-all bg-white">
                                    <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-[#3D4FA0]/10 flex-shrink-0">
                                      <Users size={15} className="text-[#3D4FA0]" />
                                    </div>
                                    <div className="flex-1 min-w-0">
                                      <div className="text-sm font-bold text-gray-900 group-hover:text-[#D4920C] transition-colors">MyHROne</div>
                                      <div className="text-[11px] text-gray-500">HRMS &amp; Payroll Platform</div>
                                    </div>
                                    <ArrowRight size={12} className="text-gray-400 group-hover:text-[#D4920C] transition-colors flex-shrink-0" />
                                  </Link>

                                  <Link href="/contact" className="mt-3 flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-xl text-xs font-bold text-white transition-all hover:-translate-y-0.5 hover:shadow-md" style={{ backgroundColor: primaryColor }}>
                                    {t("nav.getFreeDemo")} <ArrowRight size={12} />
                                  </Link>
                                </div>

                              </div>
                              <div className="bg-gradient-to-r from-[#E84821] via-[#D4920C] to-[#3D4FA0] h-1" />
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                }

                if (isErp) {
                  return (
                    <div key={item.id} className="relative" onMouseEnter={() => handleEnter("erp")} onMouseLeave={handleLeave}>
                      <button className="flex items-center gap-1 text-sm font-semibold transition-colors py-2 hover:text-[#D4920C]" style={{ color: megaOpen === "erp" ? "#E84821" : "#1F2937" }}>
                        {item.label} <ChevronDown size={14} className={`transition-transform ${megaOpen === "erp" ? "rotate-180" : ""}`} />
                      </button>
                      <AnimatePresence>
                        {megaOpen === "erp" && (
                          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }} transition={{ duration: 0.15 }} className="absolute top-full left-1/2 -translate-x-1/2 pt-3 w-[640px]">
                            <div className="bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden">
                              <div className="p-6">
                                <div className="text-[11px] font-bold uppercase tracking-widest mb-5" style={{ color: primaryColor }}>{t("nav.erpSolutions")}</div>
                                <div className="grid grid-cols-2 gap-3">
                                  {ERP_ITEMS.map(e => {
                                    const Icon = e.icon;
                                    return (
                                      <Link key={e.label} href={e.href} className="flex items-start gap-3 group p-3 rounded-xl hover:bg-amber-50 transition-colors">
                                        <div className="p-2 rounded-lg flex-shrink-0" style={{ backgroundColor: `${e.accent}15` }}>
                                          <Icon size={15} style={{ color: e.accent }} />
                                        </div>
                                        <div>
                                          <div className="text-sm font-semibold text-gray-900 group-hover:text-[#D4920C] transition-colors leading-tight">{e.label}</div>
                                          <div className="text-xs text-gray-500 mt-0.5">{e.desc}</div>
                                        </div>
                                      </Link>
                                    );
                                  })}
                                </div>
                              </div>
                              <div className="bg-gradient-to-r from-[#E84821] via-[#D4920C] to-[#3D4FA0] h-1" />
                              <Link href="/contact" className="flex items-center justify-between px-6 py-4 bg-gray-50 hover:bg-amber-100 transition-colors">
                                <span className="text-sm font-semibold text-gray-900">{t("nav.talkSapConsultant")}</span>
                                <span className="flex items-center gap-1.5 text-sm font-bold text-[#E84821]">{t("common.contactUs")} <ArrowRight size={14} /></span>
                              </Link>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                }

                const isProducts = label.includes("product");

                if (isProducts) {
                  return (
                    <div key={item.id} className="relative" onMouseEnter={() => handleEnter("products")} onMouseLeave={handleLeave}>
                      <button className="flex items-center gap-1 text-sm font-semibold transition-colors py-2 hover:text-[#D4920C]" style={{ color: megaOpen === "products" || active ? "#E84821" : "#1F2937" }}>
                        {item.label} <ChevronDown size={14} className={`transition-transform ${megaOpen === "products" ? "rotate-180" : ""}`} />
                      </button>
                      <AnimatePresence>
                        {megaOpen === "products" && (
                          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }} transition={{ duration: 0.15 }} className="absolute top-full left-1/2 -translate-x-1/2 pt-3 w-[1100px]">
                            <div className="bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden">
                              {/* Header */}
                              <div className="px-6 pt-5 pb-3 border-b border-gray-50 flex items-center justify-between">
                                <div>
                                  <div className="text-[11px] font-bold uppercase tracking-widest text-gray-400">Our Products</div>
                                  <div className="text-xs text-gray-500 mt-0.5">65+ products across 5 categories</div>
                                </div>
                                <Link href="/products" className="flex items-center gap-1 text-xs font-bold text-[#D4920C] hover:text-[#E84821] transition-colors">
                                  View all products <ArrowRight size={12} />
                                </Link>
                              </div>
                              {/* 5-column grid */}
                              <div className="grid grid-cols-5 divide-x divide-gray-50 px-2 py-4">
                                {PRODUCT_CATEGORIES.map(cat => {
                                  const CatIcon = cat.icon;
                                  return (
                                    <div key={cat.key} className="px-4">
                                      <Link href={cat.href} className="group flex items-center gap-2 mb-3 pb-2 border-b border-gray-50 hover:border-[#D4920C]/30 transition-colors">
                                        <div className="p-1.5 rounded-lg flex-shrink-0" style={{ backgroundColor: `${cat.accent}15` }}>
                                          <CatIcon size={13} style={{ color: cat.accent }} />
                                        </div>
                                        <div>
                                          <div className="text-[11px] font-bold text-gray-800 group-hover:text-[#D4920C] transition-colors leading-tight">{cat.title}</div>
                                          <div className="text-[10px]" style={{ color: cat.accent }}>{cat.count} products</div>
                                        </div>
                                      </Link>
                                      <div className="space-y-0.5">
                                        {cat.items.map(it => (
                                          <Link key={it.label} href={it.href} className={`block text-xs py-1.5 px-1.5 rounded-lg transition-colors leading-tight ${it.label.startsWith("View all") ? "font-semibold" : "text-gray-600 hover:bg-amber-50 hover:text-[#D4920C]"}`} style={it.label.startsWith("View all") ? { color: cat.accent } : {}}>
                                            {it.label}
                                          </Link>
                                        ))}
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                              {/* Footer CTA */}
                              <div className="bg-gradient-to-r from-[#E84821] via-[#D4920C] to-[#3D4FA0] h-1" />
                              <Link href="/contact" className="flex items-center justify-between px-6 py-4 bg-gray-50 hover:bg-amber-50 transition-colors">
                                <span className="text-sm font-semibold text-gray-900">Need help choosing the right product?</span>
                                <span className="flex items-center gap-1.5 text-sm font-bold text-[#E84821]">Talk to a Specialist <ArrowRight size={14} /></span>
                              </Link>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                }

                if (isIndustries) {
                  return (
                    <div key={item.id} className="relative" onMouseEnter={() => handleEnter("industries")} onMouseLeave={handleLeave}>
                      <button className="flex items-center gap-1 text-sm font-semibold transition-colors py-2 hover:text-[#D4920C]" style={{ color: megaOpen === "industries" ? "#E84821" : "#1F2937" }}>
                        {item.label} <ChevronDown size={14} className={`transition-transform ${megaOpen === "industries" ? "rotate-180" : ""}`} />
                      </button>
                      <AnimatePresence>
                        {megaOpen === "industries" && (
                          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }} transition={{ duration: 0.15 }} className="absolute top-full left-1/2 -translate-x-1/2 pt-3 w-[480px]">
                            <div className="bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden">
                              <div className="p-6">
                                <div className="text-[11px] font-bold uppercase tracking-widest mb-4" style={{ color: primaryColor }}>{t("nav.industriesWeServe")}</div>
                                <div className="grid grid-cols-2 gap-y-1">
                                  {INDUSTRY_ITEMS.map((ind) => {
                                    const Icon = ind.icon;
                                    return (
                                      <Link key={ind.label} href={ind.href} className="flex items-center gap-2.5 py-2 px-2 rounded-lg hover:bg-amber-50 group transition-colors">
                                        <Icon size={14} className="flex-shrink-0 text-gray-400 group-hover:text-[#D4920C] transition-colors" />
                                        <span className="text-sm text-gray-700 group-hover:text-[#D4920C] transition-colors font-medium">{ind.label}</span>
                                      </Link>
                                    );
                                  })}
                                </div>
                              </div>
                              <div className="bg-gradient-to-r from-[#E84821] via-[#D4920C] to-[#3D4FA0] h-1" />
                              <Link href="/industries" className="flex items-center justify-between px-6 py-4 bg-gray-50 hover:bg-amber-100 transition-colors">
                                <span className="text-sm font-semibold text-gray-900">{t("nav.viewAllIndustries")}</span>
                                <span className="flex items-center gap-1.5 text-sm font-bold text-[#E84821]">{t("common.exploreAll")} <ArrowRight size={14} /></span>
                              </Link>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                }

                return (
                  <Link
                    key={item.id}
                    href={item.url}
                    target={item.openInNewTab ? "_blank" : undefined}
                    rel={item.openInNewTab ? "noopener noreferrer" : undefined}
                    className="text-sm font-semibold transition-colors py-2 hover:text-[#D4920C]"
                    style={{ color: active ? "#E84821" : "#1F2937" }}
                    data-testid={`link-nav-${item.label}`}
                  >
                    {item.label}
                  </Link>
                );
              })}

              {/* Technologies — full-width mega-menu */}
              <div className="relative" onMouseEnter={() => handleEnter("technologies")} onMouseLeave={handleLeave}>
                <button
                  className="flex items-center gap-1 text-sm font-semibold transition-colors py-2 hover:text-[#D4920C]"
                  style={{ color: megaOpen === "technologies" || location.startsWith("/technologies") ? "#E84821" : "#1F2937" }}
                >
                  {t("nav.technologies")} <ChevronDown size={14} className={`transition-transform ${megaOpen === "technologies" ? "rotate-180" : ""}`} />
                </button>
                <AnimatePresence>
                  {megaOpen === "technologies" && (
                    <motion.div
                      initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }}
                      transition={{ duration: 0.15 }}
                      className="fixed left-0 right-0 z-50 shadow-2xl"
                      style={{ top: translateOffset + 92 }}
                    >
                      <div className="bg-white border-t border-gray-100">
                        <div className="max-w-[1400px] mx-auto px-6 py-6 overflow-x-auto">
                          <div className="flex gap-8 min-w-max">
                            {TECH_MEGA_CATS.map(cat => (
                              <div key={cat.id} className="min-w-[110px]">
                                <Link
                                  href={`/technologies/${cat.id}`}
                                  onClick={() => setMegaOpen(null)}
                                  className="block text-[11px] font-bold text-gray-800 mb-4 pb-1.5 border-b-2 border-gray-300 hover:text-[#E84821] hover:border-[#E84821] transition-colors whitespace-nowrap"
                                >
                                  {cat.title}
                                </Link>
                                <div className="flex flex-col items-center gap-4">
                                  {cat.techs.map(tech => (
                                    <Link
                                      key={tech.name}
                                      href={`/technologies/${cat.id}`}
                                      onClick={() => setMegaOpen(null)}
                                      className="flex flex-col items-center gap-1.5 group w-full"
                                    >
                                      <div className="flex items-center justify-center w-full group-hover:scale-110 transition-transform duration-200">
                                        <TechIcon slug={tech.slug} color={tech.color} name={tech.name} size={36} />
                                      </div>
                                      <span className="text-[10px] text-gray-500 text-center leading-tight group-hover:text-[#E84821] transition-colors w-full">{tech.name}</span>
                                    </Link>
                                  ))}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                        <div className="h-1 bg-gradient-to-r from-[#E84821] via-[#D4920C] to-[#3D4FA0]" />
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <Link
                href="/careers"
                className="text-sm font-semibold transition-colors py-2 hover:text-[#D4920C]"
                style={{ color: location === "/careers" ? "#E84821" : "#1F2937" }}
              >
                {t("nav.careers")}
              </Link>

              <a
                href={config.supportLoginUrl || "#"}
                target={config.supportLoginUrl ? "_blank" : undefined}
                rel={config.supportLoginUrl ? "noopener noreferrer" : undefined}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-bold border transition-all text-center leading-snug min-w-[96px]"
                style={{ borderColor: primaryColor, color: primaryColor, backgroundColor: `${primaryColor}10` }}
                onClick={e => { if (!config.supportLoginUrl) e.preventDefault(); }}
                onMouseEnter={e => { const el = e.currentTarget; el.style.backgroundColor = "#D4920C"; el.style.borderColor = "#D4920C"; el.style.color = "#fff"; }}
                onMouseLeave={e => { const el = e.currentTarget; el.style.backgroundColor = `${primaryColor}10`; el.style.borderColor = primaryColor; el.style.color = primaryColor; }}
              >
                <HeadphonesIcon size={13} className="flex-shrink-0" />
                <span>{t("nav.supportLogin")}</span>
              </a>
              <Link
                href="/contact"
                className="flex items-center justify-center px-5 py-2.5 rounded-lg text-sm font-bold text-white shadow-md hover:shadow-lg hover:-translate-y-0.5 text-center"
                style={{ backgroundColor: primaryColor || "#E84821", transform: "translateY(0)" }}
                data-testid="link-nav-cta"
              >
                {t("nav.getStarted")}
              </Link>
              <LanguageSwitcher />
            </div>

            {/* Mobile: lang switcher + hamburger */}
            <div className="lg:hidden flex items-center gap-1">
              <LanguageSwitcher />
              <button className="text-gray-700 p-2" onClick={() => setOpen(!open)} data-testid="button-mobile-menu">
                {open ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile nav */}
        <AnimatePresence>
          {open && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="lg:hidden bg-white border-t border-gray-100 overflow-hidden">
              <div className="px-4 py-4 flex flex-col gap-1 max-h-[75vh] overflow-y-auto">
                {menuItems.filter(item => {
                  const lbl = item.label.toLowerCase();
                  return lbl !== "contact" && lbl !== "contact us" && lbl !== "get in touch";
                }).map(item => (
                  <Link
                    key={item.id}
                    href={item.url}
                    target={item.openInNewTab ? "_blank" : undefined}
                    rel={item.openInNewTab ? "noopener noreferrer" : undefined}
                    className="text-sm font-semibold py-3 px-3 rounded hover:bg-amber-50"
                    style={{ color: location === item.url ? "#E84821" : "#1F2937" }}
                    onClick={() => setOpen(false)}
                  >
                    {item.label}
                  </Link>
                ))}
                <div className="mt-1 border-t border-gray-100 pt-2">
                  <div className="text-[10px] font-bold uppercase tracking-widest text-gray-400 px-3 py-1.5">{t("nav.technologies")}</div>
                  <div className="grid grid-cols-2 gap-0.5">
                    {TECH_NAV_ITEMS.map(t => (
                      <Link key={t.href} href={t.href}
                        className="flex items-center gap-2 text-sm text-gray-600 py-2 px-3 rounded hover:bg-amber-50"
                        onClick={() => setOpen(false)}>
                        <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: t.accent }} />
                        {t.label}
                      </Link>
                    ))}
                  </div>
                </div>
                <Link href="/careers" className="text-sm font-semibold py-3 px-3 rounded hover:bg-amber-50 block" style={{ color: location === "/careers" ? "#E84821" : "#1F2937" }} onClick={() => setOpen(false)}>{t("nav.careers")}</Link>
                <div className="mt-1 border-t border-gray-100 pt-2">
                  <div className="text-[10px] font-bold uppercase tracking-widest text-gray-400 px-3 py-1.5">{t("nav.erpSolutions")}</div>
                  {ERP_ITEMS.map(e => (
                    <Link key={e.label} href={e.href} className="text-sm text-gray-600 py-2 px-3 rounded hover:bg-amber-50 flex items-center gap-2" onClick={() => setOpen(false)}>
                      <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: e.accent }} />
                      {e.label}
                    </Link>
                  ))}
                </div>
                <div className="mt-1 border-t border-gray-100 pt-2">
                  <div className="text-[10px] font-bold uppercase tracking-widest text-gray-400 px-3 py-1.5">{t("nav.industriesWeServe")}</div>
                  <div className="grid grid-cols-2 gap-0.5">
                    {INDUSTRY_ITEMS.map(ind => (
                      <Link key={ind.label} href={ind.href} className="text-sm text-gray-600 py-2 px-3 rounded hover:bg-amber-50" onClick={() => setOpen(false)}>
                        {ind.label}
                      </Link>
                    ))}
                  </div>
                </div>
                <a
                  href={config.supportLoginUrl || "#"}
                  target={config.supportLoginUrl ? "_blank" : undefined}
                  rel={config.supportLoginUrl ? "noopener noreferrer" : undefined}
                  className="mt-2 flex items-center justify-center gap-2 px-4 py-3 rounded-lg text-sm font-bold border"
                  style={{ borderColor: primaryColor, color: primaryColor, backgroundColor: `${primaryColor}10` }}
                  onClick={e => { if (!config.supportLoginUrl) e.preventDefault(); setOpen(false); }}
                >
                  <HeadphonesIcon size={15} />
                  {t("nav.supportLogin")}
                </a>
                <Link href="/contact" className="mt-2 px-4 py-3 rounded-lg text-sm font-bold text-white text-center" style={{ backgroundColor: primaryColor }} onClick={() => setOpen(false)}>
                  {t("nav.getStarted")}
                </Link>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>
    </>
  );
}
