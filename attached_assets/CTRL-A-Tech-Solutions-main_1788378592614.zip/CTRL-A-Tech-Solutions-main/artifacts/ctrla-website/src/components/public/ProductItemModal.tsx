import { useEffect } from "react";
import { useLocation } from "wouter";
import { X, ArrowRight, Phone } from "lucide-react";
import { getIcon } from "@/lib/iconMap";
import { useSiteConfig } from "@/contexts/SiteConfigContext";
import type { ProductItem } from "@/types/productItem";

interface Props {
  open: boolean;
  onClose: () => void;
  product: ProductItem;
}

const CATEGORY_LABELS: Record<string, string> = {
  "erp": "ERP Solutions",
  "business-apps": "Business Applications",
  "ai-solutions": "AI Solutions",
  "cloud-platforms": "Cloud Platforms",
  "integration-suite": "Integration Suite",
};

export default function ProductItemModal({ open, onClose, product }: Props) {
  const [, navigate] = useLocation();
  const config = useSiteConfig();
  const primary = config.primaryColor;
  const accent = config.accentColor;
  const Icon = getIcon(product.iconName);

  useEffect(() => {
    if (open) {
      document.body.style.overflow = "hidden";
    }
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);

  if (!open) return null;

  const description = product.description?.trim() || product.shortDesc;
  const paragraphs = description.split(/\n\n+/).filter(Boolean);
  const hasImage = Boolean(product.imageUrl);

  function goToContact() {
    onClose();
    navigate("/contact");
    setTimeout(() => {
      const el = document.getElementById("contact-form");
      if (el) {
        el.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }, 180);
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6"
      onClick={onClose}
    >
      <div className="absolute inset-0 bg-black/65 backdrop-blur-sm" />

      <div
        className="relative bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[92vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}
      >
        <div className="h-1.5 rounded-t-2xl" style={{ backgroundColor: product.accentColor }} />

        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors z-10"
          aria-label="Close"
        >
          <X size={20} />
        </button>

        <div className="p-7 sm:p-9">
          <div className="flex items-start gap-4 mb-6">
            <div className="p-3 rounded-xl flex-shrink-0" style={{ backgroundColor: `${product.accentColor}18` }}>
              <Icon size={28} style={{ color: product.accentColor }} />
            </div>
            <div>
              <h2 className="text-2xl font-bold leading-snug" style={{ color: accent }}>{product.name}</h2>
              <span
                className="inline-block mt-1.5 px-3 py-0.5 rounded-full text-xs font-bold text-white tracking-wide"
                style={{ backgroundColor: product.accentColor }}
              >
                {CATEGORY_LABELS[product.category] ?? product.category}
              </span>
            </div>
          </div>

          {hasImage && (
            <div className="mb-6 rounded-xl overflow-hidden border border-gray-100">
              <img
                src={product.imageUrl!}
                alt={product.name}
                className="w-full h-52 object-cover"
              />
            </div>
          )}

          <div className="space-y-4 mb-8">
            {paragraphs.map((para, i) => (
              <p key={i} className="text-gray-600 text-[15px] leading-relaxed">{para}</p>
            ))}
          </div>

          <div className="pt-2 border-t border-gray-100">
            <button
              onClick={goToContact}
              className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl font-bold text-white shadow-md hover:shadow-lg transition-all hover:-translate-y-0.5 text-sm"
              style={{ backgroundColor: primary || "#D4920C" }}
            >
              <Phone size={15} /> Get in Touch <ArrowRight size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
