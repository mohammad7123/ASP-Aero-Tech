import { useState, useEffect, useCallback, useRef } from "react";
import { RefreshCw, Shield } from "lucide-react";

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";

interface CaptchaData {
  question: string;
  token: string;
}

interface Props {
  onVerify: (token: string, answer: string) => void;
  onExpire?: () => void;
  className?: string;
  theme?: "light" | "dark" | "auto";
}

export default function CaptchaWidget({ onVerify, onExpire, className, theme = "light" }: Props) {
  const [captcha, setCaptcha] = useState<CaptchaData | null>(null);
  const [answer, setAnswer] = useState("");
  const [loading, setLoading] = useState(false);
  const [fetchError, setFetchError] = useState(false);

  const isDark = theme === "dark";

  const onExpireRef = useRef(onExpire);
  useEffect(() => { onExpireRef.current = onExpire; });

  const onVerifyRef = useRef(onVerify);
  useEffect(() => { onVerifyRef.current = onVerify; });

  const captchaRef = useRef<CaptchaData | null>(null);

  const fetchCaptcha = useCallback(async () => {
    setLoading(true);
    setAnswer("");
    setFetchError(false);
    if (onExpireRef.current) onExpireRef.current();
    try {
      const res = await fetch(`${BASE}/api/public/captcha`);
      if (!res.ok) throw new Error("fetch failed");
      const data: CaptchaData = await res.json();
      setCaptcha(data);
      captchaRef.current = data;
    } catch {
      setFetchError(true);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchCaptcha();
  }, []);

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const raw = e.target.value.replace(/[^0-9]/g, "");
    setAnswer(raw);
    if (captchaRef.current && raw !== "") {
      onVerifyRef.current(captchaRef.current.token, raw);
    }
  }

  const containerClass = isDark
    ? "bg-white/5 border-white/10"
    : "bg-gray-50 border-gray-200";
  const questionClass = isDark ? "text-white" : "text-gray-800";
  const labelClass = isDark ? "text-gray-400" : "text-gray-500";
  const inputClass = isDark
    ? "bg-white/10 border-white/20 text-white placeholder:text-gray-500 focus:ring-[#E84821]/50 focus:border-[#E84821]"
    : "bg-white border-gray-300 text-gray-800 focus:ring-[#E84821]/40 focus:border-[#E84821]";
  const refreshClass = isDark
    ? "text-gray-500 hover:text-[#E84821]"
    : "text-gray-400 hover:text-[#E84821]";

  return (
    <div className={`rounded-xl border p-3 transition-all ${containerClass} ${className ?? ""}`}>
      <div className="flex items-center gap-3">
        <Shield size={18} className="text-[#E84821] shrink-0" />
        <div className="flex-1 min-w-0">
          <p className={`text-xs font-medium mb-0.5 ${labelClass}`}>
            Security Check — Verify you are human
          </p>
          {fetchError ? (
            <p className="text-xs text-red-500">
              Failed to load.{" "}
              <button type="button" onClick={fetchCaptcha} className="underline">
                Retry
              </button>
            </p>
          ) : loading ? (
            <div className="h-4 bg-gray-200 rounded animate-pulse w-36" />
          ) : (
            <p className={`text-sm font-semibold ${questionClass}`}>{captcha?.question}</p>
          )}
        </div>
        <input
          type="text"
          inputMode="numeric"
          pattern="[0-9]*"
          value={answer}
          onChange={handleChange}
          placeholder="?"
          maxLength={2}
          disabled={loading || fetchError}
          className={`w-14 border rounded-lg px-2 py-1.5 text-sm text-center focus:outline-none focus:ring-2 transition-all disabled:opacity-50 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none ${inputClass}`}
          aria-label="Answer the math question"
        />
        <button
          type="button"
          onClick={fetchCaptcha}
          title="Get a new question"
          className={`shrink-0 transition-colors ${refreshClass}`}
          disabled={loading}
        >
          <RefreshCw size={15} className={loading ? "animate-spin" : ""} />
        </button>
      </div>
    </div>
  );
}
