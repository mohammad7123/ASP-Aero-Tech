import { ReactNode, useEffect } from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";
import WhatsAppButton from "./WhatsAppButton";
import ChatbotWidget from "./ChatbotWidget";
import CookieBanner from "./CookieBanner";
import GoogleTranslate from "./GoogleTranslate";
import { useSiteConfig } from "@/contexts/SiteConfigContext";

function GAInjector() {
  const { gaId } = useSiteConfig();

  useEffect(() => {
    if (!gaId) return;
    const existing = document.getElementById("ga-script");
    if (existing) return;

    const script1 = document.createElement("script");
    script1.id = "ga-script";
    script1.async = true;
    script1.src = `https://www.googletagmanager.com/gtag/js?id=${gaId}`;
    document.head.appendChild(script1);

    const script2 = document.createElement("script");
    script2.id = "ga-config";
    script2.innerHTML = `window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${gaId}');`;
    document.head.appendChild(script2);

    return () => {
      document.getElementById("ga-script")?.remove();
      document.getElementById("ga-config")?.remove();
    };
  }, [gaId]);

  return null;
}

function LayoutContent({ children }: { children: ReactNode }) {
  const { whatsappNumber, whatsappGreeting, chatbotEnabled, chatbotName, chatbotGreeting } = useSiteConfig();

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <GAInjector />
      <GoogleTranslate />
      <Navbar />
      <main className="flex-1 pt-[76px]">
        {children}
      </main>
      <Footer />
      {whatsappNumber && (
        <WhatsAppButton number={whatsappNumber} greeting={whatsappGreeting ?? undefined} />
      )}
      {chatbotEnabled && (
        <ChatbotWidget
          botName={chatbotName ?? "CtrlA Bot"}
          greeting={chatbotGreeting ?? undefined}
          whatsappNumber={whatsappNumber}
        />
      )}
      <CookieBanner />
    </div>
  );
}

export default function PublicLayout({ children }: { children: ReactNode }) {
  return <LayoutContent>{children}</LayoutContent>;
}
