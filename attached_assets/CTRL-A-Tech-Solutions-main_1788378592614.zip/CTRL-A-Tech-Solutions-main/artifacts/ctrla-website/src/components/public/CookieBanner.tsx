import { useState, useEffect } from "react";
import { X, Cookie } from "lucide-react";
import { useTranslation } from "react-i18next";

const STORAGE_KEY = "ctrla_cookie_consent";

type ConsentValue = "all" | "essential" | null;

export default function CookieBanner() {
  const { t } = useTranslation();
  const [visible, setVisible] = useState(false);
  const [showDetails, setShowDetails] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) setVisible(true);
  }, []);

  const save = (value: ConsentValue) => {
    if (value) localStorage.setItem(STORAGE_KEY, value);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[9999] bg-white border-t border-gray-200 shadow-[0_-4px_24px_rgba(0,0,0,0.12)]">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 py-4">
        <div className="flex items-start justify-between gap-4 mb-3">
          <div className="flex items-center gap-2">
            <Cookie className="w-5 h-5 shrink-0" style={{ color: "#D4920C" }} />
            <span className="font-semibold text-gray-900 text-sm">{t("cookie.title")}</span>
          </div>
          <button
            onClick={() => save("essential")}
            className="text-gray-400 hover:text-gray-600 transition-colors shrink-0 mt-0.5"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-gray-600 leading-relaxed mb-3 max-w-4xl">
          {t("cookie.body")}{" "}
          <a href="/privacy-policy" className="underline hover:no-underline" style={{ color: "#D4920C" }}>
            {t("cookie.privacyPolicy")}
          </a>
        </p>

        {showDetails && (
          <div className="mb-3 p-3 rounded-lg bg-gray-50 border border-gray-100 text-xs text-gray-600 space-y-2">
            <div className="flex items-start gap-2">
              <input type="checkbox" checked readOnly className="mt-0.5 accent-[#D4920C]" />
              <div>
                <p className="font-semibold text-gray-800">{t("cookie.essentialTitle")}</p>
                <p>{t("cookie.essentialDesc")}</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <input type="checkbox" defaultChecked className="mt-0.5 accent-[#D4920C]" />
              <div>
                <p className="font-semibold text-gray-800">{t("cookie.analyticsTitle")}</p>
                <p>{t("cookie.analyticsDesc")}</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <input type="checkbox" defaultChecked className="mt-0.5 accent-[#D4920C]" />
              <div>
                <p className="font-semibold text-gray-800">{t("cookie.marketingTitle")}</p>
                <p>{t("cookie.marketingDesc")}</p>
              </div>
            </div>
          </div>
        )}

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => save("all")}
            className="px-4 py-2 rounded-md text-white text-xs font-semibold transition-opacity hover:opacity-90 shrink-0"
            style={{ backgroundColor: "#D4920C" }}
          >
            {t("cookie.acceptAll")}
          </button>
          <button
            onClick={() => save("essential")}
            className="px-4 py-2 rounded-md text-xs font-semibold border border-gray-300 text-gray-700 hover:bg-amber-50 transition-colors shrink-0"
          >
            {t("cookie.essentialOnly")}
          </button>
          <button
            onClick={() => setShowDetails(d => !d)}
            className="px-4 py-2 rounded-md text-xs font-semibold border border-gray-300 text-gray-700 hover:bg-amber-50 transition-colors shrink-0"
          >
            {showDetails ? t("cookie.hideDetails") : t("cookie.managePrefs")}
          </button>
        </div>
      </div>
    </div>
  );
}
