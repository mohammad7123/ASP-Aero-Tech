import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, X, Shield, Cpu, Wifi } from "lucide-react";

interface Props {
  open: boolean;
  onClose: () => void;
  title?: string;
  message?: string;
}

export default function SuccessModal({
  open,
  onClose,
  title = "Thank You!",
  message = "Thank you for contacting us! We have received your message and our team will get back to you as soon as possible.",
}: Props) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[9999] flex items-center justify-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <div className="absolute inset-0 bg-black/75 backdrop-blur-sm" />

          <motion.div
            className="relative w-full max-w-md overflow-hidden"
            style={{
              background: "linear-gradient(135deg, #07091a 0%, #0d1533 60%, #0a1a28 100%)",
              border: "1px solid rgba(0,220,255,0.18)",
              borderRadius: "1.5rem",
              boxShadow: "0 0 80px rgba(0,200,255,0.08), 0 0 0 1px rgba(0,220,255,0.06), 0 30px 60px rgba(0,0,0,0.6)",
            }}
            initial={{ scale: 0.82, opacity: 0, y: 24 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.82, opacity: 0, y: 24 }}
            transition={{ type: "spring", damping: 22, stiffness: 280 }}
            onClick={e => e.stopPropagation()}
          >
            {/* Circuit grid decoration */}
            <svg
              className="absolute inset-0 w-full h-full pointer-events-none opacity-[0.04]"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <pattern id="grid" width="24" height="24" patternUnits="userSpaceOnUse">
                  <path d="M 24 0 L 0 0 0 24" fill="none" stroke="#00e5ff" strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>

            {/* Glowing orb top-right */}
            <div
              className="absolute -top-12 -right-12 w-40 h-40 rounded-full pointer-events-none"
              style={{ background: "radial-gradient(circle, rgba(0,200,255,0.12) 0%, transparent 70%)" }}
            />

            {/* Close button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 z-10 p-1.5 rounded-lg text-gray-500 hover:text-white hover:bg-white/10 transition-all"
            >
              <X size={16} />
            </button>

            <div className="relative p-8 text-center">
              {/* Animated glow ring + icon */}
              <div className="relative inline-flex items-center justify-center mb-6">
                <motion.div
                  className="absolute rounded-full"
                  style={{
                    width: 96, height: 96,
                    background: "radial-gradient(circle, rgba(0,255,180,0.18) 0%, transparent 70%)",
                  }}
                  animate={{ scale: [1, 1.25, 1], opacity: [0.6, 1, 0.6] }}
                  transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                />
                <motion.div
                  className="relative flex items-center justify-center"
                  style={{
                    width: 72, height: 72,
                    borderRadius: "50%",
                    background: "linear-gradient(135deg, rgba(0,255,180,0.08), rgba(0,200,255,0.08))",
                    border: "1.5px solid rgba(0,255,180,0.35)",
                    boxShadow: "0 0 24px rgba(0,255,180,0.18), inset 0 0 20px rgba(0,200,255,0.06)",
                  }}
                  initial={{ scale: 0, rotate: -90 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ type: "spring", delay: 0.1, damping: 14, stiffness: 200 }}
                >
                  <CheckCircle2 size={34} style={{ color: "#00ffb4" }} />
                </motion.div>
              </div>

              {/* Title */}
              <motion.h2
                className="text-2xl font-extrabold mb-3 tracking-tight"
                style={{
                  background: "linear-gradient(135deg, #00ffb4 0%, #00c8ff 100%)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                }}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.18 }}
              >
                {title}
              </motion.h2>

              {/* Message */}
              <motion.p
                className="text-gray-400 text-sm leading-relaxed mb-8 px-2"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.28 }}
              >
                {message}
              </motion.p>

              {/* CTA button */}
              <motion.button
                onClick={onClose}
                className="px-8 py-3 rounded-xl font-bold text-white text-sm transition-all"
                style={{
                  background: "linear-gradient(135deg, #E84821 0%, #c73d1a 100%)",
                  boxShadow: "0 4px 20px rgba(232,72,33,0.35)",
                }}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.36 }}
                whileHover={{ scale: 1.03, boxShadow: "0 6px 25px rgba(232,72,33,0.45)" }}
                whileTap={{ scale: 0.97 }}
              >
                Got it, Thanks!
              </motion.button>

              {/* Cyber decoration row */}
              <div className="mt-7 flex items-center justify-center gap-3 opacity-20">
                <Shield size={13} className="text-cyan-400" />
                <div className="h-px w-10 bg-gradient-to-r from-transparent via-cyan-400 to-transparent" />
                <Cpu size={13} className="text-cyan-400" />
                <div className="h-px w-10 bg-gradient-to-r from-transparent via-cyan-400 to-transparent" />
                <Wifi size={13} className="text-cyan-400" />
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
