import { Link } from "wouter";
import { Mail, Phone, MapPin, ArrowRight, Handshake } from "lucide-react";
import { useSiteConfig } from "@/contexts/SiteConfigContext";
import { useTranslation } from "react-i18next";

function SocialIcons() {
  const config = useSiteConfig();
  const links = [
    { url: config.linkedinUrl, label: "LinkedIn", svg: <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg> },
    { url: config.twitterUrl, label: "X / Twitter", svg: <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg> },
    { url: config.facebookUrl, label: "Facebook", svg: <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg> },
    { url: config.instagramUrl, label: "Instagram", svg: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="2" width="20" height="20" rx="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg> },
    { url: config.youtubeUrl, label: "YouTube", svg: <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46a2.78 2.78 0 0 0-1.95 1.96A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.41 19.1C5.12 19.56 12 19.56 12 19.56s6.88 0 8.59-.46a2.78 2.78 0 0 0 1.95-1.95 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z"/><polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"/></svg> },
  ].filter(l => !!l.url);

  if (links.length === 0) return null;

  return (
    <div className="flex items-center gap-2 mt-4">
      {links.map(({ url, label, svg }) => (
        <a key={label} href={url!} target="_blank" rel="noopener noreferrer" aria-label={label}
          className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-600 hover:text-gray-900 transition-colors">
          {svg}
        </a>
      ))}
    </div>
  );
}

export default function Footer() {
  const { t } = useTranslation();
  const config = useSiteConfig();
  const { primaryColor, accentColor } = config;

  return (
    <footer className="bg-white border-t border-gray-100">
      <div className="h-1 flex">
        <div className="flex-[3] bg-[#E84821]" />
        <div className="flex-[2]" style={{ backgroundColor: primaryColor }} />
        <div className="flex-1 bg-[#3D4FA0]" />
      </div>

      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10">
          <div className="md:col-span-5">
            <div className="mb-4">
              {config.logoUrl ? (
                <img src={config.logoUrl} alt={config.siteName} className="h-11 object-contain" />
              ) : (
                <span className="text-xl font-bold" style={{ color: accentColor }}>{config.siteName}</span>
              )}
            </div>
            <p className="text-sm text-gray-600 max-w-sm mb-5 leading-relaxed">
              {config.tagline ?? t("footer.taglineFallback")}
            </p>
            <div className="space-y-2.5">
              {config.contactEmail && (
                <div className="flex items-center gap-2.5 text-sm text-gray-600">
                  <Mail size={15} className="shrink-0" style={{ color: primaryColor }} />
                  <a href={`mailto:${config.contactEmail}`} className="transition-colors hover:text-[#D4920C]">
                    {config.contactEmail}
                  </a>
                </div>
              )}
              {config.contactPhone && (
                <div className="flex items-center gap-2.5 text-sm text-gray-600">
                  <Phone size={15} className="shrink-0" style={{ color: primaryColor }} />
                  <a href={`tel:${config.contactPhone}`} className="transition-colors hover:text-[#D4920C]">
                    {config.contactPhone}
                  </a>
                </div>
              )}
              {config.address && (
                <div className="flex items-center gap-2.5 text-sm text-gray-600">
                  <MapPin size={15} className="shrink-0" style={{ color: primaryColor }} />
                  <span>{config.address}</span>
                </div>
              )}
            </div>
            <SocialIcons />
          </div>

          <div className="md:col-span-3">
            <h4 className="text-sm font-bold uppercase tracking-wider mb-4" style={{ color: accentColor }}>{t("footer.quickLinks")}</h4>
            <ul className="space-y-2.5 text-sm">
              {config.menuItems.map(item => (
                <li key={item.id}>
                  <Link
                    href={item.url}
                    className="text-gray-600 transition-colors hover:text-[#D4920C]"
                    target={item.openInNewTab ? "_blank" : undefined}
                    rel={item.openInNewTab ? "noopener noreferrer" : undefined}
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-4">
            <h4 className="text-sm font-bold uppercase tracking-wider mb-4" style={{ color: accentColor }}>{t("footer.getInTouch")}</h4>
            <p className="text-sm text-gray-600 mb-4 leading-relaxed">
              {t("footer.getInTouchDesc")}
            </p>
            <div className="flex flex-col gap-3">
              <Link
                href="/contact"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-bold text-white shadow-md hover:shadow-lg transition-all hover:-translate-y-0.5"
                style={{ backgroundColor: primaryColor }}
              >
                {t("footer.contactUs")} <ArrowRight size={14} />
              </Link>
              <Link
                href="/become-a-partner"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-bold border-2 transition-all hover:-translate-y-0.5"
                style={{ borderColor: primaryColor, color: primaryColor }}
              >
                <Handshake size={15} /> Become a Partner
              </Link>
            </div>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-gray-100 flex flex-col sm:flex-row justify-between items-center gap-3 text-sm text-gray-500">
          <p>© {new Date().getFullYear()} {config.siteName}. {t("footer.allRights")}</p>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#E84821]" />
            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: primaryColor }} />
            <span className="w-2 h-2 rounded-full bg-[#3D4FA0]" />
          </div>
        </div>
      </div>
    </footer>
  );
}
