import { useEffect, useState } from "react";
import { getTechIconUrl } from "@/lib/techIcon";

const cache: Record<string, string> = {};

interface TechIconProps {
  slug: string;
  color: string;
  size?: number;
  name: string;
  className?: string;
}

export function TechIcon({ slug, color, size = 36, name, className }: TechIconProps) {
  const [svg, setSvg] = useState<string | null>(cache[slug] ?? null);
  const url = getTechIconUrl(slug);

  useEffect(() => {
    if (!url) return;
    if (cache[slug]) { setSvg(cache[slug]); return; }
    fetch(url)
      .then(r => r.ok ? r.text() : Promise.reject())
      .then(text => {
        const colored = text
          .replace(/<svg([^>]*)>/, (_, attrs) => {
            const clean = attrs
              .replace(/width="[^"]*"/, "")
              .replace(/height="[^"]*"/, "")
              .replace(/fill="[^"]*"/, "");
            return `<svg${clean} width="${size}" height="${size}" fill="${color}" style="display:block">`;
          });
        cache[slug] = colored;
        setSvg(colored);
      })
      .catch(() => setSvg(null));
  }, [url, slug, color, size]);

  if (!url || svg === null) {
    return (
      <span
        style={{
          color,
          fontSize: size * 0.55,
          fontWeight: 800,
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          width: size,
          height: size,
        }}
        className={className}
      >
        {name.substring(0, 2).toUpperCase()}
      </span>
    );
  }

  return (
    <span
      className={className}
      style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: size, height: size }}
      dangerouslySetInnerHTML={{ __html: svg }}
    />
  );
}
