import { useEffect, useState } from "react";
import { FolderOpen, Loader2 } from "lucide-react";
import { MediaPickerModal } from "@/components/admin/MediaPickerModal";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { PAGE_CONTENT_SCHEMA, type ContentField } from "@/lib/pageContentSchema";

const base = import.meta.env.BASE_URL.replace(/\/$/, "");

function getToken() { return localStorage.getItem("ctrla_admin_token") ?? ""; }

async function apiFetch(path: string, method: string, body?: unknown) {
  const res = await fetch(`${base}${path}`, {
    method,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken()}` },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

export function PageContentEditor({ slug, title, onClose }: { slug: string; title: string; onClose: () => void }) {
  const { toast } = useToast();
  const qc = useQueryClient();
  const schema = PAGE_CONTENT_SCHEMA[slug];

  const [blocks, setBlocks] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [pickerFor, setPickerFor] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const data = await apiFetch(`/api/admin/pages/${slug}/content`, "GET");
        if (active) setBlocks((data?.blocks ?? {}) as Record<string, string>);
      } catch {
        if (active) setBlocks({});
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => { active = false; };
  }, [slug]);

  function setField(key: string, value: string) {
    setBlocks(prev => ({ ...prev, [key]: value }));
  }

  async function handleSave() {
    setSaving(true);
    try {
      await apiFetch(`/api/admin/pages/${slug}/content`, "PUT", { blocks });
      await qc.invalidateQueries({ queryKey: ["page-content", slug] });
      toast({ title: "Content saved", description: "Your changes are live on the site." });
      onClose();
    } catch {
      toast({ title: "Error saving content", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  if (!schema) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b sticky top-0 bg-white z-10">
          <h2 className="font-bold text-[#1C1917]">Edit Content — {title}</h2>
          <p className="text-gray-500 text-xs mt-1">Leave a field blank to use the site's built-in default text.</p>
        </div>

        {loading ? (
          <div className="p-12 flex items-center justify-center text-gray-400">
            <Loader2 className="animate-spin" size={22} />
          </div>
        ) : (
          <div className="p-6 space-y-6">
            {schema.groups.map(group => (
              <div key={group.group}>
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#E84821] mb-3">{group.group}</h3>
                <div className="space-y-4">
                  {group.fields.map(f => (
                    <FieldInput
                      key={f.key}
                      field={f}
                      value={blocks[f.key] ?? ""}
                      onChange={v => setField(f.key, v)}
                      onBrowse={() => setPickerFor(f.key)}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="p-6 border-t sticky bottom-0 bg-white flex gap-3">
          <button onClick={handleSave} disabled={saving || loading} className="bg-[#1C1917] text-white px-6 py-2.5 rounded-xl text-sm font-semibold hover:bg-[#E84821] hover:text-[#1C1917] transition-all disabled:opacity-50">
            {saving ? "Saving…" : "Save Content"}
          </button>
          <button onClick={onClose} className="border border-gray-200 text-gray-600 px-6 py-2.5 rounded-xl text-sm font-semibold hover:bg-gray-50 transition-all">Cancel</button>
        </div>
      </div>

      {pickerFor && (
        <MediaPickerModal
          onSelect={url => { setField(pickerFor, url); }}
          onClose={() => setPickerFor(null)}
        />
      )}
    </div>
  );
}

function FieldInput({ field, value, onChange, onBrowse }: { field: ContentField; value: string; onChange: (v: string) => void; onBrowse: () => void }) {
  const labelEl = <label className="block text-sm font-medium text-gray-700 mb-1">{field.label}</label>;
  const inputCls = "w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E84821]/50";

  if (field.type === "image") {
    return (
      <div>
        {labelEl}
        <div className="flex gap-2">
          <input value={value} onChange={e => onChange(e.target.value)} placeholder="https://… or browse media library" className={`flex-1 ${inputCls}`} />
          <button type="button" onClick={onBrowse} className="flex items-center gap-1.5 px-3 py-2 text-sm border border-gray-200 rounded-lg text-gray-600 hover:bg-gray-50 hover:border-[#E84821] transition-all whitespace-nowrap">
            <FolderOpen size={15} /> Browse
          </button>
        </div>
        {value && (
          <img src={value} alt="Preview" className="mt-2 h-24 w-full object-cover rounded-lg border border-gray-200" onError={e => { (e.target as HTMLImageElement).style.display = "none"; }} />
        )}
      </div>
    );
  }

  if (field.type === "textarea") {
    return (
      <div>
        {labelEl}
        <textarea rows={3} value={value} onChange={e => onChange(e.target.value)} className={inputCls} />
      </div>
    );
  }

  return (
    <div>
      {labelEl}
      <input value={value} onChange={e => onChange(e.target.value)} className={inputCls} />
    </div>
  );
}
