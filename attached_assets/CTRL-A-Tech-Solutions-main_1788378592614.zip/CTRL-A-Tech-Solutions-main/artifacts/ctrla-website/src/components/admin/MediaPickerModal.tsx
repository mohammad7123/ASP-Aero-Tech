import { useState, useRef, useCallback } from "react";
import { X, Image, Check, Upload, Loader2 } from "lucide-react";
import { useListMedia, useCreateMedia } from "@/lib/apiClient";
import { useQueryClient } from "@tanstack/react-query";
import { getToken } from "@/lib/auth";

interface Props {
  onSelect: (url: string) => void;
  onClose: () => void;
}

const base = (import.meta.env.BASE_URL ?? "/").replace(/\/$/, "");

function mediaUrl(objectPath: string): string {
  if (objectPath.startsWith("/objects/")) {
    return `${base}/api/storage/objects/${objectPath.replace(/^\/objects\//, "")}`;
  }
  return objectPath;
}

export function MediaPickerModal({ onSelect, onClose }: Props) {
  const qc = useQueryClient();
  const { data: media = [], isLoading } = useListMedia();
  const createMedia = useCreateMedia();
  const [selected, setSelected] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const images = media.filter(m => !m.mimeType || m.mimeType.startsWith("image/"));

  const uploadFile = useCallback(async (file: File) => {
    if (!file.type.startsWith("image/")) return;
    setUploading(true);
    try {
      const urlRes = await fetch(`${base}/api/storage/uploads/request-url`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken()}` },
        body: JSON.stringify({ name: file.name, size: file.size, contentType: file.type }),
      });
      if (!urlRes.ok) throw new Error("Failed to get upload URL");
      const { uploadURL, objectPath } = await urlRes.json();
      const putRes = await fetch(uploadURL, { method: "PUT", body: file, headers: { "Content-Type": file.type } });
      if (!putRes.ok) throw new Error("Upload to storage failed");
      await createMedia.mutateAsync({
        data: { filename: file.name, objectPath, mimeType: file.type, size: file.size, altText: file.name },
      });
      await qc.invalidateQueries();
      const url = `${base}/api/storage/objects/${(objectPath as string).replace(/^\/objects\//, "")}`;
      setSelected(url);
    } catch {
      alert("Upload failed. Please try again.");
    } finally {
      setUploading(false);
    }
  }, [createMedia, qc]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) uploadFile(file);
    e.target.value = "";
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) uploadFile(file);
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl">

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b">
          <h3 className="font-bold text-gray-900 text-lg">Media Library</h3>
          <div className="flex items-center gap-2">
            <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
              className="flex items-center gap-2 px-3 py-1.5 text-sm font-semibold text-white rounded-lg transition-colors disabled:opacity-60"
              style={{ backgroundColor: "#E84821" }}
            >
              {uploading ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />}
              {uploading ? "Uploading…" : "Upload from Computer"}
            </button>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors ml-1">
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Drop zone + grid */}
        <div
          className={`flex-1 overflow-y-auto p-5 ${dragOver ? "bg-orange-50" : ""}`}
          onDragOver={e => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
        >
          {/* Drag-over overlay */}
          {dragOver && (
            <div className="absolute inset-0 z-10 flex items-center justify-center bg-orange-50/80 rounded-2xl pointer-events-none">
              <div className="flex flex-col items-center gap-2 text-[#E84821]">
                <Upload size={40} />
                <span className="font-bold text-lg">Drop to upload</span>
              </div>
            </div>
          )}

          {isLoading || uploading ? (
            <div className="grid grid-cols-4 gap-3">
              {uploading && (
                <div className="aspect-square bg-orange-50 border-2 border-dashed border-[#E84821] rounded-xl flex flex-col items-center justify-center gap-2">
                  <Loader2 size={24} className="animate-spin text-[#E84821]" />
                  <span className="text-xs text-[#E84821] font-medium">Uploading…</span>
                </div>
              )}
              {[...Array(isLoading ? 8 : 4)].map((_, i) => (
                <div key={i} className="aspect-square bg-gray-100 rounded-xl animate-pulse" />
              ))}
            </div>
          ) : images.length === 0 ? (
            <div
              className="flex flex-col items-center justify-center py-16 gap-4 rounded-xl border-2 border-dashed border-gray-200 cursor-pointer hover:border-[#E84821] hover:bg-orange-50/40 transition-all"
              onClick={() => fileInputRef.current?.click()}
            >
              <div className="w-16 h-16 rounded-2xl bg-[#E84821]/10 flex items-center justify-center">
                <Upload size={28} className="text-[#E84821]" />
              </div>
              <div className="text-center">
                <p className="font-semibold text-gray-700 mb-1">Upload your first image</p>
                <p className="text-sm text-gray-400">Click to browse or drag &amp; drop an image here</p>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-4 gap-3">
              {/* Upload tile always first */}
              <button
                onClick={() => fileInputRef.current?.click()}
                className="aspect-square rounded-xl border-2 border-dashed border-gray-200 hover:border-[#E84821] hover:bg-orange-50/40 transition-all flex flex-col items-center justify-center gap-1.5 text-gray-400 hover:text-[#E84821]"
              >
                <Upload size={20} />
                <span className="text-[10px] font-semibold">Upload new</span>
              </button>

              {images.map(m => {
                const url = mediaUrl(m.objectPath);
                const isSelected = selected === url;
                return (
                  <button
                    key={m.id}
                    onClick={() => setSelected(isSelected ? null : url)}
                    className={`relative aspect-square rounded-xl overflow-hidden border-2 transition-all ${
                      isSelected ? "border-[#E84821] shadow-lg" : "border-transparent hover:border-gray-300"
                    }`}
                  >
                    <img
                      src={url}
                      alt={m.altText ?? m.filename}
                      className="w-full h-full object-cover"
                      onError={e => { (e.currentTarget as HTMLImageElement).style.display = "none"; }}
                    />
                    {isSelected && (
                      <div className="absolute inset-0 bg-[#E84821]/20 flex items-center justify-center">
                        <div className="bg-[#E84821] rounded-full p-1">
                          <Check size={14} className="text-white" />
                        </div>
                      </div>
                    )}
                    <p className="absolute bottom-0 left-0 right-0 bg-black/50 text-white text-[10px] px-2 py-1 truncate">
                      {m.filename}
                    </p>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center gap-3 px-5 py-4 border-t bg-gray-50 rounded-b-2xl">
          {selected ? (
            <div className="flex-1 flex items-center gap-2">
              <img src={selected} alt="" className="h-8 w-8 rounded object-cover border" />
              <span className="text-xs text-gray-500 truncate max-w-[280px]">{selected}</span>
            </div>
          ) : (
            <p className="flex-1 text-sm text-gray-400">Select an image or upload a new one</p>
          )}
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-100 transition-colors"
          >
            Cancel
          </button>
          <button
            disabled={!selected}
            onClick={() => { if (selected) { onSelect(selected); onClose(); } }}
            className="px-4 py-2 text-sm font-semibold bg-[#1C1917] text-white rounded-lg disabled:opacity-40 hover:bg-[#E84821] transition-all"
          >
            Use Image
          </button>
        </div>
      </div>
    </div>
  );
}
