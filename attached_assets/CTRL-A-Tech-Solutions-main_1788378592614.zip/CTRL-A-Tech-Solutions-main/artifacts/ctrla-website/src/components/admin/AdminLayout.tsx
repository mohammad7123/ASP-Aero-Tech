import { ReactNode, useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import {
  LayoutDashboard, FileText, Menu as MenuIcon, BookOpen, Image, MessageSquare,
  Settings, LogOut, ChevronRight, Briefcase, SlidersHorizontal, Package,
  Users, Megaphone, Shield, X, Activity, GraduationCap
} from "lucide-react";
import { isAuthenticated, isAdmin, clearToken, getRole } from "@/lib/auth";

type NavItem = {
  href: string;
  icon: React.ElementType;
  label: string;
  adminOnly?: boolean;
};

const navItems: NavItem[] = [
  { href: "/admin", icon: LayoutDashboard, label: "Dashboard" },
  { href: "/admin/pages", icon: FileText, label: "Pages" },
  { href: "/admin/menu", icon: MenuIcon, label: "Menu" },
  { href: "/admin/slides", icon: SlidersHorizontal, label: "Hero Slides" },
  { href: "/admin/services", icon: Briefcase, label: "Services" },
  { href: "/admin/industries", icon: Package, label: "Industries" },
  { href: "/admin/product-items", icon: Package, label: "Products" },
  { href: "/admin/blog", icon: BookOpen, label: "Blog" },
  { href: "/admin/portfolio", icon: Briefcase, label: "Portfolio" },
  { href: "/admin/media", icon: Image, label: "Media" },
  { href: "/admin/contacts", icon: MessageSquare, label: "Contacts" },
  { href: "/admin/marketing", icon: Megaphone, label: "Marketing" },
  { href: "/admin/careers", icon: GraduationCap, label: "Careers" },
  { href: "/admin/clients", icon: Shield, label: "Clients" },
  { href: "/admin/usage", icon: Activity, label: "Usage" },
  { href: "/admin/settings", icon: Settings, label: "Settings", adminOnly: true },
  { href: "/admin/users", icon: Users, label: "Users", adminOnly: true },
];

export default function AdminLayout({ children }: { children: ReactNode }) {
  const [location, navigate] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    if (!isAuthenticated()) {
      navigate("/admin/login");
    }
  }, [location]);

  useEffect(() => {
    setMobileOpen(false);
  }, [location]);

  function handleLogout() {
    clearToken();
    navigate("/admin/login");
  }

  const role = getRole();
  const admin = isAdmin();
  const visibleItems = navItems.filter(item => !item.adminOnly || admin);

  const sidebar = (
    <>
      <div className="px-5 py-5 border-b border-white/10 flex items-center justify-between">
        <Link href="/admin">
          <div className="flex items-center gap-1.5 cursor-pointer">
            <span className="text-xl font-bold text-[#E84821]">Ctrl</span>
            <span className="text-xl font-bold text-white">A</span>
            <span className="text-xs text-white/40 ml-1 mt-0.5 font-medium">Admin</span>
          </div>
        </Link>
        <button
          onClick={() => setMobileOpen(false)}
          className="lg:hidden text-white/60 hover:text-white p-1"
          aria-label="Close menu"
        >
          <X size={18} />
        </button>
      </div>

      <div className="px-3 py-3 border-b border-white/10">
        <div className="flex items-center gap-2 px-2 py-2">
          <div className={`w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold ${admin ? "bg-[#E84821]" : "bg-[#3D4FA0]"}`}>
            {admin ? <Shield size={13} /> : <Users size={13} />}
          </div>
          <div>
            <div className="text-white text-xs font-semibold leading-none">{role === "admin" ? "Administrator" : "User"}</div>
            <div className="text-white/40 text-[10px] mt-0.5 capitalize">{role} access</div>
          </div>
        </div>
      </div>

      <nav className="flex-1 px-3 py-2 overflow-y-auto scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent">
        {visibleItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href || (item.href !== "/admin" && location.startsWith(item.href));
          return (
            <Link key={item.href} href={item.href}>
              <div
                className={`flex items-center gap-3 px-3 py-2 rounded-lg mb-0.5 cursor-pointer transition-all ${
                  isActive
                    ? "bg-[#D4920C] text-white shadow-sm"
                    : "text-white/60 hover:bg-white/8 hover:text-white"
                }`}
              >
                <Icon size={15} />
                <span className="text-xs font-medium flex-1">{item.label}</span>
                {isActive && <ChevronRight size={13} className="opacity-70" />}
                {item.adminOnly && !isActive && (
                  <Shield size={9} className="opacity-40" />
                )}
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="px-3 py-4 border-t border-white/10 space-y-1">
        <a href="/" target="_blank" rel="noopener noreferrer"
          className="flex items-center gap-2 px-3 py-2 rounded-lg text-white/40 hover:text-white/70 hover:bg-white/5 transition-colors text-xs"
        >
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
          View Website
        </a>
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-white/50 hover:bg-red-500/15 hover:text-red-400 transition-colors"
        >
          <LogOut size={16} />
          <span className="text-sm font-medium">Sign Out</span>
        </button>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Mobile top bar */}
      <header className="lg:hidden fixed top-0 left-0 right-0 z-30 bg-[#1A1F36] h-14 flex items-center justify-between px-4 shadow-md">
        <button
          onClick={() => setMobileOpen(true)}
          className="text-white p-1.5 hover:bg-white/10 rounded"
          aria-label="Open menu"
        >
          <MenuIcon size={20} />
        </button>
        <div className="flex items-center gap-1">
          <span className="text-base font-bold text-[#E84821]">Ctrl</span>
          <span className="text-base font-bold text-white">A</span>
          <span className="text-[10px] text-white/40 ml-1 font-medium">Admin</span>
        </div>
        <button
          onClick={handleLogout}
          className="text-white/60 hover:text-white p-1.5 hover:bg-white/10 rounded"
          aria-label="Sign out"
        >
          <LogOut size={18} />
        </button>
      </header>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/50 z-40"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar — desktop fixed, mobile drawer */}
      <aside
        className={`bg-[#1A1F36] flex flex-col fixed inset-y-0 left-0 z-50 shadow-xl transition-transform duration-200
          w-64 lg:w-60
          ${mobileOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0`}
      >
        {sidebar}
      </aside>

      <main className="flex-1 lg:ml-60 pt-14 lg:pt-0 p-4 sm:p-6 lg:p-8 min-h-screen w-full max-w-full overflow-x-hidden">
        {children}
      </main>
    </div>
  );
}
