const TOKEN_KEY = "ctrla_admin_token";
const ROLE_KEY = "ctrla_admin_role";

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token);
  try {
    const payload = JSON.parse(atob(token.split(".")[1]));
    if (payload.role) localStorage.setItem(ROLE_KEY, payload.role);
  } catch { /* ignore */ }
}

export function clearToken(): void {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(ROLE_KEY);
}

export function getRole(): string {
  return localStorage.getItem(ROLE_KEY) ?? "user";
}

export function isAdmin(): boolean {
  return getRole() === "admin";
}

export function isAuthenticated(): boolean {
  const token = getToken();
  if (!token) return false;
  try {
    const payload = JSON.parse(atob(token.split(".")[1]));
    return payload.exp > Date.now() / 1000;
  } catch {
    return false;
  }
}
