export type FieldType = "text" | "textarea" | "image";

export interface ContentField {
  key: string;
  label: string;
  type: FieldType;
}

export interface ContentGroup {
  group: string;
  fields: ContentField[];
}

export interface PageContentSchema {
  label: string;
  groups: ContentGroup[];
}

/**
 * Defines which text/image blocks are editable per page slug. The admin panel
 * renders a form from this schema; the public pages read the same keys via
 * usePageContent(slug).field(key, default). An unset field falls back to the
 * page's built-in default, so the design is unchanged until a value is entered.
 */
export const PAGE_CONTENT_SCHEMA: Record<string, PageContentSchema> = {
  home: {
    label: "Home",
    groups: [
      {
        group: "Services Section",
        fields: [
          { key: "services_label", label: "Eyebrow label", type: "text" },
          { key: "services_title", label: "Heading", type: "text" },
          { key: "services_desc", label: "Description", type: "textarea" },
        ],
      },
      {
        group: "Industries Section",
        fields: [
          { key: "industry_label", label: "Eyebrow label", type: "text" },
          { key: "industry_title", label: "Heading", type: "text" },
          { key: "industry_desc", label: "Description", type: "textarea" },
        ],
      },
      {
        group: "WMS 360 Section",
        fields: [
          { key: "wms_intro", label: "Eyebrow label", type: "text" },
          { key: "wms_headline", label: "Headline", type: "text" },
          { key: "wms_headline_highlight", label: "Headline highlight (colored)", type: "text" },
          { key: "wms_desc", label: "Description", type: "textarea" },
        ],
      },
      {
        group: "Why Choose Section",
        fields: [
          { key: "why_label", label: "Eyebrow label", type: "text" },
          { key: "why_title", label: "Heading", type: "text" },
          { key: "why_desc", label: "Description", type: "textarea" },
        ],
      },
      {
        group: "Testimonials Section",
        fields: [
          { key: "testimonials_label", label: "Eyebrow label", type: "text" },
          { key: "testimonials_title", label: "Heading", type: "text" },
        ],
      },
      {
        group: "Blog Section",
        fields: [
          { key: "blog_label", label: "Eyebrow label", type: "text" },
          { key: "blog_title", label: "Heading", type: "text" },
        ],
      },
    ],
  },
  about: {
    label: "About Us",
    groups: [
      {
        group: "Hero",
        fields: [
          { key: "hero_eyebrow", label: "Eyebrow label", type: "text" },
          { key: "hero_subtitle", label: "Subtitle", type: "textarea" },
          { key: "hero_image", label: "Hero image", type: "image" },
        ],
      },
      {
        group: "Who We Are",
        fields: [
          { key: "who_title", label: "Heading", type: "text" },
          { key: "who_para1", label: "Paragraph 1", type: "textarea" },
          { key: "who_para2", label: "Paragraph 2", type: "textarea" },
          { key: "who_para3", label: "Paragraph 3", type: "textarea" },
        ],
      },
      {
        group: "Expertise Areas",
        fields: [
          { key: "expertise_title", label: "Heading", type: "text" },
          { key: "expertise_subtitle", label: "Description", type: "textarea" },
        ],
      },
      {
        group: "Why Choose Us",
        fields: [
          { key: "why_title", label: "Heading", type: "text" },
          { key: "why_subtitle", label: "Description", type: "textarea" },
        ],
      },
      {
        group: "Vision & Mission",
        fields: [
          { key: "vision_title", label: "Vision heading", type: "text" },
          { key: "vision_text", label: "Vision text", type: "textarea" },
          { key: "mission_title", label: "Mission heading", type: "text" },
          { key: "mission_text", label: "Mission text", type: "textarea" },
          { key: "vm_tagline", label: "Closing tagline", type: "textarea" },
        ],
      },
      {
        group: "Leadership",
        fields: [
          { key: "leaders_title", label: "Heading", type: "text" },
          { key: "leaders_subtitle", label: "Description", type: "textarea" },
        ],
      },
    ],
  },
  services: {
    label: "Services",
    groups: [
      {
        group: "Hero",
        fields: [
          { key: "hero_eyebrow", label: "Eyebrow label", type: "text" },
          { key: "hero_desc1", label: "Description paragraph 1", type: "textarea" },
          { key: "hero_desc2", label: "Description paragraph 2", type: "textarea" },
          { key: "hero_image", label: "Hero image", type: "image" },
        ],
      },
    ],
  },
  contact: {
    label: "Contact Us",
    groups: [
      {
        group: "Hero",
        fields: [
          { key: "hero_eyebrow", label: "Eyebrow label", type: "text" },
          { key: "hero_subtitle", label: "Subtitle", type: "textarea" },
          { key: "hero_image", label: "Hero image", type: "image" },
        ],
      },
      {
        group: "Form",
        fields: [
          { key: "form_title", label: "Form heading", type: "text" },
        ],
      },
    ],
  },
};

export function hasContentSchema(slug: string): boolean {
  return slug in PAGE_CONTENT_SCHEMA;
}
