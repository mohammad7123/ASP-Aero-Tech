/**
 * Convert an objectPath (e.g. "/objects/uploads/uuid") from the storage API
 * into a URL that the browser can fetch via GET /api/storage/objects/*.
 *
 * Always use this instead of manually building the URL — avoids the common
 * bug of producing /api/storage/objects/objects/uploads/… (double "objects").
 */
export function storageObjectUrl(objectPath: string): string {
  const base = (import.meta.env.BASE_URL ?? "/").replace(/\/$/, "");
  if (objectPath.startsWith("/objects/")) {
    return `${base}/api/storage/objects/${objectPath.replace(/^\/objects\//, "")}`;
  }
  if (objectPath.startsWith("http://") || objectPath.startsWith("https://")) {
    return objectPath;
  }
  return `${base}/api/storage/objects/${objectPath.replace(/^\//, "")}`;
}
