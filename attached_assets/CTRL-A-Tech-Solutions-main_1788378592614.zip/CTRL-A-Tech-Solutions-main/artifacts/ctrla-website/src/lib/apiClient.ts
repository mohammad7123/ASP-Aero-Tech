import { setBaseUrl, setAuthTokenGetter } from "@workspace/api-client-react";
import { getToken, clearToken } from "./auth";

const base = import.meta.env.BASE_URL.replace(/\/$/, "");
setBaseUrl(base || null);
setAuthTokenGetter(() => getToken() ?? "");

if (typeof window !== "undefined" && !(window as unknown as { __ctrlaFetchPatched?: boolean }).__ctrlaFetchPatched) {
  (window as unknown as { __ctrlaFetchPatched?: boolean }).__ctrlaFetchPatched = true;
  const originalFetch = window.fetch.bind(window);
  window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
    const response = await originalFetch(input, init);
    if (response.status === 401) {
      const url = typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
      const isAdminApi = url.includes("/api/admin/") || url.includes("/api/auth/me");
      const onLoginPage = window.location.pathname.includes("/admin/login");
      if (isAdminApi && !onLoginPage) {
        clearToken();
        const adminBase = base || "";
        window.location.href = `${adminBase}/admin/login`;
      }
    }
    return response;
  };
}

export * from "@workspace/api-client-react";
