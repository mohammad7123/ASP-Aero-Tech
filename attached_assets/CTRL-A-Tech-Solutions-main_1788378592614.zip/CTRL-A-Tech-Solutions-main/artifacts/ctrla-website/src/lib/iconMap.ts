import type { LucideIcon } from "lucide-react";
import {
  Database, LayoutGrid, Zap, Rocket, Network, Smartphone,
  CheckCircle2, BarChart3, Printer, Receipt, ShieldCheck, ShoppingCart,
  Package, Factory, Headphones, Wrench, Server, Cloud, Briefcase,
  ShoppingBag, Store, ClipboardList, Truck, CreditCard, Users, Building2,
  MapPin, Shield, Star, Brain, MessageSquare, TrendingDown, FileText,
  Search, TrendingUp, Cpu, RefreshCw, HardDrive, Globe, Mail, Building,
  Plug, Settings, Box, Layers, Link as LinkIcon, Activity, Bell,
  Code2, Hospital, GraduationCap, Banknote, Plane, Pill, Shirt, Key, Leaf,
  FlaskConical, HardHat, Utensils, Car,
} from "lucide-react";

export const ICON_MAP: Record<string, LucideIcon> = {
  Database, LayoutGrid, Zap, Rocket, Network, Smartphone,
  CheckCircle2, BarChart3, Printer, Receipt, ShieldCheck, ShoppingCart,
  Package, Factory, Headphones, Wrench, Server, Cloud, Briefcase,
  ShoppingBag, Store, ClipboardList, Truck, CreditCard, Users, Building2,
  MapPin, Shield, Star, Brain, MessageSquare, TrendingDown, FileText,
  Search, TrendingUp, Cpu, RefreshCw, HardDrive, Globe, Mail, Building,
  Plug, Settings, Box, Layers, Link: LinkIcon, Activity, Bell,
  Code2, Hospital, GraduationCap, Banknote, Plane, Pill, Shirt, Key, Leaf,
  FlaskConical, HardHat, Utensils, Car,
  HeadphonesIcon: Headphones,
};

export function getIcon(name: string): LucideIcon {
  return ICON_MAP[name] ?? Package;
}
