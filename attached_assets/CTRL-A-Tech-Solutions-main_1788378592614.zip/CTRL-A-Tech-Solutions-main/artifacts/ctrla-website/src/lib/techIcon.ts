/**
 * Resolves a Simple Icons slug to a reliable CDN URL.
 *
 * - Switches from cdn.simpleicons.org (unreliable on some production domains)
 *   to cdn.jsdelivr.net which is globally stable.
 * - Maps known renamed/removed slugs to their current equivalents.
 * - Returns null for icons that no longer exist in Simple Icons,
 *   so callers can render a letter-badge instead of making a 404 request.
 */

const SLUG_MAP: Record<string, string | null> = {
  magento: "adobecommerce",
  zend: null,
  langchain: null,
  springboot: "spring",
};

export function getTechIconUrl(slug: string): string | null {
  if (slug in SLUG_MAP) {
    const resolved = SLUG_MAP[slug];
    if (resolved === null) return null;
    return `https://cdn.jsdelivr.net/npm/simple-icons/icons/${resolved}.svg`;
  }
  return `https://cdn.jsdelivr.net/npm/simple-icons/icons/${slug}.svg`;
}
