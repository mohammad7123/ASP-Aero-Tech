// Maps our language switcher codes → Google Translate language codes
export const GOOGLE_LANG_MAP: Record<string, string> = {
  en: "en",
  fi: "fi",
  pt: "pt",
  fr: "fr",
  de: "de",
  es: "es",
  zh: "zh-CN",
  ja: "ja",
  ko: "ko",
  ar: "ar",
  hi: "hi",
  ta: "ta",
};

export const RTL_LANGS = ["ar"];

// The list Google Translate is allowed to offer, derived from the map above.
export const INCLUDED_LANGUAGES = Object.values(GOOGLE_LANG_MAP).join(",");

function domainVariants(): string[] {
  const host = window.location.hostname;
  const variants = ["", `; domain=${host}`];
  const parts = host.split(".");
  if (parts.length > 2) {
    variants.push(`; domain=.${parts.slice(-2).join(".")}`);
  }
  return variants;
}

function clearGoogTrans() {
  const expire = "expires=Thu, 01 Jan 1970 00:00:00 GMT";
  domainVariants().forEach((d) => {
    document.cookie = `googtrans=; path=/; ${expire}${d}`;
  });
}

// Reads the currently active language from the googtrans cookie (source of truth).
export function getCurrentLang(): string {
  const match = document.cookie.match(/googtrans=\/[^/]+\/([^;]+)/);
  if (match) {
    const g = decodeURIComponent(match[1]);
    const found = Object.entries(GOOGLE_LANG_MAP).find(([, v]) => v === g);
    if (found) return found[0];
  }
  return "en";
}

export function applyDirection(code: string) {
  const isRtl = RTL_LANGS.includes(code);
  document.documentElement.dir = isRtl ? "rtl" : "ltr";
  document.documentElement.lang = code;
}

// Sets the target language via the googtrans cookie and reloads so Google
// Translate applies the translation to the whole document on a fresh render.
export function setLang(code: string) {
  clearGoogTrans();
  if (code !== "en") {
    const g = GOOGLE_LANG_MAP[code] || "en";
    const value = `/en/${g}`;
    domainVariants().forEach((d) => {
      document.cookie = `googtrans=${value}; path=/${d}`;
    });
  }
  window.location.reload();
}
