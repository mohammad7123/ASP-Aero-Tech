import { useQuery } from "@tanstack/react-query";

const base = import.meta.env.BASE_URL.replace(/\/$/, "");

export type PageContentBlocks = Record<string, string>;

async function fetchPageContent(slug: string): Promise<PageContentBlocks> {
  const res = await fetch(`${base}/api/pages/${slug}/content`);
  if (!res.ok) return {};
  const data = (await res.json()) as { blocks?: PageContentBlocks };
  return data.blocks ?? {};
}

/**
 * Loads admin-editable content overrides for a page. Returns a `field` helper
 * that yields the override for a key when present, otherwise the built-in
 * default passed in — so an unset field renders identically to the original
 * hardcoded design.
 */
export function usePageContent(slug: string) {
  const { data } = useQuery({
    queryKey: ["page-content", slug],
    queryFn: () => fetchPageContent(slug),
    staleTime: 60_000,
  });

  const blocks = data ?? {};

  function field(key: string, fallback: string): string {
    const v = blocks[key];
    return v != null && v !== "" ? v : fallback;
  }

  return { blocks, field };
}
