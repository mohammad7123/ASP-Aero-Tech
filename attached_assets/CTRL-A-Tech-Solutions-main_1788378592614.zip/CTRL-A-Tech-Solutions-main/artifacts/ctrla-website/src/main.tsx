import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import "./i18n";

// Guard React reconciliation against Google Translate mutating text nodes.
// Google Translate wraps translated text in <font> tags; when React later tries
// to remove/insert those nodes it can throw NotFoundError. These guards make
// such operations no-ops instead of crashing the app.
if (typeof Node === "function" && Node.prototype) {
  const originalRemoveChild = Node.prototype.removeChild;
  Node.prototype.removeChild = function (this: Node, child: any) {
    if (child.parentNode !== this) {
      return child;
    }
    return originalRemoveChild.call(this, child);
  } as typeof Node.prototype.removeChild;

  const originalInsertBefore = Node.prototype.insertBefore;
  Node.prototype.insertBefore = function (this: Node, newNode: any, referenceNode: any) {
    if (referenceNode && referenceNode.parentNode !== this) {
      return newNode;
    }
    return originalInsertBefore.call(this, newNode, referenceNode);
  } as typeof Node.prototype.insertBefore;
}

createRoot(document.getElementById("root")!).render(<App />);
