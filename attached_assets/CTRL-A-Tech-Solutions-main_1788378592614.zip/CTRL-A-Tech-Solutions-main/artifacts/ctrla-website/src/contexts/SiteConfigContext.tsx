import { createContext, useContext, useEffect, ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";

export interface SiteMenuItem {
  id: number;
  label: string;
  url: string;
  pageId: number | null;
  sortOrder: number;
  openInNewTab: boolean;
  isVisible: boolean;
  createdAt: string;
}

export interface SiteConfig {
  siteName: string;
  tagline: string | null;
  logoUrl: string | null;
  faviconUrl: string | null;
  contactEmail: string | null;
  contactPhone: string | null;
  contactPhone2: string | null;
  address: string | null;
  primaryColor: string;
  accentColor: string;
  backgroundColor: string;
  fontFamily: string;
  gaId: string | null;
  whatsappNumber: string | null;
  whatsappGreeting: string | null;
  chatbotEnabled: boolean;
  chatbotName: string | null;
  chatbotGreeting: string | null;
  linkedinUrl: string | null;
  twitterUrl: string | null;
  facebookUrl: string | null;
  instagramUrl: string | null;
  youtubeUrl: string | null;
  supportLoginUrl: string | null;
  bannerHeight: number;
  bannerSpeed: number;
  menuItems: SiteMenuItem[];
}

const defaultConfig: SiteConfig = {
  siteName: "CtrlA Tech Solutions",
  tagline: null,
  logoUrl: "/logo.png",
  faviconUrl: null,
  contactEmail: "Info@ctrlatechsolutions.com",
  contactPhone: "+91-9310775007",
  contactPhone2: "+44-7557035271",
  address: "India & United Kingdom",
  primaryColor: "#D4920C",
  accentColor: "#1A1F36",
  backgroundColor: "#ffffff",
  fontFamily: "Inter",
  gaId: null,
  whatsappNumber: null,
  whatsappGreeting: null,
  chatbotEnabled: false,
  chatbotName: null,
  chatbotGreeting: null,
  linkedinUrl: null,
  twitterUrl: null,
  facebookUrl: null,
  instagramUrl: null,
  youtubeUrl: null,
  supportLoginUrl: null,
  bannerHeight: 640,
  bannerSpeed: 5000,
  menuItems: [
    { id: 0, label: "Home", url: "/", pageId: null, sortOrder: 0, openInNewTab: false, isVisible: true, createdAt: "" },
    { id: 1, label: "About", url: "/about", pageId: null, sortOrder: 1, openInNewTab: false, isVisible: true, createdAt: "" },
    { id: 2, label: "Services", url: "/services", pageId: null, sortOrder: 2, openInNewTab: false, isVisible: true, createdAt: "" },
    { id: 3, label: "Products", url: "/products", pageId: null, sortOrder: 3, openInNewTab: false, isVisible: true, createdAt: "" },
    { id: 4, label: "Blog", url: "/blog", pageId: null, sortOrder: 4, openInNewTab: false, isVisible: true, createdAt: "" },
    { id: 5, label: "Contact", url: "/contact", pageId: null, sortOrder: 5, openInNewTab: false, isVisible: true, createdAt: "" },
  ],
};

const SiteConfigContext = createContext<SiteConfig>(defaultConfig);

export function useSiteConfig() {
  return useContext(SiteConfigContext);
}

function validColor(value: unknown, fallback: string): string {
  if (typeof value !== "string") return fallback;
  const v = value.trim();
  if (v.length < 4) return fallback;
  if (v.startsWith("#") && !/^#[0-9A-Fa-f]{3,8}$/.test(v)) return fallback;
  return v;
}

async function fetchSiteConfig(): Promise<SiteConfig> {
  const base = import.meta.env.BASE_URL.replace(/\/$/, "");
  const res = await fetch(`${base}/api/public/site-config`);
  if (!res.ok) throw new Error("Failed to fetch site config");
  const data = await res.json();
  return {
    ...data,
    primaryColor: validColor(data.primaryColor, defaultConfig.primaryColor),
    accentColor: validColor(data.accentColor, defaultConfig.accentColor),
    backgroundColor: validColor(data.backgroundColor, defaultConfig.backgroundColor),
    fontFamily: data.fontFamily?.trim() || defaultConfig.fontFamily,
    contactPhone2: data.contactPhone2 ?? null,
    linkedinUrl: data.linkedinUrl ?? null,
    twitterUrl: data.twitterUrl ?? null,
    facebookUrl: data.facebookUrl ?? null,
    instagramUrl: data.instagramUrl ?? null,
    youtubeUrl: data.youtubeUrl ?? null,
    supportLoginUrl: data.supportLoginUrl ?? null,
    bannerHeight: typeof data.bannerHeight === "number" && data.bannerHeight >= 300 ? data.bannerHeight : 640,
    bannerSpeed: typeof data.bannerSpeed === "number" && data.bannerSpeed >= 1000 ? data.bannerSpeed : 5000,
    menuItems: (data.menuItems ?? []).map((m: SiteMenuItem & { isVisible?: boolean }) => ({
      ...m,
      isVisible: m.isVisible ?? true,
    })),
  };
}

function applyTheme(config: SiteConfig) {
  const root = document.documentElement;
  root.style.setProperty("--site-primary", config.primaryColor);
  root.style.setProperty("--site-accent", config.accentColor);
  root.style.setProperty("--site-bg", config.backgroundColor);
  root.style.setProperty("--site-font", config.fontFamily);
  document.body.style.fontFamily = `${config.fontFamily}, system-ui, sans-serif`;
  document.body.style.backgroundColor = config.backgroundColor;

  if (config.faviconUrl) {
    const url = config.faviconUrl;
    const guessType = (u: string) => {
      if (u.endsWith(".png")) return "image/png";
      if (u.endsWith(".ico")) return "image/x-icon";
      if (u.endsWith(".jpg") || u.endsWith(".jpeg")) return "image/jpeg";
      if (u.endsWith(".webp")) return "image/webp";
      return "image/png";
    };
    const mimeType = guessType(url);
    document.querySelectorAll<HTMLLinkElement>('link[rel="icon"], link[rel="shortcut icon"]').forEach(el => el.remove());
    const link = document.createElement("link");
    link.rel = "icon";
    link.type = mimeType;
    link.href = url + "?v=" + Date.now();
    document.head.appendChild(link);
  }
}

function sanitize(raw: SiteConfig | undefined): SiteConfig {
  if (!raw) return defaultConfig;
  return {
    ...raw,
    primaryColor: validColor(raw.primaryColor, defaultConfig.primaryColor),
    accentColor: validColor(raw.accentColor, defaultConfig.accentColor),
    backgroundColor: validColor(raw.backgroundColor, defaultConfig.backgroundColor),
    fontFamily: raw.fontFamily?.trim() || defaultConfig.fontFamily,
  };
}

export function SiteConfigProvider({ children }: { children: ReactNode }) {
  const { data } = useQuery<SiteConfig>({
    queryKey: ["site-config"],
    queryFn: fetchSiteConfig,
    staleTime: 0,
    retry: 1,
  });

  const config = sanitize(data);

  useEffect(() => {
    applyTheme(config);
  }, [data]);

  return (
    <SiteConfigContext.Provider value={config}>
      {children}
    </SiteConfigContext.Provider>
  );
}
