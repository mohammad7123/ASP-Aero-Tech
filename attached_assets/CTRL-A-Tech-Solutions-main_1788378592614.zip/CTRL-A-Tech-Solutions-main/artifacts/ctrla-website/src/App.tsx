import { lazy, Suspense } from "react";
import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import "./lib/apiClient";

const HomePage = lazy(() => import("@/pages/public/Home"));
const AboutPage = lazy(() => import("@/pages/public/About"));
const ServicesPage = lazy(() => import("@/pages/public/Services"));
const BlogListPage = lazy(() => import("@/pages/public/BlogList"));
const BlogPostPage = lazy(() => import("@/pages/public/BlogPost"));
const ContactPage = lazy(() => import("@/pages/public/Contact"));
const PortfolioPage = lazy(() => import("@/pages/public/Portfolio"));
const PortfolioItemPage = lazy(() => import("@/pages/public/PortfolioItem"));
const WMS360Page = lazy(() => import("@/pages/public/WMS360"));
const MyHROnePage = lazy(() => import("@/pages/public/MyHROne"));
const SAPBusinessOnePage = lazy(() => import("@/pages/public/SAPBusinessOne"));
const SAPBusinessOneHanaPage = lazy(() => import("@/pages/public/SAPBusinessOneHana"));
const SupportServicePage = lazy(() => import("@/pages/public/SupportService"));
const SAPB1OnCloudPage = lazy(() => import("@/pages/public/SAPB1OnCloud"));
const RiseWithSAPPage = lazy(() => import("@/pages/public/RiseWithSAP"));
const S4HANAPage = lazy(() => import("@/pages/public/S4HANA"));
const IndustriesPage = lazy(() => import("@/pages/public/Industries"));
const ProductsPage = lazy(() => import("@/pages/public/Products"));
const ProductsERPPage = lazy(() => import("@/pages/public/ProductsERP"));
const ERPSolutionsPage = lazy(() => import("@/pages/public/ERPSolutions"));
const ProductsBusinessAppsPage = lazy(() => import("@/pages/public/ProductsBusinessApps"));
const ProductsAISolutionsPage = lazy(() => import("@/pages/public/ProductsAISolutions"));
const ProductsCloudPage = lazy(() => import("@/pages/public/ProductsCloud"));
const ProductsIntegrationPage = lazy(() => import("@/pages/public/ProductsIntegration"));
const WebDevelopmentPage = lazy(() => import("@/pages/public/WebDevelopment"));
const MobileAppsPage = lazy(() => import("@/pages/public/MobileApps"));
const CustomSoftwarePage = lazy(() => import("@/pages/public/CustomSoftware"));
const CloudSolutionsPage = lazy(() => import("@/pages/public/CloudSolutions"));
const ITConsultingPage = lazy(() => import("@/pages/public/ITConsulting"));
const CybersecurityPage = lazy(() => import("@/pages/public/Cybersecurity"));
const DigitalMarketingPage = lazy(() => import("@/pages/public/DigitalMarketing"));
const BecomeAPartnerPage = lazy(() => import("@/pages/public/BecomeAPartner"));
const B1PlusCloudPage = lazy(() => import("@/pages/public/B1PlusCloud"));
const DynamicPage = lazy(() => import("@/pages/public/DynamicPage"));
const CareersPage = lazy(() => import("@/pages/public/Careers"));
const ClientsPage = lazy(() => import("@/pages/public/Clients"));
const TechnologiesPage = lazy(() => import("@/pages/public/Technologies"));
const NotFound = lazy(() => import("@/pages/not-found"));

const AdminLogin = lazy(() => import("@/pages/admin/Login"));
const AdminDashboard = lazy(() => import("@/pages/admin/Dashboard"));
const AdminPages = lazy(() => import("@/pages/admin/Pages"));
const AdminMenu = lazy(() => import("@/pages/admin/Menu"));
const AdminBlog = lazy(() => import("@/pages/admin/Blog"));
const AdminMedia = lazy(() => import("@/pages/admin/Media"));
const AdminContacts = lazy(() => import("@/pages/admin/Contacts"));
const AdminSettings = lazy(() => import("@/pages/admin/Settings"));
const AdminPortfolio = lazy(() => import("@/pages/admin/Portfolio"));
const AdminHeroSlides = lazy(() => import("@/pages/admin/HeroSlides"));
const AdminProductItems = lazy(() => import("@/pages/admin/ProductItems"));
const AdminServices = lazy(() => import("@/pages/admin/Services"));
const AdminIndustries = lazy(() => import("@/pages/admin/Industries"));
const AdminUsers = lazy(() => import("@/pages/admin/Users"));
const AdminMarketing = lazy(() => import("@/pages/admin/Marketing"));
const AdminUsage = lazy(() => import("@/pages/admin/Usage"));
const AdminCareers = lazy(() => import("@/pages/admin/Careers"));
const AdminClients = lazy(() => import("@/pages/admin/Clients"));
const AdminLayout = lazy(() => import("@/components/admin/AdminLayout"));

import { SiteConfigProvider } from "@/contexts/SiteConfigContext";
import { I18nextProvider } from "react-i18next";
import i18n from "./i18n";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, staleTime: 30_000 },
  },
});

function Router() {
  return (
    <Suspense fallback={null}>
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/about" component={AboutPage} />
        <Route path="/services" component={ServicesPage} />
        <Route path="/portfolio" component={PortfolioPage} />
        <Route path="/portfolio/:slug" component={PortfolioItemPage} />
        <Route path="/blog" component={BlogListPage} />
        <Route path="/blog/:slug" component={BlogPostPage} />
        <Route path="/contact" component={ContactPage} />
        <Route path="/careers" component={CareersPage} />
        <Route path="/clients" component={ClientsPage} />
        <Route path="/wms360" component={WMS360Page} />
        <Route path="/myhrone" component={MyHROnePage} />
        <Route path="/sap-business-one" component={SAPBusinessOnePage} />
        <Route path="/sap-business-one-hana" component={SAPBusinessOneHanaPage} />
        <Route path="/support-service" component={SupportServicePage} />
        <Route path="/sap-b1-on-cloud" component={SAPB1OnCloudPage} />
        <Route path="/rise-with-sap" component={RiseWithSAPPage} />
        <Route path="/s4-hana" component={S4HANAPage} />
        <Route path="/industries" component={IndustriesPage} />
        <Route path="/services/erp-solutions" component={ERPSolutionsPage} />
        <Route path="/services/web-development" component={WebDevelopmentPage} />
        <Route path="/services/mobile-apps" component={MobileAppsPage} />
        <Route path="/services/custom-software" component={CustomSoftwarePage} />
        <Route path="/services/cloud-solutions" component={CloudSolutionsPage} />
        <Route path="/services/cybersecurity" component={CybersecurityPage} />
        <Route path="/services/it-consulting" component={ITConsultingPage} />
        <Route path="/services/digital-marketing" component={DigitalMarketingPage} />
        <Route path="/become-a-partner" component={BecomeAPartnerPage} />
        <Route path="/b1plus-cloud" component={B1PlusCloudPage} />

        {/* Technologies */}
        <Route path="/technologies/:category" component={TechnologiesPage} />
        <Route path="/technologies">
          {() => { window.location.replace(import.meta.env.BASE_URL.replace(/\/$/, "") + "/technologies/microsoft"); return null; }}
        </Route>

        {/* Products */}
        <Route path="/products" component={ProductsPage} />
        <Route path="/products/erp" component={ProductsERPPage} />
        <Route path="/products/business-apps" component={ProductsBusinessAppsPage} />
        <Route path="/products/ai-solutions" component={ProductsAISolutionsPage} />
        <Route path="/products/cloud-platforms" component={ProductsCloudPage} />
        <Route path="/products/integration-suite" component={ProductsIntegrationPage} />

        <Route path="/admin/login" component={AdminLogin} />
        <Route path="/admin/slides">
          <Suspense fallback={null}>
            <AdminLayout><AdminHeroSlides /></AdminLayout>
          </Suspense>
        </Route>
        <Route path="/admin/product-items">
          <Suspense fallback={null}>
            <AdminLayout><AdminProductItems /></AdminLayout>
          </Suspense>
        </Route>
        <Route path="/admin/services">
          <Suspense fallback={null}>
            <AdminLayout><AdminServices /></AdminLayout>
          </Suspense>
        </Route>
        <Route path="/admin/industries">
          <Suspense fallback={null}>
            <AdminLayout><AdminIndustries /></AdminLayout>
          </Suspense>
        </Route>
        <Route path="/admin/pages">
          <Suspense fallback={null}>
            <AdminLayout><AdminPages /></AdminLayout>
          </Suspense>
        </Route>
        <Route path="/admin/menu">
          <Suspense fallback={null}>
            <AdminLayout><AdminMenu /></AdminLayout>
          </Suspense>
        </Route>
        <Route path="/admin/blog">
          <Suspense fallback={null}>
            <AdminLayout><AdminBlog /></AdminLayout>
          </Suspense>
        </Route>
        <Route path="/admin/media">
          <Suspense fallback={null}>
            <AdminLayout><AdminMedia /></AdminLayout>
          </Suspense>
        </Route>
        <Route path="/admin/contacts">
          <Suspense fallback={null}>
            <AdminLayout><AdminContacts /></AdminLayout>
          </Suspense>
        </Route>
        <Route path="/admin/settings">
          <Suspense fallback={null}>
            <AdminLayout><AdminSettings /></AdminLayout>
          </Suspense>
        </Route>
        <Route path="/admin/portfolio">
          <Suspense fallback={null}>
            <AdminLayout><AdminPortfolio /></AdminLayout>
          </Suspense>
        </Route>
        <Route path="/admin/users">
          <Suspense fallback={null}>
            <AdminLayout><AdminUsers /></AdminLayout>
          </Suspense>
        </Route>
        <Route path="/admin/marketing">
          <Suspense fallback={null}>
            <AdminLayout><AdminMarketing /></AdminLayout>
          </Suspense>
        </Route>
        <Route path="/admin/usage">
          <Suspense fallback={null}>
            <AdminLayout><AdminUsage /></AdminLayout>
          </Suspense>
        </Route>
        <Route path="/admin/careers">
          <Suspense fallback={null}>
            <AdminLayout><AdminCareers /></AdminLayout>
          </Suspense>
        </Route>
        <Route path="/admin/clients">
          <Suspense fallback={null}>
            <AdminLayout><AdminClients /></AdminLayout>
          </Suspense>
        </Route>
        <Route path="/admin">
          <Suspense fallback={null}>
            <AdminLayout><AdminDashboard /></AdminLayout>
          </Suspense>
        </Route>

        <Route path="/:slug" component={DynamicPage} />
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function App() {
  return (
    <I18nextProvider i18n={i18n}>
      <QueryClientProvider client={queryClient}>
        <SiteConfigProvider>
          <TooltipProvider>
            <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
              <Router />
            </WouterRouter>
            <Toaster />
          </TooltipProvider>
        </SiteConfigProvider>
      </QueryClientProvider>
    </I18nextProvider>
  );
}

export default App;
