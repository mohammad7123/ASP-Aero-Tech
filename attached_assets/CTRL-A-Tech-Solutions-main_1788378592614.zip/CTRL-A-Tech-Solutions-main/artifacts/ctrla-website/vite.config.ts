import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";

const port = Number(process.env.PORT ?? "5173");
const basePath = process.env.BASE_PATH ?? "/";

export default defineConfig({
  base: basePath,
  plugins: [
    react(),
    tailwindcss(),
    runtimeErrorOverlay(),
    ...(process.env.NODE_ENV !== "production" &&
    process.env.REPL_ID !== undefined
      ? [
          await import("@replit/vite-plugin-cartographer").then((m) =>
            m.cartographer({
              root: path.resolve(import.meta.dirname, ".."),
            }),
          ),
          await import("@replit/vite-plugin-dev-banner").then((m) =>
            m.devBanner(),
          ),
        ]
      : []),
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "src"),
      "@assets": path.resolve(import.meta.dirname, "..", "..", "attached_assets"),
    },
    dedupe: ["react", "react-dom"],
  },
  root: path.resolve(import.meta.dirname),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true,
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes("node_modules")) {
            if (
              id.includes("/@tanstack/") ||
              id.includes("/wouter/")
            ) {
              return "vendor-query";
            }
            if (
              id.includes("/framer-motion/") ||
              id.includes("/lucide-react/") ||
              id.includes("/recharts/")
            ) {
              return "vendor-ui";
            }
            if (
              id.includes("/i18next") ||
              id.includes("/react-i18next")
            ) {
              return "vendor-i18n";
            }
            return "vendor-misc";
          }

          if (id.includes("/pages/admin/")) {
            return "chunk-admin";
          }
          if (id.includes("/components/admin/")) {
            return "chunk-admin";
          }

          if (
            id.includes("/pages/public/Blog") ||
            id.includes("/pages/public/Portfolio")
          ) {
            return "chunk-content";
          }

          if (
            id.includes("/pages/public/Products") ||
            id.includes("/pages/public/ERPSolutions") ||
            id.includes("/pages/public/WMS360") ||
            id.includes("/pages/public/MyHROne") ||
            id.includes("/pages/public/SAP") ||
            id.includes("/pages/public/SAPB1") ||
            id.includes("/pages/public/RiseWithSAP") ||
            id.includes("/pages/public/S4HANA") ||
            id.includes("/pages/public/SupportService") ||
            id.includes("/pages/public/B1PlusCloud")
          ) {
            return "chunk-products";
          }

          if (id.includes("/pages/public/Technologies")) {
            return "chunk-technologies";
          }
        },
      },
    },
  },
  server: {
    port,
    strictPort: true,
    host: "0.0.0.0",
    allowedHosts: true,
    fs: {
      strict: true,
    },
    proxy: {
      "/api": {
        target: "http://localhost:8080",
        changeOrigin: true,
      },
      "/robots.txt": {
        target: "http://localhost:8080",
        changeOrigin: true,
      },
      "/sitemap.xml": {
        target: "http://localhost:8080",
        changeOrigin: true,
      },
    },
  },
  preview: {
    port,
    host: "0.0.0.0",
    allowedHosts: true,
  },
});
