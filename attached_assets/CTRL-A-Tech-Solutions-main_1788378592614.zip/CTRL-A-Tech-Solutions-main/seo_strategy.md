# SEO Strategy

## In scope
- Public marketing pages
- Product and solution pages
- Blog list and blog posts
- Portfolio and case study pages
- Careers, clients, technologies, contact, and other public content pages
- Public CMS pages served at `/:slug`

## Out of scope
- Authenticated admin routes under `/admin/**`
- API routes under `/api/**` except where they directly affect crawlability (`/robots.txt`, `/sitemap.xml`)

## Target audience
- Businesses evaluating SAP ERP, cloud, custom software, AI, and digital transformation services
- Prospective clients in India, the UK, and other markets served by CtrlA Tech Solutions

## Primary keywords
- CtrlA Tech Solutions
- SAP Business One partner
- SAP Business One HANA
- SAP S/4HANA
- ERP solutions
- custom software development
- web development
- mobile app development
- cloud solutions
- cybersecurity services
- IT consulting
- digital marketing services
- warehouse management system
- HR management system

## Dismissed categories
- (None yet)
