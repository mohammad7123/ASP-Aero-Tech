# ctrla-web

CtrlA Tech Solutions marketing site + admin CMS. pnpm monorepo:

- `artifacts/api-server` — Express API. In production it also serves the
  built frontend from one process (see `src/app.ts`).
- `artifacts/ctrla-website` — React/Vite frontend, prerendered per-route for SEO.
- `lib/*` — shared packages (db schema/client, zod contracts, generated API client).

See [DEPLOY.md](./DEPLOY.md) for how this is deployed to CentOS and how
CI/CD (`.github/workflows/main.yml`) works.

## Local development

```bash
pnpm install
DATABASE_URL=postgresql://... pnpm --filter @workspace/ctrla-website run dev
```

The api-server dev workflow proxies to Vite on :5173 — see `.replit` / each
package's `dev` script for the exact commands used during development.
