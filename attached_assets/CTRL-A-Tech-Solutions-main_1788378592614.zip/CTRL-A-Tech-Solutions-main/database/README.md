# Database structure migration

`schema.sql` is a structure-only PostgreSQL export of the CtrlA Tech Solutions
development database. It contains tables, sequences, defaults, indexes, unique
constraints, and foreign keys. It does **not** contain any rows or passwords.

## Apply in another Replit account

1. Import the complete project into the new Replit account.
2. Provision the new Replit PostgreSQL database.
3. Open the Shell in the new Repl.
4. Run:

   ```bash
   psql "$DATABASE_URL" -f database/schema.sql
   ```

5. Start the API server. It will seed the initial admin account and default
   website content when the new database is empty.

If the new database is already empty and the project's dependencies are
installed, the project schema can also be created from the Drizzle definitions:

```bash
pnpm --filter @workspace/db run push
```

Use only one of these methods on a fresh database. The SQL export is useful
when an exact portable copy of the current structure is needed.

## Included tables

- `admin_users`
- `pages`
- `page_content_blocks`
- `menu_items`
- `blog_categories`
- `blog_posts`
- `media`
- `contact_inquiries`
- `site_settings`
- `portfolio`
- `hero_slides`
- `product_items`
- `services`
- `industries`
- `campaigns`
- `campaign_recipients`
- `usage_events`
- `jobs`
- `job_applications`
- `clients`

Uploaded files are stored separately in object storage and are not included in
this database structure export. Reconfigure the new Repl's object-storage
secrets and copy media files separately if they need to remain available.